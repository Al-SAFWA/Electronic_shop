import test from "node:test";
import assert from "node:assert/strict";
import { createCatalogRepo } from "../assets/js/data/repositories/catalog.repo.js";
import { productToRow } from "../assets/js/domain/catalog-mappers.js";

/* Mock PostgREST: records every call so we can assert the write sequence. */
function mockRequest(responses = {}) {
  const calls = [];
  const fn = async (path, options = {}, auth = false) => {
    calls.push({ path, method: options.method || "GET", auth, body: options.body ? JSON.parse(options.body) : null, headers: options.headers || {} });
    for (const [prefix, value] of Object.entries(responses)) if (path.startsWith(prefix)) return typeof value === "function" ? value(path) : value;
    return [];
  };
  return { fn, calls };
}

test("upsertProduct writes product, replaces variants and collection links, bumps meta — all with staff auth", async () => {
  const { fn, calls } = mockRequest({ "/rest/v1/restore_collections?select=id,handle": [{ id: "iphone", handle: "iphone" }, { id: "deals", handle: "deals" }] });
  const repo = createCatalogRepo(fn);
  const mapped = productToRow({ handle: "p1", title: { ar: "a", fr: "b" }, price: 100, stock: 1, variants: [{ sku: "S1", price: 120, stock: 1 }], collections: ["deals", "iphone"] });
  await repo.upsertProduct(mapped);
  const seq = calls.map((c) => `${c.method} ${c.path.split("?")[0]}`);
  assert.deepEqual(seq, [
    "POST /rest/v1/restore_products",
    "DELETE /rest/v1/restore_product_variants",
    "POST /rest/v1/restore_product_variants",
    "DELETE /rest/v1/restore_collection_products",
    "GET /rest/v1/restore_collections",
    "POST /rest/v1/restore_collection_products",
    "POST /rest/v1/restore_catalog_meta"
  ]);
  assert.ok(calls.every((c) => c.auth === true), "every catalog write must use the staff token");
  assert.match(calls[0].headers.Prefer, /merge-duplicates/);
  assert.equal(calls[2].body[0].price_delta, 20);
  const links = calls[5].body;
  assert.deepEqual(links.map((l) => [l.collection_id, l.sort_order]).sort(), [["deals", 0], ["iphone", 1]]);
});

test("listProducts (public) uses anon, listProducts({staff}) uses token; nested select is requested", async () => {
  const { fn, calls } = mockRequest({ "/rest/v1/restore_products": [{ id: "p", handle: "p", restore_product_variants: [], restore_collection_products: [{ sort_order: 1, restore_collections: { handle: "b" } }, { sort_order: 0, restore_collections: { handle: "a" } }] }] });
  const repo = createCatalogRepo(fn);
  const pub = await repo.listProducts();
  assert.equal(calls[0].auth, false);
  assert.match(calls[0].path, /select=\*,restore_product_variants\(\*\),restore_collection_products/);
  assert.deepEqual(pub[0].collectionHandles, ["a", "b"]);
  await repo.listProducts({ staff: true });
  assert.equal(calls[1].auth, true);
});

test("deleteCoupon targets the code primary key and bumps meta", async () => {
  const { fn, calls } = mockRequest();
  await createCatalogRepo(fn).deleteCoupon("RESTORE10");
  assert.equal(calls[0].method, "DELETE");
  assert.equal(calls[0].path, "/rest/v1/restore_coupons?code=eq.RESTORE10");
  assert.equal(calls[1].path, "/rest/v1/restore_catalog_meta");
});
