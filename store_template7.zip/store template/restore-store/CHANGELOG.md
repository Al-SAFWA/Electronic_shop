# Changelog

## 1.1.0 — Catalog source of truth (relational tables)
### Data / Architecture
- **Single source of truth for products, collections and coupons.** In Supabase mode the dashboard now reads and writes
  `restore_products` / `restore_product_variants` / `restore_collection_products` / `restore_collections` / `restore_coupons`
  through `assets/js/data/repositories/catalog.repo.js`. `publish()` no longer writes these entities into `restore_state.data`
  (they are stripped; the JSON state keeps only theme/settings/pages). `restore_create_order_v2` and the dashboard therefore
  read the same rows — the dual-source bug (JSON vs tables) is gone.
- New pure mappers `assets/js/domain/catalog-mappers.js` (object ↔ row, validation, bulk price rule) shared by the dashboard,
  the storefront loader and `scripts/migrate-state-to-tables.mjs` (rewritten to reuse them).
- New migration `supabase/migrations/0003_catalog_source_of_truth.sql`: `extra jsonb` / `sku` / `sort_order` columns,
  public read of active coupons (checkout preview), `restore_catalog_meta` change marker, `restore_products_with_collections` view.
- `state.js` exposes `R.catalog` (`enabled`, `source`, `saveProduct`, `deleteProduct`, `setProductActive`, `bulkPrice`,
  `saveCollection`, `saveCoupon`, `deleteCoupon`, `importFromState`, `reload`). The storefront overlays the tables onto
  `state.products/collections/settings.coupons` at load and polls `restore_catalog_meta.version` for changes.
- Dashboard: products / collections / coupons views show the active data source; every write goes through the repository with
  an audit entry. If the tables are empty (migration not applied yet) a one-click **"Import catalog to tables"** button appears
  and the legacy draft flow keeps working until then. Local demo mode is unchanged.
- Tests: `tests/catalog-mappers.test.mjs` (round-trips, validation) and `tests/catalog-repo.test.mjs` (write sequence against a
  mock PostgREST, staff-token enforcement). `npm test` → 15 tests.

### Upgrade
1. Apply `0003_catalog_source_of_truth.sql` in the Supabase SQL editor (after 0002).
2. Open the dashboard → Products → click **Import catalog to tables** (or run `APPLY=1 node scripts/migrate-state-to-tables.mjs`).
3. Publish once so `restore_state.data` is rewritten without products/collections/coupons.

## 1.0.0
### Security
- Removed shipped demo passwords; local demo is explicit opt-in on localhost and first-login password is user-chosen (PBKDF2 hash).
- Hardened Supabase RLS/grants: staff-scoped policies, abandoned carts insert-only for public, direct public order inserts disabled by default.
- Added server-side order validation path (`create-order` Edge Function + atomic `restore_create_order` RPC) with stock decrement and fail-closed client behavior in remote mode.
- `create-order` is fail-closed in production when Turnstile is not configured; added shared rate-limit RPC/table (`restore_rate_limits`, `restore_rate_hit`) and origin restrictions.
- Staff session metadata moved to `sessionStorage`; access/refresh tokens are memory-only (never persisted). Added 2-minute pre-expiry refresh and 30-minute dashboard idle logout.
- Tightened CSP: `script-src` has no `unsafe-eval`/`unsafe-inline`; added local vendored DOMPurify 3.2.6 (MPL-2.0/Apache-2.0) wrapper for `sanitizeRichHTML`.
- Removed leaked local deployment/env artifacts (`.env.local`, `.vercel/project.json`), strengthened `.gitignore`, and added `scripts/check-secrets.sh` + `.githooks/pre-commit`. `.zip` files ignored.

### Architecture / Data
- Added additive ES module foundation (`assets/js/core`, `i18n`, `domain`, `data`) and domain tests (pricing/order/cart) runnable via `npm test`.
- Added `supabase/migrations/0002_relational.sql` (relational catalog/orders/coupons draft, reporting views, atomic relational order RPC) and `scripts/migrate-state-to-tables.mjs` (dry-run by default).
- Kept legacy `state.js`/`app.js`/`dashboard.js` entrypoints working for compatibility.

### Docs
- Added `SECURITY.md`, updated `LEGAL.md` (DOMPurify), and updated `README.md`/`supabase/README.md`.
