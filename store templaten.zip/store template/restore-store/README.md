# Restore — متجر إلكترونيات مجددة في موريتانيا

Restore is a complete, bilingual (Arabic / French) electronics storefront and admin
dashboard for Nouakchott, Mauritania. It is a static site: no framework, no build step
required for local use, and deployable on Vercel. Checkout sends the full order to
WhatsApp; the dashboard publishes content, products, prices and theme changes without a
redeploy.

## What is included

- **Storefront:** home, collections, product pages, wishlist, account, checkout, blog,
  CMS pages, order tracking and warranty-request links. Arabic is the default, with RTL,
  Mauritania flag and light/dark mode. French switches the whole site to LTR.
- **Local payments:** Bankily, Masrvi, Sedad, Click and cash on delivery. Bankily carries
  the configurable 10% promotion. There is no online card charge on the site.
- **Checkout:** customer name, phone, city, address, notes, payment method, coupon code,
  automatic shipping fees, stock checks, abandoned-cart capture and a complete WhatsApp
  order message.
- **Products:** 137 imported demo products, 11 collections, variants, color-specific
  images, battery health, condition, storage, CPU/RAM/screen/keyboard specs, included
  items, FAQs, reviews, related products, stock and low-stock hiding.
- **Dashboard:** overview, orders (status, filters, invoice, shipping label, CSV export),
  abandoned carts, products and bulk pricing, categories, collections, bilingual content,
  navigation, footer, trust bar, homepage sections and hero slides, appearance and colors,
  fonts, marketing coupons and countdown offers, reviews, blog, pages and FAQs, payment
  methods and cities, team accounts, reports, SEO, pixels, store hours, maintenance mode,
  blocklist/rate limits, audit log, forced first-password change, preview and publish.
- **PWA:** installable manifest and service worker with an offline shell.
- **Storage modes:** local-first demo (`localStorage`) with optional Supabase REST sync.
  Supabase is not required to explore the dashboard.

## Run locally

```bash
cd restore-store
python3 -m http.server 8100 --bind 127.0.0.1
```

Open <http://127.0.0.1:8100/>. The dashboard is at
<http://127.0.0.1:8100/dashboard.html>.

### Local demo (development only)

The storefront and dashboard can run locally without Supabase. **Demo staff accounts
are disabled by default** and are not shipped with passwords.

To enable local demo on `localhost` only:

1. Set `"demoEnabled": true` in `assets/js/config.js` (keep it `false` in production).
2. Open the dashboard and sign in as `owner` or `manager`.
3. On first local demo login, enter a **new password you choose** (8+ chars, letters + numbers).
   The password is stored only as a local PBKDF2 hash in your browser.

For production, use Supabase Auth + the `restore_staff` table and the
`admin-create-staff` Edge Function. Never enable demo mode on a public deployment.

The dashboard asks for the store WhatsApp number. The default number is a placeholder:
`+222 46 00 00 00` (`22246000000`). Replace it before accepting real orders.

Use the dashboard **Publish** button after edits. Until publishing, changes remain in
`restore_draft_v1` and are visible only in preview. Publishing writes `restore_state_v1`
and notifies other open tabs immediately.

To reset local demo data, open **Settings → متقدم → إعادة تعيين البيانات المحلية**.

## Deploy to Vercel

1. Push this directory to a Git repository.
2. Import it into Vercel as an **Other** project.
3. Vercel runs `node scripts/build-config.mjs`; add these environment variables if you
   want Supabase:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY` (the public anon/publishable key only)
4. Deploy. The site works in demo mode when the variables are absent.
5. Add your custom domain in Vercel and update the dashboard SEO base URL.

`vercel.json` configures cache headers, security headers and the build command. Service
workers require HTTPS in production.

### Supabase

See [`supabase/README.md`](supabase/README.md) and run
[`supabase/schema.sql`](supabase/schema.sql) in the Supabase SQL editor. It creates the
state, order, abandoned-cart and audit tables, RLS policies and the public
`restore-media` bucket.

The dashboard uploads images to Supabase Storage when remote mode is active. In local
mode images are resized and stored as data URLs inside the local draft/state.

> The anon key is public by design. Never put a `service_role` key in this repository.
> Disable public sign-ups so only staff accounts can write. For a high-traffic shop,
> put order inserts behind an Edge Function / CAPTCHA.

## Editing content

All storefront content lives in dashboard state, not in the HTML. The defaults are in
`assets/js/state.js`; the imported product catalog is in `assets/js/data.js`. Categories,
products, copy, images, colors, fonts, menus, banners, coupons, pages, FAQs and reviews
are editable from the dashboard after login. Product/section changes propagate to all
pages through shared state.

### URLs

- `collection.html?handle=<handle>` or `collection.html?q=<search>`
- `product.html?handle=<handle>`
- `page.html?slug=<slug>`
- `blog-post.html?slug=<slug>`

## File map

```
index.html, collection.html, product.html, checkout.html, wishlist.html,
account.html, blog.html, blog-post.html, page.html, dashboard.html
assets/css/styles.css      base layout and legacy component styles
assets/css/restore.css     Restore theme, RTL/LTR, dark mode, responsive rules
assets/css/dashboard.css   admin dashboard
assets/js/config.js        Supabase/public settings (no secrets, no shipped passwords)
assets/js/data.js          imported demo catalog
assets/js/state.js         state, auth, pricing, orders, Supabase adapter, sanitizers
assets/js/app.js           storefront renderer and interactions
assets/js/dashboard.js     admin application
assets/img/                logos, flags, PWA icons, hero/promo art
assets/products/           catalog photography
supabase/schema.sql        database, RLS and storage setup
supabase/functions/create-order/index.ts        server-side order validation (deploy in Supabase)
supabase/functions/admin-create-staff/index.ts  owner-only staff provisioning
sw.js, manifest.webmanifest
scripts/build-config.mjs   Vercel environment injection
```

## Local storage keys

| Key | Contents |
| --- | --- |
| `restore_state_v1` | Published store state |
| `restore_draft_v1` | Unpublished dashboard changes |
| `restore_managers_v1` | Local staff accounts and password hashes |
| `restore_orders_v1` | Demo orders |
| `restore_abandoned_v1` | Abandoned carts |
| `restore_audit_v1` | Audit log |
| `restore_session_v1` | Current demo session |
| `restore_lang_v1` | `ar` or `fr` |
| `restore_theme_v1` | `light` or `dark` |
| `restore_cart_v1` | Cart items |
| `restore_wish_v1` | Wishlist handles |
| `restore_dash_lang_v1` | Dashboard language |

There is deliberately no JSON backup/restore feature. Orders can be exported as CSV from
the dashboard.

## Production checklist

- [ ] **Disable demo mode:** keep `demoEnabled:false` in `assets/js/config.js` for public deployments.
- [ ] **Supabase Auth for staff:** create staff via `admin-create-staff`; assign `app_metadata.role` (`owner`/`manager`).
- [ ] **Deploy server-side order validation:** deploy `supabase/functions/create-order` with `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` secrets. The app uses it when configured; without it, totals come from the client (not production-safe).
- [ ] **Run hardened RLS schema:** apply `supabase/schema.sql` (staff-scoped policies, no public abandoned-cart updates, least-privilege grants).
- [ ] **Never expose secrets:** only the anon/publishable key belongs in client config. Never commit `service_role`.
- [ ] **Review CSP:** `vercel.json` and HTML meta CSPs were tightened (no `unsafe-eval`), but `unsafe-inline` remains for compatibility; migrate to nonces/hashes when refactoring inline styles/scripts.
- [ ] **XSS hygiene:** user/CMS content is escaped in key rendering paths and a `sanitizeRichHTML` helper is available; review any new `innerHTML` sinks and sanitize rich HTML.
- [ ] **Service worker cache:** bump `CACHE` in `sw.js` after security/config changes.

## Notes and limitations

- Demo reviews, press quotes and customer names are fictional sample content.
- Product photography and catalog copy are prototype assets; confirm rights and replace
  with your own photos before a commercial launch.
- Local demo mode stores orders in the browser only. Configure Supabase for durable,
  multi-device orders.
- WhatsApp confirmation is manual, by design. Bankily/Masrvi/Sedad/Click are payment
  choices; actual transfer confirmation happens over WhatsApp. No card data is collected.
- **Architecture:** this is a static client app. Server-side validation (Edge Functions),
  strict RBAC, and atomic inventory/pricing are required for a high-trust production store.
- The placeholder email is `hello@restore.mr`; update it with your real contact details.
