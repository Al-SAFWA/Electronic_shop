import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function num(v: unknown, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );
    const body = await req.json();
    const draft = body?.order && typeof body.order === "object" ? body.order : body;
    const itemsIn = Array.isArray(draft?.items) ? draft.items : [];
    if (!itemsIn.length) throw new Error("Order items are required");

    const { data: stateRow, error: stateErr } = await supabase
      .from("restore_state")
      .select("data")
      .eq("id", "main")
      .maybeSingle();
    if (stateErr) throw stateErr;
    const state = stateRow?.data && typeof stateRow.data === "object" ? stateRow.data : {};
    const settings = state.settings && typeof state.settings === "object" ? state.settings : {};
    if (settings.open === false) throw new Error("Store is closed");

    const products = new Map<string, any>((Array.isArray(state.products) ? state.products : []).map((p: any) => [String(p?.handle || ""), p]));
    const cities = Array.isArray(settings.cities) ? settings.cities : [];
    const payments = (Array.isArray(settings.payments) ? settings.payments : []).filter((p: any) => p?.active !== false);
    const coupons = Array.isArray(settings.coupons) ? settings.coupons : [];

    let subtotal = 0;
    const items = [];
    for (const raw of itemsIn) {
      const handle = String(raw?.handle || "");
      const product = products.get(handle);
      if (!product) throw new Error(`Unknown product: ${handle}`);
      const qty = Math.max(1, Math.min(20, Math.floor(num(raw?.qty, 1))));
      const stock = Math.max(0, Math.floor(num(product.stock, 0)));
      if (product.hideWhenOOS && stock < 1) throw new Error(`Out of stock: ${handle}`);
      if (stock > 0 && qty > stock) throw new Error(`Insufficient stock: ${handle}`);
      const variants = Array.isArray(product.variants) ? product.variants : [];
      const variant = variants.find((v: any) => String(v?.id || "") === String(raw?.variantId || "")) || null;
      const price = Math.max(0, Math.round(num(variant?.price ?? product.price, 0)));
      const line = price * qty;
      subtotal += line;
      items.push({
        handle,
        title: product.title,
        image: product.image,
        variantId: variant?.id || null,
        variantTitle: [variant?.label, variant?.color, variant?.storage].filter(Boolean).join(" / ") || "",
        qty,
        price,
        line,
      });
    }

    const city = cities.find((c: any) => String(c?.id || "") === String(draft?.customer?.cityId || draft?.cityId || "")) || null;
    const shipping = subtotal >= num(settings.freeShippingOver, 0) ? 0 : Math.max(0, Math.round(num(city?.fee, 0)));
    const payment = payments.find((p: any) => String(p?.id || "") === String(draft?.payment?.id || draft?.paymentId || "")) || payments[0] || null;
    if (!payment) throw new Error("No active payment method");
    const paymentDiscount = Math.round(subtotal * Math.max(0, num(payment.discount, 0)) / 100);

    const code = String(draft?.coupon || draft?.couponCode || "").trim().toUpperCase();
    let couponDiscount = 0;
    let appliedCoupon = "";
    if (code) {
      const coupon = coupons.find((c: any) => c?.active !== false && String(c?.code || "").toUpperCase() === code);
      const expired = coupon?.expiresAt && Date.parse(String(coupon.expiresAt)) < Date.now();
      if (coupon && !expired && subtotal >= num(coupon.minTotal, 0)) {
        appliedCoupon = String(coupon.code).toUpperCase();
        couponDiscount = coupon.type === "percent"
          ? Math.round(subtotal * Math.max(0, num(coupon.value, 0)) / 100)
          : Math.max(0, Math.round(num(coupon.value, 0)));
      }
    }

    const discount = Math.min(subtotal, paymentDiscount + couponDiscount);
    const total = Math.max(0, subtotal + shipping - discount);
    const id = String(draft?.id || "").trim() || `RS-${Date.now().toString(36).toUpperCase()}`;
    const now = new Date().toISOString();
    const safeOrder = {
      id,
      createdAt: now,
      updatedAt: now,
      status: "new",
      source: "secure-checkout",
      lang: String(draft?.lang || "ar").slice(0, 5),
      customer: {
        name: String(draft?.customer?.name || "").trim().slice(0, 120),
        phone: String(draft?.customer?.phone || "").trim().slice(0, 40),
        email: String(draft?.customer?.email || "").trim().slice(0, 120),
        city: String(city?.name?.ar || city?.name?.fr || draft?.customer?.city || "").slice(0, 80),
        cityId: city?.id || null,
        address: String(draft?.customer?.address || "").trim().slice(0, 300),
        notes: String(draft?.customer?.notes || "").trim().slice(0, 500),
      },
      items,
      subtotal,
      shipping,
      paymentDiscount,
      couponDiscount,
      coupon: appliedCoupon,
      discount,
      total,
      payment: { id: payment.id, name: payment.name, discount: num(payment.discount, 0) },
      currency: "MRU",
      serverValidated: true,
    };

    const { error: insertErr } = await supabase.from("restore_orders").insert({
      id: safeOrder.id,
      data: safeOrder,
      status: safeOrder.status,
      created_at: safeOrder.createdAt,
      updated_at: safeOrder.updatedAt,
    });
    if (insertErr) throw insertErr;

    return new Response(JSON.stringify({ ok: true, order: safeOrder }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String((e as any)?.message || e) }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
