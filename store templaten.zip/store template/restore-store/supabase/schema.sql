-- Restore store - Supabase schema, row level security and media bucket.
-- Run this once in the Supabase SQL editor (Project > SQL Editor > New query).
-- The dashboard/static app uses the publishable/anon key only. NEVER put the
-- service_role key in client code, config.js, or this repository.
--
-- Production security model:
--   * Staff access is granted by is_staff()/is_owner() via JWT app_metadata.role.
--   * Store/order totals should be validated server-side by the create-order
--     Edge Function (supabase/functions/create-order). Direct anon order insert
--     remains available for compatibility, but treat client-calculated totals as
--     untrusted until server validation is deployed.
--   * Public abandoned-cart writes are insert-only; do not allow anon updates.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Helper functions for role checks
-- ---------------------------------------------------------------------------
create or replace function public.is_staff()
returns boolean language sql stable as $$
  select coalesce(
    (auth.jwt() -> 'app_metadata' ->> 'role') in ('owner', 'manager'),
    false
  );
$$;

create or replace function public.is_owner()
returns boolean language sql stable as $$
  select coalesce(
    (auth.jwt() -> 'app_metadata' ->> 'role') = 'owner',
    false
  );
$$;

create or replace function public.restore_set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- Tables (order matters: customers/staff before tables referencing them)
-- ---------------------------------------------------------------------------
create table if not exists public.restore_staff (
  id uuid primary key default gen_random_uuid(),
  auth_id uuid unique not null references auth.users(id) on delete cascade,
  username text unique not null,
  email text not null,
  name jsonb not null default '{}'::jsonb, -- {ar: "", fr: ""}
  role text not null default 'manager' check (role in ('owner', 'manager')),
  whatsapp text,
  avatar text,
  active boolean not null default true,
  must_change_password boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_staff_auth_idx on public.restore_staff (auth_id);
create index if not exists restore_staff_username_idx on public.restore_staff (username);

-- Customers are for profile/wishlist/address metadata linked to Supabase Auth.
-- Do NOT store customer passwords here; use Supabase Auth.
create table if not exists public.restore_customers (
  id uuid primary key default gen_random_uuid(),
  auth_id uuid unique references auth.users(id) on delete set null,
  name text,
  phone text,
  email text,
  addresses jsonb default '[]'::jsonb,
  wishlist jsonb default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_customers_auth_idx on public.restore_customers (auth_id);
create index if not exists restore_customers_phone_idx on public.restore_customers (phone);

create table if not exists public.restore_state (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.restore_orders (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  status text not null default 'new',
  customer_id uuid references public.restore_customers(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_orders_created_idx on public.restore_orders (created_at desc);
create index if not exists restore_orders_status_idx on public.restore_orders (status);
create index if not exists restore_orders_customer_idx on public.restore_orders (customer_id);

create table if not exists public.restore_abandoned (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  cart_token text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_abandoned_created_idx on public.restore_abandoned (created_at desc);

create table if not exists public.restore_audit (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists restore_audit_created_idx on public.restore_audit (created_at desc);

-- Reviews/Comments (with moderation)
create table if not exists public.restore_reviews (
  id uuid primary key default gen_random_uuid(),
  product_handle text not null,
  customer_id uuid references public.restore_customers(id) on delete set null,
  customer_name text,
  rating int not null check (rating >= 1 and rating <= 5),
  title text,
  body text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_reviews_product_idx on public.restore_reviews (product_handle);
create index if not exists restore_reviews_status_idx on public.restore_reviews (status);
create index if not exists restore_reviews_customer_idx on public.restore_reviews (customer_id);

-- Custom Pages
create table if not exists public.restore_pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title jsonb not null, -- {ar: "", fr: ""}
  body jsonb not null,  -- {ar: "", fr: ""}
  seo_title jsonb,
  seo_description jsonb,
  visible boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_pages_slug_idx on public.restore_pages (slug);

-- Safe additive migrations for existing installations.
alter table public.restore_abandoned add column if not exists cart_token text;
alter table public.restore_abandoned add column if not exists updated_at timestamptz not null default now();
-- Legacy/insecure local-auth column; keep only if you have a controlled migration:
-- alter table public.restore_customers drop column if exists password_hash;

drop trigger if exists restore_orders_touch on public.restore_orders;
create trigger restore_orders_touch before update on public.restore_orders
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_abandoned_touch on public.restore_abandoned;
create trigger restore_abandoned_touch before update on public.restore_abandoned
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_state_touch on public.restore_state;
create trigger restore_state_touch before update on public.restore_state
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_customers_touch on public.restore_customers;
create trigger restore_customers_touch before update on public.restore_customers
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_reviews_touch on public.restore_reviews;
create trigger restore_reviews_touch before update on public.restore_reviews
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_pages_touch on public.restore_pages;
create trigger restore_pages_touch before update on public.restore_pages
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_staff_touch on public.restore_staff;
create trigger restore_staff_touch before update on public.restore_staff
for each row execute function public.restore_set_updated_at();

-- ---------------------------------------------------------------------------
-- Row level security
-- ---------------------------------------------------------------------------
alter table public.restore_state enable row level security;
alter table public.restore_orders enable row level security;
alter table public.restore_abandoned enable row level security;
alter table public.restore_audit enable row level security;
alter table public.restore_staff enable row level security;
alter table public.restore_customers enable row level security;
alter table public.restore_reviews enable row level security;
alter table public.restore_pages enable row level security;

-- Storefront visitors can read the published state but cannot change it.
drop policy if exists restore_state_public_read on public.restore_state;
create policy restore_state_public_read on public.restore_state
  for select to anon, authenticated using (true);

drop policy if exists restore_state_staff_write on public.restore_state;
create policy restore_state_staff_write on public.restore_state
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Orders
-- Public checkout insert is allowed for compatibility. Deploy create-order Edge
-- Function and prefer it; client-submitted totals are not trustworthy by themselves.
drop policy if exists restore_orders_customer_insert on public.restore_orders;
create policy restore_orders_customer_insert on public.restore_orders
  for insert to anon, authenticated
  with check (char_length(id) between 3 and 120 and jsonb_typeof(data) = 'object');

-- Customers can read their own orders
drop policy if exists restore_orders_customer_read on public.restore_orders;
create policy restore_orders_customer_read on public.restore_orders
  for select to authenticated
  using (
    customer_id = (select id from public.restore_customers where auth_id = auth.uid())
  );

-- Staff can read/update all orders
drop policy if exists restore_orders_staff_all on public.restore_orders;
create policy restore_orders_staff_all on public.restore_orders
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Abandoned carts: public insert only. No public select/update/delete.
-- Staff manage through authenticated policies / dashboard.
drop policy if exists restore_abandoned_public_insert on public.restore_abandoned;
create policy restore_abandoned_public_insert on public.restore_abandoned
  for insert to anon
  with check (char_length(id) between 3 and 120 and jsonb_typeof(data) = 'object');

drop policy if exists restore_abandoned_public_update on public.restore_abandoned;
-- Intentionally removed: anon updates exposed other customers' carts.

drop policy if exists restore_abandoned_staff_all on public.restore_abandoned;
create policy restore_abandoned_staff_all on public.restore_abandoned
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Audit logs - only staff can read/write
drop policy if exists restore_audit_staff_all on public.restore_audit;
create policy restore_audit_staff_all on public.restore_audit
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Staff - can read own profile, owner can manage all staff
drop policy if exists restore_staff_own_read on public.restore_staff;
create policy restore_staff_own_read on public.restore_staff
  for select to authenticated
  using (auth_id = auth.uid() or public.is_owner());

drop policy if exists restore_staff_own_update on public.restore_staff;
create policy restore_staff_own_update on public.restore_staff
  for update to authenticated
  using (auth_id = auth.uid()) with check (auth_id = auth.uid());

drop policy if exists restore_staff_owner_all on public.restore_staff;
create policy restore_staff_owner_all on public.restore_staff
  for all to authenticated using (public.is_owner()) with check (public.is_owner());

-- Customers - can read/write own data, staff can read all
drop policy if exists restore_customers_own_read on public.restore_customers;
create policy restore_customers_own_read on public.restore_customers
  for select to authenticated using (auth_id = auth.uid() or public.is_staff());

drop policy if exists restore_customers_own_insert on public.restore_customers;
create policy restore_customers_own_insert on public.restore_customers
  for insert to authenticated with check (auth_id = auth.uid() or public.is_staff());

drop policy if exists restore_customers_own_update on public.restore_customers;
create policy restore_customers_own_update on public.restore_customers
  for update to authenticated using (auth_id = auth.uid()) with check (auth_id = auth.uid());

drop policy if exists restore_customers_staff_all on public.restore_customers;
create policy restore_customers_staff_all on public.restore_customers
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Reviews - public can read approved, customers can create/read own, staff moderate all
drop policy if exists restore_reviews_public_read on public.restore_reviews;
create policy restore_reviews_public_read on public.restore_reviews
  for select to anon, authenticated using (status = 'approved');

drop policy if exists restore_reviews_customer_create on public.restore_reviews;
create policy restore_reviews_customer_create on public.restore_reviews
  for insert to authenticated
  with check (customer_id = (select id from public.restore_customers where auth_id = auth.uid()));

drop policy if exists restore_reviews_customer_read_own on public.restore_reviews;
create policy restore_reviews_customer_read_own on public.restore_reviews
  for select to authenticated
  using (customer_id = (select id from public.restore_customers where auth_id = auth.uid()));

drop policy if exists restore_reviews_staff_all on public.restore_reviews;
create policy restore_reviews_staff_all on public.restore_reviews
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Pages - public read visible, staff manage all
drop policy if exists restore_pages_public_read on public.restore_pages;
create policy restore_pages_public_read on public.restore_pages
  for select to anon, authenticated using (visible = true);

drop policy if exists restore_pages_staff_all on public.restore_pages;
create policy restore_pages_staff_all on public.restore_pages
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- ---------------------------------------------------------------------------
-- Media bucket (public read, staff upload)
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'restore-media',
  'restore-media',
  true,
  5242880,
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists restore_media_public_read on storage.objects;
create policy restore_media_public_read on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'restore-media');

drop policy if exists restore_media_staff_insert on storage.objects;
create policy restore_media_staff_insert on storage.objects
  for insert to authenticated
  with check (bucket_id = 'restore-media' and public.is_staff());

drop policy if exists restore_media_staff_update on storage.objects;
create policy restore_media_staff_update on storage.objects
  for update to authenticated
  using (bucket_id = 'restore-media' and public.is_staff())
  with check (bucket_id = 'restore-media' and public.is_staff());

drop policy if exists restore_media_staff_delete on storage.objects;
create policy restore_media_staff_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'restore-media' and public.is_staff());

-- ---------------------------------------------------------------------------
-- Explicit grants (least privilege; RLS still applies)
-- ---------------------------------------------------------------------------
grant usage on schema public to anon, authenticated;

grant select on public.restore_state to anon, authenticated;
grant select on public.restore_reviews to anon, authenticated;
grant select on public.restore_pages to anon, authenticated;

grant insert on public.restore_orders to anon, authenticated;
grant insert on public.restore_abandoned to anon;

grant select, insert, update, delete on public.restore_state to authenticated;
grant select, insert, update, delete on public.restore_orders to authenticated;
grant select, insert, update, delete on public.restore_abandoned to authenticated;
grant select, insert, update, delete on public.restore_audit to authenticated;
grant select, insert, update, delete on public.restore_staff to authenticated;
grant select, insert, update, delete on public.restore_customers to authenticated;
grant select, insert, update, delete on public.restore_reviews to authenticated;
grant select, insert, update, delete on public.restore_pages to authenticated;
