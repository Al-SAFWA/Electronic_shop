/* ==========================================================================
   Restore — shared store state, local/Supabase sync, language and utilities
   ========================================================================== */
(() => {
  "use strict";

  const RAW = window.STORE;
  if (!RAW) return;

  const CFG = Object.assign({
    supabaseUrl: "",
    supabaseAnonKey: "",
    mode: "auto",
    demoEnabled: false,
    createOrderFunction: "create-order",
    stateTable: "restore_state",
    ordersTable: "restore_orders",
    abandonedTable: "restore_abandoned",
    auditTable: "restore_audit",
    customersTable: "restore_customers",
    reviewsTable: "restore_reviews",
    pagesTable: "restore_pages",
    staffTable: "restore_staff",
    mediaBucket: "restore-media",
    createStaffFunction: "admin-create-staff",
    pollMs: 5000
  }, window.RESTORE_CONFIG || {});

  const REMOTE = CFG.mode !== "local" && Boolean(CFG.supabaseUrl && CFG.supabaseAnonKey);
  const LOCAL_DEV = /^(localhost|127\.0\.0\.1|\[::1\])$/i.test(location.hostname || "");
  const DEMO_ALLOWED = !REMOTE && CFG.demoEnabled === true && LOCAL_DEV;
  const LS_STATE = "restore_state_v1";
  const LS_DRAFT = "restore_draft_v1";
  const LS_MANAGERS = "restore_managers_v2";
  const LS_ORDERS = "restore_orders_v1";
  const LS_ABANDONED = "restore_abandoned_v1";
  const LS_AUDIT = "restore_audit_v1";
  const LS_SESSION = "restore_session_v1";
  const LS_CUSTOMER = "restore_customer_v1";
  const LS_CUSTOMERS = "restore_customers_v1";
  const LS_CUSTOMER_SESSION = "restore_customer_session_v1";
  const LS_REVIEWS = "restore_reviews_v1";
  const LS_LOGIN_ATTEMPTS = "restore_login_attempts_v1";
  const LS_LANG = "restore_lang_v1";
  const LS_THEME = "restore_theme_v1";
  const SYNC_CHANNEL = "restore_sync_v1";
  const CURRENCY_RATE = 10.6;
  const SALT = "restore-salt:";
  const MAX_REMOTE_REVIEWS = 500;
  const MAX_WISHLIST = 200;

  const clone = (v) => JSON.parse(JSON.stringify(v));
  const nowISO = () => new Date().toISOString();
  const roundMRU = (n) => Math.max(0, Math.round((Number(n) || 0) * CURRENCY_RATE / 5) * 5);
  const uid = (prefix = "id") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }
  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.warn("Restore: storage write failed", err);
      return false;
    }
  }
  function isPlainObject(v) {
    return v && typeof v === "object" && !Array.isArray(v);
  }
  function merge(base, override) {
    if (Array.isArray(override)) return clone(override);
    if (!isPlainObject(override)) return override === undefined ? base : override;
    const out = isPlainObject(base) ? clone(base) : {};
    for (const [key, value] of Object.entries(override)) out[key] = merge(base?.[key], value);
    return out;
  }
  function escText(value) {
    return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function sanitizeRichHTML(html) {
    const template = document.createElement("template");
    template.innerHTML = String(html ?? "");
    const blocked = new Set(["script", "style", "iframe", "object", "embed", "link", "meta", "base", "form"]);
    template.content.querySelectorAll("*").forEach((el) => {
      const tag = el.tagName.toLowerCase();
      if (blocked.has(tag)) { el.remove(); return; }
      [...el.attributes].forEach((attr) => {
        const name = attr.name.toLowerCase();
        const value = String(attr.value || "").trim();
        if (name.startsWith("on")) { el.removeAttribute(attr.name); return; }
        if ((name === "href" || name === "src" || name === "xlink:href") && /^\s*(javascript|vbscript|data):/i.test(value) && !/^\s*data:image\//i.test(value)) {
          el.removeAttribute(attr.name);
        }
      });
      if (tag === "a") el.setAttribute("rel", "noopener noreferrer");
    });
    return template.innerHTML;
  }

  const txt = (ar, fr) => ({ ar, fr });
  const name = (ar, fr) => ({ ar, fr });

  /* ------------------------------------------------------------------------
     Default content
     ------------------------------------------------------------------------ */
  const TYPE_DESCRIPTIONS = {
    Smartphone: txt(
      "هاتف مجدد بالكامل، تم فحصه وتنظيفه واختباره من طرف خبراء ريستور. يعمل بكفاءة عالية ويأتي بضمان 12 شهرًا.",
      "Téléphone entièrement reconditionné, inspecté, nettoyé et testé par les experts Restore. Il fonctionne parfaitement et bénéficie d’une garantie de 12 mois."
    ),
    Laptop: txt(
      "حاسوب محمول مجدد تم اختباره مكونًا بمكون. يصلح للعمل والدراسة والاستخدام اليومي، مع ضمان 12 شهرًا.",
      "Ordinateur portable reconditionné, testé composant par composant. Idéal pour le travail, les études et l’usage quotidien, avec 12 mois de garantie."
    ),
    Macbook: txt(
      "MacBook مجدد مع macOS مثبت وجاهز للاستخدام. تم فحص البطارية ولوحة المفاتيح والمنافذ بواسطة خبراء ريستور.",
      "MacBook reconditionné avec macOS installé et prêt à l’emploi. Batterie, clavier et ports vérifiés par les experts Restore."
    ),
    Tablets: txt(
      "جهاز لوحي مجدد تم فحصه بالكامل، مناسب للقراءة والعمل والترفيه، ويأتي بضمان 12 شهرًا.",
      "Tablette reconditionnée entièrement vérifiée, idéale pour lire, travailler et se divertir, avec 12 mois de garantie."
    ),
    Playstation: txt(
      "جهاز ألعاب مجدد تم اختباره وتنظيفه، ويأتي مع ملحقاته الأساسية وضمان 12 شهرًا.",
      "Console de jeu reconditionnée, testée et nettoyée, livrée avec ses accessoires essentiels et 12 mois de garantie."
    ),
    "Apple Watch": txt(
      "ساعة Apple مجددة تم فحص البطارية والشاشة والحساسات، وتأتي بضمان 12 شهرًا.",
      "Apple Watch reconditionnée : batterie, écran et capteurs vérifiés, avec 12 mois de garantie."
    ),
    Accessories: txt(
      "ملحق أصلي مجدد أو جديد، تم فحصه لضمان التوافق والجودة.",
      "Accessoire d’origine reconditionné ou neuf, contrôlé pour garantir compatibilité et qualité."
    )
  };

  const DEFAULT_PAGES = [
    ["about-us", "من نحن", "À propos", "ريستور متجر موريتاني متخصص في الإلكترونيات المجددة. نشتري الأجهزة المستعملة، نفحصها ونعيد تأهيلها ثم نبيعها بأسعار عادلة مع ضمان واضح.\nنعمل من نواكشوط ونوصل إلى جميع ولايات موريتانيا.\nهدفنا أن يحصل كل شخص على تقنية موثوقة بدون أن يدفع ثمن جهاز جديد.", "Restore est une boutique mauritanienne spécialisée dans l’électronique reconditionnée. Nous rachetons, contrôlons et remettons en état les appareils avant de les revendre à un prix juste avec une garantie claire.\nNous travaillons depuis Nouakchott et livrons dans toutes les wilayas de Mauritanie.\nNotre objectif : rendre la technologie fiable accessible sans payer le prix du neuf."],
    ["help", "مركز المساعدة والأسئلة الشائعة", "Centre d’aide et FAQ", "تحتاج مساعدة؟ فريق ريستور متاح من الأحد إلى الخميس، من 9:00 إلى 19:00.\nراسلنا على واتساب أو اتصل على الرقم المؤقت +222 46 00 00 00.\nيمكنك أيضًا زيارة صفحة تتبع الطلب أو تقديم طلب ضمان.", "Besoin d’aide ? L’équipe Restore est disponible du dimanche au jeudi, de 9h00 à 19h00.\nÉcrivez-nous sur WhatsApp ou appelez le numéro temporaire +222 46 00 00 00.\nVous pouvez aussi suivre une commande ou ouvrir une demande de garantie."],
    ["contact", "اتصل بنا", "Contact", "العنوان: نواكشوط، موريتانيا\nواتساب: +222 46 00 00 00\nالبريد: hello@restore.mr\nساعات العمل: 9:00 صباحًا إلى 19:00 مساءً", "Adresse : Nouakchott, Mauritanie\nWhatsApp : +222 46 00 00 00\nE-mail : hello@restore.mr\nHoraires : 9h00 à 19h00"],
    ["terms", "الشروط والأحكام", "Conditions générales", "باستخدامك موقع ريستور فإنك توافق على شروط البيع هذه. الأسعار معروضة بالأوقية الجديدة وتشمل الضريبة حيث تنطبق.\nيتم تأكيد كل طلب عبر واتساب قبل الشحن. تحتفظ ريستور بحق إلغاء أي طلب إذا لم يتوفر المنتج أو إذا كانت المعلومات غير صحيحة.\nالصور توضيحية وقد يختلف لون الجهاز قليلًا.", "En utilisant le site Restore, vous acceptez les présentes conditions de vente. Les prix sont affichés en nouvelle ouguiya et incluent les taxes applicables.\nChaque commande est confirmée via WhatsApp avant expédition. Restore peut annuler une commande en cas de rupture de stock ou d’informations erronées.\nLes photos sont indicatives ; la teinte de l’appareil peut légèrement varier."],
    ["legal", "السياسة القانونية", "Mentions légales", "ريستور اسم تجاري لمتجر إلكترونيات مجدد في موريتانيا. جميع العلامات التجارية المذكورة مملوكة لأصحابها.\nمحتوى هذا الموقع وصوره وبياناته قابلة للتعديل من لوحة التحكم. يجب مراجعة النصوص القانونية مع مستشار مختص قبل الإطلاق التجاري.", "Restore est une enseigne d’électronique reconditionnée en Mauritanie. Toutes les marques citées appartiennent à leurs propriétaires.\nLe contenu, les images et les données du site peuvent être modifiés depuis le tableau de bord. Faites réviser les textes juridiques par un professionnel avant un lancement commercial."],
    ["privacy", "سياسة الخصوصية", "Politique de confidentialité", "نجمع فقط المعلومات اللازمة لمعالجة طلبك: الاسم، رقم الهاتف، المدينة والعنوان.\nتُرسل بيانات الطلب إلى واتساب المتجر. لا نبيع بياناتك لأي طرف ثالث.\nيمكنك طلب حذف بياناتك بمراسلتنا على hello@restore.mr.", "Nous collectons uniquement les informations nécessaires au traitement de votre commande : nom, téléphone, ville et adresse.\nLes données de commande sont envoyées au WhatsApp de la boutique. Nous ne vendons pas vos données à des tiers.\nVous pouvez demander leur suppression en écrivant à hello@restore.mr."],
    ["track-order", "تتبع طلبك", "Suivre votre commande", "بعد تأكيد الطلب عبر واتساب سنرسل لك رقم التتبع ورابط شركة الشحن.\nإذا لم يصلك أي تحديث خلال 24 ساعة، راسلنا على واتساب مع رقم الطلب.", "Après confirmation de la commande sur WhatsApp, nous vous envoyons le numéro de suivi et le lien du transporteur.\nSi vous n’avez aucune nouvelle sous 24 heures, écrivez-nous sur WhatsApp avec votre numéro de commande."],
    ["raise-claim", "تقديم طلب ضمان", "Ouvrir une demande de garantie", "كل جهاز مشمول بضمان 12 شهرًا يغطي عيوب التصنيع أو الأعطال غير الناتجة عن سوء الاستخدام.\nأرسل رقم الطلب، وصف العطل، وصورة أو فيديو قصير عبر واتساب.", "Chaque appareil bénéficie d’une garantie de 12 mois couvrant les défauts de fabrication ou les pannes non liées à un mauvais usage.\nEnvoyez le numéro de commande, une description du problème et une courte photo ou vidéo via WhatsApp."],
    ["track-claim", "متابعة طلب الضمان", "Suivi de garantie", "بعد فتح طلب الضمان ستحصل على رقم متابعة. مدة المعالجة المعتادة من 3 إلى 7 أيام عمل.\nراسل الدعم على واتساب إذا احتجت تحديثًا.", "Après l’ouverture d’une demande de garantie, vous recevez un numéro de suivi. Le délai habituel est de 3 à 7 jours ouvrés.\nContactez le support sur WhatsApp pour toute mise à jour."],
    ["blog", "مدونة ريستور", "Le blog Restore", "نصائح لاختيار هاتف مجدد، مقارنات بين الأجهزة، وطرق العناية بالبطارية.\nاقرأ أحدث المقالات من لوحة التحكم أو من قسم المدونة.", "Conseils pour choisir un téléphone reconditionné, comparatifs et astuces pour préserver la batterie.\nRetrouvez les derniers articles dans la section blog."],
    ["become-a-seller", "كن بائعًا معنا", "Devenir vendeur", "هل لديك أجهزة إلكترونية تريد بيعها؟ نشتري الهواتف والحواسيب والأجهزة اللوحية بعد فحصها.\nراسلنا على واتساب مع نوع الجهاز وحالته وصور له.", "Vous avez des appareils à revendre ? Nous rachetons téléphones, ordinateurs et tablettes après contrôle.\nContactez-nous sur WhatsApp avec le modèle, l’état et quelques photos."],
    ["for-businesses", "حلول للشركات", "Solutions entreprises", "نوفر أجهزة مجددة للشركات والمدارس والمنظمات بأسعار خاصة وضمان موحد.\nاطلب عرض سعر لكمية من 10 أجهزة أو أكثر.", "Nous fournissons des appareils reconditionnés aux entreprises, écoles et organisations à tarifs préférentiels avec une garantie unique.\nDemandez un devis pour 10 appareils ou plus."],
    ["renewed", "ما معنى مجدد من ريستور؟", "Que signifie reconditionné chez Restore ?", "الجهاز المجدد هو جهاز مستعمل تم فحصه وتنظيفه وإصلاح ما يلزم فيه ليعمل كجهاز جديد.\nنفحص الشاشة، البطارية، الكاميرا، الصوت، المنافذ والاتصال، ثم نمسح البيانات ونثبت النظام.\nكل جهاز يأتي بضمان 12 شهرًا، توصيل مجاني داخل نواكشوط، وإمكانية الإرجاع خلال 10 أيام.", "Un appareil reconditionné est un appareil d’occasion contrôlé, nettoyé et réparé si nécessaire pour fonctionner comme neuf.\nNous vérifions l’écran, la batterie, les caméras, le son, les ports et la connectivité, puis nous effaçons les données et installons le système.\nChaque appareil est livré avec 12 mois de garantie, la livraison gratuite à Nouakchott et un retour possible sous 10 jours."],
    ["shipping", "الشحن والتوصيل", "Livraison", "التوصيل مجاني داخل نواكشوط. إلى المدن الأخرى تُضاف رسوم حسب الولاية وتظهر عند إتمام الطلب.\nالطلبات المؤكدة قبل الساعة 16:00 تُجهز عادة في نفس اليوم، والتوصيل داخل نواكشوط من 1 إلى 2 يوم عمل.", "La livraison est gratuite à Nouakchott. Pour les autres villes, des frais selon la wilaya sont ajoutés et affichés au moment de la commande.\nLes commandes confirmées avant 16h00 sont généralement préparées le jour même ; la livraison à Nouakchott prend 1 à 2 jours ouvrés."],
    ["returns", "الإرجاع والضمان", "Retours et garantie", "لديك 10 أيام لاختبار الجهاز وإرجاعه إذا لم يعجبك، بشرط أن يكون في حالته الأصلية.\nالضمان 12 شهرًا يغطي الأعطال التقنية، ولا يغطي الكسر أو دخول الماء أو سوء الاستخدام.\nلبدء الإرجاع راسلنا على واتساب مع رقم الطلب.", "Vous disposez de 10 jours pour tester l’appareil et le retourner s’il ne vous convient pas, à condition qu’il soit dans son état d’origine.\nLa garantie de 12 mois couvre les pannes techniques, hors casse, dégâts d’eau ou mauvais usage.\nPour un retour, contactez-nous sur WhatsApp avec votre numéro de commande."]
  ].map(([slug, ar, fr, bodyAr, bodyFr]) => ({
    slug, title: name(ar, fr), body: txt(bodyAr, bodyFr), visible: true, seoTitle: name(ar, fr)
  }));

  const DEFAULT_FAQS = [
    { id: "faq-1", q: txt("هل الأجهزة جديدة أم مستعملة؟", "Les appareils sont-ils neufs ou d’occasion ?"), a: txt("الأجهزة مجددة: مستعملة، لكنها مفحوصة ومصلحة ومعاد تأهيلها لتكون جاهزة للاستخدام.", "Les appareils sont reconditionnés : d’occasion, mais contrôlés, réparés et remis en état pour être prêts à l’emploi.") },
    { id: "faq-2", q: txt("ما مدة الضمان؟", "Quelle est la durée de la garantie ?"), a: txt("كل جهاز يأتي بضمان 12 شهرًا يغطي الأعطال التقنية غير الناتجة عن سوء الاستخدام.", "Chaque appareil bénéficie de 12 mois de garantie couvrant les pannes techniques hors mauvais usage.") },
    { id: "faq-3", q: txt("هل يمكنني الإرجاع؟", "Puis-je retourner l’appareil ?"), a: txt("نعم، لديك 10 أيام لإرجاع الجهاز في حالته الأصلية إذا لم يعجبك.", "Oui, vous avez 10 jours pour retourner l’appareil dans son état d’origine s’il ne vous convient pas.") },
    { id: "faq-4", q: txt("هل التوصيل مجاني؟", "La livraison est-elle gratuite ?"), a: txt("التوصيل مجاني داخل نواكشوط. المدن الأخرى لها رسوم تظهر عند إتمام الطلب.", "La livraison est gratuite à Nouakchott. Les autres villes ont des frais affichés lors de la commande.") },
    { id: "faq-5", q: txt("كيف أدفع؟", "Comment payer ?"), a: txt("يمكنك الدفع عبر بنكيلي، مصرفي، سداد، كليك أو نقدًا عند الاستلام. الدفع عبر بنكيلي يمنحك خصمًا 10%.", "Vous pouvez payer via Bankily, Masrvi, Sedad, Click ou en espèces à la livraison. Le paiement Bankily offre 10 % de réduction.") },
    { id: "faq-6", q: txt("هل البطارية أصلية؟", "La batterie est-elle d’origine ?"), a: txt("نفحص صحة البطارية ونعرض النسبة على صفحة المنتج. البطاريات المستبدلة تكون معتمدة ومضمونة.", "Nous contrôlons la santé de la batterie et affichons le pourcentage sur la fiche produit. Les batteries remplacées sont certifiées et garanties.") }
  ];

  const DEFAULT_HOME_REVIEWS = [
    { id: "r1", name: "أحمد ولد محمد", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("جهاز نظيف وخدمة سريعة", "Appareil impeccable et service rapide"), body: txt("وصلني الآيفون في حالة ممتازة، البطارية 96% والدفع عبر بنكيلي كان سهلًا.", "J’ai reçu l’iPhone en excellent état, batterie à 96 %, et le paiement Bankily était simple."), color: "#2e7d6f" },
    { id: "r2", name: "مريم بنت أحمد", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("أفضل تجربة شراء", "Ma meilleure expérience d’achat"), body: txt("طلبت ماك بوك للدراسة، وصل بسرعة ومع macOS مثبت. أنصح به بشدة.", "J’ai commandé un MacBook pour mes études, livré rapidement avec macOS installé. Je recommande."), color: "#6c5ce7" },
    { id: "r3", name: "الشيخ ولد سيدي", city: txt("نواذيبو", "Nouadhibou"), rating: 4, title: txt("قيمة ممتازة", "Excellent rapport qualité-prix"), body: txt("اللابتوب يعمل بشكل جيد جدًا، والتوصيل إلى نواذيبو أخذ يومين.", "Le laptop fonctionne très bien, la livraison à Nouadhibou a pris deux jours."), color: "#b06ab3" },
    { id: "r4", name: "فاطمة بنت عبد الله", city: txt("كيفة", "Kiffa"), rating: 5, title: txt("ثقة وشفافية", "Confiance et transparence"), body: txt("أعجبني أنهم يظهرون نسبة البطارية والحالة قبل الشراء. الجهاز مطابق للوصف.", "J’aime qu’ils affichent la santé de la batterie et l’état avant l’achat. L’appareil correspond à la description."), color: "#e17055" },
    { id: "r5", name: "محمد الأمين", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("خدمة واتساب رائعة", "Service WhatsApp au top"), body: txt("أجابوني على كل الأسئلة عبر واتساب وأرسلوا لي صورًا إضافية للجهاز.", "Ils ont répondu à toutes mes questions sur WhatsApp et m’ont envoyé des photos supplémentaires."), color: "#1e6fd9" },
    { id: "r6", name: "عائشة بنت بابا", city: txt("روصو", "Rosso"), rating: 4, title: txt("سأشتري مرة أخرى", "Je rachèterai"), body: txt("الساعة وصلت بحالة جيدة، فقط التغليف كان بسيطًا. الخدمة تستحق التجربة.", "La montre est arrivée en bon état, l’emballage était simple. Le service mérite le détour."), color: "#2d3436" },
    { id: "r7", name: "سيدي محمد", city: txt("أطار", "Atar"), rating: 5, title: txt("جهاز موثوق", "Appareil fiable"), body: txt("حاسوب Dell مجدد يعمل بسرعة، والضمان أعطاني راحة البال.", "Le Dell reconditionné est rapide, et la garantie me rassure."), color: "#00b894" },
    { id: "r8", name: "خديجة بنت المختار", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("أنصح الجميع", "Je recommande à tous"), body: txt("اشتريت جهازين للعائلة، كلاهما ممتاز والسعر أفضل من الجديد.", "J’ai acheté deux appareils pour la famille, tous deux excellents et bien moins chers que le neuf."), color: "#d63031" }
  ];

  const DEFAULT_PRESS = [
    { id: "p1", outlet: txt("تِك صحارى", "Tech Sahara"), quote: txt("ريستور يعيد تعريف سوق الإلكترونيات المجددة في موريتانيا بأسعار شفافة وضمان حقيقي.", "Restore redéfinit le marché du reconditionné en Mauritanie avec des prix transparents et une vraie garantie.") },
    { id: "p2", outlet: txt("نواكشوط بيزنس", "Nouakchott Business"), quote: txt("منصة محلية تربط المستهلك بأجهزة موثوقة وتقلل النفايات الإلكترونية.", "Une plateforme locale qui connecte les consommateurs à des appareils fiables et réduit les déchets électroniques.") },
    { id: "p3", outlet: txt("الرؤية", "La Vision"), quote: txt("تجربة شراء رقمية بالعربية والفرنسية مع دفع محلي وتوصيل لكل الولايات.", "Une expérience d’achat numérique en arabe et en français, avec paiement local et livraison dans toutes les wilayas.") }
  ];

  const DEFAULT_BLOG = [
    { id: "b1", slug: "choisir-telephone-reconditionne", title: txt("كيف تختار هاتفًا مجددًا دون أن تقع في الفخ؟", "Comment choisir un téléphone reconditionné sans se tromper ?"), excerpt: txt("خمسة معايير مهمة قبل الشراء: البطارية، الحالة، الضمان، المصدر، وسياسة الإرجاع.", "Cinq critères essentiels : batterie, état, garantie, provenance et politique de retour."), body: txt("ابدأ دائمًا بصحة البطارية. نسبة 85% فما فوق جيدة للاستخدام اليومي.\nتأكد من وجود ضمان مكتوب وسياسة إرجاع واضحة.\nاسأل عن الحالة الفعلية للجهاز واطلب صورًا حقيقية.\nقارن السعر بالسوق ولا تنسَ تكلفة الشحن.", "Commencez toujours par la santé de la batterie. Au-dessus de 85 %, elle convient à un usage quotidien.\nExigez une garantie écrite et une politique de retour claire.\nDemandez l’état réel de l’appareil et des photos authentiques.\nComparez le prix au marché et pensez aux frais de livraison."), image: "assets/img/category-iphone.png", date: "2026-09-12", published: true },
    { id: "b2", slug: "macbook-ou-pc-portable", title: txt("ماك بوك أم حاسوب ويندوز؟ دليل مبسط", "MacBook ou PC portable ? Le guide simple"), excerpt: txt("أيهما يناسب الدراسة والعمل والبرامج التي تحتاجها؟", "Lequel convient aux études, au travail et à vos logiciels ?"), body: txt("اختر MacBook إذا كنت تعمل على التصميم أو المونتاج أو تريد عمر بطارية طويل.\nاختر حاسوب ويندوز إذا كنت تحتاج برامج هندسية أو محاسبية خاصة أو ميزانية أقل.\nفي الحالتين، تحقق من صحة البطارية والمنافذ ولوحة المفاتيح.", "Choisissez un MacBook pour le design, le montage ou une longue autonomie.\nChoisissez un PC Windows pour certains logiciels d’ingénierie, de comptabilité ou un budget plus serré.\nDans les deux cas, vérifiez la batterie, les ports et le clavier."), image: "assets/img/category-macbooks.png", date: "2026-08-28", published: true },
    { id: "b3", slug: "entretenir-batterie", title: txt("سبع عادات تطيل عمر بطارية هاتفك", "Sept habitudes qui prolongent la batterie de votre téléphone"), excerpt: txt("نصائح عملية لشحن أذكى واستخدام أطول.", "Des conseils concrets pour charger plus intelligemment."), body: txt("حافظ على الشحن بين 20% و80% عندما يكون ذلك ممكنًا.\nتجنب الحرارة العالية أثناء الشحن.\nاستخدم شاحنًا أصليًا أو معتمدًا.\nلا تترك الهاتف مشحونًا 100% طوال الليل.", "Gardez la charge entre 20 % et 80 % lorsque c’est possible.\nÉvitez la chaleur pendant la charge.\nUtilisez un chargeur d’origine ou certifié.\nNe laissez pas le téléphone à 100 % toute la nuit."), image: "assets/img/category-chargers.png", date: "2026-07-19", published: true }
  ];

  const DEFAULT_NAV = [
    { id: "anniversary", label: txt("ريستور أنيفرساري", "Anniversaire Restore"), href: "collection.html?handle=restore-anniversary", flame: true, visible: true },
    { id: "iphones", label: txt("آيفون", "iPhones"), href: "collection.html?handle=refurbished-iphones", visible: true, sub: [
      { label: txt("سلسلة iPhone 16", "iPhone 16"), href: "collection.html?q=iPhone%2016" },
      { label: txt("سلسلة iPhone 15", "iPhone 15"), href: "collection.html?q=iPhone%2015" },
      { label: txt("سلسلة iPhone 14", "iPhone 14"), href: "collection.html?q=iPhone%2014" },
      { label: txt("سلسلة iPhone 13", "iPhone 13"), href: "collection.html?q=iPhone%2013" },
      { label: txt("سلسلة iPhone 12", "iPhone 12"), href: "collection.html?q=iPhone%2012" },
      { label: txt("سلسلة iPhone 11", "iPhone 11"), href: "collection.html?q=iPhone%2011" }
    ] },
    { id: "samsung", label: txt("سامسونج", "Samsung"), href: "collection.html?handle=used-samsung", visible: true, sub: [
      { label: txt("سلسلة Galaxy S24", "Galaxy S24"), href: "collection.html?q=S24" },
      { label: txt("سلسلة Galaxy S23", "Galaxy S23"), href: "collection.html?q=S23" },
      { label: txt("سلسلة Galaxy S22", "Galaxy S22"), href: "collection.html?q=S22" },
      { label: txt("سلسلة Galaxy S21", "Galaxy S21"), href: "collection.html?q=S21" },
      { label: txt("سلسلة Galaxy S20", "Galaxy S20"), href: "collection.html?q=S20" },
      { label: txt("سلسلة Galaxy Z", "Galaxy Z"), href: "collection.html?q=Z%20Fold" },
      { label: txt("سلسلة Galaxy Note", "Galaxy Note"), href: "collection.html?q=Note" }
    ] },
    { id: "macbooks", label: txt("ماك بوك", "MacBooks"), href: "collection.html?handle=refurbished-macbooks", visible: true, sub: [
      { label: txt("MacBook Pro", "MacBook Pro"), href: "collection.html?q=MacBook%20Pro" },
      { label: txt("MacBook Air", "MacBook Air"), href: "collection.html?q=MacBook%20Air" },
      { label: txt("iMac", "iMac"), href: "collection.html?q=iMac" }
    ] },
    { id: "laptops", label: txt("حواسيب محمولة", "Laptops"), href: "collection.html?handle=laptops-used-refurbished", visible: true, sub: [
      { label: "Lenovo", href: "collection.html?q=Lenovo" },
      { label: "Dell", href: "collection.html?q=Dell" },
      { label: "HP", href: "collection.html?q=HP" },
      { label: "Acer", href: "collection.html?q=Acer" }
    ] },
    { id: "ipads", label: txt("آيباد", "iPads"), href: "collection.html?handle=ipads", visible: true },
    { id: "accessories", label: txt("ملحقات وصوتيات", "Accessoires et audio"), href: "collection.html?handle=audio", visible: true, sub: [
      { label: txt("صوتيات", "Audio"), href: "collection.html?handle=audio" },
      { label: txt("شواحن وكابلات", "Chargeurs et câbles"), href: "collection.html?handle=chargers-power-banks-cables" },
      { label: txt("ألعاب", "Gaming"), href: "collection.html?handle=gaming" },
      { label: txt("ملحقات", "Accessoires"), href: "collection.html?handle=cases-screen-protectors" }
    ] },
    { id: "watches", label: txt("ساعة آبل", "Apple Watch"), href: "collection.html?handle=apple-watches", visible: true },
    { id: "business", label: txt("للشركات", "Entreprises"), href: "page.html?slug=for-businesses", visible: true },
    { id: "help", label: txt("تحتاج مساعدة؟", "Besoin d’aide ?"), href: "page.html?slug=help", visible: true },
    { id: "seller", label: txt("كن بائعًا", "Devenir vendeur"), href: "page.html?slug=become-a-seller", visible: true }
  ];

  const COLLECTION_TITLES = {
    "restore-anniversary": txt("ريستور أنيفرساري", "Anniversaire Restore"),
    "refurbished-iphones": txt("آيفون مجدد معتمد", "iPhone reconditionnés certifiés"),
    "used-samsung": txt("سامسونج مجدد معتمد", "Samsung reconditionnés certifiés"),
    "laptops-used-refurbished": txt("حواسيب محمولة مجددة", "Ordinateurs portables reconditionnés"),
    "refurbished-macbooks": txt("ماك بوك مجدد", "MacBook reconditionnés"),
    "ipads": txt("آيباد مجدد", "iPad reconditionnés"),
    "apple-watches": txt("ساعات آبل", "Montres Apple"),
    "audio": txt("صوتيات", "Audio"),
    "chargers-power-banks-cables": txt("شواحن وبطاريات وكابلات", "Chargeurs, batteries et câbles"),
    "gaming": txt("ألعاب", "Gaming"),
    "cases-screen-protectors": txt("محافظ وواقيات شاشة", "Coques et protections d’écran")
  };

  const DEFAULT_CATEGORIES = [
    { label: txt("ريستور أنيفرساري", "Restore Anniversary"), handle: "restore-anniversary", image: "assets/img/category-anniversary.webp" },
    { label: txt("آيفون", "iPhone"), handle: "refurbished-iphones", image: "assets/img/category-iphone.png" },
    { label: txt("سامسونج", "Samsung"), handle: "used-samsung", image: "assets/img/category-samsung.png" },
    { label: txt("ماك بوك", "MacBooks"), handle: "refurbished-macbooks", image: "assets/img/category-macbooks.png" },
    { label: txt("حواسيب محمولة", "Laptops"), handle: "laptops-used-refurbished", image: "assets/img/category-laptops.png" },
    { label: txt("آيباد", "iPads"), handle: "ipads", image: "assets/img/category-ipads.png" },
    { label: txt("ساعات آبل", "Apple Watches"), handle: "apple-watches", image: "assets/img/category-watches.png" },
    { label: txt("صوتيات", "Audio"), handle: "audio", image: "assets/img/category-audio.png" },
    { label: txt("شواحن وكابلات", "Chargeurs et câbles"), handle: "chargers-power-banks-cables", image: "assets/img/category-chargers.png" },
    { label: txt("ألعاب", "Gaming"), handle: "gaming", image: "assets/img/category-gaming.png" },
    { label: txt("ملحقات", "Accessoires"), handle: "cases-screen-protectors", image: "assets/img/category-accessories.png" }
  ];

  const DEFAULT_PAYMENTS = [
    { id: "bankily", name: txt("بنكيلي", "Bankily"), color: "#00a651", active: true, discount: 10, note: txt("خصم 10% عند الدفع عبر بنكيلي", "10 % de réduction avec Bankily") },
    { id: "masrvi", name: txt("مصرفي", "Masrvi"), color: "#0b6fb8", active: true, discount: 0, note: txt("تحويل فوري عبر مصرفي", "Paiement instantané via Masrvi") },
    { id: "sedad", name: txt("سداد", "Sedad"), color: "#6f42c1", active: true, discount: 0, note: txt("الدفع عبر تطبيق سداد", "Paiement avec l’application Sedad") },
    { id: "click", name: txt("كليك", "Click"), color: "#e67e22", active: true, discount: 0, note: txt("الدفع عبر كليك", "Paiement avec Click") },
    { id: "cod", name: txt("الدفع عند الاستلام", "Paiement à la livraison"), color: "#2d3436", active: true, discount: 0, note: txt("ادفع نقدًا عند استلام طلبك", "Payez en espèces à la réception") }
  ]
  const DEFAULT_CITIES = [
    { id: "nouakchott", name: txt("نواكشوط", "Nouakchott"), fee: 0, days: txt("1–2 أيام", "1–2 jours"), active: true },
    { id: "nouadhibou", name: txt("نواذيبو", "Nouadhibou"), fee: 500, days: txt("2–3 أيام", "2–3 jours"), active: true },
    { id: "rosso", name: txt("روصو", "Rosso"), fee: 600, days: txt("2–3 أيام", "2–3 jours"), active: true },
    { id: "kiffa", name: txt("كيفة", "Kiffa"), fee: 800, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "kaedi", name: txt("كيهيدي", "Kaédi"), fee: 700, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "atar", name: txt("أطار", "Atar"), fee: 900, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "zouerat", name: txt("الزويرات", "Zouérat"), fee: 1200, days: txt("4–6 أيام", "4–6 jours"), active: true },
    { id: "nema", name: txt("النعمة", "Néma"), fee: 1200, days: txt("4–7 أيام", "4–7 jours"), active: true },
    { id: "tidjikja", name: txt("تجكجة", "Tidjikja"), fee: 1000, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "selibaby", name: txt("سيليبابي", "Sélibaby"), fee: 900, days: txt("4–6 أيام", "4–6 jours"), active: true },
    { id: "aleg", name: txt("ألاك", "Aleg"), fee: 700, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "boutilimit", name: txt("بوتلميت", "Boutilimit"), fee: 500, days: txt("2–4 أيام", "2–4 jours"), active: true }
  ];

  const DEFAULT_ORDER_TEMPLATE = {
    ar: "مرحباً {store} 👋\nأريد تأكيد هذا الطلب:\n\nرقم الطلب: {order_id}\nالاسم: {name}\nالهاتف: {phone}\nالمدينة: {city}\nالعنوان: {address}\nطريقة الدفع: {payment}\n\nالمنتجات:\n{items}\n\nالمجموع الفرعي: {subtotal}\nالشحن: {shipping}\nالخصم: {discount}\nالإجمالي: {total}\n\nملاحظات: {notes}",
    fr: "Bonjour {store} 👋\nJe souhaite confirmer cette commande :\n\nN° de commande : {order_id}\nNom : {name}\nTéléphone : {phone}\nVille : {city}\nAdresse : {address}\nPaiement : {payment}\n\nProduits :\n{items}\n\nSous-total : {subtotal}\nLivraison : {shipping}\nRéduction : {discount}\nTotal : {total}\n\nNotes : {notes}"
  };

  const DEFAULT_WHATSAPP_TEMPLATES = {
    confirm: {
      ar: "مرحباً {name}، تم تأكيد طلبك {order_id} من {store}. سنبدأ تجهيزه ونخبرك عند الشحن. شكراً لثقتك!",
      fr: "Bonjour {name}, votre commande {order_id} chez {store} est confirmée. Nous préparons votre colis et vous informerons dès l’expédition. Merci !"
    },
    shipped: {
      ar: "مرحباً {name}، طلبك {order_id} تم شحنه وهو في الطريق إليك. سنوافيك برقم التتبع قريباً.",
      fr: "Bonjour {name}, votre commande {order_id} a été expédiée et est en route. Nous vous enverrons le numéro de suivi très bientôt."
    },
    delivered: {
      ar: "مرحباً {name}، نأمل أن تكون راضياً عن طلبك {order_id}. إذا احتجت أي مساعدة أو ضمان، راسلنا هنا.",
      fr: "Bonjour {name}, nous espérons que votre commande {order_id} vous satisfait. Pour toute aide ou garantie, écrivez-nous ici."
    }
  };

  function productDescriptions(type) {
    return TYPE_DESCRIPTIONS[type] || txt(
      "جهاز مجدد تم فحصه واختباره من طرف خبراء ريستور، ويأتي بضمان 12 شهرًا.",
      "Appareil reconditionné, inspecté et testé par les experts Restore, avec 12 mois de garantie."
    );
  }

  function hashHandle(handle) {
    let h = 0;
    for (let i = 0; i < handle.length; i++) h = (h * 31 + handle.charCodeAt(i)) >>> 0;
    return h;
  }

  function includesFor(p) {
    const map = {
      Macbook: [txt("جهاز MacBook", "MacBook"), txt("شاحن أصلي", "Chargeur d’origine"), txt("كابل USB-C", "Câble USB-C")],
      Laptop: [txt("الحاسوب المحمول", "Ordinateur portable"), txt("الشاحن", "Chargeur"), txt("كابل الطاقة", "Câble d’alimentation")],
      Smartphone: [txt("الهاتف", "Téléphone"), txt("كابل الشحن", "Câble de charge"), txt("أداة إخراج الشريحة", "Outil SIM")],
      Tablets: [txt("الجهاز اللوحي", "Tablette"), txt("كابل الشحن", "Câble de charge"), txt("الشاحن", "Chargeur")],
      "Apple Watch": [txt("الساعة", "Montre"), txt("السوار", "Bracelet"), txt("شاحن مغناطيسي", "Chargeur magnétique")],
      Playstation: [txt("الجهاز", "Console"), txt("يد التحكم", "Manette"), txt("كابلات التوصيل", "Câbles de connexion")],
      Accessories: [txt("الملحق", "Accessoire"), txt("دليل الاستخدام", "Guide d’utilisation")]
    };
    return map[p.type] || [txt("الجهاز", "Appareil"), txt("الكابل", "Câble")];
  }

  function specsFor(p, battery) {
    const title = p.title || "";
    const cpuOpt = p.options?.find((o) => /cpu/i.test(o.name));
    const ramOpt = p.options?.find((o) => /ram/i.test(o.name));
    const storageOpt = p.options?.find((o) => /storage/i.test(o.name));
    const isMac = p.type === "Macbook";
    const isLaptop = p.type === "Laptop" || isMac;
    const isPhone = p.type === "Smartphone";
    const cpuFromTitle = title.match(/(Core i[3579][^,/(-]*|M[1234](?: Pro| Max)?|Ryzen [3579][^,/(-]*)/i)?.[0];
    const cpu = cpuOpt?.values?.[0] || cpuFromTitle || (isMac ? "Apple Silicon" : isLaptop ? "Intel Core i5" : isPhone ? "SoC" : "—");
    const ram = ramOpt?.values?.[0] || (isLaptop ? (isMac ? "8 GB" : "8 GB") : isPhone ? "6 GB" : "—");
    const storage = storageOpt?.values?.[0] || (isPhone ? "128 GB" : isLaptop ? "256 GB SSD" : "—");
    const screen = isMac ? '13.3"' : isLaptop ? '14"' : isPhone ? '6.1"' : p.type === "Tablets" ? '10.2"' : p.type === "Apple Watch" ? "45 mm" : "—";
    const keyboard = isLaptop ? txt("فرنسي AZERTY", "Français AZERTY") : null;
    const condition = p.options?.find((o) => /condition|état/i.test(o.name))?.values?.[0] || "Excellent";
    return {
      cpu: { label: txt("المعالج", "Processeur"), value: cpu, choices: isLaptop ? [cpu, "Intel Core i7", "Intel Core i5", "Apple M1", "Apple M2"] : [] },
      ram: { label: txt("الذاكرة", "Mémoire RAM"), value: ram, choices: isLaptop ? [ram, "8 GB", "16 GB", "32 GB"] : [] },
      storage: { label: txt("التخزين", "Stockage"), value: storage, choices: [] },
      screen: { label: txt("حجم الشاشة", "Taille d’écran"), value: screen, choices: isLaptop ? [screen, '13.3"', '14"', '15.6"', '16"'] : isPhone ? ['5.8"', '6.1"', '6.7"'] : [] },
      keyboard: { label: txt("لوحة المفاتيح", "Clavier"), value: keyboard, choices: isLaptop ? ["Français AZERTY", "QWERTY (US)", "Arabe / Anglais"] : [] },
      condition: { label: txt("الحالة", "État"), value: condition, choices: [] },
      battery: { label: txt("صحة البطارية", "Santé de la batterie"), value: `${battery}%`, choices: [] }
    };
  }

  function priceProduct(p) {
    const price = roundMRU(p.price);
    const compare = roundMRU(p.compare);
    return {
      ...p,
      price,
      compare: compare > price ? compare : 0,
      discount: compare > price ? Math.round((1 - price / compare) * 100) : 0
    };
  }

  function buildProducts() {
    return RAW.products.map((raw, index) => {
      const seed = hashHandle(raw.handle);
      const p = priceProduct(raw);
      const stock = 2 + (seed % 17);
      const batteryBase = 84 + (seed % 16);
      const battery = p.type === "Smartphone" ? Math.min(100, batteryBase) : null;
      const condition = p.options?.find((o) => /condition|état/i.test(o.name))?.values?.[0] || (p.compare ? "Excellent" : "Good");
      const colorRemote = {};
      for (const v of raw.variants || []) {
        const alt = v.image?.alt;
        if (alt && v.image?.src) colorRemote[alt] = v.image.src;
      }
      const colors = p.colors || [];
      const colorImages = {};
      colors.forEach((c, i) => {
        colorImages[c.name] = p.images?.length
          ? p.images[Math.min(i, p.images.length - 1)]
          : p.image;
      });
      const variants = (raw.variants || []).map((v) => ({
        id: v.id,
        title: v.title,
        o1: v.o1,
        o2: v.o2,
        o3: v.o3,
        price: roundMRU(v.price ?? raw.price),
        compare: roundMRU(v.compare ?? raw.compare),
        available: v.available !== false,
        battery: battery ?? 0
      }));
      return {
        ...p,
        variants,
        price: roundMRU(raw.price),
        compare: roundMRU(raw.compare) > roundMRU(raw.price) ? roundMRU(raw.compare) : 0,
        discount: roundMRU(raw.compare) > roundMRU(raw.price) ? Math.round((1 - roundMRU(raw.price) / roundMRU(raw.compare)) * 100) : 0,
        stock,
        active: true,
        battery,
        condition,
        description: productDescriptions(p.type),
        includes: includesFor(p),
        specs: specsFor(p, battery || 92),
        colorImages,
        colorRemote,
        sku: `RS-${String(index + 1).padStart(4, "0")}`,
        warrantyMonths: 12,
        lowStock: stock <= 2
      };
    });
  }

  function buildState() {
    const products = buildProducts();
    products.forEach((p) => {
    });
    const collections = RAW.collections.map((c) => ({
      handle: c.handle,
      title: COLLECTION_TITLES[c.handle] || txt(c.title, c.title),
      visible: true
    }));
    const home = {
      anniversary: RAW.home.anniversary,
      iphones: RAW.home.iphones,
      samsung: RAW.home.samsung,
      laptops: RAW.home.laptops
    };
    return {
      version: 1,
      updatedAt: nowISO(),
      settings: {
        storeName: txt("ريستور", "Restore"),
        legalName: txt("ريستور موريتانيا", "Restore Mauritanie"),
        tagline: txt("إلكترونيات مجددة موثوقة في موريتانيا", "Électronique reconditionnée et fiable en Mauritanie"),
        logo: "assets/img/restore-logo.svg",
        logoWhite: "assets/img/restore-logo-white.svg",
        favicon: "assets/img/favicon.svg",
        colors: { primary: "#ff6400", ink: "#232323", purple: "#a72396", lavender: "#f1ecf9" },
        font: "Montserrat",
        radius: 10,
        country: {
          code: "MR",
          name: txt("موريتانيا", "Mauritanie"),
          flag: "assets/img/flag-mr.svg",
          dial: "+222",
          currencyCode: "MRU",
          currency: txt("أوقية", "MRU"),
          currencyName: txt("أوقية جديدة", "Nouvelle ouguiya"),
          currencyMode: "new"
        },
        city: txt("نواكشوط", "Nouakchott"),
        address: txt("نواكشوط، موريتانيا", "Nouakchott, Mauritanie"),
        timezone: "Africa/Nouakchott",
        phone: "+22246000000",
        phoneDisplay: "+222 46 00 00 00",
        whatsapp: "22246000000",
        email: "hello@restore.mr",
        hours: { open: "00:00", close: "23:59", days: [0, 1, 2, 3, 4, 5, 6], closed: false, maintenance: false },
        announcement: txt("توصيل مجاني داخل نواكشوط • خصم 10% عند الدفع عبر بنكيلي", "Livraison gratuite à Nouakchott • -10 % avec Bankily"),
        renewalText: txt("ما معنى مجدد من ريستور؟", "Que signifie reconditionné chez Restore ?"),
        categoriesTitle: txt("تسوق الإلكترونيات المجددة", "Électronique reconditionnée"),
        serviceTitle: txt("كل أجهزتنا أصلية ومفحوصة من طرف خبراء", "Tous nos appareils sont originaux et vérifiés par des experts"),
        serviceItems: [
          { icon: "smile", title: txt("بدون مخاطرة", "Sans risque"), text: txt("10 أيام لإرجاع الجهاز عند وجود أي مشكلة", "10 jours pour retourner l’appareil en cas de problème") },
          { icon: "badgeCheck", title: txt("فحص جهازًا بجهاز", "Vérifié un par un"), text: txt("50 نقطة فحص تشمل الشاشة، البطارية، السرعة والمتانة", "50 points de contrôle : écran, batterie, vitesse et durabilité") },
          { icon: "star", title: txt("أفضل الموردين فقط", "Seulement les meilleurs"), text: txt("نقبل موردًا واحدًا من كل أربعة بعد فحص صارم", "Nous acceptons un fournisseur sur quatre après un contrôle strict") },
          { icon: "chat", title: txt("دائمًا معك", "Toujours là pour vous"), text: txt("خدمة عملاء تجيب على أسئلتك وتتابع طلبك", "Un service client qui répond et suit votre commande") }
        ],
        trustTitle: txt("150,000+ عميل يثقون بنا", "150 000+ clients nous font confiance"),
        communityTitle: txt("انضم إلى مجتمع ريستور", "Rejoignez la communauté Restore"),
        reviewsTitle: txt("ماذا يقول عملاؤنا", "Ce que disent nos clients"),
        pressTitle: txt("ريستور في الأخبار", "Restore dans la presse"),
        trustBar: [
          { icon: "truck", label: txt("توصيل مجاني داخل نواكشوط", "Livraison gratuite à Nouakchott") },
          { icon: "shield", label: txt("ضمان 12 شهرًا", "Garantie 12 mois") },
          { icon: "return", label: txt("إرجاع خلال 10 أيام", "Retour sous 10 jours") },
          { icon: "badgeCheck", label: txt("فحص بواسطة خبراء", "Vérifié par des experts") }
        ],
        paymentOffer: txt("اشترِ عبر بنكيلي واحصل على خصم 10%", "Payez avec Bankily et obtenez 10 % de réduction"),
        paymentOfferCode: "BANKILY10",
        shippingNote: txt("رسوم الشحن تُحسب حسب المدينة عند إتمام الطلب.", "Les frais de livraison sont calculés selon la ville lors de la commande."),
        freeShippingOver: 20000,
        cities: DEFAULT_CITIES,
        payments: DEFAULT_PAYMENTS,
        navigation: DEFAULT_NAV,
        footerColumns: [
          { title: txt("من نحن", "À propos"), links: [
            { label: txt("من نحن", "À propos"), href: "page.html?slug=about-us" },
            { label: txt("تسوق الآن", "Boutique"), href: "collection.html?handle=all" },
            { label: txt("مدونتنا", "Notre blog"), href: "blog.html" },
            { label: txt("كن بائعًا", "Devenir vendeur"), href: "page.html?slug=become-a-seller" }
          ] },
          { title: txt("معلومات", "Informations"), links: [
            { label: txt("مركز المساعدة", "Centre d’aide"), href: "page.html?slug=help" },
            { label: txt("اتصل بنا", "Contact"), href: "page.html?slug=contact" },
            { label: txt("الشروط والأحكام", "Conditions générales"), href: "page.html?slug=terms" },
            { label: txt("سياسة الخصوصية", "Confidentialité"), href: "page.html?slug=privacy" }
          ] },
          { title: txt("حسابي", "Mon compte"), links: [
            { label: txt("حسابي", "Mon compte"), href: "account.html" },
            { label: txt("تتبع الطلب", "Suivre ma commande"), href: "page.html?slug=track-order" },
            { label: txt("طلب ضمان", "Demande de garantie"), href: "page.html?slug=raise-claim" },
            { label: txt("متابعة الضمان", "Suivi de garantie"), href: "page.html?slug=track-claim" }
          ] }
        ],
        social: [
          { id: "facebook", href: "https://www.facebook.com/", icon: "facebook" },
          { id: "instagram", href: "https://www.instagram.com/", icon: "instagram" },
          { id: "tiktok", href: "https://www.tiktok.com/", icon: "tiktok" }
        ],
        homeSections: [
          { id: "anniversary", visible: true, order: 1, title: txt("ريستور أنيفرساري", "Restore Anniversary"), collection: "restore-anniversary", handles: home.anniversary, layout: "plain", promo: "", flame: true },
          { id: "iphones", visible: true, order: 2, title: txt("آيفون مجدد معتمد", "iPhones reconditionnés certifiés"), collection: "refurbished-iphones", handles: home.iphones, layout: "left", promo: "assets/img/restore/promo-iphone.svg", flame: false },
          { id: "samsung", visible: true, order: 3, title: txt("سامسونج مجدد معتمد", "Samsung reconditionné certifié"), collection: "used-samsung", handles: home.samsung, layout: "right", promo: "assets/img/restore/promo-samsung.svg", flame: false },
          { id: "laptops", visible: true, order: 4, title: txt("حواسيب محمولة مجددة", "Ordinateurs portables reconditionnés"), collection: "laptops-used-refurbished", handles: home.laptops, layout: "left", promo: "assets/img/restore/promo-laptops.svg", flame: false }
        ],
        pageSections: [
          { id: "hero", visible: true, order: 1 },
          { id: "trust", visible: true, order: 2 },
          { id: "renewed", visible: true, order: 3 },
          { id: "categories", visible: true, order: 4 },
          { id: "offer", visible: true, order: 5 },
          { id: "products", visible: true, order: 6 },
          { id: "sustain", visible: true, order: 7 },
          { id: "service", visible: true, order: 8 },
          { id: "video", visible: true, order: 9 },
          { id: "reviews", visible: true, order: 10 },
          { id: "press", visible: true, order: 11 }
        ],
        heroSlides: [
          { id: "hero-1", visible: true, title: txt("تقنية مجددة، ثقة جديدة", "La tech reconditionnée, en toute confiance"), subtitle: txt("هواتف وحواسيب مفحوصة بضمان 12 شهرًا، وتوصيل لكل موريتانيا.", "Téléphones et ordinateurs contrôlés, garantis 12 mois et livrés partout en Mauritanie."), cta: txt("تسوق الآن", "Découvrir"), href: "collection.html?handle=all", image: "assets/img/hero-iphone.png", bg: "linear-gradient(135deg,#1f1f2e 0%,#39255b 55%,#ff6400 130%)" },
          { id: "hero-2", visible: true, title: txt("ماك بوك جاهز للعمل", "MacBook prêt à travailler"), subtitle: txt("macOS مثبت، بطارية مفحوصة، ولوحة مفاتيح بالعربية أو الفرنسية.", "macOS installé, batterie contrôlée et clavier arabe ou français."), cta: txt("اكتشف ماك بوك", "Voir les MacBook"), href: "collection.html?handle=refurbished-macbooks", image: "assets/img/hero-macbook.png", bg: "linear-gradient(135deg,#eef3ff 0%,#d9e5ff 45%,#f7c7ff 120%)", dark: false }
        ],
        offers: [
          { id: "bankily", active: true, title: txt("خصم 10% عند الدفع عبر بنكيلي", "10 % de réduction avec Bankily"), subtitle: txt("اختر بنكيلي عند إتمام الطلب وسيُطبّق الخصم تلقائيًا.", "Choisissez Bankily au paiement, la réduction s’applique automatiquement."), code: "BANKILY10", href: "collection.html?handle=all", startsAt: "", endsAt: new Date(Date.now() + 7 * 864e5).toISOString() }
        ],
        coupons: [
          { id: "c1", code: "RESTORE10", type: "percent", value: 10, active: true, minTotal: 0, expiresAt: "" },
          { id: "c2", code: "NOUAKCHOTT5", type: "percent", value: 5, active: true, minTotal: 10000, expiresAt: "" }
        ],
        seo: {
          title: txt("ريستور | إلكترونيات مجددة موثوقة في موريتانيا", "Restore | Électronique reconditionnée en Mauritanie"),
          description: txt("اشترِ هواتف وحواسيب مجددة مفحوصة في موريتانيا مع ضمان 12 شهرًا، توصيل سريع ودفع عبر بنكيلي ومصرفي وسداد.", "Achetez téléphones et ordinateurs reconditionnés en Mauritanie avec 12 mois de garantie, livraison rapide et paiement Bankily, Masrvi ou Sedad.")
        },
        pixels: { meta: "", tiktok: "", ga: "" },
        orderTemplate: DEFAULT_ORDER_TEMPLATE,
        whatsappTemplates: DEFAULT_WHATSAPP_TEMPLATES,
        otp: { enabled: false },
        blocklist: [],
        rateLimitSeconds: 60,
        lowStockThreshold: 2,
        autoHideOutOfStock: true,
        pwa: true,
        fakeData: true
      },
      products,
      collections,
      home,
      theme: { categories: DEFAULT_CATEGORIES },
      pages: DEFAULT_PAGES,
      faqs: DEFAULT_FAQS,
      homeReviews: DEFAULT_HOME_REVIEWS,
      press: DEFAULT_PRESS,
      blog: DEFAULT_BLOG,
      reviews: []
    };
  }

  function hydrate(saved) {
    const base = buildState();
    if (!saved) return base;
    const out = merge(base, saved);
    const baseProducts = new Map(base.products.map((p) => [p.handle, p]));
    out.products = (saved.products || base.products).map((p) => merge(baseProducts.get(p.handle) || {}, p));
    out.collections = (saved.collections || base.collections).map((c) => {
      const merged = merge(base.collections.find((x) => x.handle === c.handle) || {}, c);
      if (typeof merged.title === "string") merged.title = COLLECTION_TITLES[merged.handle] || txt(merged.title, merged.title);
      return merged;
    });
    out.pages = (saved.pages || base.pages).map((p) => merge(base.pages.find((x) => x.slug === p.slug) || {}, p));
    out.blog = (saved.blog || base.blog).map((b) => merge(base.blog.find((x) => x.slug === b.slug) || {}, b));
    out.settings.homeSections = (saved.settings?.homeSections || base.settings.homeSections).map((s) => merge(base.settings.homeSections.find((x) => x.id === s.id) || {}, s));
    out.settings.navigation = (saved.settings?.navigation || base.settings.navigation).map((n) => merge(base.settings.navigation.find((x) => x.id === n.id) || {}, n));
    out.settings.pageSections = (saved.settings?.pageSections || base.settings.pageSections).map((s) => merge(base.settings.pageSections.find((x) => x.id === s.id) || {}, s));
    out.products.forEach((p) => {
      if (!p.specs) p.specs = specsFor(p, p.battery || 92);
      if (!p.includes) p.includes = includesFor(p);
      if (!p.description) p.description = productDescriptions(p.type);
      if (!p.colorImages) p.colorImages = {};
      if (!p.colorRemote) p.colorRemote = {};
    });
    return out;
  }
  const I18N = {
    ar: {
      home: "الرئيسية", shop: "تسوق", allProducts: "كل المنتجات", search: "بحث", account: "حسابي", wishlist: "المفضلة", cart: "السلة", checkout: "إتمام الطلب",
      searchPlaceholder: "ابحث عن iPhone، Galaxy، MacBook...", close: "إغلاق", menu: "القائمة", language: "اللغة", currency: "العملة", noOrders: "لا توجد طلبات بعد.", dark: "الوضع الليلي", light: "الوضع النهاري",
      freeDelivery: "توصيل مجاني", returns: "إرجاع سهل", warranty: "ضمان 12 شهرًا", macos: "macOS مثبت", checked: "مفحوص بواسطة خبراء",
      seeAll: "عرض الكل", shopNow: "تسوق الآن", discover: "اكتشف", addToCart: "أضف إلى السلة", buyNow: "اشترِ الآن", soldOut: "نفدت الكمية",
      continueShopping: "متابعة التسوق", quickView: "نظرة سريعة", addedToCart: "تمت الإضافة إلى السلة", removedWish: "تمت الإزالة من المفضلة", savedWish: "تمت الإضافة إلى المفضلة",
      popularNow: "الأكثر طلبًا الآن", resultsFor: "{count} نتيجة لـ «{q}»", noProducts: "لا توجد منتجات", tryFilter: "جرّب كلمة بحث أو تصنيفًا آخر.", browseAll: "تصفح كل المنتجات",
      sortBy: "ترتيب حسب", featured: "المميزة", priceLow: "السعر: من الأقل للأعلى", priceHigh: "السعر: من الأعلى للأقل", biggestDiscount: "أكبر خصم", nameAZ: "الاسم أ–ي",
      all: "الكل", onSale: "عروض", loadMore: "عرض المزيد", product: "منتج", products: "منتج", collection: "التصنيف", searchResults: "نتائج البحث",
      homeCrumb: "الرئيسية", reviews: "تقييمات", review: "تقييم", battery: "البطارية", condition: "الحالة", quantity: "الكمية", description: "الوصف",
      shippingDelivery: "الشحن والتوصيل", warrantyReturns: "الضمان والإرجاع", whatsIncluded: "ماذا يوجد مع الشحنة", faqs: "الأسئلة الشائعة", related: "منتجات مشابهة", youMayLike: "قد يعجبك أيضًا",
      freeDeliverySub: "توصيل مجاني داخل نواكشوط", warrantySub: "مغطى من طرف ريستور", returnsSub: "في حال وجود أي مشكلة", checkedSub: "50 نقطة فحص قبل البيع",
      paymentOffer: "اشترِ عبر بنكيلي واحصل على خصم 10%", paymentOfferShort: "خصم 10% مع بنكيلي", orderWhatsApp: "اطلب عبر واتساب",
      customize: "خصص طلبك", cpu: "المعالج", ram: "الذاكرة", storage: "التخزين", screen: "حجم الشاشة", keyboard: "لوحة المفاتيح",
      trustedBy: "150,000+ عميل يثقون بنا", excellent: "ممتاز", customers: "عميل", basedOn: "بناءً على تقييمات العملاء",
      contactUs: "اتصل بنا", aboutUs: "من نحن", information: "معلومات", myAccount: "حسابي", replyWithin: "نرد خلال يوم عمل", workingHours: "من الأحد إلى الخميس، 9:00 إلى 19:00",
      allRights: "© {year} {store}. جميع الحقوق محفوظة.", paymentMethods: "وسائل الدفع", followUs: "تابعنا",
      emptyCart: "سلتك فارغة", emptyCartText: "أضف جهازًا للمتابعة.", emptyWish: "قائمة المفضلة فارغة", emptyWishText: "اضغط على القلب في أي منتج لحفظه هنا.",
      contactInfo: "معلومات التواصل", fullName: "الاسم الكامل", email: "البريد الإلكتروني (اختياري)", phone: "رقم الهاتف", city: "المدينة", address: "العنوان الكامل", notes: "ملاحظات (اختياري)",
      payment: "طريقة الدفع", coupon: "كود الخصم", apply: "تطبيق", subtotal: "المجموع الفرعي", shipping: "الشحن", discount: "الخصم", total: "الإجمالي", free: "مجاني",
      placeOrder: "أكمل الطلب عبر واتساب", processing: "جاري تجهيز طلبك...", required: "يرجى إكمال الحقول المطلوبة", invalidPhone: "أدخل رقم هاتف موريتاني صحيح (8 أرقام)",
      storeClosed: "المتجر مغلق مؤقتًا. يمكنك تصفح المنتجات والعودة لاحقًا.", rateLimited: "تم إرسال طلب حديثًا من هذا الرقم. انتظر قليلًا قبل المحاولة مجددًا.", blockedPhone: "تعذر إتمام الطلب. تواصل معنا عبر واتساب.",
      orderReceived: "تم تسجيل طلبك", orderReceivedText: "سيتم تحويلك إلى واتساب لإرسال تفاصيل الطلب وتأكيده.", openWhatsApp: "فتح واتساب", redirecting: "جاري التحويل إلى واتساب...",
      country: "البلد", orderSummary: "ملخص الطلب", couponInvalid: "كود الخصم غير صالح أو منتهي", couponApplied: "تم تطبيق كود الخصم", whatsappTitle: "اطلب عبر واتساب", whatsappText: "أرسل لنا تفاصيل طلبك وسنؤكده معك.",
      aboutStore: "ريستور متجر موريتاني للإلكترونيات المجددة. نفحص كل جهاز ونقدم ضمانًا واضحًا وتوصيلًا لكل الولايات.",
      newsletter: "اشترك ليصلك كل جديد", newsletterPlaceholder: "بريدك الإلكتروني", subscribe: "اشتراك", subscribed: "تم الاشتراك",
      searchHint: "ابحث عن المنتج أو الماركة", noResults: "لا توجد نتائج", popular: "الأكثر بحثًا", clear: "مسح",
      pageNotFound: "الصفحة غير موجودة", productNotFound: "المنتج غير موجود", productNotFoundText: "قد يكون المنتج نفد أو الرابط غير صحيح.", goHome: "العودة للرئيسية",
      loginDemo: "تسجيل الدخول (عرض تجريبي)", signIn: "تسجيل الدخول", signOut: "خروج", dashboardLogin: "دخول لوحة التحكم",
      addToWishlist: "أضف إلى المفضلة", orderId: "رقم الطلب", writeReview: "اكتب تقييمك", verifiedBuyer: "مشترٍ موثّق",
      login: "دخول", logout: "خروج", signedIn: "تم تسجيل الدخول", signedOut: "تم تسجيل الخروج",
      createAccount: "إنشاء حساب", accountCreated: "تم إنشاء حسابك", loginFailed: "تعذر تسجيل الدخول", registerFailed: "تعذر إنشاء الحساب", dashboardLoginNote: "أدخل بريدك الإلكتروني وكلمة المرور الخاصة بلوحة التحكم.",
      password: "كلمة المرور", trackOrder: "تتبع الطلب", trackOrderText: "أدخل رقم الطلب أو رقم الهاتف للاطلاع على حالة طلبك.",
      recentOrders: "طلباتي الأخيرة", orderNotFound: "لم نجد طلبًا مطابقًا.", myWishlist: "مفضلتي", viewWishlist: "عرض كل المفضلة", myReviews: "تقييماتي",
      reviewStatusPending: "بانتظار الموافقة", reviewStatusApproved: "منشور", reviewStatusRejected: "مرفوض",
      reviewPending: "تقييمك وصل إلى الإدارة وسيظهر بعد الموافقة عليه.", reviewIncomplete: "أكمل التقييم والعنوان والتعليق.",
      reviewSubmitted: "شكرًا! تم إرسال تقييمك للمراجعة.", loginRequired: "سجّل الدخول أولًا لتتمكن من التقييم.",
      loginToReview: "سجّل الدخول أو أنشئ حسابًا لتقييم هذا المنتج.", noReviews: "لا توجد تقييمات بعد. كن أول من يقيّم هذا المنتج.",
      rating: "التقييم", stars: "نجوم", title: "العنوان", comment: "التعليق",
      reviewTitlePlaceholder: "ملخص تجربتك", reviewBodyPlaceholder: "ما الذي أعجبك؟ وكيف كانت حالة الجهاز والخدمة؟", submitReview: "إرسال التقييم",
      closedTitle: "المتجر مغلق الآن", closedText: "نعود قريبًا. يمكنك مراسلتنا على واتساب.",
      timezone: "توقيت نواكشوط", viewAllReviews: "كل التقييمات", readMore: "اقرأ المزيد", blog: "المدونة", latestArticles: "أحدث المقالات",
      offerEnds: "ينتهي العرض خلال", days: "يوم", hours: "ساعة", minutes: "دقيقة", seconds: "ثانية",
      installment: "ادفع عبر بنكيلي واحصل على خصم {percent}%", shippingCalc: "تُحسب رسوم الشحن حسب المدينة عند إتمام الطلب.",
      macbookNote: "macOS مثبت وجاهز للاستخدام", originalDevice: "جهاز أصلي 100%", warrantyMonths: "ضمان {months} شهرًا",
      chooseSpecs: "اختر المواصفات", personalization: "تخصيص الطلب", emptyCheckout: "لا يمكن إتمام الطلب", backToShop: "العودة للمتجر"
    },
    fr: {
      home: "Accueil", shop: "Boutique", allProducts: "Tous les produits", search: "Rechercher", account: "Mon compte", wishlist: "Favoris", cart: "Panier", checkout: "Commander",
      searchPlaceholder: "Rechercher iPhone, Galaxy, MacBook...", close: "Fermer", menu: "Menu", language: "Langue", currency: "Devise", noOrders: "Aucune commande pour le moment.", dark: "Mode sombre", light: "Mode clair",
      freeDelivery: "Livraison gratuite", returns: "Retour facile", warranty: "Garantie 12 mois", macos: "macOS installé", checked: "Vérifié par des experts",
      seeAll: "Voir tout", shopNow: "Découvrir", discover: "Découvrir", addToCart: "Ajouter au panier", buyNow: "Acheter maintenant", soldOut: "Épuisé",
      continueShopping: "Continuer mes achats", quickView: "Aperçu", addedToCart: "Ajouté au panier", removedWish: "Retiré des favoris", savedWish: "Ajouté aux favoris",
      popularNow: "Populaire en ce moment", resultsFor: "{count} résultat(s) pour « {q} »", noProducts: "Aucun produit", tryFilter: "Essayez un autre mot-clé ou filtre.", browseAll: "Voir tous les produits",
      sortBy: "Trier par", featured: "En vedette", priceLow: "Prix croissant", priceHigh: "Prix décroissant", biggestDiscount: "Meilleure réduction", nameAZ: "Nom A–Z",
      all: "Tout", onSale: "Promotions", loadMore: "Voir plus", product: "produit", products: "produits", collection: "Collection", searchResults: "Résultats de recherche",
      homeCrumb: "Accueil", reviews: "Avis", review: "avis", battery: "Batterie", condition: "État", quantity: "Quantité", description: "Description",
      shippingDelivery: "Livraison", warrantyReturns: "Garantie et retours", whatsIncluded: "Contenu du colis", faqs: "Questions fréquentes", related: "Produits similaires", youMayLike: "Vous aimerez aussi",
      freeDeliverySub: "Livraison offerte à Nouakchott", warrantySub: "Assurée par Restore", returnsSub: "En cas de problème", checkedSub: "50 points de contrôle avant la vente",
      paymentOffer: "Payez avec Bankily et obtenez 10 % de réduction", paymentOfferShort: "-10 % avec Bankily", orderWhatsApp: "Commander sur WhatsApp",
      customize: "Personnalisez votre commande", cpu: "Processeur", ram: "Mémoire RAM", storage: "Stockage", screen: "Taille d’écran", keyboard: "Clavier",
      trustedBy: "150 000+ clients nous font confiance", excellent: "Excellent", customers: "clients", basedOn: "Selon les avis clients",
      contactUs: "Contactez-nous", aboutUs: "À propos", information: "Informations", myAccount: "Mon compte", replyWithin: "Réponse sous un jour ouvré", workingHours: "Dimanche à jeudi, 9h00–19h00",
      allRights: "© {year} {store}. Tous droits réservés.", paymentMethods: "Moyens de paiement", followUs: "Suivez-nous",
      emptyCart: "Votre panier est vide", emptyCartText: "Ajoutez un appareil pour continuer.", emptyWish: "Votre liste de favoris est vide", emptyWishText: "Cliquez sur le cœur d’un produit pour l’enregistrer.",
      contactInfo: "Coordonnées", fullName: "Nom complet", email: "E-mail (facultatif)", phone: "Téléphone", city: "Ville", address: "Adresse complète", notes: "Notes (facultatif)",
      payment: "Paiement", coupon: "Code promo", apply: "Appliquer", subtotal: "Sous-total", shipping: "Livraison", discount: "Réduction", total: "Total", free: "Gratuite",
      placeOrder: "Finaliser sur WhatsApp", processing: "Préparation de votre commande...", required: "Veuillez remplir les champs obligatoires", invalidPhone: "Saisissez un numéro mauritanien valide (8 chiffres)",
      storeClosed: "La boutique est temporairement fermée. Revenez plus tard.", rateLimited: "Une commande récente a déjà été envoyée depuis ce numéro. Patientez un instant.", blockedPhone: "Impossible de finaliser. Contactez-nous sur WhatsApp.",
      orderReceived: "Commande enregistrée", orderReceivedText: "Vous allez être redirigé vers WhatsApp pour envoyer les détails et confirmer.", openWhatsApp: "Ouvrir WhatsApp", redirecting: "Redirection vers WhatsApp...",
      country: "Pays", orderSummary: "Récapitulatif", couponInvalid: "Code invalide ou expiré", couponApplied: "Code appliqué", whatsappTitle: "Commander sur WhatsApp", whatsappText: "Envoyez-nous les détails de votre commande, nous la confirmerons.",
      aboutStore: "Restore est une boutique mauritanienne d’électronique reconditionnée. Chaque appareil est contrôlé, garanti et livré dans toutes les wilayas.",
      newsletter: "Recevez nos nouveautés", newsletterPlaceholder: "Votre e-mail", subscribe: "S’abonner", subscribed: "Inscription confirmée",
      searchHint: "Recherchez un produit ou une marque", noResults: "Aucun résultat", popular: "Recherches populaires", clear: "Effacer",
      pageNotFound: "Page introuvable", productNotFound: "Produit introuvable", productNotFoundText: "Le produit est peut-être épuisé ou le lien est incorrect.", goHome: "Retour à l’accueil",
      loginDemo: "Connexion (démo)", signIn: "Se connecter", signOut: "Déconnexion", dashboardLogin: "Accès tableau de bord",
      addToWishlist: "Ajouter aux favoris", orderId: "N° de commande", writeReview: "Laisser un avis", verifiedBuyer: "Achat vérifié",
      login: "Connexion", logout: "Déconnexion", signedIn: "Connexion réussie", signedOut: "Déconnexion réussie",
      createAccount: "Créer un compte", accountCreated: "Votre compte est créé", loginFailed: "Connexion impossible", registerFailed: "Création du compte impossible", dashboardLoginNote: "Entrez votre e-mail et mot de passe du tableau de bord.",
      password: "Mot de passe", trackOrder: "Suivre ma commande", trackOrderText: "Entrez le numéro de commande ou votre téléphone pour voir l’état.",
      recentOrders: "Mes dernières commandes", orderNotFound: "Aucune commande correspondante.", myWishlist: "Mes favoris", viewWishlist: "Voir tous les favoris", myReviews: "Mes avis",
      reviewStatusPending: "En attente", reviewStatusApproved: "Publié", reviewStatusRejected: "Refusé",
      reviewPending: "Votre avis est arrivé à la boutique et sera publié après validation.", reviewIncomplete: "Complétez la note, le titre et le commentaire.",
      reviewSubmitted: "Merci ! Votre avis a été envoyé pour validation.", loginRequired: "Connectez-vous pour laisser un avis.",
      loginToReview: "Connectez-vous ou créez un compte pour évaluer ce produit.", noReviews: "Aucun avis pour le moment. Soyez le premier à donner votre avis.",
      rating: "Note", stars: "étoiles", title: "Titre", comment: "Commentaire",
      reviewTitlePlaceholder: "Résumé de votre expérience", reviewBodyPlaceholder: "Qu’avez-vous aimé ? État de l’appareil et service ?", submitReview: "Envoyer l’avis",
      closedTitle: "Boutique fermée", closedText: "Nous revenons bientôt. Contactez-nous sur WhatsApp.",
      timezone: "Heure de Nouakchott", viewAllReviews: "Tous les avis", readMore: "Lire la suite", blog: "Blog", latestArticles: "Derniers articles",
      offerEnds: "L’offre se termine dans", days: "j", hours: "h", minutes: "min", seconds: "s",
      installment: "Payez avec Bankily et obtenez {percent} % de réduction", shippingCalc: "Les frais de livraison sont calculés selon la ville lors de la commande.",
      macbookNote: "macOS installé et prêt à l’emploi", originalDevice: "Appareil 100 % original", warrantyMonths: "Garantie {months} mois",
      chooseSpecs: "Choisir les options", personalization: "Personnalisation", emptyCheckout: "Commande impossible", backToShop: "Retour à la boutique"
    }
  };

  const LANG_KEY = "lang";
  let lang = localStorage.getItem(LS_LANG) === "fr" ? "fr" : "ar";
  let theme = localStorage.getItem(LS_THEME) === "dark" ? "dark" : "light";

  function t(key, vars = {}) {
    let value = I18N[lang]?.[key] ?? I18N.ar[key] ?? key;
    for (const [k, v] of Object.entries(vars)) value = value.replaceAll(`{${k}}`, v);
    return value;
  }
  function L(value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    if (typeof value === "object") return value[lang] ?? value.ar ?? value.fr ?? "";
    return String(value);
  }
  function money(n) {
    return formatCurrency(n);
  }
  function formatDate(value, opts = { year: "numeric", month: "short", day: "numeric" }) {
    try { return new Intl.DateTimeFormat(lang === "ar" ? "ar-MR" : "fr-MR", opts).format(new Date(value)); }
    catch { return String(value || ""); }
  }

  function setLang(next) {
    lang = next === "fr" ? "fr" : "ar";
    localStorage.setItem(LS_LANG, lang);
    applyDocument();
    window.dispatchEvent(new CustomEvent("restore:lang", { detail: lang }));
  }
  function setTheme(next) {
    theme = next === "dark" ? "dark" : "light";
    localStorage.setItem(LS_THEME, theme);
    applyDocument();
  }

  // Professional font definitions
  const FONT_STACKS = {
    "Montserrat": '"Montserrat", "Noto Sans Arabic", system-ui, sans-serif',
    "Inter": '"Inter", "Noto Sans Arabic", system-ui, sans-serif',
    "Roboto": '"Roboto", "Noto Sans Arabic", system-ui, sans-serif',
    "Open Sans": '"Open Sans", "Noto Sans Arabic", system-ui, sans-serif',
    "Poppins": '"Poppins", "Noto Sans Arabic", system-ui, sans-serif',
    "Noto Sans": '"Noto Sans", "Noto Sans Arabic", system-ui, sans-serif',
    "Tajawal": '"Tajawal", "Noto Sans Arabic", system-ui, sans-serif',
    "Cairo": '"Cairo", "Noto Sans Arabic", system-ui, sans-serif',
    "Amiri": '"Amiri", "Noto Naskh Arabic", serif',
    "System UI": 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Arabic", sans-serif'
  };

  function applyDocument() {
    const html = document.documentElement;
    const dashboard = document.body?.dataset.page === "dashboard";
    if (!dashboard) {
      html.lang = lang;
      html.dir = lang === "ar" ? "rtl" : "ltr";
      html.dataset.lang = lang;
    }
    html.dataset.theme = theme;
    const colors = state.settings.colors || {};
    if (colors.primary) html.style.setProperty("--orange", colors.primary);
    if (colors.ink && theme !== "dark") html.style.setProperty("--ink", colors.ink);
    else html.style.removeProperty("--ink");
    if (colors.purple) html.style.setProperty("--purple", colors.purple);
    if (colors.lavender && theme !== "dark") html.style.setProperty("--lav", colors.lavender);
    else html.style.removeProperty("--lav");
    if (state.settings.radius != null) html.style.setProperty("--radius", `${state.settings.radius}px`);
    const font = state.settings.font || "Montserrat";
    const fontStack = FONT_STACKS[font] || FONT_STACKS["Montserrat"];
    html.style.setProperty("--font-main", fontStack);
  }

  const savedState = readJSON(LS_STATE, null);
  let state = hydrate(savedState);
  let draft = null;
  {
    const savedDraft = readJSON(LS_DRAFT, null);
    if (savedDraft) draft = hydrate(savedDraft);
  }
  const startedAt = Date.now();
  const channel = "BroadcastChannel" in window ? new BroadcastChannel(SYNC_CHANNEL) : null;

  /* ------------------------------------------------------------------------
     Utilities shared by auth, reviews and media
     ------------------------------------------------------------------------ */
  const normalizeEmail = (value) => String(value || "").trim().toLowerCase();
  const normalizeDigits = (value) => String(value || "").replace(/\D/g, "");
  const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(normalizeEmail(value));
  const uniqueStrings = (list) => [...new Set((Array.isArray(list) ? list : []).map((item) => String(item || "").trim()).filter(Boolean))];

  function safeHref(value, fallback = "#") {
    const raw = String(value ?? "").trim();
    if (!raw) return fallback;
    if (raw.startsWith("#") || raw.startsWith("/")) return raw;
    try {
      const parsed = new URL(raw, location.href);
      if (["http:", "https:", "mailto:", "tel:"].includes(parsed.protocol)) return raw;
    } catch {}
    return fallback;
  }

  function bytesToHex(buffer) {
    return [...new Uint8Array(buffer)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function hexToBytes(hex) {
    const clean = String(hex || "").replace(/[^0-9a-f]/gi, "");
    const out = new Uint8Array(clean.length / 2);
    for (let index = 0; index < out.length; index += 1) out[index] = parseInt(clean.slice(index * 2, index * 2 + 2), 16);
    return out;
  }
  function weakHash(text) {
    let hash = 0x811c9dc5;
    const value = String(text || "");
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return `weak$${hash.toString(16)}$${value.length}`;
  }
  async function hashPassword(password) {
    const plain = String(password || "");
    if (!window.crypto?.subtle) return weakHash(`${SALT}${plain}`);
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(plain), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: 150000, hash: "SHA-256" }, key, 256);
    return `pbkdf2$150000$${bytesToHex(salt)}$${bytesToHex(bits)}`;
  }
  async function verifyPassword(password, stored) {
    const plain = String(password || "");
    const marker = String(stored || "");
    if (!marker) return false;
    if (marker.startsWith("weak$")) return marker === weakHash(`${SALT}${plain}`);
    if (!marker.startsWith("pbkdf2$")) return false;
    if (!window.crypto?.subtle) return false;
    const [, iterations, saltHex, digestHex] = marker.split("$");
    try {
      const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(plain), "PBKDF2", false, ["deriveBits"]);
      const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: hexToBytes(saltHex), iterations: Number(iterations) || 150000, hash: "SHA-256" }, key, 256);
      const expected = hexToBytes(digestHex);
      const actual = new Uint8Array(bits);
      if (expected.length !== actual.length) return false;
      let diff = 0;
      for (let index = 0; index < actual.length; index += 1) diff |= actual[index] ^ expected[index];
      return diff === 0;
    } catch {
      return false;
    }
  }
  function validatePassword(password) {
    const value = String(password || "");
    if (value.length < 8) throw new Error("كلمة المرور يجب أن تكون 8 أحرف على الأقل / 8 caractères minimum");
    if (value.length > 128) throw new Error("كلمة المرور طويلة جدًا");
    if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) throw new Error("كلمة المرور يجب أن تحتوي على حروف وأرقام / Lettres et chiffres requis");
    return value;
  }

  /* ------------------------------------------------------------------------
     Managers and staff sessions
     ------------------------------------------------------------------------ */
  function demoAccount(owner) {
    return {
      id: owner ? "m_owner" : "m_manager",
      username: owner ? "owner" : "manager",
      email: owner ? "owner@restore.local" : "manager@restore.local",
      name: owner ? txt("مالك المتجر (تجريبي)", "Propriétaire (démo)") : txt("مدير المتجر (تجريبي)", "Gérant (démo)"),
      displayName: owner ? txt("المالك", "Propriétaire") : txt("المدير", "Gérant"),
      role: owner ? "owner" : "manager",
      passwordHash: "",
      mustChange: true,
      whatsapp: "",
      avatar: ""
    };
  }
  const DEFAULT_MANAGERS = DEMO_ALLOWED ? [demoAccount(true), demoAccount(false)] : [];

  const savedManagers = readJSON(LS_MANAGERS, null);
  let managers = Array.isArray(savedManagers) && savedManagers.length ? savedManagers : clone(DEFAULT_MANAGERS);
  if (!REMOTE && !DEMO_ALLOWED && Array.isArray(managers) && managers.length) {
    // Production/local-secure mode: never keep passwordless demo accounts.
    managers = managers.filter((m) => m && m.passwordHash);
    if (!managers.length) localStorage.removeItem(LS_MANAGERS);
    else writeJSON(LS_MANAGERS, managers);
  }
  let session = readJSON(LS_SESSION, null);
  if (session?.mode === "local" && !DEMO_ALLOWED && !REMOTE) { session = null; localStorage.removeItem(LS_SESSION); }
  let customerAuth = readJSON(LS_CUSTOMER_SESSION, null);
  let currentCustomer = readJSON(LS_CUSTOMER, null);
  let reviewCache = [];

  function managerById(id) {
    return managers.find((item) => item.id === id) || null;
  }
  function managerByIdentifier(identifier) {
    const needle = String(identifier || "").trim().toLowerCase();
    if (!needle) return null;
    return managers.find((item) => [item.username, item.email, item.id].filter(Boolean).some((value) => String(value).toLowerCase() === needle)) || null;
  }
  function managerPublic() {
    return managers.map(({ passwordHash, ...item }) => clone(item));
  }
  function saveManagers() {
    writeJSON(LS_MANAGERS, managers);
  }
  async function createLocalManagerPassword(manager, password) {
    if (!manager) return false;
    if (!DEMO_ALLOWED && !REMOTE) throw new Error("الوضع التجريبي المحلي غير مفعّل. فعّل demoEnabled على localhost فقط أو استخدم Supabase.");
    validatePassword(password);
    manager.passwordHash = await hashPassword(password);
    manager.mustChange = false;
    saveManagers();
    return true;
  }
  async function verifyManagerPassword(manager, password) {
    if (!manager) return false;
    if (manager.passwordHash) return verifyPassword(password, manager.passwordHash);
    if (DEMO_ALLOWED && manager.mustChange && String(password || "").length >= 8) {
      // First local demo setup: user chooses the password (never shipped in code).
      await createLocalManagerPassword(manager, password);
      return true;
    }
    return false;
  }
  async function upgradeDemoHash(manager, password) {
    if (!manager || manager.passwordHash) return;
    manager.passwordHash = await hashPassword(password);
    saveManagers();
  }

  function attemptStore() {
    return readJSON(LS_LOGIN_ATTEMPTS, {});
  }
  function checkLoginLock(identifier) {
    const key = normalizeEmail(identifier);
    const record = attemptStore()[key];
    if (!record) return;
    if (Number(record.lockedUntil || 0) > Date.now()) {
      const minutes = Math.max(1, Math.ceil((record.lockedUntil - Date.now()) / 60000));
      throw new Error(`تم إيقاف المحاولات مؤقتًا. أعد المحاولة بعد ${minutes} دقيقة / Trop de tentatives. Réessayez dans ${minutes} min`);
    }
  }
  function noteLoginFailure(identifier) {
    const key = normalizeEmail(identifier);
    const store = attemptStore();
    const record = store[key] || { count: 0, firstAt: Date.now(), lockedUntil: 0 };
    if (Date.now() - Number(record.firstAt || 0) > 15 * 60000) {
      record.count = 0;
      record.firstAt = Date.now();
      record.lockedUntil = 0;
    }
    record.count = Number(record.count || 0) + 1;
    if (record.count >= 5) {
      record.lockedUntil = Date.now() + 5 * 60000;
      record.count = 0;
      record.firstAt = Date.now();
    }
    store[key] = record;
    const keys = Object.keys(store).slice(-30);
    writeJSON(LS_LOGIN_ATTEMPTS, Object.fromEntries(keys.map((item) => [item, store[item]])));
  }
  function clearLoginFailures(identifier) {
    const store = attemptStore();
    delete store[normalizeEmail(identifier)];
    writeJSON(LS_LOGIN_ATTEMPTS, store);
  }

  function localSessionFor(manager) {
    return {
      mode: "local",
      id: manager.id,
      username: manager.username,
      email: manager.email || "",
      role: manager.role === "owner" ? "owner" : "manager",
      name: L(manager.name || manager.displayName || manager.username),
      mustChange: Boolean(manager.mustChange),
      loggedAt: Date.now(),
      expiresAt: Date.now() + 12 * 3600 * 1000
    };
  }
  function persistSession(next) {
    session = next;
    if (next) writeJSON(LS_SESSION, next);
    else localStorage.removeItem(LS_SESSION);
  }

  function staffEmailFor(identifier) {
    const value = String(identifier || "").trim();
    if (isEmail(value)) return normalizeEmail(value);
    const lower = value.toLowerCase();
    if (DEMO_ALLOWED && (lower === "owner" || lower === "manager")) return `${lower}@restore.local`;
    return `${lower}@restore.mr`;
  }

  async function remoteLogin(identifier, password) {
    const email = staffEmailFor(identifier);
    const res = await fetch(remoteUrl("/auth/v1/token?grant_type=password"), {
      method: "POST",
      headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) throw new Error("بيانات الدخول غير صحيحة / Identifiants incorrects");
    const data = await res.json();
    const token = data.access_token;
    if (!token || !data.user) throw new Error("تعذر إنشاء جلسة الدخول");
    const rows = await supa(`/rest/v1/${CFG.staffTable}?auth_id=eq.${encodeURIComponent(data.user.id)}&select=*`, {}, { token });
    const staff = Array.isArray(rows) ? rows[0] : null;
    if (!staff || staff.active === false) {
      throw new Error("هذا الحساب لا يملك صلاحية دخول لوحة التحكم. راجع مالك المتجر. / Compte non autorisé.");
    }
    const next = {
      mode: "supabase",
      id: staff.id,
      authId: data.user.id,
      username: staff.email || data.user.email,
      email: staff.email || data.user.email,
      role: staff.role === "owner" ? "owner" : "manager",
      name: L(staff.name || data.user.user_metadata?.full_name || data.user.email),
      mustChange: Boolean(staff.must_change_password ?? data.user.user_metadata?.must_change_password),
      accessToken: token,
      refreshToken: data.refresh_token,
      expiresAt: Date.now() + (Number(data.expires_in) || 3600) * 1000,
      loggedAt: Date.now()
    };
    persistSession(next);
    managers = [normalizeStaffRow(staff)];
    refreshStaff().catch(() => {});
    return session;
  }

  async function login(identifier, password) {
    const value = String(identifier || "").trim();
    if (!value || !password) throw new Error("أدخل البريد/اسم المستخدم وكلمة المرور");
    if (!REMOTE && !DEMO_ALLOWED) {
      throw new Error("الوضع المحلي الآمن يتطلب Supabase. للتجربة المحلية فقط: شغّل على localhost واضبط demoEnabled:true في config.js / Mode démo local désactivé.");
    }
    checkLoginLock(value);
    try {
      if (REMOTE) {
        const result = await remoteLogin(value, password);
        clearLoginFailures(value);
        return result;
      }
      let manager = managerByIdentifier(value);
      if (!manager && DEMO_ALLOWED) {
        const lower = value.toLowerCase();
        if (lower === "owner" || lower === "manager") {
          managers = managers.length ? managers : clone(DEFAULT_MANAGERS);
          manager = managerByIdentifier(value);
        }
      }
      if (!manager) throw new Error("اسم المستخدم أو البريد غير موجود / Utilisateur introuvable");
      if (!(await verifyManagerPassword(manager, password))) throw new Error("كلمة المرور غير صحيحة / Mot de passe incorrect");
      await upgradeDemoHash(manager, password);
      persistSession(localSessionFor(manager));
      clearLoginFailures(value);
      return session;
    } catch (error) {
      noteLoginFailure(value);
      throw error;
    }
  }

  function currentSession() {
    if (!session) return null;
    if (session.expiresAt && Number(session.expiresAt) <= Date.now() && session.mode === "local") {
      logout();
      return null;
    }
    return session;
  }
  function logout() {
    persistSession(null);
    window.dispatchEvent(new CustomEvent("restore:logout"));
  }

  function normalizeStaffRow(row) {
    if (!row) return null;
    return {
      id: row.id,
      authId: row.auth_id || "",
      username: row.email || "",
      email: row.email || "",
      name: row.name || txt(row.email || "", row.email || ""),
      role: row.role === "owner" ? "owner" : "manager",
      whatsapp: row.whatsapp || "",
      avatar: row.avatar || "",
      active: row.active !== false,
      mustChange: Boolean(row.must_change_password),
      createdAt: row.created_at || "",
      updatedAt: row.updated_at || ""
    };
  }

  async function refreshStaff() {
    if (!REMOTE || session?.mode !== "supabase") return managerPublic();
    if (!(await remoteSessionValid())) return managerPublic();
    const rows = await supa(`/rest/v1/${CFG.staffTable}?select=*&order=created_at.asc`, {}, true);
    if (Array.isArray(rows) && rows.length) {
      managers = rows.map(normalizeStaffRow).filter(Boolean);
      saveManagers();
      window.dispatchEvent(new CustomEvent("restore:staff"));
    }
    return managerPublic();
  }

  async function addManager(data = {}) {
    if (session && session.role !== "owner") throw new Error("إضافة الحسابات متاحة للمالك فقط / Réservé au propriétaire");
    const role = data.role === "owner" ? "owner" : "manager";
    const name = {
      ar: String(data.nameAr || data.name || "").trim() || String(data.email || data.username || "").trim(),
      fr: String(data.nameFr || data.name || "").trim() || String(data.email || data.username || "").trim()
    };
    const whatsapp = normalizeDigits(data.whatsapp || "");
    validatePassword(data.password || "");
    if (whatsapp && ![8, 11].includes(whatsapp.length)) throw new Error("رقم واتساب غير صالح");

    if (REMOTE) {
      if (session?.mode !== "supabase" || session.role !== "owner") throw new Error("إضافة الحسابات متاحة للمالك فقط");
      const email = normalizeEmail(data.email || data.username);
      if (!isEmail(email)) throw new Error("أدخل بريدًا إلكترونيًا صالحًا للمدير");
      const res = await fetch(remoteUrl(`/functions/v1/${encodeURIComponent(CFG.createStaffFunction || "admin-create-staff")}`), {
        method: "POST",
        headers: {
          apikey: CFG.supabaseAnonKey,
          Authorization: `Bearer ${session.accessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password: data.password, name, role, whatsapp })
      });
      if (res.status === 404) throw new Error("دالة إنشاء المديرين غير منشورة. راجع supabase/README.md لنشر admin-create-staff.");
      if (!res.ok) {
        const message = await readErrorMessage(res);
        throw new Error(message || "تعذر إنشاء حساب المدير");
      }
      await refreshStaff();
      addAudit(`أضاف مديرًا: ${email}`, session.email);
      return managers.find((item) => item.email === email) || null;
    }

    const username = String(data.username || data.email || "").trim().toLowerCase();
    if (!/^[a-z0-9._@-]{3,64}$/.test(username)) throw new Error("اسم المستخدم أو البريد غير صالح");
    if (managers.some((item) => [item.username, item.email].filter(Boolean).some((value) => String(value).toLowerCase() === username))) {
      throw new Error("اسم المستخدم مستخدم بالفعل");
    }
    const manager = {
      id: uid("m"),
      username,
      email: isEmail(username) ? username : "",
      name,
      displayName: name,
      role,
      passwordHash: await hashPassword(data.password),
      mustChange: true,
      whatsapp,
      avatar: ""
    };
    managers.push(manager);
    saveManagers();
    addAudit(`أضاف مديرًا: ${username}`, session?.username);
    return manager;
  }

  function updateManager(id, patch = {}) {
    const index = managers.findIndex((item) => item.id === id);
    if (index < 0) throw new Error("الحساب غير موجود");
    if (session && session.role !== "owner") {
      const isSelf = session.id === id || session.username === managers[index].username;
      if (!isSelf) throw new Error("تعديل الحسابات الأخرى متاح للمالك فقط");
      patch = { ...patch };
      delete patch.role;
      delete patch.mustChange;
      delete patch.active;
    }
    if (managers[index].role === "owner" && patch.role && patch.role !== "owner" && managers.filter((item) => item.role === "owner").length <= 1) {
      throw new Error("لا يمكن إزالة صلاحية المالك الوحيد");
    }
    managers[index] = {
      ...managers[index],
      ...patch,
      name: patch.name || managers[index].name,
      role: patch.role === "owner" ? "owner" : patch.role === "manager" ? "manager" : managers[index].role,
      mustChange: patch.mustChange != null ? Boolean(patch.mustChange) : managers[index].mustChange
    };
    saveManagers();
    if (REMOTE && session?.mode === "supabase") {
      const body = {};
      if (patch.name) body.name = patch.name;
      if (patch.role) body.role = patch.role === "owner" ? "owner" : "manager";
      if (patch.whatsapp != null) body.whatsapp = normalizeDigits(patch.whatsapp);
      if (patch.mustChange != null) body.must_change_password = Boolean(patch.mustChange);
      if (patch.active != null) body.active = Boolean(patch.active);
      if (patch.avatar != null) body.avatar = String(patch.avatar);
      if (Object.keys(body).length) {
        supa(`/rest/v1/${CFG.staffTable}?id=eq.${encodeURIComponent(id)}`, {
          method: "PATCH",
          body: JSON.stringify(body),
          headers: { Prefer: "return=minimal" }
        }, true).catch((error) => {
          console.warn("Restore: staff update failed", error);
          refreshStaff().catch(() => {});
        });
      }
    }
    return managers[index];
  }

  function deleteManager(id) {
    if (session && session.role !== "owner") throw new Error("حذف الحسابات متاح للمالك فقط / Réservé au propriétaire");
    const manager = managers.find((item) => item.id === id);
    if (!manager) return;
    if (manager.role === "owner" && managers.filter((item) => item.role === "owner").length <= 1) throw new Error("لا يمكن حذف المالك الوحيد");
    managers = managers.filter((item) => item.id !== id);
    saveManagers();
    if (REMOTE && session?.mode === "supabase") {
      supa(`/rest/v1/${CFG.staffTable}?id=eq.${encodeURIComponent(id)}`, { method: "DELETE" }, true).catch((error) => {
        console.warn("Restore: staff delete failed", error);
        refreshStaff().catch(() => {});
      });
    }
    addAudit(`حذف مديرًا: ${manager.username}`, session?.username);
  }

  async function changePassword(username, currentPassword, newPassword, whatsapp) {
    validatePassword(newPassword);
    if (String(currentPassword) === String(newPassword)) throw new Error("اختر كلمة مرور مختلفة عن الحالية");
    const cleanWhatsapp = normalizeDigits(whatsapp || "");
    if (cleanWhatsapp && ![8, 11].includes(cleanWhatsapp.length)) throw new Error("رقم واتساب غير صالح");

    if (REMOTE) {
      if (session?.mode !== "supabase" || !session.email) throw new Error("سجّل الدخول أولًا");
      const check = await fetch(remoteUrl("/auth/v1/token?grant_type=password"), {
        method: "POST",
        headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
        body: JSON.stringify({ email: session.email, password: currentPassword })
      });
      if (!check.ok) throw new Error("كلمة المرور الحالية غير صحيحة");
      const res = await fetch(remoteUrl("/auth/v1/user"), {
        method: "PUT",
        headers: { apikey: CFG.supabaseAnonKey, Authorization: `Bearer ${session.accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify({ password: newPassword, data: { must_change_password: false } })
      });
      if (!res.ok) throw new Error(await readErrorMessage(res) || "تعذر تحديث كلمة المرور");
      await supa(`/rest/v1/${CFG.staffTable}?auth_id=eq.${encodeURIComponent(session.authId)}`, {
        method: "PATCH",
        body: JSON.stringify({ must_change_password: false, whatsapp: cleanWhatsapp }),
        headers: { Prefer: "return=minimal" }
      }, true).catch(() => {});
      const own = managers.find((item) => item.id === session.id || item.email === session.email);
      if (own) {
        own.mustChange = false;
        if (cleanWhatsapp) own.whatsapp = cleanWhatsapp;
        saveManagers();
      }
      persistSession({ ...session, mustChange: false });
    } else {
      const manager = managerByIdentifier(username) || managerById(session?.id);
      if (!manager) throw new Error("المستخدم غير موجود");
      if (!(await verifyManagerPassword(manager, currentPassword))) throw new Error("كلمة المرور الحالية غير صحيحة");
      manager.passwordHash = await hashPassword(newPassword);
      manager.mustChange = false;
      if (cleanWhatsapp) manager.whatsapp = cleanWhatsapp;
      saveManagers();
      persistSession({ ...(session || localSessionFor(manager)), mustChange: false });
    }

    if (cleanWhatsapp) {
      const phone = cleanWhatsapp.length === 8 ? `+222${cleanWhatsapp}` : `+${cleanWhatsapp}`;
      try {
        await updateOwnerSettings({ whatsapp: cleanWhatsapp, phone, phoneDisplay: formatPhone(phone) });
      } catch (error) {
        console.warn("Restore: could not update store WhatsApp", error);
      }
    }
    addAudit("غيّر كلمة المرور", session?.username);
    return session;
  }

  function changeOwnerPassword(currentPassword, newPassword) {
    return changePassword(session?.username || "owner", currentPassword, newPassword, "");
  }

  /* ------------------------------------------------------------------------
     Supabase REST helpers
     ------------------------------------------------------------------------ */
  function remoteUrl(path) {
    return `${String(CFG.supabaseUrl || "").replace(/\/$/, "")}${path}`;
  }
  async function readErrorMessage(res) {
    const text = await res.text().catch(() => "");
    if (!text) return "";
    try {
      const parsed = JSON.parse(text);
      return parsed.msg || parsed.message || parsed.error_description || parsed.error || text.slice(0, 180);
    } catch {
      return text.slice(0, 180);
    }
  }
  async function remoteSessionValid() {
    if (!REMOTE || !session || session.mode !== "supabase" || !session.accessToken) return false;
    if (!session.expiresAt || Number(session.expiresAt) > Date.now() + 45000) return true;
    if (!session.refreshToken) return false;
    try {
      const res = await fetch(remoteUrl("/auth/v1/token?grant_type=refresh_token"), {
        method: "POST",
        headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: session.refreshToken })
      });
      if (!res.ok) return false;
      const data = await res.json();
      persistSession({
        ...session,
        accessToken: data.access_token,
        refreshToken: data.refresh_token || session.refreshToken,
        expiresAt: Date.now() + (Number(data.expires_in) || 3600) * 1000
      });
      return true;
    } catch {
      return false;
    }
  }
  async function supa(path, options = {}, auth = false) {
    if (!REMOTE) throw new Error("Supabase is not configured");
    const request = { ...options, headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json", ...(options.headers || {}) } };
    let token = null;
    if (auth === true) {
      if (await remoteSessionValid()) token = session?.accessToken;
      else throw new Error("انتهت جلسة لوحة التحكم. سجّل الدخول مجددًا.");
    } else if (auth && auth.token) {
      token = auth.token;
    }
    if (token) request.headers.Authorization = `Bearer ${token}`;
    const res = await fetch(remoteUrl(path), request);
    if (!res.ok) {
      const message = await readErrorMessage(res);
      throw new Error(message || `Supabase ${res.status}`);
    }
    if (res.status === 204) return null;
    return res.json().catch(() => null);
  }

  function customerTokenExpiring() {
    return !customerAuth?.accessToken || !customerAuth?.expiresAt || Number(customerAuth.expiresAt) <= Date.now() + 45000;
  }
  async function refreshCustomerToken() {
    if (!REMOTE || !customerAuth?.refreshToken) return false;
    try {
      const res = await fetch(remoteUrl("/auth/v1/token?grant_type=refresh_token"), {
        method: "POST",
        headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: customerAuth.refreshToken })
      });
      if (!res.ok) return false;
      const data = await res.json();
      customerAuth = {
        ...customerAuth,
        accessToken: data.access_token,
        refreshToken: data.refresh_token || customerAuth.refreshToken,
        expiresAt: Date.now() + (Number(data.expires_in) || 3600) * 1000
      };
      writeJSON(LS_CUSTOMER_SESSION, customerAuth);
      return true;
    } catch {
      return false;
    }
  }
  async function supaCustomer(path, options = {}) {
    if (!REMOTE || !customerAuth?.accessToken) throw new Error("سجّل الدخول بحساب العميل أولًا");
    if (customerTokenExpiring() && !(await refreshCustomerToken())) throw new Error("انتهت جلسة العميل. أعد تسجيل الدخول.");
    const request = { ...options, headers: { apikey: CFG.supabaseAnonKey, Authorization: `Bearer ${customerAuth.accessToken}`, "Content-Type": "application/json", ...(options.headers || {}) } };
    let res = await fetch(remoteUrl(path), request);
    if (res.status === 401 && await refreshCustomerToken()) {
      request.headers.Authorization = `Bearer ${customerAuth.accessToken}`;
      res = await fetch(remoteUrl(path), request);
    }
    if (!res.ok) throw new Error(await readErrorMessage(res) || `Supabase ${res.status}`);
    if (res.status === 204) return null;
    return res.json().catch(() => null);
  }

  async function uploadMedia(dataUrl, folder = "uploads") {
    if (!REMOTE) return null;
    if (!(await remoteSessionValid())) throw new Error("انتهت جلسة Supabase. أعد تسجيل الدخول.");
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    const allowed = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif" };
    const extension = allowed[blob.type];
    if (!extension) throw new Error("صيغة الصورة غير مدعومة. استخدم PNG أو JPG أو WebP أو GIF.");
    if (blob.size > 5 * 1024 * 1024) throw new Error("الصورة أكبر من 5MB");
    const stamp = new Date().toISOString().slice(0, 10);
    const id = crypto.randomUUID ? crypto.randomUUID() : uid("img");
    const safeFolder = String(folder || "uploads").replace(/[^a-z0-9/_-]/gi, "").slice(0, 80) || "uploads";
    const objectPath = `${safeFolder}/${stamp}/${id}.${extension}`;
    const res = await fetch(remoteUrl(`/storage/v1/object/${encodeURIComponent(CFG.mediaBucket)}/${objectPath.split("/").map(encodeURIComponent).join("/")}`), {
      method: "POST",
      headers: {
        apikey: CFG.supabaseAnonKey,
        Authorization: `Bearer ${session.accessToken}`,
        "Content-Type": blob.type,
        "x-upsert": "false"
      },
      body: blob
    });
    if (!res.ok) throw new Error(await readErrorMessage(res) || `Storage ${res.status}`);
    return remoteUrl(`/storage/v1/object/public/${encodeURIComponent(CFG.mediaBucket)}/${objectPath.split("/").map(encodeURIComponent).join("/")}`);
  }

  function resizeImage(file, maxDimension = 1400, quality = 0.86) {
    return new Promise((resolve, reject) => {
      if (!file) return reject(new Error("لم يتم اختيار صورة"));
      if (!/^image\//.test(file.type || "")) return reject(new Error("الملف ليس صورة صالحة"));
      if (file.size > 10 * 1024 * 1024) return reject(new Error("الصورة أكبر من 10MB"));
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("تعذر قراءة الصورة"));
      reader.onload = () => {
        if (file.type === "image/svg+xml") {
          resolve(String(reader.result || ""));
          return;
        }
        const image = new Image();
        image.onerror = () => reject(new Error("صورة غير صالحة"));
        image.onload = () => {
          try {
            const max = Math.max(200, Number(maxDimension) || 1400);
            const scale = Math.min(1, max / Math.max(image.width || 1, image.height || 1));
            const canvas = document.createElement("canvas");
            canvas.width = Math.max(1, Math.round((image.width || 1) * scale));
            canvas.height = Math.max(1, Math.round((image.height || 1) * scale));
            const context = canvas.getContext("2d");
            if (!context) throw new Error("تعذر تجهيز الصورة");
            context.drawImage(image, 0, 0, canvas.width, canvas.height);
            resolve(canvas.toDataURL("image/webp", Math.min(0.95, Math.max(0.6, Number(quality) || 0.86))));
          } catch (error) {
            reject(error);
          }
        };
        image.src = String(reader.result || "");
      };
      reader.readAsDataURL(file);
    });
  }

  /* ------------------------------------------------------------------------
     Orders, abandoned carts and audit
     ------------------------------------------------------------------------ */
  function notifyOrders() {
    channel?.postMessage({ type: "orders" });
    window.dispatchEvent(new CustomEvent("restore:orders"));
  }
  function getOrders() {
    const list = readJSON(LS_ORDERS, []);
    return Array.isArray(list) ? list : [];
  }
  function saveOrders(orders, broadcast = true) {
    writeJSON(LS_ORDERS, Array.isArray(orders) ? orders : []);
    if (broadcast) notifyOrders();
  }
  function getCustomerOrders() {
    const customer = currentCustomer;
    if (!customer) return [];
    const phone = normalizeDigits(customer.phone || "").slice(-8);
    const email = normalizeEmail(customer.email || "");
    return getOrders().filter((order) => {
      const orderPhone = normalizeDigits(order.customer?.phone || "").slice(-8);
      const orderEmail = normalizeEmail(order.customer?.email || "");
      return (customer.authId && order.customerAuthId === customer.authId) ||
        (customer.id && order.customerId === customer.id) ||
        (phone && orderPhone === phone) ||
        (email && orderEmail === email);
    });
  }
  async function submitOrder(order) {
    if (!order) throw new Error("طلب غير صالح");
    // Prefer server-side validation when an Edge Function is configured.
    if (REMOTE && CFG.createOrderFunction) {
      try {
        const res = await fetch(remoteUrl(`/functions/v1/${CFG.createOrderFunction}`), {
          method: "POST",
          headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
          body: JSON.stringify({ order })
        });
        const payload = await res.json().catch(() => ({}));
        if (res.ok && payload?.ok && payload?.order) {
          const next = normalizeRemoteOrder({ id: payload.order.id, data: payload.order, status: payload.order.status, created_at: payload.order.createdAt, updated_at: payload.order.updatedAt }) || payload.order;
          const orders = getOrders().filter((o) => o.id !== next.id);
          orders.unshift(next);
          saveOrders(orders);
          return next;
        }
        if (res.status >= 400 && res.status < 500) {
          throw new Error(payload?.error || "تعذر التحقق من الطلب على الخادم");
        }
        console.warn("Restore: secure order function unavailable, falling back to client flow", payload?.error || res.status);
      } catch (error) {
        if (String(error?.message || "").includes("التحقق من الطلب")) throw error;
        console.warn("Restore: secure order function error", error);
      }
    }
    // Fallback: local/client-side order (demo or when edge function is not deployed).
    return addOrder({ ...order, serverValidated: false, validationMode: REMOTE ? "client-fallback" : "local-demo" });
  }

  function addOrder(order) {
    if (!order || !order.id) throw new Error("طلب غير صالح");
    const next = { ...order, updatedAt: nowISO() };
    if (currentCustomer) {
      next.customerId = currentCustomer.id || "";
      next.customerAuthId = customerAuth?.user?.id || currentCustomer.authId || "";
    }
    const orders = getOrders();
    orders.unshift(next);
    saveOrders(orders);
    if (REMOTE) {
      supa(`/rest/v1/${CFG.ordersTable}`, {
        method: "POST",
        body: JSON.stringify({
          id: next.id,
          data: next,
          status: next.status || "new",
          customer_id: next.customerAuthId || null,
          created_at: next.createdAt || nowISO(),
          updated_at: next.updatedAt
        }),
        headers: { Prefer: "resolution=merge-duplicates,return=minimal" }
      }).catch((error) => console.warn("Restore: remote order failed", error));
    }
    return next;
  }
  function updateOrder(id, patch) {
    const orders = getOrders().map((order) => order.id === id ? { ...order, ...patch, updatedAt: nowISO() } : order);
    saveOrders(orders);
    const updated = orders.find((order) => order.id === id) || null;
    if (REMOTE && updated) {
      supa(`/rest/v1/${CFG.ordersTable}?id=eq.${encodeURIComponent(id)}`, {
        method: "PATCH",
        body: JSON.stringify({ data: updated, status: updated.status, updated_at: updated.updatedAt }),
        headers: { Prefer: "return=minimal" }
      }, true).catch((error) => console.warn("Restore: order update failed", error));
    }
    return updated;
  }

  function normalizeRemoteOrder(row) {
    if (!row) return null;
    const data = row.data && typeof row.data === "object" ? clone(row.data) : {};
    data.id = data.id || row.id;
    data.status = data.status || row.status || "new";
    data.createdAt = data.createdAt || row.created_at || nowISO();
    data.updatedAt = data.updatedAt || row.updated_at || data.createdAt;
    if (row.customer_id) data.customerAuthId = row.customer_id;
    return data;
  }
  async function refreshOrders() {
    if (!REMOTE) return getOrders();
    let rows = null;
    try {
      if (session?.mode === "supabase" && await remoteSessionValid()) {
        rows = await supa(`/rest/v1/${CFG.ordersTable}?select=*&order=created_at.desc&limit=1000`, {}, true);
      } else if (customerAuth?.accessToken) {
        if (customerTokenExpiring() && !(await refreshCustomerToken())) return getOrders();
        const uidValue = customerAuth.user?.id;
        if (!uidValue) return getOrders();
        rows = await supa(`/rest/v1/${CFG.ordersTable}?customer_id=eq.${encodeURIComponent(uidValue)}&select=*&order=created_at.desc&limit=300`);
      }
    } catch (error) {
      console.warn("Restore: order refresh failed", error);
      return getOrders();
    }
    if (!Array.isArray(rows) || !rows.length) return getOrders();
    const local = getOrders();
    const map = new Map(local.map((order) => [order.id, order]));
    let changed = false;
    rows.map(normalizeRemoteOrder).filter(Boolean).forEach((remoteOrder) => {
      const existing = map.get(remoteOrder.id);
      if (!existing || Date.parse(remoteOrder.updatedAt || 0) > Date.parse(existing.updatedAt || 0)) {
        map.set(remoteOrder.id, remoteOrder);
        changed = true;
      }
    });
    if (changed) saveOrders([...map.values()]);
    return getOrders();
  }

  function getAbandoned() {
    const rows = readJSON(LS_ABANDONED, []);
    return Array.isArray(rows) ? rows : [];
  }
  function abandonedToken() {
    const key = "restore_abandoned_token_v1";
    let token = localStorage.getItem(key);
    if (!token) { token = uid("tok"); localStorage.setItem(key, token); }
    return token;
  }
  function saveAbandoned(entry) {
    const rows = getAbandoned();
    const phone = normalizeDigits(entry.phone);
    const existing = rows.find((item) => normalizeDigits(item.phone) === phone && item.status === "open" && phone);
    if (existing) Object.assign(existing, entry, { updatedAt: nowISO(), cartToken: abandonedToken() });
    else rows.unshift({ id: phone ? `ab_${phone.slice(-8)}` : `ab_${Date.now()}`, createdAt: nowISO(), status: "open", cartToken: abandonedToken(), ...entry });
    writeJSON(LS_ABANDONED, rows.slice(0, 100));
    channel?.postMessage({ type: "abandoned" });
    if (REMOTE && phone) {
      const row = rows.find((item) => normalizeDigits(item.phone) === phone && item.status === "open");
      const payload = { id: row.id, data: row, cart_token: row.cartToken || abandonedToken(), created_at: row.createdAt, updated_at: row.updatedAt || nowISO() };
      // Insert-only for anon safety (no public update permission). Ignore duplicates.
      supa(`/rest/v1/${CFG.abandonedTable}`, {
        method: "POST",
        body: JSON.stringify(payload),
        headers: { Prefer: "resolution=ignore-duplicates,return=minimal" }
      }).catch(() => {});
    }
  }
  function removeAbandoned(id) {
    writeJSON(LS_ABANDONED, getAbandoned().filter((item) => item.id !== id));
    channel?.postMessage({ type: "abandoned" });
  }

  function getAudit() {
    const rows = readJSON(LS_AUDIT, []);
    return Array.isArray(rows) ? rows : [];
  }
  function addAudit(action, actor) {
    const log = { id: uid("log"), action: String(action || "").slice(0, 300), actor: String(actor || session?.username || "system"), at: nowISO() };
    const rows = [log, ...getAudit()].slice(0, 500);
    writeJSON(LS_AUDIT, rows);
    channel?.postMessage({ type: "audit" });
    if (REMOTE && session?.mode === "supabase") {
      supa(`/rest/v1/${CFG.auditTable}`, {
        method: "POST",
        body: JSON.stringify({ id: log.id, data: log, created_at: log.at }),
        headers: { Prefer: "return=minimal" }
      }, true).catch(() => {});
    }
  }

  /* ------------------------------------------------------------------------
     Published state, drafts and remote polling
     ------------------------------------------------------------------------ */
  async function pushPublishedState(next) {
    if (!REMOTE) return;
    if (!(await remoteSessionValid())) throw new Error("انتهت جلسة Supabase. أعد تسجيل الدخول.");
    await supa(`/rest/v1/${CFG.stateTable}`, {
      method: "POST",
      body: JSON.stringify({ id: "main", data: next, updated_at: next.updatedAt }),
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" }
    }, true);
  }
  async function publish(next = state) {
    const candidate = hydrate(clone(next));
    candidate.updatedAt = nowISO();
    candidate.version = Number(candidate.version || 0) + 1;
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("انتهت جلسة Supabase. أعد تسجيل الدخول.");
      await pushPublishedState(candidate);
    }
    state = candidate;
    const stored = writeJSON(LS_STATE, state);
    if (!stored) throw new Error("تعذر حفظ البيانات محليًا. مساحة التخزين ممتلئة.");
    localStorage.removeItem(LS_DRAFT);
    draft = null;
    applyDocument();
    channel?.postMessage({ type: "state", updatedAt: state.updatedAt });
    window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "publish" } }));
    return state;
  }
  function saveDraft(next = state) {
    const candidate = hydrate(clone(next));
    candidate.updatedAt = nowISO();
    draft = candidate;
    writeJSON(LS_DRAFT, draft);
    return draft;
  }
  function discardDraft() {
    localStorage.removeItem(LS_DRAFT);
    draft = null;
  }
  function useDraft() {
    if (!draft) return state;
    state = hydrate(clone(draft));
    applyDocument();
    return state;
  }
  function resetLocalDemo() {
    [LS_STATE, LS_DRAFT, LS_MANAGERS, LS_ORDERS, LS_ABANDONED, LS_AUDIT, LS_SESSION, LS_CUSTOMERS, LS_REVIEWS, LS_CUSTOMER, LS_CUSTOMER_SESSION, LS_LOGIN_ATTEMPTS]
      .forEach((key) => localStorage.removeItem(key));
    location.reload();
  }
  async function loadRemoteState() {
    if (!REMOTE) return false;
    try {
      const rows = await supa(`/rest/v1/${CFG.stateTable}?id=eq.main&select=id,data,updated_at`);
      const remote = Array.isArray(rows) ? rows[0] : null;
      if (!remote?.data) return false;
      const remoteStamp = Date.parse(remote.updated_at || remote.data.updatedAt || 0) || 0;
      const localStamp = Date.parse(state.updatedAt || 0) || 0;
      if (remoteStamp <= localStamp) return false;
      state = hydrate(remote.data);
      writeJSON(LS_STATE, state);
      applyDocument();
      window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "remote" } }));
      return true;
    } catch (error) {
      console.warn("Restore: state sync failed", error);
      return false;
    }
  }

  /* ------------------------------------------------------------------------
     Customer accounts, addresses and wishlist
     ------------------------------------------------------------------------ */
  function publicCustomer(customer) {
    if (!customer) return null;
    const { passwordHash, ...safe } = customer;
    return clone({
      ...safe,
      addresses: Array.isArray(safe.addresses) ? safe.addresses : [],
      wishlist: Array.isArray(safe.wishlist) ? safe.wishlist : []
    });
  }
  function normalizeCustomerRow(row) {
    if (!row) return null;
    return {
      id: row.id,
      authId: row.auth_id || "",
      name: row.name || "",
      email: normalizeEmail(row.email || ""),
      phone: normalizeDigits(row.phone || ""),
      addresses: Array.isArray(row.addresses) ? row.addresses : [],
      wishlist: uniqueStrings(row.wishlist || []).slice(0, MAX_WISHLIST),
      createdAt: row.created_at || nowISO()
    };
  }
  function saveLocalCustomer() {
    if (currentCustomer) writeJSON(LS_CUSTOMER, publicCustomer(currentCustomer));
    else localStorage.removeItem(LS_CUSTOMER);
  }
  function readLocalCustomers() {
    const rows = readJSON(LS_CUSTOMERS, []);
    return Array.isArray(rows) ? rows : [];
  }
  function saveLocalCustomers(rows) {
    writeJSON(LS_CUSTOMERS, rows);
  }
  function notifyCustomer() {
    channel?.postMessage({ type: "customer" });
    window.dispatchEvent(new CustomEvent("restore:customer", { detail: currentCustomer }));
  }
  const WISH_KEY = "restore_wish_v1";
  function readWishlist() {
    try {
      const value = JSON.parse(localStorage.getItem(WISH_KEY) || "[]");
      return uniqueStrings(Array.isArray(value) ? value : []).slice(0, MAX_WISHLIST);
    } catch {
      return [];
    }
  }
  function writeWishlist(handles) {
    const list = uniqueStrings(handles).slice(0, MAX_WISHLIST);
    localStorage.setItem(WISH_KEY, JSON.stringify(list));
    return list;
  }
  function mergeWishlist(customer) {
    if (!customer) return readWishlist();
    const merged = uniqueStrings([...readWishlist(), ...(customer.wishlist || [])]).slice(0, MAX_WISHLIST);
    writeWishlist(merged);
    if (merged.length !== (customer.wishlist || []).length || merged.some((handle) => !(customer.wishlist || []).includes(handle))) {
      customer.wishlist = merged;
      saveLocalCustomer();
      if (REMOTE && customer.authId) {
        supaCustomer(`/rest/v1/${CFG.customersTable}?auth_id=eq.${encodeURIComponent(customer.authId)}`, {
          method: "PATCH",
          body: JSON.stringify({ wishlist: merged }),
          headers: { Prefer: "return=minimal" }
        }).catch(() => {});
      }
    }
    return merged;
  }
  function getCustomer() {
    return currentCustomer;
  }
  function getCustomerSession() {
    return customerAuth;
  }
  function setCustomerSession(data) {
    customerAuth = data ? {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresAt: Date.now() + (Number(data.expires_in) || 3600) * 1000,
      user: data.user,
      mode: "supabase"
    } : null;
    if (customerAuth) writeJSON(LS_CUSTOMER_SESSION, customerAuth);
    else localStorage.removeItem(LS_CUSTOMER_SESSION);
  }

  async function loadRemoteCustomerProfile(user) {
    if (!user?.id) throw new Error("جلسة عميل غير صالحة");
    const rows = await supaCustomer(`/rest/v1/${CFG.customersTable}?auth_id=eq.${encodeURIComponent(user.id)}&select=*`);
    let profile = Array.isArray(rows) ? rows[0] : null;
    if (!profile) {
      const created = await supaCustomer(`/rest/v1/${CFG.customersTable}`, {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify({
          auth_id: user.id,
          name: user.user_metadata?.full_name || user.email?.split("@")[0] || "Client",
          email: normalizeEmail(user.email || ""),
          phone: normalizeDigits(user.user_metadata?.phone || ""),
          addresses: [],
          wishlist: readWishlist()
        })
      });
      profile = Array.isArray(created) ? created[0] : created;
    }
    const customer = normalizeCustomerRow(profile);
    if (!customer) throw new Error("تعذر تحميل حساب العميل");
    customer.authId = user.id;
    currentCustomer = customer;
    saveLocalCustomer();
    mergeWishlist(customer);
    notifyCustomer();
    await refreshOrders().catch(() => {});
    return customer;
  }

  async function customerRegister(data = {}) {
    const name = String(data.name || "").trim();
    const email = normalizeEmail(data.email || "");
    const phone = normalizeDigits(data.phone || "");
    const password = String(data.password || "");
    if (name.length < 2) throw new Error("أدخل الاسم الكامل / Nom complet requis");
    if (!isEmail(email)) throw new Error("أدخل بريدًا إلكترونيًا صالحًا / E-mail invalide");
    if (phone && phone.length !== 8) throw new Error("رقم الهاتف يجب أن يكون 8 أرقام / 8 chiffres requis");
    validatePassword(password);
    const wishlist = uniqueStrings(data.wishlist || readWishlist()).slice(0, MAX_WISHLIST);

    if (REMOTE) {
      const res = await fetch(remoteUrl("/auth/v1/signup"), {
        method: "POST",
        headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
        body: JSON.stringify({
          email,
          password,
          data: { full_name: name, phone }
        })
      });
      if (!res.ok) throw new Error(await readErrorMessage(res) || "تعذر إنشاء الحساب");
      const auth = await res.json();
      if (!auth.access_token || !auth.user) {
        throw new Error("تم إنشاء الحساب. تحقق من بريدك الإلكتروني لتأكيده ثم سجّل الدخول. / Vérifiez votre e-mail pour confirmer le compte.");
      }
      setCustomerSession(auth);
      writeWishlist(wishlist);
      const profile = await loadRemoteCustomerProfile(auth.user);
      if (wishlist.length) await customerSyncWishlist(wishlist);
      return profile;
    }

    const rows = readLocalCustomers();
    if (rows.some((item) => normalizeEmail(item.email) === email)) throw new Error("الحساب موجود بالفعل / Compte déjà existant");
    if (phone && rows.some((item) => normalizeDigits(item.phone) === phone)) throw new Error("رقم الهاتف مستخدم بالفعل");
    const customer = {
      id: uid("cust"),
      authId: "",
      name,
      email,
      phone,
      passwordHash: await hashPassword(password),
      addresses: [],
      wishlist,
      createdAt: nowISO()
    };
    rows.push(customer);
    saveLocalCustomers(rows);
    currentCustomer = publicCustomer(customer);
    saveLocalCustomer();
    mergeWishlist(currentCustomer);
    notifyCustomer();
    return currentCustomer;
  }

  async function customerLogin(identifier, password) {
    let email = "";
    let phone = "";
    let secret = password;
    if (identifier && typeof identifier === "object") {
      email = normalizeEmail(identifier.email || "");
      phone = normalizeDigits(identifier.phone || "");
      secret = String(identifier.password || "");
    } else {
      const value = String(identifier || "").trim();
      if (isEmail(value)) email = normalizeEmail(value);
      else phone = normalizeDigits(value);
      secret = String(password || "");
    }
    if (!email && !phone) throw new Error("أدخل البريد الإلكتروني أو رقم الهاتف");
    if (!secret) throw new Error("أدخل كلمة المرور");
    checkLoginLock(email || phone);

    if (REMOTE && email) {
      try {
        const res = await fetch(remoteUrl("/auth/v1/token?grant_type=password"), {
          method: "POST",
          headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
          body: JSON.stringify({ email, password: secret })
        });
        if (!res.ok) throw new Error(await readErrorMessage(res) || "بيانات الدخول غير صحيحة");
        const auth = await res.json();
        setCustomerSession(auth);
        const profile = await loadRemoteCustomerProfile(auth.user);
        clearLoginFailures(email || phone);
        return profile;
      } catch (error) {
        // Local demo accounts still work when Supabase is configured.
        console.warn("Restore: remote customer login failed, trying local demo account", error.message);
      }
    }

    const rows = readLocalCustomers();
    const customer = rows.find((item) => (email && normalizeEmail(item.email) === email) || (phone && normalizeDigits(item.phone) === phone));
    if (!customer) {
      noteLoginFailure(email || phone);
      throw new Error("الحساب غير موجود / Compte introuvable");
    }
    if (!(await verifyPassword(secret, customer.passwordHash))) {
      noteLoginFailure(email || phone);
      throw new Error("كلمة المرور غير صحيحة / Mot de passe incorrect");
    }
    currentCustomer = publicCustomer(customer);
    saveLocalCustomer();
    mergeWishlist(currentCustomer);
    notifyCustomer();
    clearLoginFailures(email || phone);
    return currentCustomer;
  }

  function customerLogout() {
    if (REMOTE && customerAuth?.accessToken) {
      fetch(remoteUrl("/auth/v1/logout"), {
        method: "POST",
        headers: { apikey: CFG.supabaseAnonKey, Authorization: `Bearer ${customerAuth.accessToken}` }
      }).catch(() => {});
    }
    customerAuth = null;
    currentCustomer = null;
    localStorage.removeItem(LS_CUSTOMER_SESSION);
    localStorage.removeItem(LS_CUSTOMER);
    notifyCustomer();
    window.dispatchEvent(new CustomEvent("restore:customerLogout"));
  }

  function customerSyncWishlist(handles) {
    const list = writeWishlist(uniqueStrings(Array.isArray(handles) ? handles : readWishlist()));
    if (!currentCustomer) return list;
    currentCustomer.wishlist = list;
    saveLocalCustomer();
    if (!currentCustomer.authId) {
      const rows = readLocalCustomers();
      const index = rows.findIndex((item) => item.id === currentCustomer.id);
      if (index >= 0) {
        rows[index].wishlist = list;
        saveLocalCustomers(rows);
      }
    }
    if (REMOTE && currentCustomer.authId && customerAuth?.accessToken) {
      supaCustomer(`/rest/v1/${CFG.customersTable}?auth_id=eq.${encodeURIComponent(currentCustomer.authId)}`, {
        method: "PATCH",
        body: JSON.stringify({ wishlist: list }),
        headers: { Prefer: "return=minimal" }
      }).catch((error) => console.warn("Restore: wishlist sync failed", error));
    }
    return list;
  }
  function customerToggleWishlist(handle) {
    const list = readWishlist();
    const next = list.includes(handle) ? list.filter((item) => item !== handle) : [...list, handle];
    customerSyncWishlist(next);
    return next.includes(handle);
  }

  function customerAddAddress(address = {}) {
    if (!currentCustomer) throw new Error("سجّل الدخول أولًا");
    const entry = { ...address, id: uid("addr"), createdAt: nowISO() };
    currentCustomer.addresses = [...(currentCustomer.addresses || []), entry];
    saveLocalCustomer();
    if (currentCustomer.authId && customerAuth?.accessToken) {
      supaCustomer(`/rest/v1/${CFG.customersTable}?auth_id=eq.${encodeURIComponent(currentCustomer.authId)}`, {
        method: "PATCH",
        body: JSON.stringify({ addresses: currentCustomer.addresses }),
        headers: { Prefer: "return=minimal" }
      }).catch(() => {});
    }
    return entry;
  }
  function customerUpdateAddress(id, patch = {}) {
    if (!currentCustomer) return;
    currentCustomer.addresses = (currentCustomer.addresses || []).map((address) => address.id === id ? { ...address, ...patch } : address);
    saveLocalCustomer();
    if (currentCustomer.authId && customerAuth?.accessToken) {
      supaCustomer(`/rest/v1/${CFG.customersTable}?auth_id=eq.${encodeURIComponent(currentCustomer.authId)}`, {
        method: "PATCH",
        body: JSON.stringify({ addresses: currentCustomer.addresses }),
        headers: { Prefer: "return=minimal" }
      }).catch(() => {});
    }
  }
  function customerDeleteAddress(id) {
    if (!currentCustomer) return;
    currentCustomer.addresses = (currentCustomer.addresses || []).filter((address) => address.id !== id);
    saveLocalCustomer();
    if (currentCustomer.authId && customerAuth?.accessToken) {
      supaCustomer(`/rest/v1/${CFG.customersTable}?auth_id=eq.${encodeURIComponent(currentCustomer.authId)}`, {
        method: "PATCH",
        body: JSON.stringify({ addresses: currentCustomer.addresses }),
        headers: { Prefer: "return=minimal" }
      }).catch(() => {});
    }
  }

  async function restoreCustomerSession() {
    if (!REMOTE || !customerAuth?.accessToken) return null;
    try {
      if (customerTokenExpiring() && !(await refreshCustomerToken())) throw new Error("expired");
      const res = await fetch(remoteUrl("/auth/v1/user"), {
        headers: { apikey: CFG.supabaseAnonKey, Authorization: `Bearer ${customerAuth.accessToken}` }
      });
      if (!res.ok) throw new Error("expired");
      const user = await res.json();
      customerAuth.user = user;
      writeJSON(LS_CUSTOMER_SESSION, customerAuth);
      return await loadRemoteCustomerProfile(user);
    } catch {
      customerAuth = null;
      currentCustomer = null;
      localStorage.removeItem(LS_CUSTOMER_SESSION);
      localStorage.removeItem(LS_CUSTOMER);
      return null;
    }
  }

  /* ------------------------------------------------------------------------
     Product reviews (moderated)
     ------------------------------------------------------------------------ */
  function normalizeReview(review = {}) {
    const status = ["pending", "approved", "rejected"].includes(review.status)
      ? review.status
      : review.approved === false ? "rejected" : "approved";
    return {
      id: review.id || uid("rev"),
      productHandle: review.productHandle || review.product_handle || review.handle || "",
      customerId: review.customerId || review.customer_id || "",
      customerName: review.customerName || review.customer_name || review.name || "Client",
      email: normalizeEmail(review.email || ""),
      rating: Math.max(1, Math.min(5, Number(review.rating) || 5)),
      title: review.title ?? "",
      body: review.body ?? review.comment ?? "",
      status,
      verified: review.verified !== false,
      createdAt: review.createdAt || review.created_at || nowISO(),
      updatedAt: review.updatedAt || review.updated_at || ""
    };
  }
  function loadLocalReviews() {
    const rows = readJSON(LS_REVIEWS, []);
    return (Array.isArray(rows) ? rows : []).map(normalizeReview).slice(0, MAX_REMOTE_REVIEWS);
  }
  function setReviewCache(rows, broadcast = true) {
    const next = (Array.isArray(rows) ? rows : []).map(normalizeReview).slice(0, MAX_REMOTE_REVIEWS);
    const before = reviewCache.map((review) => `${review.id}:${review.status}`).join("|");
    const after = next.map((review) => `${review.id}:${review.status}`).join("|");
    reviewCache = next;
    if (broadcast && before !== after) {
      channel?.postMessage({ type: "reviews" });
      window.dispatchEvent(new CustomEvent("restore:reviews"));
    }
    return reviewCache;
  }
  function persistLocalReviews(rows, broadcast = true) {
    const normalized = (Array.isArray(rows) ? rows : []).map(normalizeReview).slice(0, MAX_REMOTE_REVIEWS);
    writeJSON(LS_REVIEWS, normalized);
    setReviewCache(normalized, broadcast);
    return normalized;
  }
  async function refreshReviews() {
    if (!REMOTE) {
      setReviewCache(loadLocalReviews(), true);
      return reviewCache;
    }
    try {
      const staff = session?.mode === "supabase" && await remoteSessionValid();
      const query = staff
        ? `?select=*&order=created_at.desc&limit=${MAX_REMOTE_REVIEWS}`
        : `?status=eq.approved&select=*&order=created_at.desc&limit=${MAX_REMOTE_REVIEWS}`;
      const rows = await supa(`/rest/v1/${CFG.reviewsTable}${query}`, {}, staff);
      if (Array.isArray(rows)) setReviewCache(rows.map((row) => normalizeReview({
        ...row,
        productHandle: row.product_handle,
        customerId: row.customer_id,
        customerName: row.customer_name,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      })), true);
    } catch (error) {
      console.warn("Restore: review sync failed", error);
      setReviewCache(loadLocalReviews(), false);
    }
    return reviewCache;
  }
  function publicReviewsFor(handle) {
    const editorReviews = (state.reviews || [])
      .filter((review) => (review.handle === handle || review.productHandle === handle) && review.approved !== false)
      .map((review) => normalizeReview({ ...review, status: "approved", productHandle: handle }));
    const moderated = reviewCache.filter((review) => review.productHandle === handle && review.status === "approved");
    const seen = new Set();
    return [...moderated, ...editorReviews].filter((review) => {
      const key = review.id || `${review.customerName}:${String(review.title)}:${review.createdAt}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function getProductReviews(handle) {
    return publicReviewsFor(handle).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  function getPendingReviews() {
    return reviewCache.filter((review) => review.status === "pending");
  }
  function getAllCustomerReviews() {
    return clone(reviewCache);
  }
  function customerReviews() {
    if (!currentCustomer) return [];
    const ids = [currentCustomer.id, currentCustomer.authId, customerAuth?.user?.id].filter(Boolean);
    return reviewCache.filter((review) => ids.includes(review.customerId) || (currentCustomer.email && review.email === normalizeEmail(currentCustomer.email)));
  }
  async function submitReview(data = {}) {
    if (!currentCustomer) throw new Error("loginRequired");
    const productHandle = String(data.productHandle || "").trim();
    const rating = Number(data.rating);
    const title = String(data.title || "").trim().slice(0, 120);
    const body = String(data.body || "").trim().slice(0, 2000);
    if (!productHandle || !state.products.some((product) => product.handle === productHandle)) throw new Error("المنتج غير موجود");
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new Error("التقييم يجب أن يكون بين 1 و 5");
    if (title.length < 2) throw new Error("أضف عنوانًا للتقييم");
    if (body.length < 4) throw new Error("أضف تعليقًا للتقييم");
    if (reviewCache.some((review) => review.productHandle === productHandle && review.status === "pending" && review.customerId === (customerAuth?.user?.id || currentCustomer.id))) {
      throw new Error("لديك تقييم قيد المراجعة لهذا المنتج");
    }

    if (REMOTE) {
      if (!customerAuth?.accessToken) throw new Error("سجّل الدخول بحساب العميل لتقييم المنتج");
      const rows = await supaCustomer(`/rest/v1/${CFG.reviewsTable}?select=*`, {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify({
          product_handle: productHandle,
          customer_id: customerAuth.user.id,
          customer_name: currentCustomer.name,
          rating,
          title,
          body,
          status: "pending"
        })
      });
      const row = Array.isArray(rows) ? rows[0] : rows;
      if (!row) throw new Error("تعذر حفظ التقييم");
      const normalized = normalizeReview({
        ...row,
        productHandle: row.product_handle,
        customerId: row.customer_id,
        customerName: row.customer_name,
        createdAt: row.created_at
      });
      await refreshReviews();
      return normalized;
    }

    const review = normalizeReview({
      id: uid("rev"),
      productHandle,
      customerId: currentCustomer.id,
      customerName: currentCustomer.name,
      email: currentCustomer.email,
      rating,
      title,
      body,
      status: "pending",
      verified: true,
      createdAt: nowISO()
    });
    const rows = loadLocalReviews();
    rows.unshift(review);
    persistLocalReviews(rows);
    return review;
  }
  async function moderateReview(reviewId, action) {
    const id = String(reviewId || "");
    if (!id) throw new Error("تقييم غير معروف");
    const status = action === "reject" || action === "rejected" ? "rejected" : "approved";
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("سجّل الدخول إلى لوحة التحكم");
      await supa(`/rest/v1/${CFG.reviewsTable}?id=eq.${encodeURIComponent(id)}`, {
        method: "PATCH",
        body: JSON.stringify({ status, updated_at: nowISO() }),
        headers: { Prefer: "return=minimal" }
      }, true);
      await refreshReviews();
      return true;
    }
    const rows = loadLocalReviews();
    const index = rows.findIndex((review) => review.id === id);
    if (index < 0) return false;
    rows[index].status = status;
    rows[index].updatedAt = nowISO();
    persistLocalReviews(rows);
    return true;
  }
  async function deleteCustomerReview(reviewId) {
    const id = String(reviewId || "");
    if (!id) return false;
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("سجّل الدخول إلى لوحة التحكم");
      await supa(`/rest/v1/${CFG.reviewsTable}?id=eq.${encodeURIComponent(id)}`, { method: "DELETE" }, true);
      await refreshReviews();
      return true;
    }
    const rows = loadLocalReviews().filter((review) => review.id !== id);
    persistLocalReviews(rows);
    return true;
  }

  /* ------------------------------------------------------------------------
     Currency display
     ------------------------------------------------------------------------ */
  const LS_CURRENCY_MODE = "restore_currency_mode_v1";
  let currencyMode = localStorage.getItem(LS_CURRENCY_MODE) || state.settings.country?.currencyMode || "new";
  if (currencyMode !== "old" && currencyMode !== "new") currencyMode = "new";

  function getCurrencyMode() {
    return currencyMode;
  }
  function setCurrencyMode(mode) {
    if (mode !== "old" && mode !== "new") return;
    currencyMode = mode;
    localStorage.setItem(LS_CURRENCY_MODE, mode);
    window.dispatchEvent(new CustomEvent("restore:currencyMode", { detail: mode }));
    window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "currency" } }));
  }
  function formatCurrency(amount) {
    const multiplier = currencyMode === "old" ? 10 : 1;
    const value = Math.max(0, Number(amount) || 0) * multiplier;
    const formatted = new Intl.NumberFormat(lang === "ar" ? "en-US" : "fr-FR", { maximumFractionDigits: 0 }).format(Math.round(value));
    if (lang === "ar") return `${formatted} ${currencyMode === "old" ? "أوقية قديمة" : "أوقية"}`;
    return `${formatted} ${currencyMode === "old" ? "MRO" : "MRU"}`;
  }

  /* ------------------------------------------------------------------------
     Content pages and owner settings
     ------------------------------------------------------------------------ */
  function validateSlug(slug) {
    const value = String(slug || "").trim().toLowerCase();
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value) || value.length > 80) throw new Error("الرابط يجب أن يحتوي على حروف إنجليزية وأرقام وشرطات فقط");
    return value;
  }
  function getPages() {
    return clone(state.pages || []);
  }
  function getPage(slug) {
    const value = String(slug || "").trim();
    return clone((state.pages || []).find((page) => page.slug === value && page.visible !== false) || null);
  }
  async function savePage(pageData = {}) {
    const slug = validateSlug(pageData.slug);
    const title = pageData.title || {};
    if (!L(title).trim()) throw new Error("عنوان الصفحة مطلوب");
    const page = {
      ...pageData,
      slug,
      title: { ar: String(title.ar || L(title)).trim(), fr: String(title.fr || L(title)).trim() },
      body: {
        ar: String(pageData.body?.ar || "").trim(),
        fr: String(pageData.body?.fr || "").trim()
      },
      visible: pageData.visible !== false,
      seoTitle: pageData.seoTitle || title,
      seoDescription: pageData.seoDescription || { ar: "", fr: "" },
      updatedAt: nowISO()
    };
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("سجّل الدخول إلى لوحة التحكم");
      await supa(`/rest/v1/${CFG.pagesTable}`, {
        method: "POST",
        body: JSON.stringify({
          slug: page.slug,
          title: page.title,
          body: page.body,
          seo_title: page.seoTitle,
          seo_description: page.seoDescription,
          visible: page.visible,
          updated_at: page.updatedAt
        }),
        headers: { Prefer: "resolution=merge-duplicates,return=representation" }
      }, true);
    }
    const pages = (state.pages || []).filter((item) => item.slug !== slug);
    pages.push(page);
    state = hydrate({ ...state, pages });
    writeJSON(LS_STATE, state);
    return clone(page);
  }
  async function deletePage(slug) {
    const value = validateSlug(slug);
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("سجّل الدخول إلى لوحة التحكم");
      await supa(`/rest/v1/${CFG.pagesTable}?slug=eq.${encodeURIComponent(value)}`, { method: "DELETE" }, true);
    }
    state = hydrate({ ...state, pages: (state.pages || []).filter((page) => page.slug !== value) });
    writeJSON(LS_STATE, state);
    return true;
  }

  function normalizePhone(phone) {
    const digits = normalizeDigits(phone);
    if (!digits) return "";
    if (digits.length === 8) return `+222${digits}`;
    if (digits.length === 11 && digits.startsWith("222")) return `+${digits}`;
    throw new Error("رقم الهاتف يجب أن يكون 8 أرقام موريتانية");
  }
  function normalizeSocial(list) {
    const allowed = new Set(["facebook", "instagram", "tiktok", "youtube", "x", "twitter", "snapchat", "whatsapp", "linkedin", "telegram"]);
    const out = [];
    for (const entry of Array.isArray(list) ? list : []) {
      const id = String(entry.id || entry.platform || "").trim().toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 24);
      const href = safeHref(entry.href || "", "");
      if (!id || !href || !/^https:\/\//i.test(href)) continue;
      if (!allowed.has(id) && !allowed.has(id.replace("-", ""))) continue;
      out.push({ id, icon: allowed.has(id) ? id : "instagram", href });
      if (out.length >= 12) break;
    }
    return out;
  }
  async function updateOwnerSettings(patch = {}) {
    if (session && session.role !== "owner") throw new Error("هذه الإعدادات متاحة للمالك فقط / Réservé au propriétaire");
    const next = clone(state);
    const settings = next.settings;
    const allowedKeys = ["storeName", "legalName", "tagline", "email", "whatsapp", "phone", "phoneDisplay", "address", "city", "social", "hours"];
    for (const key of allowedKeys) {
      if (!(key in patch)) continue;
      if (key === "email") {
        const email = normalizeEmail(patch.email);
        if (email && !isEmail(email)) throw new Error("البريد الإلكتروني غير صالح");
        settings.email = email;
      } else if (key === "whatsapp") {
        const digits = normalizeDigits(patch.whatsapp);
        if (digits && ![8, 11].includes(digits.length)) throw new Error("رقم واتساب غير صالح");
        if (digits.length === 11 && !digits.startsWith("222")) throw new Error("رقم واتساب موريتاني غير صالح");
        settings.whatsapp = digits;
      } else if (key === "phone") {
        settings.phone = normalizePhone(patch.phone);
        if (!patch.phoneDisplay) settings.phoneDisplay = formatPhone(settings.phone);
      } else if (key === "social") {
        settings.social = normalizeSocial(patch.social);
      } else if (key === "phoneDisplay") {
        const display = String(patch.phoneDisplay || "").trim().slice(0, 32);
        if (display && !/^[+0-9 ()-]{7,32}$/.test(display)) throw new Error("صيغة الرقم المعروض غير صالحة");
        settings.phoneDisplay = display || formatPhone(settings.phone);
      } else {
        settings[key] = patch[key];
      }
    }
    next.updatedAt = nowISO();
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("انتهت جلسة Supabase. أعد تسجيل الدخول.");
      await pushPublishedState(next);
    }
    state = hydrate(next);
    writeJSON(LS_STATE, state);
    applyDocument();
    channel?.postMessage({ type: "state", updatedAt: state.updatedAt });
    window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "owner-settings" } }));
    return clone(state.settings);
  }

  /* ------------------------------------------------------------------------
     Query, pricing and store utilities
     ------------------------------------------------------------------------ */
  const AR_DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;
  function normalizeText(value) {
    return String(value || "")
      .toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(AR_DIACRITICS, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }
  const STOP_WORDS = new Set(["series", "série", "serie", "the", "and", "with", "من", "سلسلة", "ال", "في"]);
  function queryTokens(query) {
    return normalizeText(query).split(" ").filter((token) => token && !STOP_WORDS.has(token));
  }
  function productSearchText(product) {
    const options = (product.options || []).flatMap((option) => [option.name, ...(option.values || [])]);
    return normalizeText([product.title, product.vendor, product.type, product.handle, product.sku, ...(product.collections || []), ...options, product.condition].join(" "));
  }
  function matchesQuery(product, query) {
    const tokens = queryTokens(query);
    if (!tokens.length) return true;
    const haystack = productSearchText(product);
    return tokens.every((token) => haystack.includes(token));
  }
  function effectivePrice(product) {
    const variants = (product.variants || []).filter((variant) => variant.available);
    if (!variants.length) return Number(product.price) || 0;
    return Math.min(Number(product.price) || 0, ...variants.map((variant) => Number(variant.price) || Number(product.price) || 0));
  }
  function bestCardImage(product) {
    return product.image || product.images?.[0] || "";
  }
  function isStoreOpen(date = new Date()) {
    const hours = state.settings.hours || {};
    if (hours.closed || hours.maintenance) return false;
    try {
      const parts = new Intl.DateTimeFormat("en-GB", { timeZone: state.settings.timezone || "Africa/Nouakchott", weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false }).formatToParts(date);
      const get = (type) => parts.find((part) => part.type === type)?.value;
      const map = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      const day = map[get("weekday")];
      if (!(hours.days || [0, 1, 2, 3, 4, 5, 6]).includes(day)) return false;
      const current = Number(get("hour")) * 60 + Number(get("minute"));
      const [openHour, openMinute] = String(hours.open || "09:00").split(":").map(Number);
      const [closeHour, closeMinute] = String(hours.close || "19:00").split(":").map(Number);
      const start = openHour * 60 + openMinute;
      const end = closeHour * 60 + closeMinute;
      return end < start ? current >= start || current < end : current >= start && current < end;
    } catch {
      return true;
    }
  }
  function orderId() {
    const date = new Date();
    return `RS-${String(date.getFullYear()).slice(2)}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  }
  function decrementStock(items) {
    try {
      const next = clone(state);
      for (const item of items || []) {
        const product = next.products.find((candidate) => candidate.handle === item.handle);
        if (!product) continue;
        product.stock = Math.max(0, Number(product.stock || 0) - Number(item.qty || 1));
        product.lowStock = product.stock <= Number(next.settings.lowStockThreshold || 2);
      }
      next.updatedAt = nowISO();
      state = next;
      writeJSON(LS_STATE, state);
      channel?.postMessage({ type: "state", updatedAt: state.updatedAt });
      window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "stock" } }));
    } catch (error) {
      console.warn("Restore: could not update local stock", error);
    }
  }
  function statusMeta(id) {
    const map = {
      new: { label: txt("جديد", "Nouveau"), color: "#ff6400" },
      confirmed: { label: txt("مؤكد", "Confirmé"), color: "#0b6fb8" },
      preparing: { label: txt("قيد التجهيز", "En préparation"), color: "#8e44ad" },
      shipped: { label: txt("تم الشحن", "Expédié"), color: "#00a651" },
      delivered: { label: txt("تم التسليم", "Livré"), color: "#2e7d32" },
      cancelled: { label: txt("ملغي", "Annulé"), color: "#c0392b" },
      returned: { label: txt("مرتجع", "Retourné"), color: "#7f8c8d" }
    };
    return map[id] || map.new;
  }
  function formatPhone(value) {
    const digits = normalizeDigits(value);
    if (digits.startsWith("222") && digits.length >= 11) return `+222 ${digits.slice(3, 5)} ${digits.slice(5, 7)} ${digits.slice(7, 9)} ${digits.slice(9, 11)}`.trim();
    if (digits.length === 8) return `+222 ${digits.slice(0, 2)} ${digits.slice(2, 4)} ${digits.slice(4, 6)} ${digits.slice(6, 8)}`;
    return value || "";
  }

  /* ------------------------------------------------------------------------
     Cross-tab and cross-device notifications
     ------------------------------------------------------------------------ */
  if (REMOTE) {
    loadRemoteState();
    setInterval(loadRemoteState, Math.max(2500, Number(CFG.pollMs) || 5000));
    setInterval(() => {
      if (session?.mode === "supabase") remoteSessionValid().catch(() => {});
      if (customerAuth?.accessToken) refreshCustomerToken().catch(() => {});
    }, 60000);
    setTimeout(() => {
      if (session?.mode === "supabase") refreshStaff().catch(() => {});
      if (customerAuth?.accessToken) restoreCustomerSession().catch(() => {});
      refreshReviews().catch(() => {});
    }, 400);
  } else {
    reviewCache = loadLocalReviews();
    setTimeout(() => refreshReviews().catch(() => {}), 0);
  }
  channel?.addEventListener("message", (event) => {
    if (event.data?.type === "state") window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "tab" } }));
    if (event.data?.type === "orders") window.dispatchEvent(new CustomEvent("restore:orders", { detail: { source: "tab" } }));
    if (event.data?.type === "reviews") window.dispatchEvent(new CustomEvent("restore:reviews", { detail: { source: "tab" } }));
    if (event.data?.type === "customer") {
      currentCustomer = readJSON(LS_CUSTOMER, null);
      window.dispatchEvent(new CustomEvent("restore:customer", { detail: currentCustomer }));
    }
  });
  window.addEventListener("storage", (event) => {
    if (event.key === LS_STATE) window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "storage" } }));
    if (event.key === LS_ORDERS) window.dispatchEvent(new CustomEvent("restore:orders", { detail: { source: "storage" } }));
    if (event.key === LS_REVIEWS) {
      setReviewCache(loadLocalReviews(), false);
      window.dispatchEvent(new CustomEvent("restore:reviews", { detail: { source: "storage" } }));
    }
    if (event.key === LS_CUSTOMER || event.key === LS_CUSTOMERS) {
      currentCustomer = readJSON(LS_CUSTOMER, null);
      window.dispatchEvent(new CustomEvent("restore:customer", { detail: currentCustomer }));
    }
  });

  /* ------------------------------------------------------------------------
     Public API
     ------------------------------------------------------------------------ */
  applyDocument();
  const R = {
    config: CFG,
    remote: REMOTE,
    demoAllowed: DEMO_ALLOWED,
    localDev: LOCAL_DEV,
    get state() { return state; },
    set state(value) { state = value; },
    get store() { return state; },
    get draft() { return draft; },
    get lang() { return lang; },
    get theme() { return theme; },
    get managers() { return managerPublic(); },
    get orders() { return getOrders(); },
    get abandoned() { return getAbandoned(); },
    get audit() { return getAudit(); },
    escText, sanitizeRichHTML, sanitizeHTML: sanitizeRichHTML,
    t, L, money, formatDate, formatPhone, formatCurrency, normalizeText, matchesQuery, queryTokens, safeHref,
    setLang, setTheme, applyDocument, clone, uid, uploadMedia, resizeImage,
    effectivePrice, bestCardImage, isStoreOpen,
    getCurrencyMode, setCurrencyMode,
    login, logout, currentSession, changePassword, changeOwnerPassword, addManager, updateManager, deleteManager, refreshStaff,
    customerLogin, customerRegister, customerLogout, getCustomer, getCustomerSession, restoreCustomerSession,
    customerSyncWishlist, customerToggleWishlist, customerAddAddress, customerUpdateAddress, customerDeleteAddress,
    getCustomerOrders, getOrders, addOrder, submitOrder, updateOrder, refreshOrders,
    submitReview, moderateReview, deleteCustomerReview, refreshReviews,
    getProductReviews, getPendingReviews, getAllCustomerReviews, customerReviews,
    addReview: submitReview, getApprovedReviews: getProductReviews,
    orderId, statusMeta, decrementStock,
    getAbandoned, saveAbandoned, removeAbandoned,
    getPages, getPage, savePage, deletePage,
    updateOwnerSettings,
    getAudit, addAudit,
    publish, saveDraft, discardDraft, useDraft, resetLocalDemo, loadRemoteState,
    supa, remoteSessionValid,
    get statuses() { return ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled", "returned"]; }
  };
  window.RESTORE = R;
})();
