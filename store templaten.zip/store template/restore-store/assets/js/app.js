/* ==========================================================================
   Restore storefront — front-end application
   ========================================================================== */
(() => {
  "use strict";

  const R = window.RESTORE;
  if (!R) return;
  if (new URLSearchParams(location.search).get("preview") === "1") R.useDraft();
  const S = R.store;
  const SET = S.settings;
  const ALL_PRODUCTS = S.products;
  const PRODUCTS = ALL_PRODUCTS.filter((p) => p.active !== false && (!SET.autoHideOutOfStock || Number(p.stock) > 0));
  const BY_HANDLE = new Map(ALL_PRODUCTS.map((p) => [p.handle, p]));
  const CART_KEY = "restore_cart_v1";
  const WISH_KEY = "restore_wish_v1";
  const MAX_QTY = 10;
  const t = (key, vars) => R.t(key, vars);
  const L = (value) => R.L(value);

  /* ------------------------------------------------------------------------
     Utilities
     ------------------------------------------------------------------------ */
  const esc = (s) =>
    String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const money = (n) => R.money(n);

  const discountFor = (price, compare) =>
    compare && compare > price ? Math.round((1 - price / compare) * 100) : 0;

  const variantLabel = (v) => [v.o1, v.o2, v.o3].filter(Boolean).join(" / ");
  const SPEC_LABELS = { cpu: "cpu", ram: "ram", storage: "storage", screen: "screen", keyboard: "keyboard", condition: "condition", battery: "battery" };
  const specsText = (specs) => Object.entries(specs || {})
    .filter(([key, value]) => value && SPEC_LABELS[key])
    .map(([key, value]) => `${t(SPEC_LABELS[key])}: ${value}`)
    .join(" · ");

  const svg = (body, filled = false) =>
    `<svg viewBox="0 0 24 24" ${filled ? 'fill="currentColor" stroke="none"' : 'fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"'}>${body}</svg>`;

  const ICON = {
    search: svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>'),
    user: svg('<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20.5c.6-3.6 3.6-5.5 7.5-5.5s6.9 1.9 7.5 5.5"/>'),
    heart: svg('<path d="M12 20.3S4.8 15.9 4.8 10.9A4.1 4.1 0 0 1 12 8a4.1 4.1 0 0 1 7.2 2.9c0 5-7.2 9.4-7.2 9.4z"/>'),
    bag: svg('<path d="M6.2 8.2h11.6l1 11.6H5.2l1-11.6z"/><path d="M9 8.2V6.4a3 3 0 0 1 6 0v1.8"/>'),
    chevronDown: svg('<path d="M6 9l6 6 6-6"/>'),
    chevronRight: svg('<path d="M9 5.5l6.5 6.5L9 18.5"/>'),
    arrowRight: svg('<path d="M4.5 12h15M13.5 6l6 6-6 6"/>'),
    arrowLeft: svg('<path d="M19.5 12h-15M10.5 6l-6 6 6 6"/>'),
    chevronLeft: svg('<path d="M15 5.5L8.5 12 15 18.5"/>'),
    close: svg('<path d="M6 6l12 12M18 6L6 18"/>'),
    menu: svg('<path d="M3.5 6.5h17M3.5 12h17M3.5 17.5h17"/>'),
    flame: svg('<path d="M12.4 2.2c.5 3.6-3.2 5.1-3.2 8.8a2.8 2.8 0 0 0 5.6 0c0-1.1-.4-2-1-2.7 2 1.2 3.2 3 3.2 5.2a5.9 5.9 0 1 1-11.8 0c0-4.4 3.6-6.6 6.2-11.3z"/>', true),
    trash: svg('<path d="M4 7h16M9 7V5h6v2M7 7l1 13h8l1-13M10 11v6M14 11v6"/>'),
    play: svg('<path d="M8 5.5v13l10-6.5z"/>', true),
    star: svg('<path d="M12 3.2l2.7 5.5 6 .9-4.35 4.25 1.03 6L12 16.9l-5.38 2.8 1.03-6L3.3 9.6l6-.9L12 3.2z"/>', true),
    truck: svg('<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17.5" cy="18" r="1.6"/>'),
    shield: svg('<path d="M12 3l7 2.6v5.6c0 4.4-3 7.6-7 9.8-4-2.2-7-5.4-7-9.8V5.6L12 3z"/><path d="M9 12l2 2 4-4"/>'),
    return: svg('<path d="M4 9h10a5 5 0 0 1 0 10H8"/><path d="M8 5L4 9l4 4"/>'),
    info: svg('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
    check: svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
    smile: svg('<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5c1 1.3 2.2 2 3.5 2s2.5-.7 3.5-2"/><path d="M9 9.5h.01M15 9.5h.01" stroke-width="2.2"/>'),
    userRound: svg('<circle cx="12" cy="8" r="3.4"/><path d="M5.5 20c.7-3.4 3.4-5 6.5-5s5.8 1.6 6.5 5"/>'),
    badgeCheck: svg('<path d="M12 2.5l2.1 1.6 2.6-.4 1.1 2.4 2.4 1.1-.4 2.6L21.5 12l-1.6 2.1.4 2.6-2.4 1.1-1.1 2.4-2.6-.4L12 21.5l-2.1-1.6-2.6.4-1.1-2.4-2.4-1.1.4-2.6L2.5 12l1.6-2.1-.4-2.6 2.4-1.1 1.1-2.4 2.6.4L12 2.5z"/><path d="M8.3 12.2l2.4 2.4 5-5" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>', true),
    chat: svg('<path d="M4 4h16v11H9.5L4 19.5V4z"/><path d="M8 9.5h8M8 12.5h5" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>', true),
    facebook: svg('<path d="M13.5 21v-7h2.4l.4-2.8h-2.8V9.4c0-.8.2-1.4 1.5-1.4h1.4V5.5c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.7v2.1H8v2.8h2.5v7h3z"/>', true),
    instagram: svg('<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r="1" fill="currentColor" stroke="none"/>'),
    tiktok: svg('<path d="M14.5 3h2.6c.2 1.6 1.1 2.9 2.8 3.4v2.6c-1.2 0-2.3-.4-3.2-1v6.4a5.6 5.6 0 1 1-5.6-5.6c.3 0 .6 0 .9.1v2.7a2.8 2.8 0 1 0 2 2.7V3z"/>', true),
    apple: svg('<path d="M16.2 12.6c0-2.1 1.7-3.1 1.8-3.2-1-1.4-2.5-1.6-3-1.6-1.3-.1-2.5.7-3.1.7-.6 0-1.6-.7-2.7-.7-1.4 0-2.7.8-3.4 2.1-1.5 2.5-.4 6.3 1 8.4.7 1 1.5 2.2 2.6 2.1 1-.1 1.4-.7 2.7-.7s1.6.7 2.7.7c1.1 0 1.8-1 2.5-2 .8-1.1 1.1-2.2 1.1-2.3-.1 0-2.2-.8-2.2-3.5z"/><path d="M14.1 6.1c.6-.7 1-1.6.9-2.6-.9 0-2 .6-2.6 1.3-.6.6-1 1.6-.9 2.5 1 .1 2-.5 2.6-1.2z"/>', true),
    sun: svg('<circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M18.7 5.3l-1.4 1.4M6.7 17.3l-1.4 1.4"/>'),
    moon: svg('<path d="M20 15.3A8.5 8.5 0 0 1 8.7 4a8.5 8.5 0 1 0 11.3 11.3z"/>'),
    whatsapp: svg('<path d="M20.5 11.7a8.5 8.5 0 0 1-12.6 7.5L3.5 20.5l1.3-4.3a8.5 8.5 0 1 1 15.7-4.5z"/><path d="M8.4 7.8c.2-.4.4-.4.7-.4h.5c.2 0 .4 0 .5.4l.8 1.9c.1.2 0 .4-.1.6l-.6.7c-.2.2-.1.3 0 .5.7 1.2 1.7 2.2 2.9 2.9.2.1.4.2.5 0l.7-.8c.2-.2.4-.2.6-.1l1.9.9c.3.1.4.3.4.5 0 1-.5 1.8-1.4 2.1-.6.2-1.4.3-2.3.1-3.6-.8-6.4-3.6-7.2-7.2-.2-1-.1-1.8.1-2.4z"/>', true),
    mapPin: svg('<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>'),
    mail: svg('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5L12 13l8.5-6.5"/>'),
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    leaf: svg('<path d="M20 4c-7.5 0-13 3.2-13 9.2 0 2 .7 3.7 2 4.8C12 14 15 11 19 9c-3 3-5.8 6-7.4 9.6"/><path d="M4 20c2.5-2.3 5.6-3.7 9-4"/>'),
    recycle: svg('<path d="M8.5 4.5h7l2.5 4.3M18 9l1.5 2.6-2.7 1.6M17.2 16H9.8l-2.5-4.3M8.8 15l-2.5-4.2 2.6-1.6M5 13.5l-1.5 2.6 2.7 1.6"/>'),
    bolt: svg('<path d="M13 2L4.5 13H11l-1 9L19.5 11H13z"/>', true),
    creditCard: svg('<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 9.5h19M6 15h4"/>'),
    download: svg('<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>'),
    chevronUp: svg('<path d="M6 15l6-6 6 6"/>'),
    logout: svg('<path d="M4 9h10a5 5 0 0 1 0 10H8"/><path d="M8 5L4 9l4 4"/>'),
  };

  function hydrateIcons(root = document) {
    root.querySelectorAll("[data-icon]").forEach((el) => {
      const name = el.dataset.icon;
      if (ICON[name]) el.innerHTML = ICON[name];
    });
  }

  let toastTimer;
  function toast(msg) {
    let t = document.getElementById("toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "toast";
      t.className = "toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
  }

  /* ------------------------------------------------------------------------
     Cart
     ------------------------------------------------------------------------ */
  function readCart() {
    try {
      const v = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
      return Array.isArray(v) ? v : [];
    } catch {
      return [];
    }
  }

  function writeCart(items) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    syncBadges();
    renderCart();
  }

  function cartDetails() {
    return readCart()
      .map((it) => {
        const product = BY_HANDLE.get(it.handle);
        if (!product) return null;
        const variant = product.variants.find((v) => String(v.id) === String(it.variantId)) || product.variants[0];
        return { ...it, product, variant, line: (Number(variant?.price ?? product.price) || 0) * it.qty };
      })
      .filter(Boolean);
  }

  const cartCount = () => readCart().reduce((n, it) => n + (Number(it.qty) || 0), 0);
  const cartSubtotal = () => cartDetails().reduce((n, it) => n + it.line, 0);

  function addToCart(handle, variantId, qty = 1, specs = {}) {
    const product = BY_HANDLE.get(handle);
    if (!product) return;
    const cleanSpecs = Object.fromEntries(Object.entries(specs || {}).filter(([, v]) => v != null && v !== ""));
    const key = JSON.stringify(cleanSpecs);
    const items = readCart();
    const found = items.find((it) => it.handle === handle && String(it.variantId) === String(variantId) && JSON.stringify(it.specs || {}) === key);
    if (found) found.qty = Math.min(MAX_QTY, found.qty + qty);
    else items.push({ handle, variantId, qty: Math.min(MAX_QTY, qty), specs: cleanSpecs });
    writeCart(items);
    toast(t("addedToCart"));
  }

  function setQty(variantId, handle, qty) {
    const items = readCart();
    const it = items.find((x) => x.handle === handle && String(x.variantId) === String(variantId));
    if (!it) return;
    it.qty = Math.max(0, Math.min(MAX_QTY, qty));
    writeCart(items.filter((x) => x.qty > 0));
  }

  function removeLine(handle, variantId) {
    writeCart(readCart().filter((x) => !(x.handle === handle && String(x.variantId) === String(variantId))));
  }

  /* ------------------------------------------------------------------------
     Wishlist
     ------------------------------------------------------------------------ */
  function readWish() {
    try {
      const v = JSON.parse(localStorage.getItem(WISH_KEY) || "[]");
      return new Set(Array.isArray(v) ? v : []);
    } catch {
      return new Set();
    }
  }

  function toggleWish(handle) {
    const set = readWish();
    if (set.has(handle)) {
      set.delete(handle);
      toast(t("removedWish"));
    } else {
      set.add(handle);
      toast(t("savedWish"));
    }
    localStorage.setItem(WISH_KEY, JSON.stringify([...set]));
    if (R.getCustomer()) R.customerSyncWishlist([...set]);
    syncBadges();
    document.querySelectorAll("[data-wish]").forEach((b) => b.classList.toggle("active", set.has(b.dataset.wish)));
    if (document.body.dataset.page === "wishlist") renderWishlist();
  }

  function syncBadges() {
    const n = cartCount();
    document.querySelectorAll(".cart-count-n").forEach((el) => {
      el.textContent = n;
      el.hidden = n === 0;
    });
    const w = readWish().size;
    document.querySelectorAll(".wish-count").forEach((el) => {
      el.textContent = w;
      el.hidden = w === 0;
    });
  }

  /* ------------------------------------------------------------------------
     Header & footer
     ------------------------------------------------------------------------ */
  const NAV = (SET.navigation || []).filter((n) => n.visible !== false);

  function renderHeader() {
    const el = document.getElementById("site-header");
    if (!el) return;
    const lang = R.lang;
    const other = lang === "ar" ? "fr" : "ar";
    const otherLabel = other === "fr" ? "Français" : "العربية";
    const otherFlag = other === "fr" ? "assets/img/flag-fr.svg" : "assets/img/flag-mr.svg";
    const currentFlag = lang === "fr" ? "assets/img/flag-fr.svg" : "assets/img/flag-mr.svg";
    const currencyLabel = () => R.getCurrencyMode() === "old" ? (lang === "ar" ? "قديمة" : "Ancienne") : (lang === "ar" ? "جديدة" : "Nouvelle");
    const closed = !R.isStoreOpen();
    el.className = "site-header";
    el.innerHTML = `
      <div class="announcement ${closed ? "is-closed" : ""} announce-slide"><span>${esc(closed ? t("storeClosed") : L(SET.announcement))}</span></div>
      <div class="container header-top">
        <button class="menu-btn" type="button" data-open-menu aria-label="${esc(t("menu"))}">${ICON.menu}</button>
        <a class="logo" href="index.html" aria-label="${esc(L(SET.storeName))}"><img src="${SET.logo}" alt="${esc(L(SET.storeName))}"></a>
        <form class="search" id="header-search" role="search" autocomplete="off">
          <input type="search" placeholder="${esc(t("searchPlaceholder"))}" aria-label="${esc(t("search"))}">
          <button class="search-btn" type="submit" aria-label="${esc(t("search"))}">${ICON.search}</button>
        </form>
        <div class="header-actions">
          <div class="customer-account" id="customer-account"></div></div>
          <div class="lang-switch">
            <button class="lang-current" type="button" data-lang-toggle aria-label="${esc(t("language"))}">
              <img src="${currentFlag}" alt="" width="20" height="14"><span>${lang.toUpperCase()}</span>${ICON.chevronDown}
            </button>
            <div class="lang-menu">
              <button type="button" data-set-lang="ar"><img src="assets/img/flag-mr.svg" alt="" width="22" height="15"><span>العربية</span></button>
              <button type="button" data-set-lang="fr"><img src="assets/img/flag-fr.svg" alt="" width="22" height="15"><span>Français</span></button>
            </div>
          </div><button class="icon-btn theme-btn" type="button" data-theme-toggle aria-label="${esc(R.theme === "dark" ? t("light") : t("dark"))}">${R.theme === "dark" ? ICON.sun : ICON.moon}</button>
          <a class="icon-btn" href="account.html" aria-label="${esc(t("account"))}">${ICON.user}</a>
          <a class="icon-btn" href="wishlist.html" aria-label="${esc(t("wishlist"))}">${ICON.heart}<span class="cart-count wish-count" hidden>0</span></a>
          <button class="icon-btn" type="button" data-open-cart aria-label="${esc(t("cart"))}">${ICON.bag}<span class="cart-count cart-count-n" hidden>0</span></button>
        </div>
      </div>
      <nav class="main-nav" aria-label="Main">
        <div class="container nav-inner">
          ${NAV.map((n) => `
            <div class="nav-item">
              <a href="${esc(R.safeHref(n.href))}">${esc(L(n.label))}${n.flame ? '<span class="flame" data-icon="flame" aria-hidden="true"></span>' : ""}</a>
              ${n.sub?.length ? `<div class="nav-drop">${n.sub.map((s) => `<a href="${esc(R.safeHref(s.href))}">${esc(L(s.label))}</a>`).join("")}</div>` : ""}
            </div>`).join("")}
        </div>
        <button class="nav-scroll" type="button" aria-label="${esc(t("seeAll"))}"><span data-icon="chevronRight" aria-hidden="true"></span></button>
      </nav>`;
    const form = el.querySelector("#header-search");
    const input = form.querySelector("input");
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      openSearch(input.value);
    });
    input.addEventListener("focus", () => {
      input.blur();
      openSearch(input.value);
    });
    el.querySelectorAll("[data-open-cart]").forEach((b) => b.addEventListener("click", openCart));
    el.querySelector("[data-open-menu]")?.addEventListener("click", openMenu);
    el.querySelector(".nav-scroll")?.addEventListener("click", () => {
      el.querySelector(".nav-inner")?.scrollBy({ left: (R.lang === "ar" ? -1 : 1) * 260, behavior: "smooth" });
    });
    el.querySelector("[data-lang-toggle]")?.addEventListener("click", (ev) => {
      ev.stopPropagation();
      el.querySelector(".lang-switch")?.classList.toggle("open");
    });
    el.querySelector("[data-currency-toggle]")?.addEventListener("click", (ev) => {
      ev.stopPropagation();
      el.querySelector(".currency-switch")?.classList.toggle("open");
    });
    el.querySelectorAll("[data-set-currency]").forEach((btn) => {
      btn.addEventListener("click", () => {
        R.setCurrencyMode(btn.dataset.setCurrency);
        el.querySelector(".currency-switch")?.classList.remove("open");
      });
    });
    // Currency label update
    window.addEventListener("restore:currencyMode", () => {
      const label = el.querySelector(".currency-label");
      if (label) label.textContent = currencyLabel();
    });
    // Account dropdown
    el.querySelector("[data-account-toggle]")?.addEventListener("click", (ev) => {
      ev.stopPropagation();
      el.querySelector(".account-dropdown")?.classList.toggle("open");
    });
    el.querySelector("[data-customer-logout]")?.addEventListener("click", () => {
      R.customerLogout();
      location.reload();
    });
    // Close dropdowns on outside click
    document.addEventListener("click", () => {
      el.querySelector(".lang-switch")?.classList.remove("open");
      el.querySelector(".currency-switch")?.classList.remove("open");
      el.querySelector(".account-dropdown")?.classList.remove("open");
    });
    el.querySelector(".lang-current span")?.setAttribute("title", otherLabel);
    hydrateIcons(el);
  }
  function renderCustomerAccount() {
    const root = document.getElementById("customer-account");
    if (!root) return;
    const cust = R.getCustomer();
    if (cust) {
      const initial = String(cust.name || "U").trim().slice(0, 1).toUpperCase();
      root.innerHTML = `
        <div class="account-dropdown">
          <button class="account-btn" type="button" data-account-toggle aria-label="${esc(t("account"))}">
            <span class="account-avatar">${esc(initial)}</span>
            <span class="account-name">${esc(cust.name)}</span>
            ${ICON.chevronDown}
          </button>
          <div class="account-menu">
            <a href="account.html">${ICON.user} ${esc(t("myAccount"))}</a>
            <a href="wishlist.html">${ICON.heart} ${esc(t("wishlist"))}</a>
            <button type="button" data-customer-logout>${ICON.logout} ${esc(t("logout"))}</button>
          </div>
        </div>`;
    } else {
      root.innerHTML = `<a class="btn btn-outline btn-sm account-login-link" href="account.html">${ICON.user} ${esc(t("login"))}</a>`;
    }
  }

  function renderFooter() {
    const el = document.getElementById("site-footer");
    if (!el) return;
    const year = new Date().getFullYear();
    const trust = `
      <div class="trust-bar">
        <div class="container trust-inner">
          <ul class="trust-list">
            ${(SET.trustBar || []).map((item) => `<li><span class="trust-ico" data-icon="${esc(item.icon)}"></span>${esc(L(item.label))}</li>`).join("")}
          </ul>
          <div class="footer-promo">${ICON.bolt}<span>${esc(L(SET.paymentOffer))}</span></div>
        </div>
      </div>`;
    el.innerHTML = trust + `
      <footer class="footer">
        <div class="container footer-main">
          <div>
            <a class="logo" href="index.html" aria-label="${esc(L(SET.storeName))}"><img src="${SET.logoWhite}" alt="${esc(L(SET.storeName))}"></a>
            <div class="footer-contact">
              <h4>${esc(t("contactUs"))}</h4>
              <div class="row"><span>${ICON.mapPin} ${esc(L(SET.address))}</span></div>
              <div class="row"><span>${ICON.whatsapp} <a href="https://wa.me/${esc(SET.whatsapp)}" target="_blank" rel="noopener" dir="ltr">${esc(SET.phoneDisplay)}</a></span><span>${esc(t("replyWithin"))}</span></div>
              <div class="row"><span>${ICON.mail} <a href="mailto:${esc(SET.email)}">${esc(SET.email)}</a></span></div>
              <div class="row"><span>${ICON.clock} ${esc(t("workingHours"))}</span></div>
            </div>
            <div class="footer-pay" aria-label="${esc(t("paymentMethods"))}">
              ${(SET.payments || []).filter((p) => p.active).map((p) => p.image || p.logo
                ? `<span class="pay-badge pay-image" style="--pay:${esc(p.color)}"><img src="${esc(p.image || p.logo)}" alt="${esc(L(p.name))}" loading="lazy"></span>`
                : `<span class="pay-badge pay-text" style="--pay:${esc(p.color)}">${esc(L(p.name))}</span>`).join("")}
            </div>
            <form class="newsletter" id="newsletter-form">
              <label for="newsletter-email">${esc(t("newsletter"))}</label>
              <div><input id="newsletter-email" type="email" placeholder="${esc(t("newsletterPlaceholder"))}" required><button type="submit">${esc(t("subscribe"))}</button></div>
            </form>
          </div>
          ${(SET.footerColumns || []).map((col) => `
            <div>
              <h4>${esc(L(col.title))}</h4>
              <ul class="footer-links">
                ${col.links.map((l) => `<li><a href="${esc(R.safeHref(l.href))}">${esc(L(l.label))}</a></li>`).join("")}
              </ul>
            </div>`).join("")}
        </div>
        <div class="container footer-bottom">
          <p>${esc(t("allRights", { year, store: L(SET.storeName) }))} · ${esc(L(SET.city))}, ${esc(L(SET.country.name))}</p>
          <div class="footer-bottom-links">
            <a href="dashboard.html">${R.lang === "ar" ? "لوحة التحكم" : "Tableau de bord"}</a>
            <div class="socials">
              ${(SET.social || []).map((s) => `<a href="${esc(R.safeHref(s.href, ""))}" target="_blank" rel="noopener" aria-label="${esc(s.id)}">${ICON[s.icon] || ICON.instagram}</a>`).join("")}
            </div>
          </div>
        </div>
      </footer>`;
    const form = el.querySelector("#newsletter-form");
    form?.addEventListener("submit", (event) => {
      event.preventDefault();
      toast(t("subscribed"));
      form.reset();
    });
    hydrateIcons(el);
  }

  /* ------------------------------------------------------------------------
     Cart drawer
     ------------------------------------------------------------------------ */
  function mountCart() {
    if (document.getElementById("cart-drawer")) return;
    const wrap = document.createElement("div");
    wrap.innerHTML = `
      <div class="overlay" id="cart-overlay"></div>
      <aside class="drawer" id="cart-drawer" aria-label="${esc(t("cart"))}" aria-hidden="true">
        <div class="drawer-head">
          <h3>${esc(t("cart"))} <span id="cart-title-count"></span></h3>
          <button class="drawer-close" type="button" data-close-cart aria-label="${esc(t("close"))}">${ICON.close}</button>
        </div>
        <div class="drawer-body" id="cart-body"></div>
        <div class="drawer-foot" id="cart-foot"></div>
      </aside>`;
    document.body.appendChild(wrap);
    document.getElementById("cart-overlay").addEventListener("click", closeCart);
    wrap.querySelector("[data-close-cart]").addEventListener("click", closeCart);
  }

  function openCart() {
    mountCart();
    renderCart();
    document.getElementById("cart-overlay").classList.add("open");
    const d = document.getElementById("cart-drawer");
    d.classList.add("open");
    d.setAttribute("aria-hidden", "false");
    document.body.classList.add("no-scroll");
  }

  function closeCart() {
    document.getElementById("cart-overlay")?.classList.remove("open");
    const d = document.getElementById("cart-drawer");
    if (d) {
      d.classList.remove("open");
      d.setAttribute("aria-hidden", "true");
    }
    document.body.classList.remove("no-scroll");
  }

  function renderCart() {
    if (!document.getElementById("cart-drawer")) return;
    const items = cartDetails();
    const body = document.getElementById("cart-body");
    const foot = document.getElementById("cart-foot");
    const count = items.reduce((n, it) => n + it.qty, 0);
    const titleCount = document.getElementById("cart-title-count");
    if (titleCount) titleCount.textContent = count ? `(${count})` : "";
    if (!items.length) {
      body.innerHTML = `<div class="cart-empty">${ICON.bag}<p>${esc(t("emptyCart"))}</p><a class="btn btn-primary" href="collection.html?handle=all" style="margin-top:16px">${esc(t("shopNow"))}</a></div>`;
      foot.innerHTML = "";
      return;
    }
    body.innerHTML = items.map((it) => `
      <div class="cart-item">
        <a class="cart-item-img" href="product.html?handle=${encodeURIComponent(it.handle)}"><img src="${it.product.image}" alt="${esc(it.product.title)}"></a>
        <div>
          <a class="cart-item-title" href="product.html?handle=${encodeURIComponent(it.handle)}">${esc(it.product.title)}</a>
          <div class="cart-item-var">${esc(variantLabel(it.variant) || "")}</div>
          ${it.specs && Object.keys(it.specs).length ? `<div class="cart-item-specs">${esc(specsText(it.specs))}</div>` : ""}
          <div class="qty">
            <button type="button" data-cart-dec="${esc(it.variant.id)}" data-handle="${esc(it.handle)}" aria-label="-">−</button>
            <span>${it.qty}</span>
            <button type="button" data-cart-inc="${esc(it.variant.id)}" data-handle="${esc(it.handle)}" aria-label="+">+</button>
          </div>
        </div>
        <div class="cart-item-right">
          <div class="cart-item-price">${money(it.line)}</div>
          <button class="cart-remove" type="button" data-cart-remove="${esc(it.variant.id)}" data-handle="${esc(it.handle)}" aria-label="${esc(t("close"))}">${ICON.trash}</button>
        </div>
      </div>`).join("");
    foot.innerHTML = `
      <div class="cart-sub"><span>${esc(t("subtotal"))}</span><span>${money(cartSubtotal())}</span></div>
      <div class="cart-note">${esc(t("shippingCalc"))}</div>
      <a class="btn btn-primary btn-block" href="checkout.html">${esc(t("checkout"))}</a>`;
  }

  /* ------------------------------------------------------------------------
     Search
     ------------------------------------------------------------------------ */
  function mountSearch() {
    if (document.getElementById("search-overlay")) return;
    const el = document.createElement("div");
    el.innerHTML = `
      <div class="search-overlay" id="search-overlay">
        <div class="search-panel" role="dialog" aria-label="${esc(t("search"))}">
          <div class="container">
            <div class="search-panel-head">
              <input id="search-input" type="search" placeholder="${esc(t("searchPlaceholder"))}" autocomplete="off">
              <button class="search-close" type="button" data-close-search aria-label="${esc(t("close"))}">${ICON.close}</button>
            </div>
            <div class="search-hint" id="search-hint">${esc(t("popular"))}</div>
            <div class="search-results" id="search-results"></div>
          </div>
        </div>
      </div>`;
    document.body.appendChild(el);
    const overlay = document.getElementById("search-overlay");
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeSearch();
    });
    overlay.querySelector("[data-close-search]").addEventListener("click", closeSearch);
    overlay.querySelector("#search-input").addEventListener("input", (e) => runSearch(e.target.value));
    overlay.querySelector("#search-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const q = e.target.value.trim();
        if (!q) return;
        closeSearch();
        location.href = `collection.html?q=${encodeURIComponent(q)}`;
      }
    });
    runSearch("");
  }

  function openSearch(q = "") {
    mountSearch();
    const overlay = document.getElementById("search-overlay");
    overlay.classList.add("open");
    document.body.classList.add("no-scroll");
    const input = document.getElementById("search-input");
    input.value = q;
    setTimeout(() => input.focus(), 40);
    runSearch(q);
  }

  function closeSearch() {
    document.getElementById("search-overlay")?.classList.remove("open");
    document.body.classList.remove("no-scroll");
  }

  /* ------------------------------------------------------------------------
     Mobile menu
     ------------------------------------------------------------------------ */
  function mountMenu() {
    if (document.getElementById("menu-drawer")) return;
    const el = document.createElement("div");
    el.innerHTML = `
      <div class="menu-overlay" id="menu-overlay"></div>
      <aside class="menu-drawer" id="menu-drawer" aria-label="${esc(t("menu"))}" aria-hidden="true">
        <div class="drawer-head">
          <h3>${esc(t("menu"))}</h3>
          <button class="drawer-close" type="button" data-close-menu aria-label="${esc(t("close"))}">${ICON.close}</button>
        </div>
        <nav class="menu-links" aria-label="Mobile">
          ${NAV.map((n) => `<a href="${esc(R.safeHref(n.href))}">${esc(L(n.label))}${n.flame ? '<span class="flame" data-icon="flame" aria-hidden="true"></span>' : ""}</a>`).join("")}
        </nav>
        <div class="menu-extra">
          <a href="account.html">${ICON.user} ${esc(t("myAccount"))}</a>
          <a href="wishlist.html">${ICON.heart} ${esc(t("wishlist"))}</a>
          <a href="page.html?slug=help">${ICON.info} ${esc(t("contactUs"))}</a>
          <a href="dashboard.html">${ICON.badgeCheck} ${R.lang === "ar" ? "لوحة التحكم" : "Tableau de bord"}</a>
        </div>
        <div class="menu-preferences">
          <button type="button" data-set-lang="ar" class="${R.lang === "ar" ? "active" : ""}"><img src="assets/img/flag-mr.svg" alt="" width="22"> العربية</button>
          <button type="button" data-set-lang="fr" class="${R.lang === "fr" ? "active" : ""}"><img src="assets/img/flag-fr.svg" alt="" width="22"> Français</button>
          <button type="button" data-theme-toggle>${R.theme === "dark" ? ICON.sun : ICON.moon} ${esc(R.theme === "dark" ? t("light") : t("dark"))}</button>
        </div>
      </aside>`;
    document.body.appendChild(el);
    document.getElementById("menu-overlay").addEventListener("click", closeMenu);
    el.querySelector("[data-close-menu]").addEventListener("click", closeMenu);
    hydrateIcons(el);
  }

  function openMenu() {
    mountMenu();
    document.getElementById("menu-overlay").classList.add("open");
    const d = document.getElementById("menu-drawer");
    d.classList.add("open");
    d.setAttribute("aria-hidden", "false");
    document.body.classList.add("no-scroll");
  }

  function closeMenu() {
    document.getElementById("menu-overlay")?.classList.remove("open");
    const d = document.getElementById("menu-drawer");
    if (d) {
      d.classList.remove("open");
      d.setAttribute("aria-hidden", "true");
    }
    document.body.classList.remove("no-scroll");
  }

  function runSearch(q) {
    const box = document.getElementById("search-results");
    const hint = document.getElementById("search-hint");
    if (!box) return;
    q = (q || "").trim();
    let items;
    if (q.length < 2) {
      hint.textContent = t("popular");
      const popular = ["iphone-13-pro-max", "iphone-14-pro-max", "galaxy-s21-plus", "lenovo-thinkpad-t460-core-i5-6th-gen", "hp-chromebook-11-g3-celeron-5th-gen", "galaxy-z-fold-3", "iphone-15-pro-max", "galaxy-s20-plus"];
      items = popular.map((h) => BY_HANDLE.get(h)).filter((p) => p && PRODUCTS.includes(p));
    } else {
      const found = PRODUCTS.filter((p) => R.matchesQuery(p, q));
      hint.textContent = t("resultsFor", { count: found.length, q });
      items = found.slice(0, 12);
    }
    box.innerHTML = items.length ? items.map((p) => `
      <a class="search-result" href="product.html?handle=${encodeURIComponent(p.handle)}">
        <img src="${p.image}" alt="${esc(p.title)}">
        <div><div class="t">${esc(p.title)}</div><div class="p">${money(p.price)}</div></div>
      </a>`).join("") : `<div class="search-empty">${esc(t("noResults"))} — ${esc(t("tryFilter"))}</div>`;
  }

  /* ------------------------------------------------------------------------
     Product card
     ------------------------------------------------------------------------ */
  const CONDITION_LABELS = {
    "New": { ar: "جديد", fr: "Neuf" },
    "Like New": { ar: "كالجديد", fr: "Comme neuf" },
    "Excellent": { ar: "ممتاز", fr: "Excellent" },
    "Very Good": { ar: "جيد جدًا", fr: "Très bon" },
    "Good": { ar: "جيد", fr: "Bon" },
    "Fair": { ar: "مقبول", fr: "Correct" }
  };
  const conditionLabel = (value) => CONDITION_LABELS[value]?.[R.lang] || value || "";

  function cardHTML(p) {
    const badge = p.discount > 0 ? `<span class="badge">-${p.discount}%</span>` : "";
    const colors = (p.colors || []).slice(0, 4);
    const firstColor = p.colors?.[0];
    const initialImage = (firstColor && p.colorImages?.[firstColor.name]) || p.image;
    const swatches = colors.map((c, i) => `<button class="swatch${i === 0 ? " selected" : ""}" type="button" style="background:${c.hex}" data-color="${esc(c.name)}" data-color-img="${esc(p.colorImages?.[c.name] || p.image)}" data-color-hex="${esc(c.hex)}" title="${esc(c.name)}" aria-label="${esc(c.name)}"></button>`).join("");
    const more = (p.colors || []).length > 4 ? `<span class="swatch-more">+${p.colors.length - 4}</span>` : "";
    const wished = readWish().has(p.handle) ? " active" : "";
    return `
      <article class="product-card" data-handle="${esc(p.handle)}">
        <a class="card-media" href="product.html?handle=${encodeURIComponent(p.handle)}" aria-label="${esc(p.title)}">
          ${badge}<img src="${initialImage}" alt="${esc(p.title)}" loading="lazy" data-card-main>
          <span class="card-tint" data-card-tint aria-hidden="true"></span>
          ${Number(p.stock) <= 0 ? `<span class="sold-out-badge">${esc(t("soldOut"))}</span>` : ""}
        </a>
        <button class="wish${wished}" type="button" data-wish="${esc(p.handle)}" aria-label="${esc(t("addToWishlist"))}">${ICON.heart}</button>
        <a class="card-title" href="product.html?handle=${encodeURIComponent(p.handle)}">${esc(p.title)}</a>
        <div class="card-meta">
          ${p.battery ? `<span class="card-battery">${ICON.bolt}${p.battery}%</span>` : ""}
          <span class="card-condition">${esc(conditionLabel(p.condition))}</span>
        </div>
        <div class="swatches">${swatches}${more}</div>
        <div class="card-price">${money(p.price)} ${p.compare > p.price ? `<s>${money(p.compare)}</s>` : ""}</div>
      </article>`;
  }

  /* ------------------------------------------------------------------------
     Home
     ------------------------------------------------------------------------ */
  function renderHome() {
    const root = document.getElementById("home-root");
    if (!root) return;
    const renderers = {
      hero: heroHTML,
      trust: trustBarHTML,
      renewed: renewedHTML,
      categories: categoriesHTML,
      offer: offerHTML,
      products: productSectionsHTML,
      sustain: sustainHTML,
      service: serviceHTML,
      video: videoHTML,
      reviews: reviewsHTML,
      press: pressHTML
    };
    const order = (SET.pageSections || [])
      .filter((s) => s.visible !== false)
      .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
    root.innerHTML = order.map((section) => renderers[section.id] ? renderers[section.id]() : "").join("");
    setupHero();
    setupCategoryScroller();
    setupCountdowns();
    hydrateIcons(root);
    observeReveals();
  }

  function setupHero() {
    const hero = document.getElementById("hero");
    if (!hero) return;
    const slides = [...hero.querySelectorAll(".hero-slide")];
    const dots = [...hero.querySelectorAll(".hero-dots button")];
    if (!slides.length) return;
    let idx = 0;
    let timer;
    const show = (n) => {
      idx = (n + slides.length) % slides.length;
      slides.forEach((slide, i) => slide.classList.toggle("active", i === idx));
      dots.forEach((dot, i) => dot.classList.toggle("active", i === idx));
    };
    const play = () => {
      clearInterval(timer);
      if (slides.length > 1) timer = setInterval(() => show(idx + 1), 6500);
    };
    hero.querySelector(".prev")?.addEventListener("click", () => { show(idx - 1); play(); });
    hero.querySelector(".next")?.addEventListener("click", () => { show(idx + 1); play(); });
    dots.forEach((dot, i) => dot.addEventListener("click", () => { show(i); play(); }));
    hero.addEventListener("mouseenter", () => clearInterval(timer));
    hero.addEventListener("mouseleave", play);
    play();
  }

  function setupCategoryScroller() {
    const track = document.getElementById("cat-track");
    document.querySelector(".cat-arrow")?.addEventListener("click", () => track?.scrollBy({ left: (R.lang === "ar" ? -1 : 1) * 380, behavior: "smooth" }));
  }

  function setupCountdowns() {
    const nodes = [...document.querySelectorAll("[data-countdown]")];
    if (!nodes.length) return;
    const tick = () => {
      nodes.forEach((node) => {
        const end = Date.parse(node.dataset.countdown || "");
        if (!end) { node.innerHTML = ""; return; }
        const diff = end - Date.now();
        if (diff <= 0) {
          node.innerHTML = `<span class="countdown-ended">${R.lang === "ar" ? "انتهى العرض" : "Offre terminée"}</span>`;
          return;
        }
        const days = Math.floor(diff / 864e5);
        const hours = Math.floor((diff % 864e5) / 36e5);
        const mins = Math.floor((diff % 36e5) / 6e4);
        const secs = Math.floor((diff % 6e4) / 1000);
        node.innerHTML = `
          <span class="countdown-label">${esc(t("offerEnds"))}</span>
          <span class="countdown-box"><b>${days}</b><small>${esc(t("days"))}</small></span>
          <span class="countdown-box"><b>${String(hours).padStart(2, "0")}</b><small>${esc(t("hours"))}</small></span>
          <span class="countdown-box"><b>${String(mins).padStart(2, "0")}</b><small>${esc(t("minutes"))}</small></span>
          <span class="countdown-box"><b>${String(secs).padStart(2, "0")}</b><small>${esc(t("seconds"))}</small></span>`;
      });
    };
    tick();
    clearInterval(window.__restoreCountdown);
    window.__restoreCountdown = setInterval(tick, 1000);
  }

  let revealObserver;
  function observeReveals() {
    const nodes = document.querySelectorAll(".reveal:not(.in)");
    if (!nodes.length) return;
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      nodes.forEach((node) => node.classList.add("in"));
      return;
    }
    revealObserver = revealObserver || new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: "0px 0px -30px" });
    nodes.forEach((node) => revealObserver.observe(node));
  }

  /* ------------------------------------------------------------------------
     Home sections
     ------------------------------------------------------------------------ */
  function heroHTML() {
    const slides = (SET.heroSlides || []).filter((s) => s.visible !== false);
    if (!slides.length) return "";
    return `<section class="hero" id="hero" aria-label="${esc(L(SET.tagline))}">
      ${slides.map((slide, i) => {
        const image = slide.image || "assets/products/iphone-13-pro-max-1.png";
        const light = slide.dark === false;
        return `<div class="hero-slide hero-banner ${light ? "hero-light" : "hero-dark"}${i === 0 ? " active" : ""}" style="background:${esc(slide.bg || "linear-gradient(135deg,#1f1f2e,#39255b)")}">
          <div class="container hero-inner">
            <div class="hero-copy">
              <span class="hero-eyebrow">${esc(L(SET.storeName))} · ${esc(L(SET.city))}</span>
              <h1>${esc(L(slide.title))}</h1>
              <p>${esc(L(slide.subtitle))}</p>
              <a class="btn ${light ? "btn-dark" : "btn-primary"}" href="${esc(R.safeHref(slide.href || "collection.html?handle=all"))}">${esc(L(slide.cta) || t("shopNow"))} ${ICON.arrowRight}</a>
              <div class="hero-pills">
                <span>${ICON.shield} ${esc(t("warranty"))}</span>
                <span>${ICON.truck} ${esc(t("freeDelivery"))}</span>
                <span>${ICON.badgeCheck} ${esc(t("checked"))}</span>
              </div>
            </div>
            <div class="hero-visual">
              <div class="hero-glow"></div>
              <img src="${esc(image)}" alt="${esc(L(slide.title))}" loading="${i === 0 ? "eager" : "lazy"}">
            </div>
          </div>
        </div>`;
      }).join("")}
      ${slides.length > 1 ? `<button class="hero-arrow prev" type="button" aria-label="Previous">${ICON.chevronLeft}</button>
        <button class="hero-arrow next" type="button" aria-label="Next">${ICON.chevronRight}</button>
        <div class="hero-dots">${slides.map((_, i) => `<button type="button" class="${i === 0 ? "active" : ""}" aria-label="Slide ${i + 1}"></button>`).join("")}</div>` : ""}
    </section>`;
  }

  function trustBarHTML() {
    return `<div class="trust-bar home-trust reveal">
      <div class="container trust-inner">
        <ul class="trust-list">
          ${(SET.trustBar || []).map((item) => `<li><span class="trust-ico" data-icon="${esc(item.icon)}"></span>${esc(L(item.label))}</li>`).join("")}
        </ul>
        <a class="bnpl" href="checkout.html">${ICON.bolt} ${esc(L(SET.paymentOffer))}</a>
      </div>
    </div>`;
  }

  function renewedHTML() {
    return `<a class="renewed reveal" href="page.html?slug=renewed">
      <span class="info">i</span>
      ${esc(L(SET.renewalText))}
      <span data-icon="chevronRight" aria-hidden="true"></span>
    </a>`;
  }

  function categoriesHTML() {
    return `<section class="categories reveal" aria-labelledby="cat-heading">
      <div class="container">
        <h2 id="cat-heading">${esc(L(SET.categoriesTitle))}</h2>
        <div class="cat-wrap">
          <div class="cat-track" id="cat-track">
            ${(S.theme?.categories || []).map((c) => `
              <a class="cat-card" href="collection.html?handle=${encodeURIComponent(c.handle)}">
                <img src="${c.image}" alt="${esc(L(c.label))}" loading="lazy"><span>${esc(L(c.label))}</span>
              </a>`).join("")}
          </div>
          <button class="cat-arrow" type="button" aria-label="${esc(t("seeAll"))}"><span data-icon="chevronRight"></span></button>
        </div>
      </div>
    </section>`;
  }

  function offerHTML() {
    const offer = (SET.offers || []).find((o) => o.active !== false);
    if (!offer) return "";
    const ends = offer.endsAt ? Date.parse(offer.endsAt) : 0;
    return `<section class="offer-banner reveal">
      <div class="container">
        <div class="offer-card">
          <div class="offer-copy">
            <span class="offer-tag">${ICON.bolt} ${esc(t("paymentOfferShort"))}</span>
            <h2>${esc(L(offer.title))}</h2>
            <p>${esc(L(offer.subtitle))}</p>
            ${ends ? `<div class="countdown" data-countdown="${esc(offer.endsAt)}"></div>` : ""}
          </div>
          <div class="offer-side">
            <div class="offer-code"><small>${R.lang === "ar" ? "استخدم الكود" : "Code"}</small><strong>${esc(offer.code || "BANKILY10")}</strong></div>
            <a class="btn btn-primary" href="${esc(R.safeHref(offer.href || "collection.html?handle=all"))}">${esc(t("shopNow"))} ${ICON.arrowRight}</a>
          </div>
        </div>
      </div>
    </section>`;
  }

  function productSectionHTML(section) {
    let items = (section.handles || []).map((h) => BY_HANDLE.get(h)).filter((p) => p && PRODUCTS.includes(p));
    if (!items.length) {
      items = PRODUCTS.filter((p) => (p.collections || []).includes(section.collection)).slice(0, 10);
    }
    if (!items.length) return "";
    const cards = items.slice(0, 12).map(cardHTML).join("");
    const head = `
      <div class="section-head">
        <h2>${esc(L(section.title))}${section.flame ? '<span class="flame" data-icon="flame" aria-hidden="true"></span>' : ""}</h2>
        <a class="see-all" href="collection.html?handle=${encodeURIComponent(section.collection || "all")}">${esc(t("seeAll"))}</a>
      </div>`;
    if (section.layout === "plain") {
      return `<section class="product-section reveal"><div class="container">${head}
        <div class="carousel-wrap">
          <div class="track-clip"><div class="track">${cards}</div></div>
          <button class="carousel-arrow next" type="button" data-scroll="next" aria-label="${esc(t("seeAll"))}">${ICON.chevronRight}</button>
        </div></div></section>`;
    }
    const promo = section.promo ? `<a class="promo" href="collection.html?handle=${encodeURIComponent(section.collection || "all")}"><img src="${esc(section.promo)}" alt="${esc(L(section.title))}" loading="lazy"></a>` : "";
    const panel = `<div class="carousel-wrap"><div class="carousel-panel"><div class="track">${cards}</div></div>
      <button class="carousel-arrow next" type="button" data-scroll="next" aria-label="${esc(t("seeAll"))}">${ICON.chevronRight}</button></div>`;
    return `<section class="product-section reveal"><div class="container">${head}
      <div class="blocks with-${section.layout || "left"}">${section.layout === "right" ? panel + promo : promo + panel}</div></div></section>`;
  }

  function productSectionsHTML() {
    return (SET.homeSections || [])
      .filter((s) => s.visible !== false)
      .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
      .map(productSectionHTML)
      .join("");
  }


  const SUSTAIN_CARDS = [
    { id: "green", icon: "recycle", title: { ar: "تقنية تدوم أطول", fr: "Une tech qui dure plus longtemps" }, text: { ar: "كل جهاز مجدد يقلل النفايات الإلكترونية ويؤخر الحاجة إلى جهاز جديد.", fr: "Chaque appareil reconditionné réduit les déchets électroniques et repousse l’achat d’un appareil neuf." } },
    { id: "orange", icon: "leaf", title: { ar: "أثر بيئي أقل", fr: "Moins d’impact environnemental" }, text: { ar: "نستخدم تغليفًا بسيطًا ونقلل الموارد المستهلكة في كل عملية تجديد.", fr: "Nous utilisons un emballage simple et réduisons les ressources consommées à chaque reconditionnement." } },
    { id: "purple", icon: "shield", title: { ar: "قيمة حقيقية", fr: "Une vraie valeur" }, text: { ar: "أجهزة موثوقة بأسعار عادلة، مع ضمان واضح ودعم محلي في موريتانيا.", fr: "Des appareils fiables à prix juste, avec une garantie claire et un support local en Mauritanie." } }
  ];
  function sustainHTML() {
    return `<section class="sustain reveal" aria-label="${R.lang === "ar" ? "الاستدامة" : "Durabilité"}">
      <div class="container">
        <div class="sustain-track">
          ${SUSTAIN_CARDS.map((card) => `<article class="sustain-card sustain-${card.id}">
            <span class="sustain-ico" data-icon="${card.icon}"></span>
            <h3>${esc(L(card.title))}</h3>
            <p>${esc(L(card.text))}</p>
          </article>`).join("")}
        </div>
        <div class="sustain-dots" aria-hidden="true">
          ${SUSTAIN_CARDS.map((_, i) => `<button class="${i === 0 ? "active" : ""}" type="button"></button>`).join("")}
        </div>
      </div>
    </section>`;
  }

  function serviceHTML() {
    const items = SET.serviceItems || [];
    const feature = (item) => `<div class="feature">
      <span class="ico" data-icon="${esc(item.icon)}" aria-hidden="true"></span>
      <h3>${esc(L(item.title))}</h3>
      <p>${esc(L(item.text))}</p>
    </div>`;
    return `<div class="container">
      <section class="service reveal" aria-labelledby="service-heading">
        <h2 id="service-heading">${esc(L(SET.serviceTitle))}</h2>
        <div class="service-grid">
          <div>${items.slice(0, 2).map(feature).join("")}</div>
          <img class="service-img" src="assets/img/service-phones.webp" alt="${esc(L(SET.storeName))}" loading="lazy">
          <div>${items.slice(2, 4).map(feature).join("")}</div>
        </div>
      </section>
    </div>`;
  }

  function videoHTML() {
    const socials = (SET.social || []).map((s) => `<a href="${esc(R.safeHref(s.href, ""))}" target="_blank" rel="noopener" aria-label="${esc(s.id)}">${ICON[s.icon] || ICON.instagram}</a>`).join("");
    const images = ["assets/img/restore/video-1.svg", "assets/img/restore/video-2.svg", "assets/img/restore/video-3.svg", "assets/img/restore/video-4.svg", "assets/img/restore/video-5.svg"];
    return `<section class="video-section reveal" aria-labelledby="video-heading">
      <div class="container">
        <h2 id="video-heading">${esc(L(SET.trustTitle))}</h2>
        <div class="video-panel">
          <div class="community">
            <h3>${esc(L(SET.communityTitle))}</h3>
            <div class="socials">${socials}</div>
          </div>
          ${images.map((src, i) => `<a class="video-card" href="#" data-video aria-label="${R.lang === "ar" ? "قصة عميل" : "Témoignage client"}">
            <img src="${src}" alt="" loading="lazy"><span class="play" data-icon="play" aria-hidden="true"></span>
          </a>`).join("")}
          <button class="carousel-arrow" type="button" data-scroll="next" aria-label="${esc(t("seeAll"))}"><span data-icon="chevronRight"></span></button>
        </div>
      </div>
    </section>`;
  }

  function starsHTML(rating, className = "review-stars") {
    return `<div class="${className}" aria-label="${rating} / 5">${[1, 2, 3, 4, 5].map((n) => `<span class="tp-star${n > rating ? " off" : ""}" data-icon="star"></span>`).join("")}</div>`;
  }

  function reviewsHTML() {
    const reviews = S.homeReviews || [];
    return `<section class="reviews reveal" aria-labelledby="reviews-heading">
      <div class="container">
        <div class="reviews-head">
          <h2 id="reviews-heading">${esc(L(SET.reviewsTitle))}</h2>
          <div class="reviews-meta">
            <span>${esc(L(SET.trustTitle))}</span>
            <span class="sep">|</span>
            <span>${esc(t("excellent"))}</span>
            <span class="tp-stars" aria-label="5 / 5">${[1, 2, 3, 4, 5].map(() => `<span class="tp-star" data-icon="star"></span>`).join("")}</span>
            <span class="tp-logo"><span class="mark" data-icon="star"></span>${esc(L(SET.storeName))}</span>
          </div>
        </div>
        <div class="reviews-track">
          ${reviews.map((review) => `<article class="review-card">
            <span class="review-avatar" style="background:${esc(review.color || "#2e7d6f")}">${esc((review.name || "R").slice(0, 1))}</span>
            <div class="review-name">${esc(review.name)}</div>
            ${starsHTML(Number(review.rating) || 5)}
            <div class="review-title">${esc(L(review.title))}</div>
            <p class="review-body">${esc(L(review.body))}</p>
          </article>`).join("")}
        </div>
        <div class="reviews-dots" aria-hidden="true">${reviews.map((_, i) => `<button class="${i === 0 ? "active" : ""}" type="button"></button>`).join("")}</div>
      </div>
    </section>`;
  }

  function pressHTML() {
    const items = S.press || [];
    return `<section class="press reveal" aria-label="${esc(L(SET.pressTitle))}">
      <div class="container">
        <h2 class="press-title">${esc(L(SET.pressTitle))}</h2>
        <div class="press-grid">
          ${items.map((item) => `<div>
            <div class="press-outlet">${esc(L(item.outlet))}</div>
            <p>“${esc(L(item.quote))}”</p>
          </div>`).join("")}
        </div>
        <div class="press-dots" aria-hidden="true"><button class="active" type="button"></button><button type="button"></button></div>
      </div>
    </section>`;
  }

  const COL = { handle: "all", q: "", brand: "all", sale: false, sort: "featured", shown: 10, items: [] };

  function renderCollection() {
    const params = new URLSearchParams(location.search);
    COL.handle = params.get("handle") || "all";
    COL.q = (params.get("q") || "").trim();
    const col = S.collections.find((c) => c.handle === COL.handle);
    const list = COL.handle === "all" ? PRODUCTS.slice() : PRODUCTS.filter((p) => (p.collections || []).includes(COL.handle));
    COL.items = COL.q ? list.filter((p) => R.matchesQuery(p, COL.q)) : list;

    const title = COL.q ? `${t("searchResults")}: “${COL.q}”` : col ? L(col.title) : COL.handle === "all" ? t("allProducts") : t("collection");
    document.title = `${title} | ${L(SET.storeName)}`;
    document.getElementById("col-title").textContent = title;
    document.getElementById("col-count").textContent = `${COL.items.length} ${COL.items.length === 1 ? t("product") : t("products")}`;
    const sortLabel = document.querySelector(".sort-wrap label");
    if (sortLabel) sortLabel.textContent = t("sortBy");

    const crumb = document.getElementById("col-crumb");
    if (crumb) crumb.innerHTML = `<a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><span>${esc(title)}</span>`;

    const vendors = [...new Set(COL.items.map((p) => p.vendor).filter(Boolean))].sort();
    const filters = document.getElementById("col-filters");
    filters.innerHTML = `
      <button class="chip ${COL.brand === "all" && !COL.sale ? "active" : ""}" type="button" data-brand="all">${esc(t("all"))}</button>
      ${vendors.map((v) => `<button class="chip ${COL.brand === v ? "active" : ""}" type="button" data-brand="${esc(v)}">${esc(v)}</button>`).join("")}
      <button class="chip ${COL.sale ? "active" : ""}" type="button" data-sale="1">${esc(t("onSale"))}</button>`;

    const sort = document.getElementById("col-sort");
    if (sort) {
      const labels = [["featured", "featured"], ["price-asc", "priceLow"], ["price-desc", "priceHigh"], ["discount", "biggestDiscount"], ["title", "nameAZ"]];
      sort.innerHTML = labels.map(([value, key]) => `<option value="${value}">${esc(t(key))}</option>`).join("");
      sort.value = COL.sort;
    }
    drawCollectionGrid();
    bindCollectionOnce();
  }

  function drawCollectionGrid() {
    let items = COL.items.slice();
    if (COL.brand !== "all") items = items.filter((p) => p.vendor === COL.brand);
    if (COL.sale) items = items.filter((p) => p.discount > 0);
    if (COL.sort === "price-asc") items.sort((a, b) => R.effectivePrice(a) - R.effectivePrice(b));
    else if (COL.sort === "price-desc") items.sort((a, b) => R.effectivePrice(b) - R.effectivePrice(a));
    else if (COL.sort === "discount") items.sort((a, b) => b.discount - a.discount);
    else if (COL.sort === "title") items.sort((a, b) => a.title.localeCompare(b.title));

    const grid = document.getElementById("col-grid");
    const shown = items.slice(0, COL.shown);
    grid.innerHTML = shown.length
      ? shown.map(cardHTML).join("")
      : `<div class="empty-state" style="grid-column:1/-1"><h2>${esc(t("noProducts"))}</h2><p>${esc(t("tryFilter"))}</p><a class="btn btn-primary" href="collection.html?handle=all">${esc(t("browseAll"))}</a></div>`;
    const count = document.querySelector(".collection-head .count");
    if (count) count.textContent = `${items.length} ${items.length === 1 ? t("product") : t("products")}`;
    const more = document.getElementById("load-more");
    if (more) {
      more.style.display = items.length > COL.shown ? "" : "none";
      more.textContent = t("loadMore");
    }
    observeReveals();
    hydrateIcons(grid);
  }

  let collectionBound = false;
  function bindCollectionOnce() {
    if (collectionBound) return;
    collectionBound = true;
    document.getElementById("col-sort")?.addEventListener("change", (e) => {
      COL.sort = e.target.value;
      COL.shown = 10;
      drawCollectionGrid();
    });
    document.getElementById("load-more")?.addEventListener("click", () => {
      COL.shown += 10;
      drawCollectionGrid();
    });
    document.addEventListener("click", (e) => {
      const b = e.target.closest("[data-brand]");
      if (b) {
        COL.brand = b.dataset.brand;
        COL.shown = 10;
        document.querySelectorAll("[data-brand]").forEach((x) => x.classList.toggle("active", x === b));
        drawCollectionGrid();
      }
      const s = e.target.closest("[data-sale]");
      if (s) {
        COL.sale = !COL.sale;
        s.classList.toggle("active", COL.sale);
        COL.shown = 10;
        drawCollectionGrid();
      }
    });
  }

  /* ------------------------------------------------------------------------
     Product page
     ------------------------------------------------------------------------ */
  const PDP = { p: null, sel: {}, qty: 1, specs: {} };

  const OPT_LABELS = {
    color: { ar: "اللون", fr: "Couleur" },
    colour: { ar: "اللون", fr: "Couleur" },
    storage: { ar: "التخزين", fr: "Stockage" },
    "storage/ram": { ar: "التخزين / الذاكرة", fr: "Stockage / RAM" },
    condition: { ar: "الحالة", fr: "État" },
    ram: { ar: "الذاكرة", fr: "RAM" },
    cpu: { ar: "المعالج", fr: "Processeur" },
    connectivity: { ar: "الاتصال", fr: "Connectivité" },
    "strap color": { ar: "لون السوار", fr: "Couleur du bracelet" }
  };
  const optLabel = (name) => OPT_LABELS[String(name).toLowerCase()]?.[R.lang] || name;
  const optValue = (name, value) => /condition|état/i.test(name) ? conditionLabel(value) : value;

  function productSeed(p) {
    let h = 0;
    for (let i = 0; i < p.handle.length; i++) h = (h * 31 + p.handle.charCodeAt(i)) >>> 0;
    return h;
  }

  function productReviews(p) {
    const moderated = R.getProductReviews(p.handle).map((review) => ({
      ...review,
      handle: p.handle,
      name: review.customerName,
      date: review.createdAt
    }));
    const specific = (S.reviews || []).filter((r) => (r.handle === p.handle || r.productHandle === p.handle) && r.approved !== false);
    if (moderated.length || specific.length) {
      const seen = new Set();
      return [...moderated, ...specific].filter((review) => {
        const key = review.id || `${review.name}:${L(review.title)}:${review.date}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }
    const seed = productSeed(p);
    const names = [
      ["أحمد ولد محمد", "Ahmed Ould Mohamed"],
      ["مريم بنت أحمد", "Mariem Mint Ahmed"],
      ["الشيخ ولد سيدي", "Cheikh Ould Sidi"],
      ["فاطمة بنت عبد الله", "Fatimetou Mint Abdallah"]
    ];
    const titles = [
      { ar: "جهاز مطابق للوصف", fr: "Conforme à la description" },
      { ar: "تغليف جيد وتوصيل سريع", fr: "Bien emballé et livraison rapide" },
      { ar: "قيمة ممتازة", fr: "Excellent rapport qualité-prix" }
    ];
    const bodies = [
      { ar: "وصل الجهاز بحالة ممتازة، البطارية جيدة والاتصال ممتاز. خدمة واتساب كانت سريعة.", fr: "L’appareil est arrivé en excellent état, batterie correcte et connectivité parfaite. Le service WhatsApp a été rapide." },
      { ar: "طلبت يوم الأحد ووصلني في نواكشوط يوم الاثنين. كل شيء يعمل كما هو مذكور.", fr: "Commandé dimanche, livré lundi à Nouakchott. Tout fonctionne comme annoncé." },
      { ar: "السعر أقل من الجديد والضمان أعطاني ثقة. أنصح به لمن يبحث عن جهاز موثوق.", fr: "Le prix est bien inférieur au neuf et la garantie inspire confiance. Je recommande." }
    ];
    return [0, 1, 2].map((i) => ({
      id: `${p.handle}-review-${i}`,
      handle: p.handle,
      name: R.lang === "ar" ? names[(seed + i) % names.length][0] : names[(seed + i) % names.length][1],
      rating: 4 + ((seed + i) % 2),
      title: titles[(seed + i) % titles.length],
      body: bodies[(seed + i) % bodies.length],
      verified: true,
      date: "2026-09-18"
    }));
  }

  function productRating(p) {
    const reviews = productReviews(p);
    return (reviews.reduce((sum, r) => sum + (Number(r.rating) || 5), 0) / Math.max(1, reviews.length)).toFixed(1);
  }

  function specKeysFor(p) {
    if (p.type === "Macbook" || p.type === "Laptop") return ["cpu", "ram", "storage", "screen", "keyboard", "condition"];
    if (p.type === "Smartphone") return ["storage", "screen", "condition", "battery"];
    if (p.type === "Tablets") return ["storage", "screen", "condition", "battery"];
    if (p.type === "Apple Watch") return ["screen", "condition", "battery"];
    if (p.type === "Playstation") return ["storage", "condition"];
    return ["condition", "battery"];
  }

  function pdpSpecsHTML(p) {
    const specs = p.specs || {};
    const keys = specKeysFor(p).filter((key) => specs[key]);
    if (!keys.length) return "";
    return `<div class="specs-section">
      <div class="specs-head"><span>${esc(t("personalization"))}</span><small>${esc(t("chooseSpecs"))}</small></div>
      <div class="specs-grid">
        ${keys.map((key) => {
          const spec = specs[key];
          const value = PDP.specs[key] ?? spec.value;
          const choices = [...new Set((spec.choices || []).filter(Boolean))];
          const isBattery = key === "battery";
          if (!choices.length || isBattery) {
            return `<div class="spec-field static"><span>${esc(L(spec.label))}</span><strong dir="auto">${esc(value)}</strong>${isBattery ? `<em class="battery-pill">${ICON.bolt}${p.battery ? `${p.battery}%` : value}</em>` : ""}</div>`;
          }
          return `<div class="spec-field"><label>${esc(L(spec.label))}</label>
            <select dir="ltr" data-spec="${esc(key)}">${choices.map((choice) => `<option value="${esc(choice)}" ${String(choice) === String(value) ? "selected" : ""}>${esc(choice)}</option>`).join("")}</select>
          </div>`;
        }).join("")}
      </div>
    </div>`;
  }

  function pdpVariant() {
    const p = PDP.p;
    if (!p) return null;
    const keys = (p.options || []).map((o) => o.name);
    let v = (p.variants || []).find((x) => keys.every((k, i) => x["o" + (i + 1)] === PDP.sel[k]));
    if (!v) v = (p.variants || []).find((x) => x.available) || p.variants?.[0];
    return v;
  }

  function pdpInfoHTML() {
    const p = PDP.p;
    const v = pdpVariant();
    const price = Number(v?.price ?? p.price);
    const compare = v?.compare ?? p.compare;
    const disc = discountFor(price, compare);
    const rating = productRating(p);
    const reviewsCount = productReviews(p).length;
    const conditionOption = p.options?.find((o) => /condition|état/i.test(o.name));
    const currentCondition = conditionLabel(conditionOption?.values?.find((value) => value === PDP.sel[conditionOption.name]) || p.condition);
    const options = (p.options || []).map((o) => {
      if (!o.values.length) return "";
      const isColor = /color|colour/i.test(o.name);
      const buttons = o.values.map((val) => {
        const active = PDP.sel[o.name] === val;
        if (isColor) {
          const c = (p.colors || []).find((x) => x.name === val);
          return `<button class="opt-btn color-opt ${active ? "active" : ""}" type="button" data-opt="${esc(o.name)}" data-value="${esc(val)}" data-color-hex="${esc(c?.hex || "")}"><span class="color-dot" style="background:${c ? c.hex : "#ccc"}"></span>${esc(val)}</button>`;
        }
        return `<button class="opt-btn ${active ? "active" : ""}" type="button" dir="auto" data-opt="${esc(o.name)}" data-value="${esc(val)}">${esc(optValue(o.name, val))}</button>`;
      }).join("");
      return `<div class="opt-label">${esc(optLabel(o.name))} <span dir="auto">${esc(optValue(o.name, PDP.sel[o.name] || ""))}</span></div><div class="opt-values">${buttons}</div>`;
    }).join("");

    const soldOut = Number(p.stock) <= 0 || !p.available || !v?.available;
    const whatsappText = `${R.lang === "ar" ? "مرحباً" : "Bonjour"} ${L(SET.storeName)}، ${R.lang === "ar" ? "أريد الاستفسار عن" : "je voudrais des informations sur"} ${p.title}${v?.title ? ` (${v.title})` : ""}.`;
    return `
      <div class="product-info" id="product-info">
        <div class="vendor">${esc(p.vendor || L(SET.storeName))}</div>
        <h1>${esc(p.title)}</h1>
        <div class="rating">${[1, 2, 3, 4, 5].map((n) => `<span class="tp-star${n > Math.round(Number(rating)) ? " off" : ""}" data-icon="star"></span>`).join("")}<span>${rating} · ${reviewsCount} ${esc(t("reviews"))}</span></div>
        <div class="product-badges">
          ${p.battery ? `<span class="product-badge battery">${ICON.bolt} ${esc(t("battery"))} ${p.battery}%</span>` : ""}
          <span class="product-badge">${esc(currentCondition)}</span>
          ${p.type === "Macbook" ? `<span class="product-badge">${ICON.apple} ${esc(t("macos"))}</span>` : ""}
        </div>
        <div class="price-row">
          <span class="price-now">${money(price)}</span>
          ${compare && compare > price ? `<span class="price-was">${money(compare)}</span><span class="price-badge">-${disc}%</span>` : ""}
        </div>
        <div class="payment-offer-line">${ICON.bolt}<span>${esc(L(SET.paymentOffer))}</span></div>
        ${options}
        ${pdpSpecsHTML(p)}
        <div class="opt-label">${esc(t("quantity"))}</div>
        <div class="qty">
          <button type="button" data-qty="-1" aria-label="-">−</button>
          <span id="qty-val">${PDP.qty}</span>
          <button type="button" data-qty="1" aria-label="+">+</button>
        </div>
        <div class="product-actions">
          <button class="btn btn-primary" type="button" data-add-cart ${soldOut ? "disabled" : ""}>${soldOut ? esc(t("soldOut")) : esc(t("addToCart"))}</button>
          <button class="btn btn-dark" type="button" data-buy-now ${soldOut ? "disabled" : ""}>${esc(t("buyNow"))}</button>
        </div>
        <a class="whatsapp-order" href="https://wa.me/${esc(SET.whatsapp)}?text=${encodeURIComponent(whatsappText)}" target="_blank" rel="noopener">${ICON.whatsapp} ${esc(t("orderWhatsApp"))}</a>
        <div class="trust-mini">
          <div>${ICON.truck}<span>${esc(t("freeDelivery"))}<small>${esc(t("freeDeliverySub"))}</small></span></div>
          <div>${ICON.shield}<span>${esc(t("warranty"))}<small>${esc(t("warrantySub"))}</small></span></div>
          <div>${ICON.return}<span>${esc(t("returns"))}<small>${esc(t("returnsSub"))}</small></span></div>
          ${p.type === "Macbook" ? `<div>${ICON.badgeCheck}<span>${esc(t("macos"))}<small>${esc(t("checkedSub"))}</small></span></div>` : `<div>${ICON.badgeCheck}<span>${esc(t("checked"))}<small>${esc(t("checkedSub"))}</small></span></div>`}
        </div>
        <div class="included-card">
          <h3>${esc(t("whatsIncluded"))}</h3>
          <ul>${(p.includes || []).map((item) => `<li>${ICON.check}<span>${esc(L(item))}</span></li>`).join("")}</ul>
        </div>
        <div class="accordion">
          <details open><summary>${esc(t("description"))}</summary><div class="acc-body"><p>${esc(L(p.description))}</p><p class="muted">${esc(L(SET.originalDevice))} · ${esc(t("warrantyMonths", { months: p.warrantyMonths || 12 }))}</p></div></details>
          <details><summary>${esc(t("shippingDelivery"))}</summary><div class="acc-body"><p>${esc(L(SET.shippingNote))}</p><p>${esc(R.lang === "ar" ? "نواكشوط: توصيل مجاني · باقي المدن: رسوم حسب الولاية." : "Nouakchott : livraison offerte · Autres villes : frais selon la wilaya.")}</p></div></details>
          <details><summary>${esc(t("warrantyReturns"))}</summary><div class="acc-body"><p>${esc(R.lang === "ar" ? "ضمان 12 شهرًا يغطي الأعطال التقنية، وإرجاع خلال 10 أيام في حال وجود مشكلة." : "Garantie 12 mois couvrant les pannes techniques et retour sous 10 jours en cas de problème.")}</p></div></details>
        </div>
      </div>
      ${renderProductReviews(p)}`;
  }

  
  function renderProductReviews(product) {
    const reviews = R.getProductReviews(product.handle);
    const cust = R.getCustomer();
    const pending = cust ? R.customerReviews().filter((r) => r.productHandle === product.handle && r.status === "pending") : [];
    const canReview = Boolean(cust) && !pending.length;
    const average = reviews.length ? reviews.reduce((sum, r) => sum + Number(r.rating || 5), 0) / reviews.length : 0;
    return `
      <section class="product-reviews reveal" aria-labelledby="reviews-heading">
        <div class="container">
          <div class="reviews-head">
            <h2 id="reviews-heading">${esc(t("reviews"))} <span class="reviews-count">(${reviews.length})</span></h2>
            ${reviews.length ? `<div class="reviews-summary">${renderRatingStars(average)} <span>${average.toFixed(1)} / 5 · ${reviews.length} ${esc(t("reviews"))}</span></div>` : ""}
          </div>
          ${pending.length ? `<div class="review-pending-note">${ICON.shield} ${esc(t("reviewPending"))}</div>` : ""}
          <div class="reviews-list">
            ${reviews.length ? reviews.map((r) => `
              <article class="review-card">
                <div class="review-header">
                  <span class="review-avatar" style="background:${hashColor(String(r.customerName || "R"))}">${esc(String(r.customerName || "R").slice(0, 1))}</span>
                  <div>
                    <strong>${esc(r.customerName || "")}${r.verified ? ` <span class="verified-badge">${esc(t("verifiedBuyer"))}</span>` : ""}</strong>
                    <div class="review-meta">${renderRatingStars(Number(r.rating) || 5)} <time>${esc(R.formatDate(r.createdAt))}</time></div>
                  </div>
                </div>
                <h4>${esc(L(r.title))}</h4>
                <p>${esc(L(r.body))}</p>
              </article>`).join("") : `<p class="muted">${esc(t("noReviews"))}</p>`}
          </div>
          ${canReview ? `
            <div class="review-form" id="review-form">
              <h3>${esc(t("writeReview"))}</h3>
              <div class="form-grid">
                <div class="field"><label>${esc(t("rating"))}</label>
                  <div class="rating-input" data-rating="0">
                    ${[1, 2, 3, 4, 5].map((n) => `<button type="button" data-star="${n}" aria-label="${n} / 5">${ICON.star}</button>`).join("")}
                  </div>
                </div>
                <div class="field"><label>${esc(t("title"))}</label><input type="text" id="review-title" placeholder="${esc(t("reviewTitlePlaceholder"))}"></div>
                <div class="field span-2"><label>${esc(t("comment"))}</label><textarea id="review-body" rows="3" placeholder="${esc(t("reviewBodyPlaceholder"))}"></textarea></div>
                <div class="field span-2"><button class="btn btn-primary" type="button" id="submit-review">${esc(t("submitReview"))}</button></div>
              </div>
            </div>` : cust ? "" : `
            <p class="review-login-prompt"><a href="account.html">${esc(t("loginToReview"))}</a></p>`}
        </div>
      </section>`;
  }

  function renderRatingStars(rating) {
    const full = Math.round(rating);
    return [1,2,3,4,5].map(n => `<span class="tp-star${n > full ? " off" : ""}" data-icon="star"></span>`).join("");
  }

  function hashColor(str) {
    let hash = 0;
    for (let i=0;i<str.length;i++) hash = str.charCodeAt(i) + ((hash<<5)-hash);
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 65%, 45%)`;
  }

function renderProduct() {
    const handle = new URLSearchParams(location.search).get("handle");
    const p = handle ? BY_HANDLE.get(handle) : null;
    if (!p) {
      document.title = `${t("productNotFound")} | ${L(SET.storeName)}`;
      const crumb = document.getElementById("prod-crumb");
      if (crumb) crumb.innerHTML = `<a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><span>${esc(t("productNotFound"))}</span>`;
      const root = document.getElementById("product-root");
      if (root) root.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
        <h2>${esc(t("productNotFound"))}</h2>
        <p>${esc(t("productNotFoundText"))}</p>
        <a class="btn btn-primary" href="collection.html?handle=all">${esc(t("browseAll"))}</a>
      </div>`;
      ["product-extra", "product-related"].forEach((id) => { const el = document.getElementById(id); if (el) el.innerHTML = ""; });
      return;
    }
    PDP.p = p;
    PDP.qty = 1;
    PDP.sel = {};
    PDP.specs = {};
    Object.entries(p.specs || {}).forEach(([key, spec]) => { PDP.specs[key] = spec.value; });
    (p.options || []).forEach((o) => {
      if (o.values.length) PDP.sel[o.name] = o.values[0];
    });
    const v = pdpVariant();
    if (v) (p.options || []).forEach((o, i) => { if (v["o" + (i + 1)]) PDP.sel[o.name] = v["o" + (i + 1)]; });

    applyProductSeo(p);
    const col = S.collections.find((c) => (p.collections || []).includes(c.handle));
    const crumb = document.getElementById("prod-crumb");
    if (crumb) {
      crumb.innerHTML = `<a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><a href="collection.html?handle=${encodeURIComponent(p.collections?.[0] || "all")}">${esc(col ? L(col.title) : t("shop"))}</a><span>/</span><span>${esc(p.title)}</span>`;
    }

    const images = [...new Set([p.image, ...(p.images || []), ...Object.values(p.colorImages || {})].filter(Boolean))];
    const initialImage = p.colorImages?.[p.colors?.[0]?.name] || images[0];
    const root = document.getElementById("product-root");
    root.innerHTML = `
      <div class="gallery">
        <div class="gallery-main">
          <img id="gallery-main-img" src="${initialImage}" alt="${esc(p.title)}">
          <span class="color-tint" id="gallery-tint" aria-hidden="true"></span>
        </div>
        <div class="thumbs">
          ${images.map((src, i) => `<button type="button" class="${src === initialImage ? "active" : ""}" data-thumb="${src}" aria-label="${esc(p.title)} ${i + 1}"><img src="${src}" alt="" loading="lazy"></button>`).join("")}
        </div>
      </div>
      ${pdpInfoHTML()}`;

    const reviews = productReviews(p);
    const extra = document.getElementById("product-extra");
    if (extra) {
      extra.innerHTML = `<div class="container">
        <section class="product-faq reveal" aria-labelledby="faq-heading">
          <div class="section-head"><h2 id="faq-heading">${esc(t("faqs"))}</h2></div>
          <div class="accordion faq-accordion">
            ${((S.faqs || SET.faqs || [])).map((faq) => `<details><summary>${esc(L(faq.q))}</summary><div class="acc-body"><p>${esc(L(faq.a))}</p></div></details>`).join("")}
          </div>
        </section>
        <section class="product-reviews reveal" aria-labelledby="product-reviews-heading">
          <div class="reviews-head">
            <h2 id="product-reviews-heading">${esc(t("reviews"))} <span class="reviews-count">(${reviews.length})</span></h2>
            <div class="reviews-meta">${[1, 2, 3, 4, 5].map((n) => `<span class="tp-star${n > Math.round(Number(productRating(p))) ? " off" : ""}" data-icon="star"></span>`).join("")} <strong>${productRating(p)}</strong> · ${esc(t("verifiedBuyer"))}</div>
          </div>
          <div class="review-grid">
            ${reviews.map((review) => `<article class="review-card">
              <span class="review-avatar" style="background:${esc(review.color || "#2e7d6f")}">${esc((review.name || "R").slice(0, 1))}</span>
              <div class="review-name">${esc(review.name)} ${review.verified ? `<i>${esc(t("verifiedBuyer"))}</i>` : ""}</div>
              ${starsHTML(Number(review.rating) || 5)}
              <div class="review-title">${esc(L(review.title))}</div>
              <p class="review-body">${esc(L(review.body))}</p>
            </article>`).join("")}
          </div>
        </section>
      </div>`;
    }

    const related = document.getElementById("product-related");
    if (related) {
      const pool = PRODUCTS.filter((x) => x.handle !== p.handle && (x.collections || []).some((c) => (p.collections || []).includes(c)));
      const items = (pool.length ? pool : PRODUCTS.filter((x) => x.handle !== p.handle)).slice(0, 5);
      related.innerHTML = `<div class="container"><section class="related reveal"><h2>${esc(t("related"))}</h2><div class="grid">${items.map(cardHTML).join("")}</div></section></div>`;
    }
    hydrateIcons(root);
    hydrateIcons(extra);
    hydrateIcons(related);
    observeReveals();
  }

  /* ------------------------------------------------------------------------
     Checkout
     ------------------------------------------------------------------------ */
  function renderCheckout() {
    const root = document.getElementById("checkout-root");
    if (!root) return;
    document.title = `${t("checkout")} | ${L(SET.storeName)}`;
    const items = cartDetails();
    if (!items.length) {
      root.innerHTML = `<div class="container"><div class="empty-state"><h2>${esc(t("emptyCheckout"))}</h2><p>${esc(t("emptyCartText"))}</p><a class="btn btn-primary" href="collection.html?handle=all">${esc(t("shopNow"))}</a></div></div>`;
      return;
    }
    const subtotal = cartSubtotal();
    const cities = (SET.cities || []).filter((c) => c.active !== false);
    const payments = (SET.payments || []).filter((p) => p.active !== false);
    if (!payments.length) {
      root.innerHTML = `<div class="container"><div class="empty-state"><h2>${esc(t("emptyCheckout"))}</h2><p>${esc(R.lang === "ar" ? "لا توجد وسيلة دفع مفعّلة. أضفها من لوحة التحكم." : "Aucun moyen de paiement actif. Ajoutez-en depuis le tableau de bord.")}</p></div></div>`;
      return;
    }
    const open = R.isStoreOpen();
    const defaultCity = cities.find((c) => c.id === "nouakchott") || cities[0];
    let appliedCoupon = null;
    let selectedPayment = payments[0];

    root.innerHTML = `
      <div class="container">
        <div class="breadcrumb"><a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><span>${esc(t("checkout"))}</span></div>
        <div class="checkout-head">
          <div><span class="eyebrow">${esc(L(SET.storeName))} · ${esc(L(SET.city))}</span><h1>${esc(t("checkout"))}</h1></div>
          <div class="checkout-secure">${ICON.shield} ${R.lang === "ar" ? "طلب آمن ومؤكد عبر واتساب" : "Commande sécurisée et confirmée sur WhatsApp"}</div>
        </div>
        ${!open ? `<div class="store-closed-banner">${ICON.clock}<div><strong>${esc(t("closedTitle"))}</strong><span>${esc(t("storeClosed"))}</span></div></div>` : ""}
        <div class="checkout-layout">
          <form id="checkout-form" class="checkout-form" novalidate>
            <section class="checkout-block">
              <div class="checkout-block-head"><span>1</span><h2>${esc(t("contactInfo"))}</h2></div>
              <div class="field-row">
                <div class="field"><label for="co-name">${esc(t("fullName"))} *</label><input id="co-name" autocomplete="name" required></div>
                <div class="field"><label for="co-phone">${esc(t("phone"))} *</label><div class="phone-input"><span>+222</span><input id="co-phone" inputmode="tel" autocomplete="tel" placeholder="46 00 00 00" maxlength="14" required></div></div>
              </div>
              <div class="field"><label for="co-email">${esc(t("email"))}</label><input id="co-email" type="email" autocomplete="email" placeholder="you@example.com"></div>
            </section>
            <section class="checkout-block">
              <div class="checkout-block-head"><span>2</span><h2>${esc(t("shippingDelivery"))}</h2></div>
              <div class="field-row">
                <div class="field"><label for="co-city">${esc(t("city"))} *</label><select id="co-city">${cities.map((city) => `<option value="${esc(city.id)}" ${city.id === defaultCity?.id ? "selected" : ""}>${esc(L(city.name))} — ${Number(city.fee) ? money(city.fee) : t("free")}</option>`).join("")}</select></div>
                <div class="field"><label>${esc(t("country"))}</label><div class="country-readonly"><img src="${SET.country.flag}" alt="" width="22" height="15">${esc(L(SET.country.name))}</div></div>
              </div>
              <div class="field"><label for="co-address">${esc(t("address"))} *</label><input id="co-address" autocomplete="street-address" placeholder="${esc(R.lang === "ar" ? "الحي، الشارع، رقم المنزل" : "Quartier, rue, numéro")}" required></div>
              <div class="field"><label for="co-notes">${esc(t("notes"))}</label><textarea id="co-notes" rows="3" placeholder="${esc(R.lang === "ar" ? "أي تفاصيل إضافية عن الطلب" : "Toute précision utile")}"></textarea></div>
              <p class="field-note">${ICON.truck} ${esc(L(SET.shippingNote))}</p>
            </section>
            <section class="checkout-block">
              <div class="checkout-block-head"><span>3</span><h2>${esc(t("payment"))}</h2></div>
              <div class="payment-grid">
                ${payments.map((payment, i) => `<label class="payment-card ${i === 0 ? "active" : ""}" style="--pay:${esc(payment.color)}">
                  <input type="radio" name="co-payment" value="${esc(payment.id)}" ${i === 0 ? "checked" : ""}>
                  <span class="payment-mark">${(payment.image || payment.logo) ? `<img src="${esc(payment.image || payment.logo)}" alt="${esc(L(payment.name))}">` : esc(L(payment.name).slice(0, 2))}</span>
                  <span class="payment-copy"><strong>${esc(L(payment.name))}</strong><small>${esc(L(payment.note))}</small></span>
                  ${payment.discount ? `<span class="payment-discount">-${payment.discount}%</span>` : ""}
                </label>`).join("")}
              </div>
              <div class="coupon-row">
                <div class="field"><label for="co-coupon">${esc(t("coupon"))}</label><input id="co-coupon" placeholder="RESTORE10"></div>
                <button class="btn btn-outline" type="button" id="apply-coupon">${esc(t("apply"))}</button>
              </div>
              <p class="field-note">${ICON.info} ${esc(R.lang === "ar" ? "الدفع يتم تأكيده عبر واتساب. لا يتم سحب أي مبلغ من هذا الموقع." : "Le paiement est confirmé sur WhatsApp. Aucun paiement n’est débité sur ce site.")}</p>
            </section>
          </div>
          <aside class="order-summary">
            <h2>${esc(t("orderSummary"))}</h2>
            <div class="sum-items">
              ${items.map((it) => `<div class="sum-item">
                <img src="${it.product.image}" alt="${esc(it.product.title)}">
                <div><div class="t">${esc(it.product.title)}</div><div class="p">${esc(variantLabel(it.variant))}${it.specs && Object.keys(it.specs).length ? ` · ${esc(specsText(it.specs))}` : ""} × ${it.qty}</div><strong>${money(it.line)}</strong></div>
              </div>`).join("")}
            </div>
            <div class="sum-rows">
              <div class="sum-row"><span>${esc(t("subtotal"))}</span><span id="sum-subtotal">${money(subtotal)}</span></div>
              <div class="sum-row"><span>${esc(t("shipping"))} <small id="sum-city"></small></span><span id="sum-shipping">${money(0)}</span></div>
              <div class="sum-row discount" id="payment-row" hidden><span id="sum-payment-label">${esc(L(selectedPayment.name))} -${selectedPayment.discount || 0}%</span><span id="sum-payment">0</span></div>
              <div class="sum-row discount" id="coupon-row" hidden><span>${esc(t("coupon"))}</span><span id="sum-coupon">0</span></div>
              <div class="sum-row total"><span>${esc(t("total"))}</span><span id="sum-total">${money(subtotal)}</span></div>
            </div>
            <button class="btn btn-primary btn-block btn-whatsapp" type="button" id="place-order" ${!open ? "disabled" : ""}>${ICON.whatsapp} ${esc(!open ? t("closedTitle") : t("placeOrder"))}</button>
            <p class="checkout-redirect-note">${esc(t("redirecting"))}</p>
            <div class="accepted-pay">${payments.map((payment) => `<span style="--pay:${esc(payment.color)}">${esc(L(payment.name))}</span>`).join("")}</div>
            <div class="summary-help">${ICON.whatsapp}<span>${esc(t("contactUs"))}: <a class="phone-ltr" href="https://wa.me/${esc(SET.whatsapp)}" target="_blank" rel="noopener">${esc(SET.phoneDisplay)}</a></span></div>
          </aside>
        </div>
      </div>`;

    const $ = (id) => document.getElementById(id);
    const digits = (value) => String(value || "").replace(/\D/g, "");
    const store = () => SET.storeName;

    // Prefill known customer details without overwriting a typed draft.
    const signedCustomer = R.getCustomer();
    if (signedCustomer) {
      if ($("co-name") && !$("co-name").value) $("co-name").value = signedCustomer.name || "";
      if ($("co-phone") && !$("co-phone").value) $("co-phone").value = digits(signedCustomer.phone).slice(-8);
      if ($("co-email") && !$("co-email").value) $("co-email").value = signedCustomer.email || "";
      const savedAddress = (signedCustomer.addresses || [])[0];
      if (savedAddress) {
        if ($("co-address") && !$("co-address").value) $("co-address").value = savedAddress.address || savedAddress.line1 || "";
        if ($("co-city") && savedAddress.cityId) $("co-city").value = savedAddress.cityId;
        refresh();
      }
    }

    function selectedCity() {
      return cities.find((city) => city.id === $("co-city")?.value) || defaultCity;
    }
    function totals() {
      const city = selectedCity();
      const shipping = subtotal >= Number(SET.freeShippingOver || 0) ? 0 : Number(city?.fee || 0);
      const paymentDiscount = Math.round(subtotal * Number(selectedPayment?.discount || 0) / 100);
      let couponDiscount = 0;
      if (appliedCoupon) {
        couponDiscount = appliedCoupon.type === "percent"
          ? Math.round(subtotal * Number(appliedCoupon.value || 0) / 100)
          : Number(appliedCoupon.value || 0);
      }
      const discount = Math.min(subtotal, paymentDiscount + Math.max(0, couponDiscount));
      return { city, shipping, paymentDiscount, couponDiscount: Math.max(0, couponDiscount), discount, total: Math.max(0, subtotal + shipping - discount) };
    }

  function refresh() {
      const calc = totals();
      $("sum-shipping").textContent = calc.shipping ? money(calc.shipping) : t("free");
      $("sum-city").textContent = calc.city ? `· ${L(calc.city.name)}` : "";
      $("sum-payment-label").textContent = `${L(selectedPayment.name)} -${selectedPayment.discount || 0}%`;
      $("sum-payment").textContent = `- ${money(calc.paymentDiscount)}`;
      $("sum-payment").closest(".sum-row").hidden = !calc.paymentDiscount;
      $("sum-coupon").textContent = `- ${money(calc.couponDiscount)}`;
      $("sum-coupon").closest(".sum-row").hidden = !calc.couponDiscount;
      $("sum-total").textContent = money(calc.total);
      $("sum-subtotal").textContent = money(subtotal);
    }
    function saveLead() {
      const phone = digits($("co-phone")?.value);
      const name = $("co-name")?.value.trim();
      if (!phone && !name) return;
      R.saveAbandoned({
        name,
        phone,
        city: L(selectedCity()?.name),
        cityId: selectedCity()?.id,
        items: items.map((it) => ({ handle: it.handle, title: it.product.title, qty: it.qty, variant: variantLabel(it.variant) })),
        subtotal,
        lang: R.lang
      });
    }
    let leadTimer;
    const onLead = () => {
      clearTimeout(leadTimer);
      leadTimer = setTimeout(saveLead, 900);
    };
    ["co-name", "co-phone", "co-email", "co-address", "co-notes"].forEach((id) => $(id)?.addEventListener("input", onLead));
    ["co-city"].forEach((id) => $(id)?.addEventListener("change", () => { onLead(); refresh(); }));
    document.querySelectorAll('input[name="co-payment"]').forEach((radio) => {
      radio.addEventListener("change", () => {
        selectedPayment = payments.find((payment) => payment.id === radio.value) || payments[0];
        document.querySelectorAll(".payment-card").forEach((card) => card.classList.toggle("active", card.querySelector("input")?.checked));
        refresh();
      });
    });
    $("apply-coupon")?.addEventListener("click", () => {
      const code = $("co-coupon").value.trim().toUpperCase();
      if (!code) return;
      const coupon = (SET.coupons || []).find((item) => item.active !== false && String(item.code).toUpperCase() === code);
      const expired = coupon?.expiresAt && Date.parse(coupon.expiresAt) < Date.now();
      if (!coupon || expired || subtotal < Number(coupon.minTotal || 0)) {
        appliedCoupon = null;
        toast(t("couponInvalid"));
      } else {
        appliedCoupon = coupon;
        toast(`${t("couponApplied")}: ${code}`);
      }
      refresh();
    });

    $("place-order")?.addEventListener("click", async () => {
      if (!open) { toast(t("storeClosed")); return; }
      const name = $("co-name").value.trim();
      const address = $("co-address").value.trim();
      const email = $("co-email").value.trim();
      const notes = $("co-notes").value.trim();
      let phone = digits($("co-phone").value);
      if (phone.startsWith("222") && phone.length > 8) phone = phone.slice(3);
      if (!name || !phone || !address) {
        toast(t("required"));
        (!name ? $("co-name") : !phone ? $("co-phone") : $("co-address")).focus();
        return;
      }
      if (phone.length !== 8) {
        toast(t("invalidPhone"));
        $("co-phone").focus();
        return;
      }
      const fullPhone = `+222${phone}`;
      const blocked = (SET.blocklist || []).map(digits).filter(Boolean);
      if (blocked.includes(phone) || blocked.includes(fullPhone.replace(/\D/g, ""))) {
        toast(t("blockedPhone"));
        return;
      }
      const rateKey = `restore_last_order_${phone}`;
      const lastOrder = Number(localStorage.getItem(rateKey) || 0);
      const limit = Math.max(0, Number(SET.rateLimitSeconds || 0)) * 1000;
      if (limit && Date.now() - lastOrder < limit) {
        toast(t("rateLimited"));
        return;
      }
      const btn = $("place-order");
      if (btn) { btn.disabled = true; btn.dataset.label = btn.innerHTML; btn.textContent = t("processing") || "…"; }
      try {
        const calc = totals();
        const draft = {
          id: R.orderId(),
          createdAt: new Date().toISOString(),
          status: "new",
          source: "whatsapp",
          lang: R.lang,
          customer: {
            name,
            phone: fullPhone,
            email,
            city: L(calc.city?.name),
            cityId: calc.city?.id,
            address,
            notes
          },
          items: items.map((it) => ({
            handle: it.handle,
            title: it.product.title,
            image: it.product.image,
            variantId: it.variant?.id,
            variantTitle: variantLabel(it.variant),
            specs: it.specs || {},
            specsText: specsText(it.specs),
            battery: it.product.battery || null,
            condition: conditionLabel(it.product.condition),
            qty: it.qty,
            price: Number(it.variant?.price ?? it.product.price),
            line: it.line
          })),
          subtotal,
          shipping: calc.shipping,
          paymentDiscount: calc.paymentDiscount,
          couponDiscount: calc.couponDiscount,
          coupon: appliedCoupon?.code || "",
          discount: calc.discount,
          total: calc.total,
          payment: { id: selectedPayment.id, name: L(selectedPayment.name), discount: selectedPayment.discount || 0 },
          currency: "MRU",
          storePhone: SET.whatsapp
        };

        // Server-validated when the create-order Edge Function is deployed; falls back safely otherwise.
        const order = (typeof R.submitOrder === "function") ? await R.submitOrder(draft) : R.addOrder(draft);
        const payName = L(order.payment?.name || selectedPayment.name);
        const cityName = L(order.customer?.city || calc.city?.name);
        const messageItems = (order.items || draft.items).map((item) => {
          const variant = item.variantTitle ? ` (${item.variantTitle})` : "";
          const specs = item.specsText ? `\n   ${item.specsText}` : "";
          return `- ${item.title}${variant}${specs} × ${item.qty} = ${money(item.line ?? item.price * item.qty)}`;
        }).join("\n");
        const template = SET.orderTemplate?.[R.lang] || SET.orderTemplate?.ar || "";
        const values = {
          store: L(SET.storeName),
          order_id: order.id,
          name,
          phone: fullPhone,
          city: cityName,
          address,
          payment: payName,
          items: messageItems,
          subtotal: money(order.subtotal),
          shipping: order.shipping ? money(order.shipping) : t("free"),
          discount: money(order.discount),
          total: money(order.total),
          notes: notes || (R.lang === "ar" ? "لا توجد" : "Aucune")
        };
        let message = template;
        Object.entries(values).forEach(([key, value]) => { message = message.replaceAll(`{${key}}`, String(value ?? "")); });
        let wa = digits(SET.whatsapp);
        if (wa.length === 8) wa = `222${wa}`;
        if (!wa) { toast(R.lang === "ar" ? "أضف رقم واتساب من لوحة التحكم" : "Ajoutez le WhatsApp depuis le tableau de bord"); return; }
        const link = `https://wa.me/${wa}?text=${encodeURIComponent(message)}`;
        if (order.whatsappUrl !== link && typeof R.updateOrder === "function") R.updateOrder(order.id, { whatsappUrl: link, message });

        R.decrementStock(order.items || draft.items);
        const openLead = R.getAbandoned().find((lead) => lead.status === "open" && digits(lead.phone) === phone);
        if (openLead) R.removeAbandoned(openLead.id);
        localStorage.setItem(rateKey, String(Date.now()));
        localStorage.removeItem(CART_KEY);
        syncBadges();
        renderCart();

        root.innerHTML = `<div class="container"><div class="checkout-success">
          <div class="ico">${ICON.check}</div>
          <span class="eyebrow">${esc(L(SET.storeName))}</span>
          <h1>${esc(t("orderReceived"))}</h1>
          <p>${esc(t("orderReceivedText"))}${order.serverValidated ? ` <small>(${esc(R.lang === "ar" ? "تم التحقق من السعر على الخادم" : "Prix validé côté serveur")})</small>` : ""}</p>
          <div class="success-order">
            <div><span>${esc(t("orderId"))}</span><strong>${esc(order.id)}</strong></div>
            <div><span>${esc(t("total"))}</span><strong>${money(order.total)}</strong></div>
            <div><span>${esc(t("payment"))}</span><strong>${esc(payName)}</strong></div>
          </div>
          <a class="btn btn-primary btn-whatsapp" id="open-whatsapp" href="${link}" target="_blank" rel="noopener">${ICON.whatsapp} ${esc(t("openWhatsApp"))}</a>
          <a class="btn btn-outline" href="collection.html?handle=all">${esc(t("backToShop"))}</a>
          <p class="redirecting">${esc(t("redirecting"))}</p>
        </div></div>`;
        setTimeout(() => { window.location.href = link; }, 1100);
      } catch (error) {
        console.error("Restore: checkout failed", error);
        toast(String(error?.message || t("required") || "Error"));
        if (btn) { btn.disabled = false; btn.innerHTML = btn.dataset.label || t("placeOrder"); }
      }
    });

    refresh();
  }

  /* ------------------------------------------------------------------------
     Wishlist page
     ------------------------------------------------------------------------ */
  function renderWishlist() {
    const grid = document.getElementById("wishlist-grid");
    if (!grid) return;
    document.title = `${t("wishlist")} | ${L(SET.storeName)}`;
    const heading = document.querySelector(".collection-head h1");
    if (heading) heading.textContent = t("wishlist");
    const items = ALL_PRODUCTS.filter((p) => readWish().has(p.handle));
    grid.innerHTML = items.length
      ? items.map(cardHTML).join("")
      : `<div class="empty-state" style="grid-column:1/-1"><h2>${esc(t("emptyWish"))}</h2><p>${esc(t("emptyWishText"))}</p><a class="btn btn-primary" href="collection.html?handle=all">${esc(t("browseAll"))}</a></div>`;
    observeReveals();
    hydrateIcons(grid);
  }

  /* ------------------------------------------------------------------------
     Static pages
     ------------------------------------------------------------------------ */
  function renderPage() {
    const slug = new URLSearchParams(location.search).get("slug") || "about-us";
    const page = R.getPage(slug);
    const root = document.getElementById("page-root");
    if (!root) return;
    const crumb = document.querySelector(".breadcrumb");
    if (!page) {
      document.title = `${t("pageNotFound")} | ${L(SET.storeName)}`;
      if (crumb) crumb.innerHTML = `<a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><span>${esc(t("pageNotFound"))}</span>`;
      root.innerHTML = `<div class="empty-state page-missing"><h1>${esc(t("pageNotFound"))}</h1><p>${esc(t("productNotFoundText"))}</p><a class="btn btn-primary" href="index.html">${esc(t("goHome"))}</a></div>`;
      return;
    }
    document.title = `${L(page.seoTitle) || L(page.title)} | ${L(SET.storeName)}`;
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) metaDescription.setAttribute("content", L(page.seoDescription) || String(L(page.body)).slice(0, 160));
    if (crumb) crumb.innerHTML = `<a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><span>${esc(L(page.title))}</span>`;
    const paragraphs = String(L(page.body)).split("\n").filter(Boolean).map((line) => `<p>${esc(line)}</p>`).join("");
    const contact = slug === "contact" ? `<div class="page-contact-actions">
      <a class="btn btn-primary" href="https://wa.me/${esc(SET.whatsapp)}" target="_blank" rel="noopener">${ICON.whatsapp} ${esc(t("orderWhatsApp"))}</a>
      <a class="btn btn-outline" href="mailto:${esc(SET.email)}">${ICON.mail} ${esc(SET.email)}</a>
    </div>` : "";
    root.innerHTML = `<span class="eyebrow">${esc(L(SET.storeName))}</span><h1>${esc(L(page.title))}</h1>${paragraphs}${contact}
      <p class="page-meta">${esc(L(SET.city))}, ${esc(L(SET.country.name))} · <span class="phone-ltr">${esc(SET.phoneDisplay)}</span></p>`;
    observeReveals();
  }

  function renderBlog() {
    const root = document.getElementById("blog-root");
    if (!root) return;
    const posts = (S.blog || []).filter((post) => post.published !== false).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    document.title = `${t("blog")} | ${L(SET.storeName)}`;
    root.innerHTML = `<div class="container">
      <div class="blog-head"><span class="eyebrow">${esc(L(SET.storeName))}</span><h1>${esc(t("blog"))}</h1><p>${esc(t("latestArticles"))}</p></div>
      <div class="blog-grid">
        ${posts.map((post) => `<a class="blog-card reveal" href="blog-post.html?slug=${encodeURIComponent(post.slug)}">
          <div class="blog-card-img"><img src="${esc(post.image || "assets/img/category-iphone.png")}" alt="${esc(L(post.title))}" loading="lazy"></div>
          <div class="blog-card-body"><time>${esc(R.formatDate(post.date))}</time><h2>${esc(L(post.title))}</h2><p>${esc(L(post.excerpt))}</p><span class="read-more">${esc(t("readMore"))} ${ICON.arrowRight}</span></div>
        </a>`).join("") || `<div class="empty-state" style="grid-column:1/-1"><h2>${esc(t("noProducts"))}</h2></div>`}
      </div>
    </div>`;
    observeReveals();
  }

  function renderBlogPost() {
    const root = document.getElementById("blog-root");
    if (!root) return;
    const slug = new URLSearchParams(location.search).get("slug");
    const post = (S.blog || []).find((item) => item.slug === slug && item.published !== false);
    if (!post) {
      document.title = `${t("pageNotFound")} | ${L(SET.storeName)}`;
      root.innerHTML = `<div class="container"><div class="empty-state"><h1>${esc(t("pageNotFound"))}</h1><a class="btn btn-primary" href="blog.html">${esc(t("blog"))}</a></div></div>`;
      return;
    }
    document.title = `${L(post.title)} | ${L(SET.storeName)}`;
    root.innerHTML = `<div class="container">
      <div class="breadcrumb"><a href="index.html">${esc(t("homeCrumb"))}</a><span>/</span><a href="blog.html">${esc(t("blog"))}</a><span>/</span><span>${esc(L(post.title))}</span></div>
      <article class="blog-post">
        <span class="eyebrow">${esc(R.formatDate(post.date))}</span>
        <h1>${esc(L(post.title))}</h1>
        <p class="blog-excerpt">${esc(L(post.excerpt))}</p>
        <img class="blog-hero" src="${esc(post.image || "assets/img/category-iphone.png")}" alt="${esc(L(post.title))}">
        ${String(L(post.body)).split("\n").filter(Boolean).map((line) => `<p>${esc(line)}</p>`).join("")}
        <a class="btn btn-outline" href="blog.html">${esc(t("blog"))}</a>
      </article>
    </div>`;
  }

  function renderAccount() {
    const root = document.getElementById("account-root");
    if (!root) return;
    document.title = `${t("myAccount")} | ${L(SET.storeName)}`;
    const cust = R.getCustomer();
    const orders = R.getOrders();
    const myOrders = cust ? R.getCustomerOrders() : [];

    const trackCard = `
      <section class="account-card">
        <span class="eyebrow">${esc(L(SET.storeName))}</span>
        <h2>${esc(t("trackOrder"))}</h2>
        <p>${esc(t("trackOrderText"))}</p>
        <div class="field"><label for="acc-order">${esc(t("orderId"))}</label><input id="acc-order" placeholder="RS-261022-A1B2" dir="ltr"></div>
        <div class="field"><label for="acc-phone">${esc(t("phone"))}</label><input id="acc-phone" inputmode="tel" placeholder="46 00 00 00" dir="ltr"></div>
        <button class="btn btn-primary btn-block" type="button" id="acc-track">${esc(t("trackOrder"))}</button>
        <div id="acc-result"></div>
        ${myOrders.length ? `<h3 class="account-subtitle">${esc(t("recentOrders"))}</h3>
        <div class="account-orders">${myOrders.slice(0, 5).map((order) => {
          const status = R.statusMeta(order.status);
          return `<div class="account-order"><div><strong>${esc(order.id)}</strong><small>${esc(R.formatDate(order.createdAt))} · ${esc(order.items?.length || 0)} ${esc(t("products"))}</small></div><span class="status-pill" style="--status:${status.color}">${esc(L(status.label))}</span><b>${money(order.total)}</b></div>`;
        }).join("")}</div>` : `<p class="muted">${esc(t("noOrders"))}</p>`}
      </section>`;

    if (!cust) {
      root.innerHTML = `<div class="account-layout">
        <section class="account-card account-auth-card">
          <div class="account-auth-tabs">
            <button class="active" type="button" data-auth-tab="login">${esc(t("signIn"))}</button>
            <button type="button" data-auth-tab="register">${esc(t("createAccount"))}</button>

          </div>
          <form id="login-form" class="account-auth-form">
            <div class="field"><label>${esc(t("email"))}</label><input type="email" id="login-email" required dir="ltr" placeholder="you@example.com" autocomplete="email"></div>
            <div class="field"><label>${esc(t("password"))}</label><input type="password" id="login-password" required minlength="6" autocomplete="current-password"></div>
            <button class="btn btn-primary btn-block" type="submit">${esc(t("signIn"))}</button>
          </form>
          <form id="register-form" class="account-auth-form" hidden>
            <div class="field"><label>${esc(t("fullName"))}</label><input id="reg-name" required autocomplete="name"></div>
            <div class="field"><label>${esc(t("email"))}</label><input type="email" id="reg-email" required dir="ltr" autocomplete="email"></div>
            <div class="field"><label>${esc(t("phone"))}</label><input id="reg-phone" inputmode="tel" dir="ltr" placeholder="46 00 00 00" autocomplete="tel"></div>
            <div class="field"><label>${esc(t("password"))}</label><input type="password" id="reg-password" required minlength="8" autocomplete="new-password"></div>
            <button class="btn btn-primary btn-block" type="submit">${esc(t("createAccount"))}</button>
          </form>
          
          </div>
        </section>
        ${trackCard}
      </div>`;

      root.querySelectorAll("[data-auth-tab]").forEach((button) => {
        button.addEventListener("click", () => {
          const tab = button.dataset.authTab;
          root.querySelectorAll("[data-auth-tab]").forEach((b) => b.classList.toggle("active", b === button));
          root.querySelector("#login-form").hidden = tab !== "login";
          root.querySelector("#register-form").hidden = tab !== "register";

          root.querySelector("#auth-error")?.remove();
        });
      });

      const showAuthError = (message) => {
        let box = root.querySelector("#auth-error");
        if (!box) {
          box = document.createElement("p");
          box.id = "auth-error";
          box.className = "account-auth-error";
          root.querySelector(".account-auth-card").appendChild(box);
        }
        box.textContent = message;
      };

      root.querySelector("#login-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const button = event.submitter;
        if (button) button.disabled = true;
        const email = root.querySelector("#login-email").value;
        const password = root.querySelector("#login-password").value;
        try {
          // Try admin login first (works with username or email)
          try {
            await R.login(email, password);
            const session = R.currentSession();
            if (session?.role === "owner" || session?.role === "manager") {
              toast(t("signedIn") + " - " + (session.role === "owner" ? t("owner") : t("manager")), "good");
              setTimeout(() => { window.location.href = "dashboard.html"; }, 500);
              return;
            }
          } catch {}
          // Fallback to customer login
          await R.customerLogin(email, password);
          toast(t("signedIn"), "good");
          renderCustomerAccount();
          renderAccount();
        } catch (error) {
          showAuthError(error.message || t("loginFailed"));
        } finally {
          if (button) button.disabled = false;
        }
      });

      // Dashboard login handler
      root.querySelector("#dash-login-btn")?.addEventListener("click", async () => {
        const button = root.querySelector("#dash-login-btn");
        button.disabled = true;
        try {
          // Accept a username or a full e-mail address.
          const identifier = root.querySelector("#dash-email").value.trim();
          const password = root.querySelector("#dash-password").value;
          await R.login(identifier, password);
          toast(t("signedIn") + " (" + t("dashboardLogin") + ")", "good");
          setTimeout(() => { window.location.href = "dashboard.html"; }, 500);
        } catch (error) {
          showAuthError(error.message || t("loginFailed"));
        } finally {
          button.disabled = false;
        }
      });

      root.querySelector("#register-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const button = event.submitter;
        if (button) button.disabled = true;
        try {
          const wishlist = [...readWish()];
          await R.customerRegister({
            name: root.querySelector("#reg-name").value,
            email: root.querySelector("#reg-email").value,
            phone: root.querySelector("#reg-phone").value,
            password: root.querySelector("#reg-password").value,
            wishlist
          });
          toast(t("accountCreated"), "good");
          renderCustomerAccount();
          renderAccount();
        } catch (error) {
          showAuthError(error.message || t("registerFailed"));
        } finally {
          if (button) button.disabled = false;
        }
      });
    } else {
      const initial = String(cust.name || "U").trim().slice(0, 1).toUpperCase();
      const wishlist = (cust.wishlist || []).map((handle) => BY_HANDLE.get(handle)).filter(Boolean).slice(0, 6);
      const myReviews = R.customerReviews().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
      const statusLabel = { pending: t("reviewStatusPending"), approved: t("reviewStatusApproved"), rejected: t("reviewStatusRejected") };
      root.innerHTML = `<div class="account-layout">
        <section class="account-card">
          <div class="account-profile">
            <span class="account-avatar lg">${esc(initial)}</span>
            <div class="grow"><h1>${esc(cust.name)}</h1><p dir="ltr">${esc(cust.email)}${cust.phone ? ` · ${esc(cust.phone)}` : ""}</p></div>
            <button class="btn btn-outline btn-sm" type="button" id="account-logout">${ICON.logout} ${esc(t("logout"))}</button>
          </div>
          <h3 class="account-subtitle">${esc(t("myWishlist"))} <span class="muted">(${(cust.wishlist || []).length})</span></h3>
          ${wishlist.length ? `<div class="account-wishlist">${wishlist.map((product) => `<a class="account-wish-item" href="product.html?handle=${encodeURIComponent(product.handle)}"><img src="${esc(product.image)}" alt="${esc(product.title)}"><span>${esc(product.title)}</span></a>`).join("")}</div>` : `<p class="muted">${esc(t("emptyWish"))}</p>`}
          <a class="text-link" href="wishlist.html">${esc(t("viewWishlist"))} ${ICON.arrowRight}</a>
          <h3 class="account-subtitle">${esc(t("myReviews"))}</h3>
          ${myReviews.length ? `<div class="account-reviews">${myReviews.map((review) => `<div class="account-review"><div class="grow"><strong>${esc(L(review.title))}</strong><small>${esc(review.productHandle)} · ${esc(R.formatDate(review.createdAt))}</small></div><span class="badge-soft ${review.status === "approved" ? "green" : review.status === "rejected" ? "red" : "orange"}">${esc(statusLabel[review.status] || review.status)}</span></div>`).join("")}</div>` : `<p class="muted">${esc(t("noReviews"))}</p>`}
        </section>
        ${trackCard}
      </div>`;
      root.querySelector("#account-logout")?.addEventListener("click", () => {
        R.customerLogout();
        renderCustomerAccount();
        toast(t("signedOut"), "good");
        renderAccount();
      });
    }

    const findOrder = () => {
      const code = document.getElementById("acc-order").value.trim().toUpperCase();
      const phone = document.getElementById("acc-phone").value.replace(/\D/g, "").slice(-8);
      const found = orders.find((order) => (!code || order.id.toUpperCase() === code) && (!phone || String(order.customer?.phone).replace(/\D/g, "").endsWith(phone)));
      const box = document.getElementById("acc-result");
      if (!found) {
        box.innerHTML = `<div class="account-result error">${esc(t("orderNotFound"))}</div>`;
        return;
      }
      const status = R.statusMeta(found.status);
      box.innerHTML = `<div class="account-result"><div class="result-head"><strong>${esc(found.id)}</strong><span class="status-pill" style="--status:${status.color}">${esc(L(status.label))}</span></div><p>${esc(found.customer?.name || "")} · ${money(found.total)}</p><ul>${(found.items || []).map((item) => `<li>${esc(item.title)} × ${item.qty}</li>`).join("")}</ul></div>`;
    };
    document.getElementById("acc-track")?.addEventListener("click", findOrder);
    document.getElementById("acc-order")?.addEventListener("keydown", (event) => { if (event.key === "Enter") findOrder(); });
  }

  /* ------------------------------------------------------------------------
     Global events
     ------------------------------------------------------------------------ */
  document.addEventListener("click", (e) => {
    // Account dropdown in the header
    if (e.target.closest("[data-account-toggle]")) {
      e.stopPropagation();
      document.querySelector(".account-dropdown")?.classList.toggle("open");
      return;
    }
    document.querySelectorAll(".account-dropdown.open").forEach((dropdown) => {
      if (!dropdown.contains(e.target)) dropdown.classList.remove("open");
    });
    if (e.target.closest("[data-customer-logout]")) {
      R.customerLogout();
      renderCustomerAccount();
      toast(t("signedOut"), "good");
      if (document.body.dataset.page === "account") renderAccount();
      return;
    }
    // Review form submission
    if (e.target.matches("#submit-review")) {
      const rating = Number(document.querySelector(".rating-input")?.dataset.rating || 0);
      const title = document.getElementById("review-title")?.value?.trim();
      const body = document.getElementById("review-body")?.value?.trim();
      const handle = new URLSearchParams(location.search).get("handle");
      if (!rating || !title || !body || !handle) {
        toast(t("reviewIncomplete"), "error");
        return;
      }
      R.submitReview({ productHandle: handle, rating, title, body }).then(() => {
        toast(t("reviewSubmitted"), "good");
        setTimeout(() => location.reload(), 1200);
      }).catch((error) => {
        if (String(error?.message) === "loginRequired") {
          toast(t("loginRequired"), "error");
          setTimeout(() => { location.href = "account.html"; }, 1200);
        } else {
          toast(error?.message || t("reviewIncomplete"), "error");
        }
      });
      return;
    }
    if (e.target.matches(".rating-input button")) {
      const val = Number(e.target.dataset.star);
      e.target.closest(".rating-input").dataset.rating = val;
      e.target.closest(".rating-input").querySelectorAll("button").forEach((b, i) => {
        b.classList.toggle("active", i < val);
      });
      return;
    }
    const setLang = e.target.closest("[data-set-lang]");
    if (setLang) {
      e.preventDefault();
      if (setLang.dataset.setLang !== R.lang) {
        R.setLang(setLang.dataset.setLang);
        location.reload();
      }
      return;
    }
    const themeToggle = e.target.closest("[data-theme-toggle]");
    if (themeToggle) {
      e.preventDefault();
      const next = R.theme === "dark" ? "light" : "dark";
      R.setTheme(next);
      document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
        button.innerHTML = `${next === "dark" ? ICON.sun : ICON.moon}${button.closest(".menu-preferences") ? ` ${esc(next === "dark" ? t("light") : t("dark"))}` : ""}`;
      });
      return;
    }
    if (e.target.closest("[data-country]")) {
      toast(`${L(SET.country.name)} · ${L(SET.country.currencyName)}`);
      return;
    }
    if (!e.target.closest(".lang-switch")) document.querySelector(".lang-switch")?.classList.remove("open");
    if (e.target.closest("[data-video]")) {
      e.preventDefault();
      toast(R.lang === "ar" ? "فيديوهات المجتمع ستُضاف قريبًا" : "Les vidéos de la communauté arrivent bientôt");
      return;
    }
    const inc = e.target.closest("[data-cart-inc]");
    if (inc) {
      const it = readCart().find((x) => x.handle === inc.dataset.handle && String(x.variantId) === inc.dataset.cartInc);
      if (it) setQty(inc.dataset.cartInc, inc.dataset.handle, it.qty + 1);
      return;
    }
    const dec = e.target.closest("[data-cart-dec]");
    if (dec) {
      const it = readCart().find((x) => x.handle === dec.dataset.handle && String(x.variantId) === String(dec.dataset.cartDec));
      if (it) setQty(dec.dataset.cartDec, dec.dataset.handle, it.qty - 1);
      return;
    }
    const rem = e.target.closest("[data-cart-remove]");
    if (rem) {
      removeLine(rem.dataset.handle, rem.dataset.cartRemove);
      return;
    }
    const wish = e.target.closest("[data-wish]");
    if (wish) {
      e.preventDefault();
      toggleWish(wish.dataset.wish);
      return;
    }
    const sw = e.target.closest(".swatch");
    if (sw) {
      e.preventDefault();
      const card = sw.closest(".product-card");
      if (card) {
        card.querySelectorAll(".swatch").forEach((x) => x.classList.remove("selected"));
        sw.classList.add("selected");
        const img = card.querySelector("[data-card-main]");
        if (img && sw.dataset.colorImg) img.src = sw.dataset.colorImg;
        const tint = card.querySelector("[data-card-tint]");
        if (tint) {
          const isFirst = card.querySelector(".swatch") === sw;
          tint.style.background = sw.dataset.colorHex || "transparent";
          tint.style.opacity = isFirst || (img && sw.dataset.colorImg !== img.dataset.initialSrc) ? "0" : ".18";
          if (sw.dataset.colorHex) tint.style.opacity = isFirst ? "0" : ".16";
        }
      }
      return;
    }
    const scrollBtn = e.target.closest("[data-scroll]");
    if (scrollBtn) {
      const track = scrollBtn.closest(".carousel-wrap")?.querySelector(".track") || scrollBtn.closest(".video-panel");
      if (track) track.scrollBy({ left: (scrollBtn.dataset.scroll === "next" ? 1 : -1) * track.clientWidth * 0.8, behavior: "smooth" });
      return;
    }
    if (e.target.closest("[data-close-search]")) { closeSearch(); return; }
    if (e.target.closest("[data-close-cart]")) { closeCart(); return; }
    if (e.target.closest("[data-add-cart]")) {
      if (!PDP.p) return;
      const v = pdpVariant();
      if (!v) return;
      addToCart(PDP.p.handle, v.id, PDP.qty, PDP.specs);
      openCart();
      return;
    }
    if (e.target.closest("[data-buy-now]")) {
      if (!PDP.p) return;
      const v = pdpVariant();
      if (!v) return;
      addToCart(PDP.p.handle, v.id, PDP.qty, PDP.specs);
      location.href = "checkout.html";
      return;
    }
    const opt = e.target.closest("[data-opt]");
    if (opt && PDP.p) {
      PDP.sel[opt.dataset.opt] = opt.dataset.value;
      const keys = (PDP.p.options || []).map((o) => o.name);
      let v = (PDP.p.variants || []).find((x) => keys.every((k, i) => x["o" + (i + 1)] === PDP.sel[k]));
      if (!v) {
        const idx = (PDP.p.options || []).findIndex((o) => o.name === opt.dataset.opt);
        v = (PDP.p.variants || []).find((x) => x.available && x["o" + (idx + 1)] === opt.dataset.value) || (PDP.p.variants || []).find((x) => x["o" + (idx + 1)] === opt.dataset.value);
        if (v) (PDP.p.options || []).forEach((o, i) => { if (v["o" + (i + 1)]) PDP.sel[o.name] = v["o" + (i + 1)]; });
      }
      const info = document.getElementById("product-info");
      if (info) info.outerHTML = pdpInfoHTML();
      if (/color|colour/i.test(opt.dataset.opt)) {
        const main = document.getElementById("gallery-main-img");
        const tint = document.getElementById("gallery-tint");
        const img = PDP.p.colorImages?.[opt.dataset.value] || PDP.p.image;
        if (main && img) main.src = img;
        if (tint) {
          const first = PDP.p.colors?.[0]?.name;
          tint.style.background = opt.dataset.colorHex || "transparent";
          tint.style.opacity = first === opt.dataset.value ? "0" : ".18";
        }
        document.querySelectorAll("[data-thumb]").forEach((thumb) => thumb.classList.toggle("active", thumb.dataset.thumb === img));
      }
      hydrateIcons();
      return;
    }
    const qbtn = e.target.closest("[data-qty]");
    if (qbtn) {
      PDP.qty = Math.max(1, Math.min(MAX_QTY, PDP.qty + Number(qbtn.dataset.qty)));
      const span = document.getElementById("qty-val");
      if (span) span.textContent = PDP.qty;
      return;
    }
    const sdot = e.target.closest(".sustain-dots button, .reviews-dots button, .press-dots button");
    if (sdot) {
      const dots = [...sdot.parentElement.children];
      const section = sdot.closest("section") || sdot.closest(".container");
      const track = sdot.closest(".sustain")?.querySelector(".sustain-track") || sdot.closest(".reviews")?.querySelector(".reviews-track") || sdot.closest(".press")?.querySelector(".press-grid");
      if (track && section) {
        const i = dots.indexOf(sdot);
        const card = track.firstElementChild;
        const width = card ? card.getBoundingClientRect().width + 12 : track.clientWidth;
        track.scrollTo({ left: (R.lang === "ar" ? -1 : 1) * i * width, behavior: "smooth" });
        dots.forEach((dot, index) => dot.classList.toggle("active", index === i));
      }
      return;
    }
    const thumb = e.target.closest("[data-thumb]");
    if (thumb) {
      const main = document.getElementById("gallery-main-img");
      if (main) main.src = thumb.dataset.thumb;
      const tint = document.getElementById("gallery-tint");
      if (tint) tint.style.opacity = "0";
      document.querySelectorAll("[data-thumb]").forEach((item) => item.classList.toggle("active", item === thumb));
      return;
    }
  });

  document.addEventListener("change", (event) => {
    const spec = event.target.closest("[data-spec]");
    if (spec) {
      PDP.specs[spec.dataset.spec] = spec.value;
      toast(R.lang === "ar" ? "تم حفظ خيار الطلب" : "Option enregistrée");
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeSearch();
      closeCart();
      closeMenu();
    }
  });

  window.addEventListener("scroll", () => {
    document.querySelector(".site-header")?.classList.toggle("scrolled", window.scrollY > 160);
  }, { passive: true });

  window.addEventListener("restore:changed", () => {
    if (document.body?.dataset.page === "dashboard") return;
    if (!document.querySelector("input:focus, textarea:focus, select:focus")) {
      setTimeout(() => location.reload(), 250);
    }
  });

  window.addEventListener("restore:customer", () => {
    renderCustomerAccount();
    const page = document.body?.dataset.page;
    if (page === "wishlist") renderWishlist();
    if (page === "account") renderAccount();
  });

  window.addEventListener("restore:orders", () => {
    if (document.body?.dataset.page === "account") renderAccount();
  });

  window.addEventListener("restore:reviews", () => {
    if (document.body?.dataset.page !== "product" || !PDP.p) return;
    const section = document.querySelector("#product-extra .product-reviews");
    if (!section) return;
    const wrapper = document.createElement("div");
    wrapper.innerHTML = renderProductReviews(PDP.p);
    const next = wrapper.firstElementChild;
    if (next) {
      section.replaceWith(next);
      hydrateIcons(next);
      observeReveals();
    }
  });

  function injectPixels() {
    const pixels = SET.pixels || {};
    if (!pixels.meta && !pixels.tiktok && !pixels.ga) return;
    if (document.querySelector("script[data-restore-pixels]")) return;
    const script = document.createElement("script");
    script.src = "assets/js/pixels.js";
    script.defer = true;
    script.dataset.restorePixels = "true";
    if (pixels.meta) script.dataset.meta = String(pixels.meta).replace(/[^A-Za-z0-9_.-]/g, "").slice(0, 80);
    if (pixels.tiktok) script.dataset.tiktok = String(pixels.tiktok).replace(/[^A-Za-z0-9_.-]/g, "").slice(0, 80);
    if (pixels.ga) script.dataset.ga = String(pixels.ga).replace(/[^A-Za-z0-9_.-]/g, "").slice(0, 80);
    document.head.appendChild(script);
  }

  function setMeta(attribute, key, content) {
    if (!content) return;
    let tag = document.head.querySelector(`meta[${attribute}="${key}"]`);
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute(attribute, key);
      document.head.appendChild(tag);
    }
    tag.setAttribute("content", content);
  }

  function absoluteUrl(value) {
    if (!value) return "";
    try { return new URL(value, location.href).href; } catch { return value; }
  }

  function setJsonLd(data) {
    let script = document.head.querySelector('script[data-seo-jsonld]');
    if (!script) {
      script = document.createElement("script");
      script.type = "application/ld+json";
      script.dataset.seoJsonld = "true";
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(data);
  }

  function setCanonical(url) {
    let link = document.head.querySelector('link[rel="canonical"]');
    if (!link) {
      link = document.createElement("link");
      link.rel = "canonical";
      document.head.appendChild(link);
    }
    link.href = url;
  }

  function applySeo() {
    if (!SET.seo) return;
    const base = String(SET.baseUrl || location.origin).replace(/\/$/, "");
    if (document.body?.dataset.page === "home") {
      const title = L(SET.seo.title) || `${L(SET.storeName)} | ${L(SET.tagline)}`;
      const description = L(SET.seo.description) || "";
      document.title = title;
      const meta = document.querySelector('meta[name="description"]');
      if (meta) meta.setAttribute("content", description);
      setCanonical(`${base}/`);
      setMeta("property", "og:title", title);
      setMeta("property", "og:description", description);
      setMeta("property", "og:type", "website");
      setMeta("property", "og:url", `${base}/`);
      setMeta("property", "og:image", absoluteUrl(SET.seo.image || SET.logo));
      setMeta("property", "og:locale", R.lang === "ar" ? "ar_MR" : "fr_FR");
      setMeta("name", "twitter:card", "summary_large_image");
      setMeta("name", "twitter:title", title);
      setMeta("name", "twitter:description", description);
      setMeta("name", "twitter:image", absoluteUrl(SET.seo.image || SET.logo));
      const structured = {
        "@context": "https://schema.org",
        "@type": "Store",
        name: L(SET.storeName),
        description,
        url: base,
        image: absoluteUrl(SET.seo.image || SET.logo),
        telephone: SET.phoneDisplay || SET.phone,
        email: SET.email,
        address: { "@type": "PostalAddress", addressLocality: L(SET.city), addressCountry: SET.country?.code || "MR" },
        sameAs: (SET.social || []).map((item) => item.href).filter(Boolean)
      };
      if (SET.hours) {
        structured.openingHours = `${String(SET.hours.open || "09:00")}-${String(SET.hours.close || "19:00")}`;
      }
      setJsonLd(structured);
    }
    const themeColor = document.querySelector('meta[name="theme-color"]') || document.createElement("meta");
    themeColor.setAttribute("name", "theme-color");
    themeColor.setAttribute("content", R.theme === "dark" ? "#101014" : SET.colors.primary);
    if (!themeColor.parentNode) document.head.appendChild(themeColor);
    const favicon = document.querySelector('link[rel="icon"]');
    if (favicon && SET.favicon) favicon.setAttribute("href", SET.favicon);
  }

  function applyProductSeo(product) {
    const base = String(SET.baseUrl || location.origin).replace(/\/$/, "");
    const path = `/product.html?handle=${encodeURIComponent(product.handle)}`;
    const title = `${product.title} | ${L(SET.storeName)}`;
    const description = `${product.title} — ${L(product.description)}`.slice(0, 300);
    const image = absoluteUrl(product.image);
    document.title = title;
    setCanonical(`${base}${path}`);
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", description);
    setMeta("property", "og:title", title);
    setMeta("property", "og:description", description);
    setMeta("property", "og:type", "product");
    setMeta("property", "og:url", `${base}${path}`);
    setMeta("property", "og:image", image);
    setMeta("name", "twitter:card", "summary_large_image");
    setMeta("name", "twitter:title", title);
    setMeta("name", "twitter:description", description);
    setMeta("name", "twitter:image", image);
    const rating = Number(productRating(product)) || 0;
    const offers = {
      "@type": "Offer",
      url: `${base}${path}`,
      priceCurrency: "MRU",
      price: Number(product.price) || 0,
      priceValidUntil: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10),
      availability: Number(product.stock) > 0 && product.available !== false ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      itemCondition: "https://schema.org/RefurbishedCondition"
    };
    const data = {
      "@context": "https://schema.org",
      "@type": "Product",
      name: product.title,
      image: (product.images || [product.image]).filter(Boolean).map(absoluteUrl),
      description: L(product.description),
      sku: product.sku || product.handle,
      brand: { "@type": "Brand", name: product.vendor || L(SET.storeName) },
      offers
    };
    if (rating) {
      data.aggregateRating = {
        "@type": "AggregateRating",
        ratingValue: rating,
        reviewCount: Math.max(1, productReviews(product).length),
        bestRating: 5
      };
    }
    setJsonLd(data);
  }

  /* ------------------------------------------------------------------------
     Boot
     ------------------------------------------------------------------------ */
  function boot() {
    applySeo();
    renderHeader();
    renderCustomerAccount();
    renderFooter();
    mountCart();
    syncBadges();
    hydrateIcons();
    injectPixels();
    renderCustomerAccount();
    const page = document.body.dataset.page;
    if (page === "home") renderHome();
    else if (page === "collection") renderCollection();
    else if (page === "product") renderProduct();
    else if (page === "checkout") renderCheckout();
    else if (page === "wishlist") renderWishlist();
    else if (page === "page") renderPage();
    else if (page === "account") renderAccount();
    else if (page === "blog") renderBlog();
    else if (page === "post") renderBlogPost();
    renderCart();
    hydrateIcons();
    if (SET.pwa && "serviceWorker" in navigator && location.protocol !== "file:") {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
