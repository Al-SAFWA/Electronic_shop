# تقرير مراجعة تقنية مستقلة وصارمة
**الموضوع:** قالب متجر إلكتروني ثابت + Supabase (إصدار 1.5.0) — قابلية البيع كنسخ منفصلة لتجار مختلفين (كل تاجر بمشروع Supabase مجاني خاص واستضافة مجانية)  
**المراجع:** وكيل تقني مستقل (تنفيذ فعلي للأوامر/قراءة الكود المتاحة؛ بدون افتراضات)  
**تاريخ التنفيذ:** 2026-11-09  
**بيئة التنفيذ:** Linux، دليل العمل `/home/mouhammed/Documents/store template/restore-store`

## ملاحظة نطاق حتمية (شفافية)
- ملف `store template8.zip` **غير موجود** في بيئة العمل.
  - **الدليل:** `glob` للنمط `store template8.zip` بلا نتائج؛ `find /home/mouhammed -name "store template8.zip" -not -path "*/proc/*"` بلا نتائج.
- تم تنفيذ المراجعة على محتوى القالب الموجود فعلياً في `/home/mouhammed/Documents/store template/restore-store`.
  - **الدليل:** `package.json:3` → `"version": "1.5.0"`؛ رأس `CHANGELOG.md` يذكر `1.5.0`.
- **نتيجة ذلك:** خطوة `unzip` للملف المضغوط **لم تُنفَّذ** كملف `.zip`؛ اعتُبر المجلد الحالي مصدر `restore-store`. أي بند يعتمد على ملف مضغوط بعينه موثق أدناه.

---

## 1) الاختبارات الآلية (نُفّذت حرفياً قدر الإمكان + مخرجات)

### 1.1 `npm install` (داخل `restore-store`)
**الأمر:** `npm install`  
**النتيجة:** نجح  
**الدليل (مقتطف مخرجات):**
```text
npm warn deprecated whatwg-encoding@3.1.1: Use @exodus/bytes instead for a more spec-conformant and faster implementation
npm warn deprecated eslint@9.39.5: This version is no longer supported. Please see https://eslint.org/version-support for other options.

added 145 packages, and audited 146 packages in 8s

36 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities
```

### 1.2 `npm run check` (مركب، كما طُلب)
**الأمر:** `npm run check`  
**النتيجة:** **فشل كأمر مركب** (توقف عند `lint:js`)، مع نجاح أجزاء سابقة منه.  
**الدليل:**
```text
> restore-store@1.5.0 check
> npm run lint && npm run lint:js && npm test && npm run test:smoke && npm run test:db

> restore-store@1.5.0 lint
> node scripts/check-boundaries.mjs && node scripts/check-syntax.mjs && node scripts/check-brand.mjs && echo 'lint ok'

architecture ok: 75 files, all ≤ 600 lines, layers respected, no dead files
syntax ok
brand neutral: 98 files clean
lint ok

> restore-store@1.5.0 lint:js
> eslint assets/js

sh: line 1: eslint: command not found

Exited with code 127
```
**تفسير مبني على الدليل:** الأمر المركب لم يُكمل `test/smoke/db` بسبب فشل استدعاء `eslint` في `PATH` داخل خطوة `lint:js`، رغم أن `npm install` نجح. تم التحقق من المراحل المتبقية وتشغيل ESLint المطلوب بشكل منفصل (أدناه).

### 1.3 اختبارات منفصلة (للتحقق من الحالة الفعلية بعد توقف المركب)

| الأمر | النتيجة | الدليل |
|---|---:|---|
| `npm test` | نجح | `ℹ tests 16` / `ℹ pass 16` / `ℹ fail 0` / `ℹ duration_ms 1096.572642` (node --test، `tests/*.test.mjs`) |
| `npm run test:smoke` | نجح | 10 صفحات `OK` (index, collection, product, checkout, wishlist, page, account, blog, blog-post, dashboard) + `OK dashboard.html body=12168 routes=18` + `smoke ok — all pages and dashboard routes render without errors` |
| `npm run test:db` | نجح | طبق `schema.sql` و`0002_relational.sql` و`0003_catalog_source_of_truth.sql` و`0004_catalog_atomic.sql` و`0005_fix_create_order_v2.sql`؛ سيناريوهات RPC/audit/RLS/قيود/مخزون/طلب نجحت؛ انتهى بـ **`DONE — all database scenarios passed`** (اختبار تكامل DB عبر PGlite/PostgreSQL 16 حسب بنية الاختبار). |
| `npx eslint assets/js sw.js scripts tests` | نجح (صامت) | `---ESLINT_EXIT:0---` |
| `npm audit --audit-level=high` | نجح | `found 0 vulnerabilities` |

**أدلة RLS/سلوك مهمة من `test:db` (مخرجات فعلية):**
- `OK anon reads active products`
- `OK anon cannot read orders`
- `OK anon cannot read customers`
- `OK anon cannot read staff`
- `OK anon cannot read audit log`
- `OK anon cannot change prices price=120000`
- `OK anon cannot insert orders directly (must go through create-order)`
- `OK restore_rate_hit allows 3 then blocks [true,true,true,false]`
- `OK anon cannot call restore_rate_hit`

---

## 2) اختبار إنشاء عميل جديد

### 2.1 الأمر المنفّذ
```bash
node scripts/new-client.mjs --key test1 --ar "متجر الاختبار" --fr "Test Store" --phone 22241111111 --email test@example.org --color "#dc2626" --domain test1.pages.dev --out /tmp/clients
```
**النتيجة:** نجح الإنشاء  
**الدليل:**
```text
brand applied: متجر الاختبار / Test Store @ https://test1.pages.dev

✔ Client created at /tmp/clients/test1
  next: open /tmp/clients/test1/CLIENT.md and follow A → D
```

### 2.2 التحقق في `/tmp/clients/test1`

| المطلوب | النتيجة | الدليل |
|---|---:|---|
| `brand.config.js` يحمل القيم + `staffEmailDomain=example.org` | نجح | `/tmp/clients/test1/assets/js/brand.config.js`: `key:"test1"`, `name {"ar":"متجر الاختبار","fr":"Test Store"}`, `phone "+22241111111"`, `whatsapp "22241111111"`, `email "test@example.org"`, `staffEmailDomain: "example.org"`, `colors.primary "#dc2626"`, `domain "test1.pages.dev"` |
| `<title>` في `index.html` و`dashboard.html` يحمل الاسم الجديد | نجح | `index.html:7: <title>متجر الاختبار | منتجات أصلية وتوصيل سريع</title>`؛ `dashboard.html:7: <title>لوحة تحكم متجر الاختبار | Test Store Dashboard</title>` |
| `sitemap.xml` و`robots.txt` يحملان `test1.pages.dev` | نجح | `sitemap.xml`: `<loc>https://test1.pages.dev/</loc>` وروابط منتجات/مجموعات على `test1.pages.dev`؛ `robots.txt`: `Sitemap: https://test1.pages.dev/sitemap.xml` |
| `supabase/ALL_IN_ONE.sql` موجود ويحتوي schema + 0002..0005 بالترتيب | نجح | الملف موجود (63389 بايت). الرأس يذكر: `schema.sql, 0002_relational.sql, 0003_catalog_source_of_truth.sql, 0004_catalog_atomic.sql, 0005_fix_create_order_v2.sql`. أقسام الهجرات عند الأسطر: `592` (0002)، `835` (0003)، `900` (0004)، `1092` (0005) — **بالترتيب** |
| وجود `CLIENT.md`, `LICENSE-CLIENT.txt`, `_headers`, `.github/workflows/keepalive.yml` | نجح | جميعها `EXISTS` |
| `npm run check` داخل مجلد العميل | نجح (مع ملاحظة إجراء) | تم ربط `node_modules` بالقالب: `ln -s /home/mouhammed/Documents/store template/restore-store/node_modules node_modules` لتجنب إعادة تثبيت. النتيجة: `lint ok` (architecture 75 files ≤600, syntax ok, brand neutral 98 files clean)، `eslint assets/js` بلا أخطاء، `tests 16 pass/0 fail`، `smoke ok` (routes=18)، `DONE — all database scenarios passed` |
| بحث آثار العلامة الأصلية | **فشل جزئي** | الأمر: `grep -rn "ريستور\|Restore Maurit\|restore\.mr\|cdn\.shopify" --include='*.html' --include='*.js' --include='*.json' .` داخل العميل. **النتيجة: مطابقة واحدة (ليست صفراً):** `./package.json:6: "description": "Restore Mauritania storefront and dashboard"`. لا مطابقات لـ `cdn.shopify`/`restore.mr`/`ريستور` في النطاق المطلوب عدا هذا السطر. |

---

## 3) اختبار يدوي في المتصفح (وضع محلي)

> المطلوب حرفياً: تعديل `assets/js/config.js` إلى `mode:"local", demoEnabled:true`، تشغيل `python3 -m http.server 8100`، وفتح/اختبار المتجر واللوحة و`guide.html` مع فحص Console وسلوك UI.

| الجزء | النتيجة | الدليل / السبب |
|---|---:|---|
| إعداد محلي (تعديل config + خادم) | **جزئي (تقني)** | تم تعديل `assets/js/config.js` مؤقتاً إلى `mode:"local"` و`demoEnabled:true` (تم التحقق نصياً)، تشغيل خادم مؤقت، ثم **إعادة** `config.js` لحالته الأصلية بعد الفحص. استجابات HTTP عبر `curl`: `index.html 200/1837`، `product.html?handle=smartphone-pro-128 200/1965`، `dashboard.html 200/1816`، `guide.html 200/6405`. |
| أ) المتجر: 21 منتج تجريبي SVG، لافتة موافقة البكسلات لا تظهر بلا معرّفات، إضافة للسلة، تغيير AR/FR، فتح `product.html?handle=smartphone-pro-128`، إكمال طلب حتى النجاح، فحص Console | **لم يُنفَّذ (تفاعلي بصري/Console)** | يتطلب متصفحاً حقيقياً وتفاعلاً ومراقبة Console وإكمال تدفق الطلب. **أدلة سياقية غير تفاعلية:** `assets/js/data.js` يحتوي كتالوج demo بعناصر متعددة تشمل `smartphone-pro-128` حتى `screen-protector` وصور `assets/products/*.svg` (دليل وجود demo data)؛ منطق البكسلات/الموافقة في `assets/js/ui/storefront/15-global-events.js:261-296` يحمّل `assets/js/pixels.js` فقط عند `restore_consent_v1 === "granted"` وإلا يعرض لافتة/لا يحمّل (راجع القسم 4). |
| ب) لوحة التحكم `/dashboard.html`: دخول owner بكلمة سر ≥8 (أول مرة demo)، تنقل 18 مساراً، إضافة منتج ونشره وظهوره بالمتجر، فتح طلب وطباعة فاتورة، رصد ReferenceError/شاشة بيضاء | **لم يُنفَّذ (تفاعلي بصري/Console)** | يتطلب جلسة UI وتنقلاً وتفاعلاً. **دليل جزئي:** smoke يؤكد `dashboard.html body=12168 routes=18` دون أخطاء تحميل في سياق الاختبار؛ سلوك demo مقيد ببيئة محلية/إعدادات (`config.demoEnabled`, منطق `DEMO_ALLOWED/LOCAL_DEV` في الخدمات). لا يمكن تأكيد غياب ReferenceError أو نجاح النشر/الطباعة دون متصفح. |
| ج) `/guide.html` يفتح ويُقرأ | **جزئي** | HTTP 200 وحجم 6405 بايت على الخادم المحلي؛ لم يُقيّم العرض/القراءة البصرية. |

---

## 4) مراجعة الأمان (قراءة الكود — دون تخمين)

### 4.1 `service_role` تحت `assets/`
**النتيجة:** نجح (لا وجود لمفتاح/استخدام فعلي؛ ذكر تعليمي فقط).  
**الدليل:** `grep -rn "service_role|serviceRole|SERVICE_ROLE" assets/` → مطابقة واحدة: `assets/js/config.js:3` (تعليق: "Never put a service_role key here.").

### 4.2 RLS على `restore_orders` / `restore_customers` (هل anon يستطيع القراءة؟) + مقارنة `tests/db`
**النتيجة:** نجح (anon **لا** يقرأ orders/customers ولا يدرج orders مباشرة، وفق schema واختبار فعلي).  
**أدلة schema (`supabase/schema.sql`):**
- تفعيل RLS: `alter table public.restore_orders enable row level security;` (`:182`)، `alter table public.restore_customers enable row level security;` (`:186`).
- الطلبات: سياسة إدراج عميل/anon المباشرة **محذوفة/معلّقة للتوافق فقط** (`drop policy if exists restore_orders_customer_insert` `:202`؛ قالب policy معلّق `:205-208` مع تعليق "Direct public inserts are disabled / COMPATIBILITY ONLY"). قراءة العميل المصادق لطلباته فقط عبر `customer_id = (select id from restore_customers where auth_id = auth.uid())` (`:210-216`). الموظفون `is_staff()` (`:218-220`).
- العملاء: `restore_customers_own_read` يقيّد القراءة بـ `auth_id = auth.uid() or public.is_staff()` (`:257-259`) — لا سياسة `anon select`. إدراج/تحديث ذاتي للمصادق (`:261-267`)، وإدارة موظف (`:269-271`).
**مقارنة `tests/db`:** تطابق مع النتائج الفعلية: `anon cannot read orders/customers/staff/audit`, `anon cannot insert orders directly (must go through create-order)`, `anon cannot change prices`.

### 4.3 حساب الأسعار/المجاميع على الخادم (`restore_create_order_v2`) لا المتصفح
**النتيجة:** نجح من حيث **التصميم والكود**؛ النشر الفعلي لم يُختبر (خارج النطاق).  
**الدليل:**
- `supabase/migrations/0002_relational.sql:185` و`0005_fix_create_order_v2.sql:7`: تعريف `restore_create_order_v2(p_order jsonb)` (يحسب subtotal/shipping/discount/total، يتحقق من عناصر/مخزون/كوبون، يدرج في `restore_orders` مع `validated`).
- صلاحيات التنفيذ مقيدة: `revoke all ... from public, anon, authenticated; grant execute ... to service_role` (`0002:239-240`, `0005:62-63`).
- Edge Function `supabase/functions/create-order/index.ts:94-97,102` تستدعي RPC `restore_create_order_v2`.
- `assets/js/config.js`: `requireServerOrders: true`, `createOrderFunction: "create-order"`.
**ملاحظة:** سلامة المسار في الإنتاج تعتمد على نشر RPC/الدالة وتهيئة Supabase — **لم يُنفَّذ نشر حي**.

### 4.4 CSP في `vercel.json` و`_headers`
**النتيجة:** **نجح للسكربتات؛ ملاحظة على الأنماط.**  
**الدليل:** `vercel.json:76-77` يحتوي CSP؛ `/tmp/clients/test1/_headers` يحتوي CSP مكافئاً وظيفياً. ملاحظة وجودية: ملف `_headers` **غير موجود** في جذر القالب الحالي (موجود في نسخة العميل) — راجع المشكلة 3.
- `script-src 'self' https://www.googletagmanager.com https://analytics.tiktok.com https://connect.facebook.net;` → **لا `unsafe-inline` للسكربتات** ✓.
- `style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;` → يسمح **`unsafe-inline` للأنماط** (ليس سكربتات) ⚠️.
- سياسات إضافية جيدة ظاهرة في `_headers` العميل: `X-Frame-Options: SAMEORIGIN`, `object-src 'none'`, `base-uri 'self'`, `form-action 'self'`, `Strict-Transport-Security`، إلخ.

### 4.5 البكسلات: هل تُحمَّل قبل الموافقة؟
**النتيجة:** نجح (الكود يمنع التحميل قبل الموافقة).  
**الدليل:** `assets/js/ui/storefront/15-global-events.js:261-296`:
- مفتاح الموافقة `restore_consent_v1` (`:263-264`).
- إن لم تكن هناك موافقة (`consent !== "granted"`) يعرض لافتة عند غياب الاختيار ولا يحمّل البكسلات (`:289`).
- عند الموافقة فقط يحقن `<script src="assets/js/pixels.js" ...>` (`:291-297`).
- تحميل معرفات البكسلات مشروط بوجود إعدادات (`pixels.meta/tiktok/ga`) بعد فحص الموافقة.

### 4.6 حد المحاولات في `admin-create-staff` و`create-order`
**النتيجة:** نجح (موجود في الكود، وRPC rate-hit مثبت باختبار DB).  
**الدليل:**
- `supabase/functions/admin-create-staff/index.ts:46-50`: حد مشترك عبر `admin.rpc("restore_rate_hit", { p_key: staff:${ip}, p_limit: 10, p_window_seconds: 600 })`؛ عند خطأ RPC → `503 rate_limit_unavailable` (fail-closed)؛ عند التجاوز → `429 too_many_requests`.
- `supabase/functions/create-order/index.ts:70,75-80`: حد محلي فوري (`429`) + حد مشترك عبر `restore_rate_hit` (`order:${ip}`, `MAX_REQ`/60s) مع fallback محلي عند تعذر RPC.
- `tests/db`: `restore_rate_hit allows 3 then blocks [true,true,true,false]` و`anon cannot call restore_rate_hit`.

---

## 5) ما لا يمكنني اختباره هنا (مذكور صراحة — لم يُنفَّذ)
- **لم يُنفَّذ:** نشر فعلي على Supabase مستضاف.
- **لم يُنفَّذ:** نشر Edge Functions (`create-order`, `admin-create-staff`) وتشغيلها في بيئة حية.
- **لم يُنفَّذ:** نشر فعلي على Cloudflare Pages (أو Netlify) والتحقق من تطبيق `_headers`/CSP/HSTS على مضيف حي.
- **لم يُنفَّذ:** تشغيل GitHub Actions.
- **لم يُنفَّذ:** آلية keep-alive الفعلية ضد مشروع Supabase مجاني حي (الملف `.github/workflows/keepalive.yml` موجود في نسخة العميل، لكن لم يُشغّل).
- **لم يُنفَّذ:** الاختبار اليدوي التفاعلي الكامل في متصفح (Console، تنقل 18 مسار فعلي، إضافة/نشر منتج بواجهة حية، طباعة فاتورة، إكمال طلب حتى النجاح بصرياً).

---

## 6) جدول الملخص

| البند | النتيجة | الدليل |
|---|---:|---|
| توفر `store template8.zip` + unzip | فشل/لم يُنفَّذ كمضغوط | `find/glob` بلا نتائج؛ التنفيذ على `restore-store` v1.5.0 |
| `npm install` | نجح | `added 145 packages... found 0 vulnerabilities` |
| `npm run check` (مركب) | فشل كأمر مركب | توقف عند `lint:js`: `eslint: command not found`, exit 127؛ قبله `architecture ok 75 files ≤600`, `syntax ok`, `brand neutral 98 files clean` |
| `npm test` | نجح | 16/16 pass, 0 fail |
| `npm run test:smoke` | نجح | 10 صفحات OK + `dashboard routes=18`, smoke ok |
| `npm run test:db` | نجح | schema+0002..0005 + سيناريوهات RLS/RPC؛ `DONE — all database scenarios passed` |
| `npx eslint assets/js sw.js scripts tests` | نجح | خروج 0 (صامت) |
| `npm audit --audit-level=high` | نجح | 0 vulnerabilities |
| إنشاء عميل `new-client` | نجح | `/tmp/clients/test1` بالقيم المطلوبة |
| تحقق محتوى عميل (brand/titles/sitemap/robots/ALL_IN_ONE/ملفات) | نجح | قيم صحيحة؛ عناوين صحيحة؛ دومين test1.pages.dev؛ ALL_IN_ONE بالترتيب؛ ملفات مطلوبة موجودة |
| `npm run check` داخل العميل | نجح | lint+eslint+16/16+smoke+db كلها ناجحة (مع ربط node_modules) |
| بحث آثار علامة أصلية في العميل (html/js/json) | **فشل جزئي** | `test1/package.json:6` = وصف "Restore Mauritania..." |
| اختبار يدوي متصفح A/B/C (كامل تفاعلي) | لم يُنفَّذ (جزئي تقني) | HTTP 200 جزئي؛ Console/تنقل/نشر/طلب/فاتورة غير منفذة |
| `service_role` تحت `assets/` | نجح | تعليق فقط في `config.js:3` |
| RLS anon على orders/customers | نجح | schema + tests/db تؤكد المنع |
| تسعير خادم `restore_create_order_v2` | نجح (كود/تصميم) | RPC يحسب ومقيد لـ service_role؛ يتطلب نشر حي |
| CSP يمنع `unsafe-inline` للسكربتات | نجح للسكربتات / ملاحظة | `script-src` بلا unsafe-inline؛ `style-src` يسمح unsafe-inline |
| البكسلات بعد الموافقة | نجح | تحميل `pixels.js` مشروط بـ `granted` |
| حد محاولات admin-create-staff / create-order | نجح | `restore_rate_hit` + 429/503؛ مثبت جزئياً باختبار DB |
| نشر Supabase/Functions/Pages/Actions/keep-alive حي | لم يُنفَّذ | خارج البيئة/بدون اعتمادات |

---

## 7) أخطر 5 مشاكل (مرتبة بالخطورة) + كيفية إعادة الإنتاج

### 1) [متوسط/علامة تجارية وتجاري] تسرب هوية أصلية في نسخة العميل المُولَّدة (`package.json.description`)
- **الأثر:** عميل جديد يستلم ملفاً ضمن النسخة يحمل "Restore Mauritania"، ما يخالف حيادية المنتج القابل للبيع وقد يسبب التباس علامة/تسليم.
- **الدليل:** `/tmp/clients/test1/package.json:6` → `"description": "Restore Mauritania storefront and dashboard"`.
- **إعادة الإنتاج:**
  1. `node scripts/new-client.mjs --key test1 --ar "متجر الاختبار" --fr "Test Store" --phone 22241111111 --email test@example.org --color "#dc2626" --domain test1.pages.dev --out /tmp/clients`
  2. `grep -rn "Restore Maurit" /tmp/clients/test1 --include='*.json'`
  3. **المتوقع الصحيح:** 0 نتائج. **الفعلي:** مطابقة في `package.json`.

### 2) [متوسط/تشغيلي وجودة تسليم] `npm run check` المركب يفشل بعد `npm install` ناجح بسبب `eslint` غير مستدعى بشكل موثوق
- **الأثر:** بوابة الجودة المعلنة تفشل (exit 127) في بيئة القالب، ما يربك المطور/التاجر/CI ويضعف موثوقية "check واحد يثبت الجاهزية".
- **الدليل:** `npm run check` → `lint ok` ثم `lint:js` ينفذ `eslint assets/js` مباشرة → `sh: line 1: eslint: command not found` / exit 127. بالمقابل `npx eslint assets/js sw.js scripts tests` → exit 0، و`npm run check` داخل العميل نجح في سياق التنفيذ الموثق.
- **إعادة الإنتاج:**
  1. داخل `restore-store` بعد `npm install`.
  2. نفّذ `npm run check` → ينهار عند `lint:js`.
  3. نفّذ `npx eslint assets/js sw.js scripts tests` → ينجح (صامت، 0).
  4. **المتوقع:** `npm run check` ينجح بالكامل أو يفشل بسبب مشكلة كود حقيقية، لا بسبب حل مسار أداة مثبتة.

### 3) [منخفض-متوسط/اتساق أمان النشر] غياب `_headers` في جذر القالب رغم وجوده في نسخة العميل واعتماد Vercel على `vercel.json`
- **الأثر:** عند نشر القالب/نسخ غير مكتملة على Cloudflare Pages/Netlify قد تُفقد سياسات الأمان والرؤوس (CSP/HSTS/no-store للوحة/dashboard/guide) ما لم يُنتبه لملف `_headers`.
- **الدليل:** في جذر القالب: لا ملف `_headers` (بحث `find` بلا نتائج). في `/tmp/clients/test1/_headers`: موجود ويحتوي CSP وHSTS و`X-Frame-Options` وno-store لـ `/dashboard.html`.
- **إعادة الإنتاج:**
  1. `ls /home/mouhammed/Documents/store\ template/restore-store/_headers` → غير موجود.
  2. `ls /tmp/clients/test1/_headers` → موجود.
  3. قارن تغطية الاستضافة المستهدفة (Vercel يستخدم `vercel.json`؛ صفحات/Netlify تحتاج `_headers` عادة).

### 4) [منخفض/تقوية CSP] `style-src` يسمح `'unsafe-inline'`
- **الأثر:** يضعف CSP ضد حقن أنماط/بعض هجمات UI redress. **السكربتات** محمية بشكل أفضل (`script-src` بلا `unsafe-inline`).
- **الدليل:** `vercel.json:77` و`test1/_headers`: `style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;` مقابل `script-src 'self' ...` بدون `unsafe-inline`.
- **إعادة الإنتاج:** افتح `vercel.json` أو `_headers` وابحث عن `style-src` → ستجد `'unsafe-inline'`.

### 5) [منخفض/فجوة تحقق لا عيباً مثبتاً] عدم التحقق اليدوي التفاعلي لتدفقات حرجة (لوحة/نشر/فاتورة/طلب/Console)
- **الأثر:** smoke يثبت التحميل والمسارات شكلياً، لكنه لا يثبت سلامة Runtime UI، غياب ReferenceError، أو اكتمال السيناريوهات التجارية تفاعلياً.
- **الدليل:** smoke: 10 صفحات + `routes=18` ناجحة؛ HTTP 200 لصفحات أساسية. **لم يُنفَّذ:** تسجيل دخول owner/demo في متصفح، تنقل 18 مسار فعلي، إضافة/نشر منتج ورؤيته بالمتجر، فتح طلب وطباعة فاتورة، إكمال طلب حتى النجاح، وسجل Console.
- **إعادة الإنتاج (يدوي مطلوب):**
  1. في القالب: اضبط `assets/js/config.js` → `mode:"local", demoEnabled:true`.
  2. `python3 -m http.server 8100` وافتح `http://localhost:8100`.
  3. نفّذ سيناريوهات القسم 3 (أ/ب/ج) وسجّل أي خطأ Console أو شاشة بيضاء ونتيجة كل خطوة.

---

## 8) الدرجات (من 10)

| المحور | الدرجة | التبرير |
|---|---:|---|
| الأمان | **8/10** | RLS تمنع anon من orders/customers وتمنع إدراج طلب مباشر (مثبت schema+tests/db)، تسعير/تحقق عبر `restore_create_order_v2` مقيد بـ service_role، حدود محاولات في الدوال + `restore_rate_hit`، البكسلات خلف موافقة، و`script-src` بلا unsafe-inline؛ ينقص تحقق نشر حي و`style-src` يسمح unsafe-inline. |
| جاهزية البيع كنسخ منفصلة | **7/10** | `new-client` ينتج نسخة عملية (هوية، عناوين، دومين، ALL_IN_ONE schema+0002..0005، headers، keepalive، CLIENT/LICENSE) والعميل يجتاز `check`؛ لكن وُجد تسرب علامة أصلية في `package.json` ووُجد عدم اتساق `_headers` على مستوى القالب. |
| جودة الكود | **8/10** | `architecture ok` (75 ملف، ≤600 سطر، طبقات محترمة، بلا ملفات ميتة)، `syntax ok`، ESLint صامت، ونجاح 16/16 unit + smoke + DB integration؛ يعيبه فشل `npm run check` المركب عند `lint:js` في بيئة القالب. |
| التوثيق | **8/10** | توفر `README`, `CHANGELOG`, `SECURITY`, `guide.html`, `CLIENT.md`, `docs/UPDATING.md` وتعليقات أمان/تهيئة واضحة؛ لم يُختبر اكتمال/صحة إجراءات النشر الحي خطوة بخطوة. |
| تجربة التاجر | **6/10 (تقدير جزئي)** | توجد مواد إرشاد وتدفق demo وتقسيم واضح، لكن غياب التنفيذ اليدوي التفاعلي الكامل (لوحة 18 مسار، نشر/ظهور منتج، فاتورة، طلب مكتمل، Console) يمنع تأكيد تجربة خالية من العيوب. |

---

## 9) التوصية النهائية
**الحكم: بشرط (ليس "نعم" مطلقاً اليوم).**

**لماذا؟**
- الأساس التقني في النطاق المُختبر **جيد نسبياً**: اختبارات unit/smoke/DB ناجحة، RLS وسلوك الطلب/المعدل يظهران بشكل صحيح في الاختبارات، `script-src` مقيد، والبكسلات مشروطة بالموافقة.
- لكن البيع لتاجر صغير كنسخ منفصلة يتطلب **حداً أدنى إضافياً** قبل الاطمئنان التجاري:
  1. **إصلاح تسرب الهوية** في مخرجات `new-client` (خصوصاً `package.json` وأي حقول نصية مشابهة) وتوسيع فحص الحياد ليغطيها.
  2. **إصلاح موثوقية `npm run check`** (`lint:js` عبر `npx`/مسار bin صريح) لأنها بوابة التسليم.
  3. **تنفيذ تحقق يدوي فعلي** للقسم 3 (متصفح + Console + 18 مسار + نشر/فاتورة/طلب).
  4. **تنفيذ تحقق نشر حي** (Supabase مستضاف + Edge Functions + Cloudflare Pages/الاستضافة المختارة + GitHub Actions/keep-alive) — وهذه النقاط **لم تُنفَّذ** في هذا التقرير ولا يجوز اعتبارها ناجحة.

**خلاصة عملية:** يمكن اعتباره قريباً من الجاهزية هندسياً، لكنه **لا يُنصح ببيعه لتاجر صغير اليوم دون إغلاق الشروط 1–4 أعلاه**.
