// Minimal, strict-where-it-matters config: catches undefined identifiers (the class of bug that broke the dashboard
// reviews view in 1.2.x) and redeclarations. Style rules come in a later phase.
import globals from "globals";
export default [
  { ignores: ["node_modules/**", "assets/vendor/**", "supabase/functions/**"] },
  {
    files: ["assets/js/**/*.js", "scripts/**/*.mjs", "tests/**/*.mjs"],
    languageOptions: { ecmaVersion: 2023, sourceType: "module", globals: { ...globals.browser, ...globals.node, DOMPurify: "readonly" } },
    rules: { "no-undef": "error", "no-redeclare": "error", "no-dupe-keys": "error", "no-unreachable": "error", "no-unused-vars": "off" }
  },
  { files: ["assets/js/domain/**/*.js", "assets/js/data/**/*.js", "assets/js/core/**/*.js"],
    rules: { "no-restricted-globals": ["error", "document", "window", "localStorage"], "no-restricted-imports": ["error", { patterns: [{ group: ["**/ui/**", "**/services/**"], message: "domain/data/core must not import ui or services (ui → services → domain → data → core)." }] }] } },
  { files: ["sw.js"], languageOptions: { globals: globals.serviceworker }, rules: { "no-undef": "error" } }
];
