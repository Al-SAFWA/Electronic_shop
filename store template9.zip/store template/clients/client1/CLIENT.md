# My Store / متجري — delivery checklist
Template version: 1.5.0 · created 2026-11-09 · key: `client1` · domain: `client1.pages.dev`

Everything below is free. Nothing is shared with any other merchant.

## A. Supabase (merchant's own account — use the merchant's e-mail: contact@client1.com)
1. https://supabase.com → Sign up with **contact@client1.com** → New project → name `client1`, region closest to the merchant, strong DB password (save it).
2. Project → **SQL Editor** → New query → paste the whole file `supabase/ALL_IN_ONE.sql` → **Run**. Expect "Success. No rows returned".
3. Project → **Authentication → Users → Add user** → e-mail + password of the merchant (this is the dashboard owner login). Copy the user's UUID.
4. SQL Editor → run (replace the UUID and name):
   ```sql
   insert into public.restore_staff (auth_id, username, email, name, role, active)
   values ('PASTE-UUID', 'client1', 'contact@client1.com', 'My Store', 'owner', true);
   ```
5. Project → **Storage** → confirm bucket `restore-media` exists (created by the SQL). If not: New bucket `restore-media`, public.
6. Project → **Settings → API** → copy **Project URL** and **anon public** key into `assets/js/config.js` (`supabaseUrl`, `supabaseAnonKey`). Never paste the service_role key anywhere in this repo.
7. Edge Functions (needs Supabase CLI once on your machine: `npm i -g supabase`):
   ```bash
   supabase login
   supabase link --project-ref <PROJECT-REF>
   supabase secrets set SUPABASE_URL=https://<PROJECT-REF>.supabase.co SUPABASE_SERVICE_ROLE_KEY=<from Settings → API>
   supabase functions deploy create-order --no-verify-jwt
   supabase functions deploy admin-create-staff --no-verify-jwt
   ```

## B. Hosting (free, commercial use allowed) — Cloudflare Pages (recommended) or GitHub Pages
1. Create a **new private GitHub repo** for this merchant only, push this folder (`git init && git add . && git commit -m "init" && git push`).
2. Repo → Settings → Secrets → add `SUPABASE_URL` and `SUPABASE_ANON_KEY` (for the keep-alive workflow).
3. Cloudflare Pages → Create project → connect the repo → Framework: None, build command: *(empty)*, output dir: `/` → Deploy. URL: `https://client1.pages.dev`.
   (GitHub Pages alternative: Settings → Pages → Deploy from branch → main / root.)
4. Custom domain later: Pages → Custom domains → add → follow DNS instructions. Then set `domain` in `assets/js/brand.config.js`, run `npm run brand`, commit.

## C. Hand-over to the merchant
- Dashboard: `https://client1.pages.dev/dashboard.html` — login = the e-mail/password from step A3. Ask them to change the password on first login.
- Send them `guide.html` (`https://client1.pages.dev/guide.html`) — the merchant manual in Arabic.
- Products → "نقل الكتالوج إلى الجداول" once, then replace the demo products/images from the dashboard.
- Settings → logo, colours, phone, WhatsApp, cities, payment methods.

## D. Verify (5 minutes)
- [ ] Storefront opens, no console errors; products visible.
- [ ] Dashboard login works; add a product; it appears on the storefront after publish.
- [ ] Place a test order on the storefront → appears in Dashboard → Orders.
- [ ] Keep-alive workflow runs green (Actions → run manually once).
