# Architecture (1.3.0)

```
assets/js/
  config.js, data.js, theme-init.js, pixels.js   # plain scripts (window.*), loaded by the HTML pages
  state.js      → assembler for services/*       # window.RESTORE API (storefront + dashboard share it)
  app.js        → assembler for ui/storefront/*  # public storefront pages
  dashboard.js  → assembler for ui/dashboard/*   # staff dashboard
  services/     # business/application services: config, default content, staff auth, Supabase REST,
                # orders, publish, catalog, customers, reviews, currency, pages/settings, sync events
  ui/storefront/, ui/dashboard/                  # rendering + event delegation, one feature per file
  domain/       # pure functions (pricing, catalog mappers) — no DOM, no network, unit-tested
  data/         # Supabase client + repositories (catalog.repo → RPC restore_upsert_product / restore_delete_product)
  core/         # dom (esc, sanitizeRichHTML), utils
  i18n/         # ar.js, fr.js + index
```

## The `ctx` pattern
`state.js`, `app.js` and `dashboard.js` used to be three closure monoliths (2.5–2.9k lines each) whose functions
shared ~15 mutable variables. They were split **mechanically and scope-aware** (acorn + eslint-scope): every
top-level function/const moved to a feature module, every cross-module reference became `ctx.name`, and every
shared mutable variable became a `ctx` property. Behaviour is byte-for-byte the same — verified by rendering all
10 pages and 18 dashboard routes before/after in jsdom (identical DOM sizes, zero errors).

Rules enforced by `npm run lint` (`scripts/check-boundaries.mjs`, exit 1):
1. `core/ domain/ data/ i18n/` never import `ui/` or `services/`; `services/` never imports `ui/`; `domain/` never imports `data/`.
2. No file under `assets/js` above 600 lines.
3. No dead files: every JS file is imported by another module or loaded by an HTML page.

`npm run lint:js` (ESLint `no-undef`) catches undefined identifiers across modules — the class of bug that made the
dashboard **reviews** view crash in 1.2.x (`L is not defined`).

## Next refactoring steps (not done yet — honest scope)
- Modules still communicate through `ctx` instead of explicit imports; converting module-by-module to named
  imports is safe now that files are small and the smoke/eslint nets exist.
- `services/01-default-content.js` is demo content and could move to `data/defaults/`.
