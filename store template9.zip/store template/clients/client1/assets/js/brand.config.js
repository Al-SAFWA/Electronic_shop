/* ============================================================================
   BRAND CONFIG — the ONLY place a merchant's identity lives.
   `npm run new-client` fills this file; the dashboard can override everything later (saved in the database).
   Plain script (not a module) so it is available before state.js runs.
   ============================================================================ */
window.BRAND = {
  key: "client1",
  name: {"ar":"متجري","fr":"My Store"},
  legalName: {"ar":"متجري","fr":"My Store"},
  tagline: {"ar":"منتجات أصلية وتوصيل سريع","fr":"منتجات أصلية وتوصيل سريع"},
  logo: "assets/img/brand-logo.svg",
  logoWhite: "assets/img/brand-logo-white.svg",
  favicon: "assets/img/favicon.svg",
  colors: { primary: "#2563eb", ink: "#0f172a", purple: "#7c3aed", lavender: "#eef2ff" },
  font: "Montserrat",
  country: { code: "MR", name: { ar: "موريتانيا", fr: "Mauritanie" }, dial: "+222", currencyCode: "MRU", currency: { ar: "أوقية", fr: "MRU" }, currencyName: { ar: "أوقية جديدة", fr: "Nouvelle ouguiya" }, flag: "assets/img/flag-mr.svg" },
  city: {"ar":"نواكشوط","fr":"نواكشوط"},
  address: {"ar":"نواكشوط","fr":"نواكشوط"},
  timezone: "Africa/Nouakchott",
  phone: "+22200000000",
  phoneDisplay: "+222 00 00 00 00",
  whatsapp: "22200000000",
  email: "contact@client1.com",
  staffEmailDomain: "client1.com",
  domain: "client1.pages.dev",
  social: { facebook: "", instagram: "", tiktok: "", snapchat: "", youtube: "", x: "" },
  couponPrefix: "WELCOME"                        // demo coupon code = WELCOME10
};
