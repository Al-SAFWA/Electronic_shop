/* state.js → Default content (part 1)
   Extracted mechanically from the former monolith; shared state lives on `ctx` (see state.js). */
import { t as tI18n, L as LI18n } from "../i18n/index.js";

export function install(ctx) {
  const B = window.BRAND || {};
  const BN = { ar: B.name?.ar || "متجر", fr: B.name?.fr || "Store" };
  const bt = (ar, fr) => ctx.txt(ar.split("{brand}").join(BN.ar), fr.split("{brand}").join(BN.fr));
  Object.assign(ctx, { productDescriptions, hashHandle, includesFor, specsFor, priceProduct, buildProducts, buildState, hydrate, t, money, formatDate, setLang, setTheme });
  const TYPE_DESCRIPTIONS = {
    Smartphone: bt(
      "هاتف مجدد بالكامل، تم فحصه وتنظيفه واختباره من طرف خبراء {brand}. يعمل بكفاءة عالية ويأتي بضمان 12 شهرًا.",
      "Téléphone entièrement reconditionné, inspecté, nettoyé et testé par les experts {brand}. Il fonctionne parfaitement et bénéficie d’une garantie de 12 mois."
    ),
    Laptop: ctx.txt(
      "حاسوب محمول مجدد تم اختباره مكونًا بمكون. يصلح للعمل والدراسة والاستخدام اليومي، مع ضمان 12 شهرًا.",
      "Ordinateur portable reconditionné, testé composant par composant. Idéal pour le travail, les études et l’usage quotidien, avec 12 mois de garantie."
    ),
    Macbook: bt(
      "MacBook مجدد مع macOS مثبت وجاهز للاستخدام. تم فحص البطارية ولوحة المفاتيح والمنافذ بواسطة خبراء {brand}.",
      "MacBook reconditionné avec macOS installé et prêt à l’emploi. Batterie, clavier et ports vérifiés par les experts {brand}."
    ),
    Tablets: ctx.txt(
      "جهاز لوحي مجدد تم فحصه بالكامل، مناسب للقراءة والعمل والترفيه، ويأتي بضمان 12 شهرًا.",
      "Tablette reconditionnée entièrement vérifiée, idéale pour lire, travailler et se divertir, avec 12 mois de garantie."
    ),
    Playstation: ctx.txt(
      "جهاز ألعاب مجدد تم اختباره وتنظيفه، ويأتي مع ملحقاته الأساسية وضمان 12 شهرًا.",
      "Console de jeu reconditionnée, testée et nettoyée, livrée avec ses accessoires essentiels et 12 mois de garantie."
    ),
    "Apple Watch": ctx.txt(
      "ساعة Apple مجددة تم فحص البطارية والشاشة والحساسات، وتأتي بضمان 12 شهرًا.",
      "Apple Watch reconditionnée : batterie, écran et capteurs vérifiés, avec 12 mois de garantie."
    ),
    Accessories: ctx.txt(
      "ملحق أصلي مجدد أو جديد، تم فحصه لضمان التوافق والجودة.",
      "Accessoire d’origine reconditionné ou neuf, contrôlé pour garantir compatibilité et qualité."
    )
  };

  const DEFAULT_PAGES = [
    ["about-us", "من نحن", "À propos", BN.ar + " متجر موريتاني متخصص في الإلكترونيات المجددة. نشتري الأجهزة المستعملة، نفحصها ونعيد تأهيلها ثم نبيعها بأسعار عادلة مع ضمان واضح.\nنعمل من نواكشوط ونوصل إلى جميع ولايات موريتانيا.\nهدفنا أن يحصل كل شخص على تقنية موثوقة بدون أن يدفع ثمن جهاز جديد.", BN.fr + " est une boutique mauritanienne spécialisée dans l’électronique reconditionnée. Nous rachetons, contrôlons et remettons en état les appareils avant de les revendre à un prix juste avec une garantie claire.\nNous travaillons depuis Nouakchott et livrons dans toutes les wilayas de Mauritanie.\nNotre objectif : rendre la technologie fiable accessible sans payer le prix du neuf."],
    ["help", "مركز المساعدة والأسئلة الشائعة", "Centre d’aide et FAQ", "تحتاج مساعدة؟ فريق " + BN.ar + " متاح من الأحد إلى الخميس، من 9:00 إلى 19:00.\nراسلنا على واتساب أو اتصل على الرقم المؤقت " + (B.phoneDisplay || "") + ".\nيمكنك أيضًا زيارة صفحة تتبع الطلب أو تقديم طلب ضمان.", "Besoin d’aide ? L’équipe " + BN.fr + " est disponible du dimanche au jeudi, de 9h00 à 19h00.\nÉcrivez-nous sur WhatsApp ou appelez le numéro temporaire " + (B.phoneDisplay || "") + ".\nVous pouvez aussi suivre une commande ou ouvrir une demande de garantie."],
    ["contact", "اتصل بنا", "Contact", "العنوان: نواكشوط، موريتانيا\nواتساب: " + (B.phoneDisplay || "") + "\nالبريد: " + (B.email || "") + "\nساعات العمل: 9:00 صباحًا إلى 19:00 مساءً", "Adresse : Nouakchott, Mauritanie\nWhatsApp : " + (B.phoneDisplay || "") + "\nE-mail : " + (B.email || "") + "\nHoraires : 9h00 à 19h00"],
    ["terms", "الشروط والأحكام", "Conditions générales", "باستخدامك موقع " + BN.ar + " فإنك توافق على شروط البيع هذه. الأسعار معروضة بالأوقية الجديدة وتشمل الضريبة حيث تنطبق.\nيتم تأكيد كل طلب عبر واتساب قبل الشحن. تحتفظ " + BN.ar + " بحق إلغاء أي طلب إذا لم يتوفر المنتج أو إذا كانت المعلومات غير صحيحة.\nالصور توضيحية وقد يختلف لون الجهاز قليلًا.", "En utilisant le site " + BN.fr + ", vous acceptez les présentes conditions de vente. Les prix sont affichés en nouvelle ouguiya et incluent les taxes applicables.\nChaque commande est confirmée via WhatsApp avant expédition. " + BN.fr + " peut annuler une commande en cas de rupture de stock ou d’informations erronées.\nLes photos sont indicatives ; la teinte de l’appareil peut légèrement varier."],
    ["legal", "السياسة القانونية", "Mentions légales", BN.ar + " اسم تجاري لمتجر إلكترونيات مجدد في موريتانيا. جميع العلامات التجارية المذكورة مملوكة لأصحابها.\nمحتوى هذا الموقع وصوره وبياناته قابلة للتعديل من لوحة التحكم. يجب مراجعة النصوص القانونية مع مستشار مختص قبل الإطلاق التجاري.", BN.fr + " est une enseigne d’électronique reconditionnée en Mauritanie. Toutes les marques citées appartiennent à leurs propriétaires.\nLe contenu, les images et les données du site peuvent être modifiés depuis le tableau de bord. Faites réviser les textes juridiques par un professionnel avant un lancement commercial."],
    ["privacy", "سياسة الخصوصية", "Politique de confidentialité", "نجمع فقط المعلومات اللازمة لمعالجة طلبك: الاسم، رقم الهاتف، المدينة والعنوان.\nتُرسل بيانات الطلب إلى واتساب المتجر. لا نبيع بياناتك لأي طرف ثالث.\nيمكنك طلب حذف بياناتك بمراسلتنا على " + (B.email || "") + ".", "Nous collectons uniquement les informations nécessaires au traitement de votre commande : nom, téléphone, ville et adresse.\nLes données de commande sont envoyées au WhatsApp de la boutique. Nous ne vendons pas vos données à des tiers.\nVous pouvez demander leur suppression en écrivant à " + (B.email || "") + "."],
    ["track-order", "تتبع طلبك", "Suivre votre commande", "بعد تأكيد الطلب عبر واتساب سنرسل لك رقم التتبع ورابط شركة الشحن.\nإذا لم يصلك أي تحديث خلال 24 ساعة، راسلنا على واتساب مع رقم الطلب.", "Après confirmation de la commande sur WhatsApp, nous vous envoyons le numéro de suivi et le lien du transporteur.\nSi vous n’avez aucune nouvelle sous 24 heures, écrivez-nous sur WhatsApp avec votre numéro de commande."],
    ["raise-claim", "تقديم طلب ضمان", "Ouvrir une demande de garantie", "كل جهاز مشمول بضمان 12 شهرًا يغطي عيوب التصنيع أو الأعطال غير الناتجة عن سوء الاستخدام.\nأرسل رقم الطلب، وصف العطل، وصورة أو فيديو قصير عبر واتساب.", "Chaque appareil bénéficie d’une garantie de 12 mois couvrant les défauts de fabrication ou les pannes non liées à un mauvais usage.\nEnvoyez le numéro de commande, une description du problème et une courte photo ou vidéo via WhatsApp."],
    ["track-claim", "متابعة طلب الضمان", "Suivi de garantie", "بعد فتح طلب الضمان ستحصل على رقم متابعة. مدة المعالجة المعتادة من 3 إلى 7 أيام عمل.\nراسل الدعم على واتساب إذا احتجت تحديثًا.", "Après l’ouverture d’une demande de garantie, vous recevez un numéro de suivi. Le délai habituel est de 3 à 7 jours ouvrés.\nContactez le support sur WhatsApp pour toute mise à jour."],
    ["blog", "مدونة " + BN.ar, "Le blog " + BN.fr, "نصائح لاختيار هاتف مجدد، مقارنات بين الأجهزة، وطرق العناية بالبطارية.\nاقرأ أحدث المقالات من لوحة التحكم أو من قسم المدونة.", "Conseils pour choisir un téléphone reconditionné, comparatifs et astuces pour préserver la batterie.\nRetrouvez les derniers articles dans la section blog."],
    ["become-a-seller", "كن بائعًا معنا", "Devenir vendeur", "هل لديك أجهزة إلكترونية تريد بيعها؟ نشتري الهواتف والحواسيب والأجهزة اللوحية بعد فحصها.\nراسلنا على واتساب مع نوع الجهاز وحالته وصور له.", "Vous avez des appareils à revendre ? Nous rachetons téléphones, ordinateurs et tablettes après contrôle.\nContactez-nous sur WhatsApp avec le modèle, l’état et quelques photos."],
    ["for-businesses", "حلول للشركات", "Solutions entreprises", "نوفر أجهزة مجددة للشركات والمدارس والمنظمات بأسعار خاصة وضمان موحد.\nاطلب عرض سعر لكمية من 10 أجهزة أو أكثر.", "Nous fournissons des appareils reconditionnés aux entreprises, écoles et organisations à tarifs préférentiels avec une garantie unique.\nDemandez un devis pour 10 appareils ou plus."],
    ["renewed", "ما معنى مجدد من " + BN.ar + "؟", "Que signifie reconditionné chez " + BN.fr + " ?", "الجهاز المجدد هو جهاز مستعمل تم فحصه وتنظيفه وإصلاح ما يلزم فيه ليعمل كجهاز جديد.\nنفحص الشاشة، البطارية، الكاميرا، الصوت، المنافذ والاتصال، ثم نمسح البيانات ونثبت النظام.\nكل جهاز يأتي بضمان 12 شهرًا، توصيل مجاني داخل نواكشوط، وإمكانية الإرجاع خلال 10 أيام.", "Un appareil reconditionné est un appareil d’occasion contrôlé, nettoyé et réparé si nécessaire pour fonctionner comme neuf.\nNous vérifions l’écran, la batterie, les caméras, le son, les ports et la connectivité, puis nous effaçons les données et installons le système.\nChaque appareil est livré avec 12 mois de garantie, la livraison gratuite à Nouakchott et un retour possible sous 10 jours."],
    ["shipping", "الشحن والتوصيل", "Livraison", "التوصيل مجاني داخل نواكشوط. إلى المدن الأخرى تُضاف رسوم حسب الولاية وتظهر عند إتمام الطلب.\nالطلبات المؤكدة قبل الساعة 16:00 تُجهز عادة في نفس اليوم، والتوصيل داخل نواكشوط من 1 إلى 2 يوم عمل.", "La livraison est gratuite à Nouakchott. Pour les autres villes, des frais selon la wilaya sont ajoutés et affichés au moment de la commande.\nLes commandes confirmées avant 16h00 sont généralement préparées le jour même ; la livraison à Nouakchott prend 1 à 2 jours ouvrés."],
    ["returns", "الإرجاع والضمان", "Retours et garantie", "لديك 10 أيام لاختبار الجهاز وإرجاعه إذا لم يعجبك، بشرط أن يكون في حالته الأصلية.\nالضمان 12 شهرًا يغطي الأعطال التقنية، ولا يغطي الكسر أو دخول الماء أو سوء الاستخدام.\nلبدء الإرجاع راسلنا على واتساب مع رقم الطلب.", "Vous disposez de 10 jours pour tester l’appareil et le retourner s’il ne vous convient pas, à condition qu’il soit dans son état d’origine.\nLa garantie de 12 mois couvre les pannes techniques, hors casse, dégâts d’eau ou mauvais usage.\nPour un retour, contactez-nous sur WhatsApp avec votre numéro de commande."]
  ].map(([slug, ar, fr, bodyAr, bodyFr]) => ({
    slug, title: ctx.name(ar, fr), body: ctx.txt(bodyAr, bodyFr), visible: true, seoTitle: ctx.name(ar, fr)
  }));

  const DEFAULT_FAQS = [
    { id: "faq-1", q: ctx.txt("هل الأجهزة جديدة أم مستعملة؟", "Les appareils sont-ils neufs ou d’occasion ?"), a: ctx.txt("الأجهزة مجددة: مستعملة، لكنها مفحوصة ومصلحة ومعاد تأهيلها لتكون جاهزة للاستخدام.", "Les appareils sont reconditionnés : d’occasion, mais contrôlés, réparés et remis en état pour être prêts à l’emploi.") },
    { id: "faq-2", q: ctx.txt("ما مدة الضمان؟", "Quelle est la durée de la garantie ?"), a: ctx.txt("كل جهاز يأتي بضمان 12 شهرًا يغطي الأعطال التقنية غير الناتجة عن سوء الاستخدام.", "Chaque appareil bénéficie de 12 mois de garantie couvrant les pannes techniques hors mauvais usage.") },
    { id: "faq-3", q: ctx.txt("هل يمكنني الإرجاع؟", "Puis-je retourner l’appareil ?"), a: ctx.txt("نعم، لديك 10 أيام لإرجاع الجهاز في حالته الأصلية إذا لم يعجبك.", "Oui, vous avez 10 jours pour retourner l’appareil dans son état d’origine s’il ne vous convient pas.") },
    { id: "faq-4", q: ctx.txt("هل التوصيل مجاني؟", "La livraison est-elle gratuite ?"), a: ctx.txt("التوصيل مجاني داخل نواكشوط. المدن الأخرى لها رسوم تظهر عند إتمام الطلب.", "La livraison est gratuite à Nouakchott. Les autres villes ont des frais affichés lors de la commande.") },
    { id: "faq-5", q: ctx.txt("كيف أدفع؟", "Comment payer ?"), a: ctx.txt("يمكنك الدفع عبر بنكيلي، مصرفي، سداد، كليك أو نقدًا عند الاستلام. الدفع عبر بنكيلي يمنحك خصمًا 10%.", "Vous pouvez payer via Bankily, Masrvi, Sedad, Click ou en espèces à la livraison. Le paiement Bankily offre 10 % de réduction.") },
    { id: "faq-6", q: ctx.txt("هل البطارية أصلية؟", "La batterie est-elle d’origine ?"), a: ctx.txt("نفحص صحة البطارية ونعرض النسبة على صفحة المنتج. البطاريات المستبدلة تكون معتمدة ومضمونة.", "Nous contrôlons la santé de la batterie et affichons le pourcentage sur la fiche produit. Les batteries remplacées sont certifiées et garanties.") }
  ];

  const DEFAULT_HOME_REVIEWS = [
    { id: "r1", name: "أحمد ولد محمد", city: { ar: B.city?.ar || "نواكشوط", fr: B.city?.fr || "Nouakchott" }, rating: 5, title: ctx.txt("جهاز نظيف وخدمة سريعة", "Appareil impeccable et service rapide"), body: ctx.txt("وصلني الآيفون في حالة ممتازة، البطارية 96% والدفع عبر بنكيلي كان سهلًا.", "J’ai reçu l’iPhone en excellent état, batterie à 96 %, et le paiement Bankily était simple."), color: "#2e7d6f" },
    { id: "r2", name: "مريم بنت أحمد", city: { ar: B.city?.ar || "نواكشوط", fr: B.city?.fr || "Nouakchott" }, rating: 5, title: ctx.txt("أفضل تجربة شراء", "Ma meilleure expérience d’achat"), body: ctx.txt("طلبت ماك بوك للدراسة، وصل بسرعة ومع macOS مثبت. أنصح به بشدة.", "J’ai commandé un MacBook pour mes études, livré rapidement avec macOS installé. Je recommande."), color: "#6c5ce7" },
    { id: "r3", name: "الشيخ ولد سيدي", city: ctx.txt("نواذيبو", "Nouadhibou"), rating: 4, title: ctx.txt("قيمة ممتازة", "Excellent rapport qualité-prix"), body: ctx.txt("اللابتوب يعمل بشكل جيد جدًا، والتوصيل إلى نواذيبو أخذ يومين.", "Le laptop fonctionne très bien, la livraison à Nouadhibou a pris deux jours."), color: "#b06ab3" },
    { id: "r4", name: "فاطمة بنت عبد الله", city: ctx.txt("كيفة", "Kiffa"), rating: 5, title: ctx.txt("ثقة وشفافية", "Confiance et transparence"), body: ctx.txt("أعجبني أنهم يظهرون نسبة البطارية والحالة قبل الشراء. الجهاز مطابق للوصف.", "J’aime qu’ils affichent la santé de la batterie et l’état avant l’achat. L’appareil correspond à la description."), color: "#e17055" },
    { id: "r5", name: "محمد الأمين", city: { ar: B.city?.ar || "نواكشوط", fr: B.city?.fr || "Nouakchott" }, rating: 5, title: ctx.txt("خدمة واتساب رائعة", "Service WhatsApp au top"), body: ctx.txt("أجابوني على كل الأسئلة عبر واتساب وأرسلوا لي صورًا إضافية للجهاز.", "Ils ont répondu à toutes mes questions sur WhatsApp et m’ont envoyé des photos supplémentaires."), color: "#1e6fd9" },
    { id: "r6", name: "عائشة بنت بابا", city: ctx.txt("روصو", "Rosso"), rating: 4, title: ctx.txt("سأشتري مرة أخرى", "Je rachèterai"), body: ctx.txt("الساعة وصلت بحالة جيدة، فقط التغليف كان بسيطًا. الخدمة تستحق التجربة.", "La montre est arrivée en bon état, l’emballage était simple. Le service mérite le détour."), color: "#2d3436" },
    { id: "r7", name: "سيدي محمد", city: ctx.txt("أطار", "Atar"), rating: 5, title: ctx.txt("جهاز موثوق", "Appareil fiable"), body: ctx.txt("حاسوب Dell مجدد يعمل بسرعة، والضمان أعطاني راحة البال.", "Le Dell reconditionné est rapide, et la garantie me rassure."), color: "#00b894" },
    { id: "r8", name: "خديجة بنت المختار", city: { ar: B.city?.ar || "نواكشوط", fr: B.city?.fr || "Nouakchott" }, rating: 5, title: ctx.txt("أنصح الجميع", "Je recommande à tous"), body: ctx.txt("اشتريت جهازين للعائلة، كلاهما ممتاز والسعر أفضل من الجديد.", "J’ai acheté deux appareils pour la famille, tous deux excellents et bien moins chers que le neuf."), color: "#d63031" }
  ];

  const DEFAULT_PRESS = [
    { id: "p1", outlet: ctx.txt("تِك صحارى", "Tech Sahara"), quote: bt("{brand} يعيد تعريف سوق الإلكترونيات المجددة في موريتانيا بأسعار شفافة وضمان حقيقي.", "{brand} redéfinit le marché du reconditionné en Mauritanie avec des prix transparents et une vraie garantie.") },
    { id: "p2", outlet: ctx.txt("نواكشوط بيزنس", "Nouakchott Business"), quote: ctx.txt("منصة محلية تربط المستهلك بأجهزة موثوقة وتقلل النفايات الإلكترونية.", "Une plateforme locale qui connecte les consommateurs à des appareils fiables et réduit les déchets électroniques.") },
    { id: "p3", outlet: ctx.txt("الرؤية", "La Vision"), quote: ctx.txt("تجربة شراء رقمية بالعربية والفرنسية مع دفع محلي وتوصيل لكل الولايات.", "Une expérience d’achat numérique en arabe et en français, avec paiement local et livraison dans toutes les wilayas.") }
  ];

  const DEFAULT_BLOG = [
    { id: "b1", slug: "choisir-telephone-reconditionne", title: ctx.txt("كيف تختار هاتفًا مجددًا دون أن تقع في الفخ؟", "Comment choisir un téléphone reconditionné sans se tromper ?"), excerpt: ctx.txt("خمسة معايير مهمة قبل الشراء: البطارية، الحالة، الضمان، المصدر، وسياسة الإرجاع.", "Cinq critères essentiels : batterie, état, garantie, provenance et politique de retour."), body: ctx.txt("ابدأ دائمًا بصحة البطارية. نسبة 85% فما فوق جيدة للاستخدام اليومي.\nتأكد من وجود ضمان مكتوب وسياسة إرجاع واضحة.\nاسأل عن الحالة الفعلية للجهاز واطلب صورًا حقيقية.\nقارن السعر بالسوق ولا تنسَ تكلفة الشحن.", "Commencez toujours par la santé de la batterie. Au-dessus de 85 %, elle convient à un usage quotidien.\nExigez une garantie écrite et une politique de retour claire.\nDemandez l’état réel de l’appareil et des photos authentiques.\nComparez le prix au marché et pensez aux frais de livraison."), image: "assets/img/category-iphone.png", date: "2026-09-12", published: true },
    { id: "b2", slug: "macbook-ou-pc-portable", title: ctx.txt("ماك بوك أم حاسوب ويندوز؟ دليل مبسط", "MacBook ou PC portable ? Le guide simple"), excerpt: ctx.txt("أيهما يناسب الدراسة والعمل والبرامج التي تحتاجها؟", "Lequel convient aux études, au travail et à vos logiciels ?"), body: ctx.txt("اختر MacBook إذا كنت تعمل على التصميم أو المونتاج أو تريد عمر بطارية طويل.\nاختر حاسوب ويندوز إذا كنت تحتاج برامج هندسية أو محاسبية خاصة أو ميزانية أقل.\nفي الحالتين، تحقق من صحة البطارية والمنافذ ولوحة المفاتيح.", "Choisissez un MacBook pour le design, le montage ou une longue autonomie.\nChoisissez un PC Windows pour certains logiciels d’ingénierie, de comptabilité ou un budget plus serré.\nDans les deux cas, vérifiez la batterie, les ports et le clavier."), image: "assets/img/category-macbooks.png", date: "2026-08-28", published: true },
    { id: "b3", slug: "entretenir-batterie", title: ctx.txt("سبع عادات تطيل عمر بطارية هاتفك", "Sept habitudes qui prolongent la batterie de votre téléphone"), excerpt: ctx.txt("نصائح عملية لشحن أذكى واستخدام أطول.", "Des conseils concrets pour charger plus intelligemment."), body: ctx.txt("حافظ على الشحن بين 20% و80% عندما يكون ذلك ممكنًا.\nتجنب الحرارة العالية أثناء الشحن.\nاستخدم شاحنًا أصليًا أو معتمدًا.\nلا تترك الهاتف مشحونًا 100% طوال الليل.", "Gardez la charge entre 20 % et 80 % lorsque c’est possible.\nÉvitez la chaleur pendant la charge.\nUtilisez un chargeur d’origine ou certifié.\nNe laissez pas le téléphone à 100 % toute la nuit."), image: "assets/img/category-chargers.png", date: "2026-07-19", published: true }
  ];

  const DEFAULT_NAV = [
    { id: "anniversary", label: bt("{brand} أنيفرساري", "Anniversaire {brand}"), href: "collection.html?handle=restore-anniversary", flame: true, visible: true },
    { id: "iphones", label: ctx.txt("آيفون", "iPhones"), href: "collection.html?handle=refurbished-iphones", visible: true, sub: [
      { label: ctx.txt("سلسلة iPhone 16", "iPhone 16"), href: "collection.html?q=iPhone%2016" },
      { label: ctx.txt("سلسلة iPhone 15", "iPhone 15"), href: "collection.html?q=iPhone%2015" },
      { label: ctx.txt("سلسلة iPhone 14", "iPhone 14"), href: "collection.html?q=iPhone%2014" },
      { label: ctx.txt("سلسلة iPhone 13", "iPhone 13"), href: "collection.html?q=iPhone%2013" },
      { label: ctx.txt("سلسلة iPhone 12", "iPhone 12"), href: "collection.html?q=iPhone%2012" },
      { label: ctx.txt("سلسلة iPhone 11", "iPhone 11"), href: "collection.html?q=iPhone%2011" }
    ] },
    { id: "samsung", label: ctx.txt("سامسونج", "Samsung"), href: "collection.html?handle=used-samsung", visible: true, sub: [
      { label: ctx.txt("سلسلة Galaxy S24", "Galaxy S24"), href: "collection.html?q=S24" },
      { label: ctx.txt("سلسلة Galaxy S23", "Galaxy S23"), href: "collection.html?q=S23" },
      { label: ctx.txt("سلسلة Galaxy S22", "Galaxy S22"), href: "collection.html?q=S22" },
      { label: ctx.txt("سلسلة Galaxy S21", "Galaxy S21"), href: "collection.html?q=S21" },
      { label: ctx.txt("سلسلة Galaxy S20", "Galaxy S20"), href: "collection.html?q=S20" },
      { label: ctx.txt("سلسلة Galaxy Z", "Galaxy Z"), href: "collection.html?q=Z%20Fold" },
      { label: ctx.txt("سلسلة Galaxy Note", "Galaxy Note"), href: "collection.html?q=Note" }
    ] },
    { id: "macbooks", label: ctx.txt("ماك بوك", "MacBooks"), href: "collection.html?handle=refurbished-macbooks", visible: true, sub: [
      { label: ctx.txt("MacBook Pro", "MacBook Pro"), href: "collection.html?q=MacBook%20Pro" },
      { label: ctx.txt("MacBook Air", "MacBook Air"), href: "collection.html?q=MacBook%20Air" },
      { label: ctx.txt("iMac", "iMac"), href: "collection.html?q=iMac" }
    ] },
    { id: "laptops", label: ctx.txt("حواسيب محمولة", "Laptops"), href: "collection.html?handle=laptops-used-refurbished", visible: true, sub: [
      { label: "Lenovo", href: "collection.html?q=Lenovo" },
      { label: "Dell", href: "collection.html?q=Dell" },
      { label: "HP", href: "collection.html?q=HP" },
      { label: "Acer", href: "collection.html?q=Acer" }
    ] },
    { id: "ipads", label: ctx.txt("آيباد", "iPads"), href: "collection.html?handle=ipads", visible: true },
    { id: "accessories", label: ctx.txt("ملحقات وصوتيات", "Accessoires et audio"), href: "collection.html?handle=audio", visible: true, sub: [
      { label: ctx.txt("صوتيات", "Audio"), href: "collection.html?handle=audio" },
      { label: ctx.txt("شواحن وكابلات", "Chargeurs et câbles"), href: "collection.html?handle=chargers-power-banks-cables" },
      { label: ctx.txt("ألعاب", "Gaming"), href: "collection.html?handle=gaming" },
      { label: ctx.txt("ملحقات", "Accessoires"), href: "collection.html?handle=cases-screen-protectors" }
    ] },
    { id: "watches", label: ctx.txt("ساعة آبل", "Apple Watch"), href: "collection.html?handle=apple-watches", visible: true },
    { id: "business", label: ctx.txt("للشركات", "Entreprises"), href: "page.html?slug=for-businesses", visible: true },
    { id: "help", label: ctx.txt("تحتاج مساعدة؟", "Besoin d’aide ?"), href: "page.html?slug=help", visible: true },
    { id: "seller", label: ctx.txt("كن بائعًا", "Devenir vendeur"), href: "page.html?slug=become-a-seller", visible: true }
  ];

  const COLLECTION_TITLES = {
    "restore-anniversary": bt("{brand} أنيفرساري", "Anniversaire {brand}"),
    "refurbished-iphones": ctx.txt("آيفون مجدد معتمد", "iPhone reconditionnés certifiés"),
    "used-samsung": ctx.txt("سامسونج مجدد معتمد", "Samsung reconditionnés certifiés"),
    "laptops-used-refurbished": ctx.txt("حواسيب محمولة مجددة", "Ordinateurs portables reconditionnés"),
    "refurbished-macbooks": ctx.txt("ماك بوك مجدد", "MacBook reconditionnés"),
    "ipads": ctx.txt("آيباد مجدد", "iPad reconditionnés"),
    "apple-watches": ctx.txt("ساعات آبل", "Montres Apple"),
    "audio": ctx.txt("صوتيات", "Audio"),
    "chargers-power-banks-cables": ctx.txt("شواحن وبطاريات وكابلات", "Chargeurs, batteries et câbles"),
    "gaming": ctx.txt("ألعاب", "Gaming"),
    "cases-screen-protectors": ctx.txt("محافظ وواقيات شاشة", "Coques et protections d’écran")
  };

  const DEFAULT_CATEGORIES = [
    { label: bt("{brand} أنيفرساري", "{brand} Anniversary"), handle: "restore-anniversary", image: "assets/img/category-anniversary.webp" },
    { label: ctx.txt("آيفون", "iPhone"), handle: "refurbished-iphones", image: "assets/img/category-iphone.png" },
    { label: ctx.txt("سامسونج", "Samsung"), handle: "used-samsung", image: "assets/img/category-samsung.png" },
    { label: ctx.txt("ماك بوك", "MacBooks"), handle: "refurbished-macbooks", image: "assets/img/category-macbooks.png" },
    { label: ctx.txt("حواسيب محمولة", "Laptops"), handle: "laptops-used-refurbished", image: "assets/img/category-laptops.png" },
    { label: ctx.txt("آيباد", "iPads"), handle: "ipads", image: "assets/img/category-ipads.png" },
    { label: ctx.txt("ساعات آبل", "Apple Watches"), handle: "apple-watches", image: "assets/img/category-watches.png" },
    { label: ctx.txt("صوتيات", "Audio"), handle: "audio", image: "assets/img/category-audio.png" },
    { label: ctx.txt("شواحن وكابلات", "Chargeurs et câbles"), handle: "chargers-power-banks-cables", image: "assets/img/category-chargers.png" },
    { label: ctx.txt("ألعاب", "Gaming"), handle: "gaming", image: "assets/img/category-gaming.png" },
    { label: ctx.txt("ملحقات", "Accessoires"), handle: "cases-screen-protectors", image: "assets/img/category-accessories.png" }
  ];

  const DEFAULT_PAYMENTS = [
    { id: "bankily", name: ctx.txt("بنكيلي", "Bankily"), color: "#00a651", active: true, discount: 10, note: ctx.txt("خصم 10% عند الدفع عبر بنكيلي", "10 % de réduction avec Bankily") },
    { id: "masrvi", name: ctx.txt("مصرفي", "Masrvi"), color: "#0b6fb8", active: true, discount: 0, note: ctx.txt("تحويل فوري عبر مصرفي", "Paiement instantané via Masrvi") },
    { id: "sedad", name: ctx.txt("سداد", "Sedad"), color: "#6f42c1", active: true, discount: 0, note: ctx.txt("الدفع عبر تطبيق سداد", "Paiement avec l’application Sedad") },
    { id: "click", name: ctx.txt("كليك", "Click"), color: "#e67e22", active: true, discount: 0, note: ctx.txt("الدفع عبر كليك", "Paiement avec Click") },
    { id: "cod", name: ctx.txt("الدفع عند الاستلام", "Paiement à la livraison"), color: "#2d3436", active: true, discount: 0, note: ctx.txt("ادفع نقدًا عند استلام طلبك", "Payez en espèces à la réception") }
  ]
  const DEFAULT_CITIES = [
    { id: "nouakchott", name: ctx.txt("نواكشوط", "Nouakchott"), fee: 0, days: ctx.txt("1–2 أيام", "1–2 jours"), active: true },
    { id: "nouadhibou", name: ctx.txt("نواذيبو", "Nouadhibou"), fee: 500, days: ctx.txt("2–3 أيام", "2–3 jours"), active: true },
    { id: "rosso", name: ctx.txt("روصو", "Rosso"), fee: 600, days: ctx.txt("2–3 أيام", "2–3 jours"), active: true },
    { id: "kiffa", name: ctx.txt("كيفة", "Kiffa"), fee: 800, days: ctx.txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "kaedi", name: ctx.txt("كيهيدي", "Kaédi"), fee: 700, days: ctx.txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "atar", name: ctx.txt("أطار", "Atar"), fee: 900, days: ctx.txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "zouerat", name: ctx.txt("الزويرات", "Zouérat"), fee: 1200, days: ctx.txt("4–6 أيام", "4–6 jours"), active: true },
    { id: "nema", name: ctx.txt("النعمة", "Néma"), fee: 1200, days: ctx.txt("4–7 أيام", "4–7 jours"), active: true },
    { id: "tidjikja", name: ctx.txt("تجكجة", "Tidjikja"), fee: 1000, days: ctx.txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "selibaby", name: ctx.txt("سيليبابي", "Sélibaby"), fee: 900, days: ctx.txt("4–6 أيام", "4–6 jours"), active: true },
    { id: "aleg", name: ctx.txt("ألاك", "Aleg"), fee: 700, days: ctx.txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "boutilimit", name: ctx.txt("بوتلميت", "Boutilimit"), fee: 500, days: ctx.txt("2–4 أيام", "2–4 jours"), active: true }
  ];

  const DEFAULT_ORDER_TEMPLATE = {
    ar: "مرحباً {store} 👋\nأريد تأكيد هذا الطلب:\n\nرقم الطلب: {order_id}\nالاسم: {name}\nالهاتف: {phone}\nالمدينة: {city}\nالعنوان: {address}\nطريقة الدفع: {payment}\n\nالمنتجات:\n{items}\n\nالمجموع الفرعي: {subtotal}\nالشحن: {shipping}\nالخصم: {discount}\nالإجمالي: {total}\n\nملاحظات: {notes}",
    fr: "Bonjour {store} 👋\nJe souhaite confirmer cette commande :\n\nN° de commande : {order_id}\nNom : {name}\nTéléphone : {phone}\nVille : {city}\nAdresse : {address}\nPaiement : {payment}\n\nProduits :\n{items}\n\nSous-total : {subtotal}\nLivraison : {shipping}\nRéduction : {discount}\nTotal : {total}\n\nNotes : {notes}"
  };

  const DEFAULT_WHATSAPP_TEMPLATES = {
    confirm: {
      ar: "مرحباً {name}، تم تأكيد طلبك {order_id} من {store}. سنبدأ تجهيزه ونخبرك عند الشحن. شكراً لثقتك!",
      fr: "Bonjour {name}, votre commande {order_id} chez {store} est confirmée. Nous préparons votre colis et vous informerons dès l’expédition. Merci !"
    },
    shipped: {
      ar: "مرحباً {name}، طلبك {order_id} تم شحنه وهو في الطريق إليك. سنوافيك برقم التتبع قريباً.",
      fr: "Bonjour {name}, votre commande {order_id} a été expédiée et est en route. Nous vous enverrons le numéro de suivi très bientôt."
    },
    delivered: {
      ar: "مرحباً {name}، نأمل أن تكون راضياً عن طلبك {order_id}. إذا احتجت أي مساعدة أو ضمان، راسلنا هنا.",
      fr: "Bonjour {name}, nous espérons que votre commande {order_id} vous satisfait. Pour toute aide ou garantie, écrivez-nous ici."
    }
  };

  function productDescriptions(type) {
    return TYPE_DESCRIPTIONS[type] || bt(
      "جهاز مجدد تم فحصه واختباره من طرف خبراء {brand}، ويأتي بضمان 12 شهرًا.",
      "Appareil reconditionné, inspecté et testé par les experts {brand}, avec 12 mois de garantie."
    );
  }

  function hashHandle(handle) {
    let h = 0;
    for (let i = 0; i < handle.length; i++) h = (h * 31 + handle.charCodeAt(i)) >>> 0;
    return h;
  }

  function includesFor(p) {
    const map = {
      Macbook: [ctx.txt("جهاز MacBook", "MacBook"), ctx.txt("شاحن أصلي", "Chargeur d’origine"), ctx.txt("كابل USB-C", "Câble USB-C")],
      Laptop: [ctx.txt("الحاسوب المحمول", "Ordinateur portable"), ctx.txt("الشاحن", "Chargeur"), ctx.txt("كابل الطاقة", "Câble d’alimentation")],
      Smartphone: [ctx.txt("الهاتف", "Téléphone"), ctx.txt("كابل الشحن", "Câble de charge"), ctx.txt("أداة إخراج الشريحة", "Outil SIM")],
      Tablets: [ctx.txt("الجهاز اللوحي", "Tablette"), ctx.txt("كابل الشحن", "Câble de charge"), ctx.txt("الشاحن", "Chargeur")],
      "Apple Watch": [ctx.txt("الساعة", "Montre"), ctx.txt("السوار", "Bracelet"), ctx.txt("شاحن مغناطيسي", "Chargeur magnétique")],
      Playstation: [ctx.txt("الجهاز", "Console"), ctx.txt("يد التحكم", "Manette"), ctx.txt("كابلات التوصيل", "Câbles de connexion")],
      Accessories: [ctx.txt("الملحق", "Accessoire"), ctx.txt("دليل الاستخدام", "Guide d’utilisation")]
    };
    return map[p.type] || [ctx.txt("الجهاز", "Appareil"), ctx.txt("الكابل", "Câble")];
  }

  function specsFor(p, battery) {
    const title = p.title || "";
    const cpuOpt = p.options?.find((o) => /cpu/i.test(o.name));
    const ramOpt = p.options?.find((o) => /ram/i.test(o.name));
    const storageOpt = p.options?.find((o) => /storage/i.test(o.name));
    const isMac = p.type === "Macbook";
    const isLaptop = p.type === "Laptop" || isMac;
    const isPhone = p.type === "Smartphone";
    const cpuFromTitle = title.match(/(Core i[3579][^,/(-]*|M[1234](?: Pro| Max)?|Ryzen [3579][^,/(-]*)/i)?.[0];
    const cpu = cpuOpt?.values?.[0] || cpuFromTitle || (isMac ? "Apple Silicon" : isLaptop ? "Intel Core i5" : isPhone ? "SoC" : "—");
    const ram = ramOpt?.values?.[0] || (isLaptop ? (isMac ? "8 GB" : "8 GB") : isPhone ? "6 GB" : "—");
    const storage = storageOpt?.values?.[0] || (isPhone ? "128 GB" : isLaptop ? "256 GB SSD" : "—");
    const screen = isMac ? '13.3"' : isLaptop ? '14"' : isPhone ? '6.1"' : p.type === "Tablets" ? '10.2"' : p.type === "Apple Watch" ? "45 mm" : "—";
    const keyboard = isLaptop ? ctx.txt("فرنسي AZERTY", "Français AZERTY") : null;
    const condition = p.options?.find((o) => /condition|état/i.test(o.name))?.values?.[0] || "Excellent";
    return {
      cpu: { label: ctx.txt("المعالج", "Processeur"), value: cpu, choices: isLaptop ? [cpu, "Intel Core i7", "Intel Core i5", "Apple M1", "Apple M2"] : [] },
      ram: { label: ctx.txt("الذاكرة", "Mémoire RAM"), value: ram, choices: isLaptop ? [ram, "8 GB", "16 GB", "32 GB"] : [] },
      storage: { label: ctx.txt("التخزين", "Stockage"), value: storage, choices: [] },
      screen: { label: ctx.txt("حجم الشاشة", "Taille d’écran"), value: screen, choices: isLaptop ? [screen, '13.3"', '14"', '15.6"', '16"'] : isPhone ? ['5.8"', '6.1"', '6.7"'] : [] },
      keyboard: { label: ctx.txt("لوحة المفاتيح", "Clavier"), value: keyboard, choices: isLaptop ? ["Français AZERTY", "QWERTY (US)", "Arabe / Anglais"] : [] },
      condition: { label: ctx.txt("الحالة", "État"), value: condition, choices: [] },
      battery: { label: ctx.txt("صحة البطارية", "Santé de la batterie"), value: `${battery}%`, choices: [] }
    };
  }

  function priceProduct(p) {
    const price = ctx.roundMRU(p.price);
    const compare = ctx.roundMRU(p.compare);
    return {
      ...p,
      price,
      compare: compare > price ? compare : 0,
      discount: compare > price ? Math.round((1 - price / compare) * 100) : 0
    };
  }

  function buildProducts() {
    return ctx.RAW.products.map((raw, index) => {
      const seed = hashHandle(raw.handle);
      const p = priceProduct(raw);
      const stock = 2 + (seed % 17);
      const batteryBase = 84 + (seed % 16);
      const battery = p.type === "Smartphone" ? Math.min(100, batteryBase) : null;
      const condition = p.options?.find((o) => /condition|état/i.test(o.name))?.values?.[0] || (p.compare ? "Excellent" : "Good");
      const colorRemote = {};
      for (const v of raw.variants || []) {
        const alt = v.image?.alt;
        if (alt && v.image?.src) colorRemote[alt] = v.image.src;
      }
      const colors = p.colors || [];
      const colorImages = {};
      colors.forEach((c, i) => {
        colorImages[c.name] = p.images?.length
          ? p.images[Math.min(i, p.images.length - 1)]
          : p.image;
      });
      const variants = (raw.variants || []).map((v) => ({
        id: v.id,
        title: v.title,
        o1: v.o1,
        o2: v.o2,
        o3: v.o3,
        price: ctx.roundMRU(v.price ?? raw.price),
        compare: ctx.roundMRU(v.compare ?? raw.compare),
        available: v.available !== false,
        battery: battery ?? 0
      }));
      return {
        ...p,
        variants,
        price: ctx.roundMRU(raw.price),
        compare: ctx.roundMRU(raw.compare) > ctx.roundMRU(raw.price) ? ctx.roundMRU(raw.compare) : 0,
        discount: ctx.roundMRU(raw.compare) > ctx.roundMRU(raw.price) ? Math.round((1 - ctx.roundMRU(raw.price) / ctx.roundMRU(raw.compare)) * 100) : 0,
        stock,
        active: true,
        battery,
        condition,
        description: productDescriptions(p.type),
        includes: includesFor(p),
        specs: specsFor(p, battery || 92),
        colorImages,
        colorRemote,
        sku: `RS-${String(index + 1).padStart(4, "0")}`,
        warrantyMonths: 12,
        lowStock: stock <= 2
      };
    });
  }

  function buildState() {
    const products = buildProducts();
    products.forEach((p) => {
    });
    const collections = ctx.RAW.collections.map((c) => ({
      handle: c.handle,
      title: COLLECTION_TITLES[c.handle] || ctx.txt(c.title, c.title),
      visible: true
    }));
    const home = {
      anniversary: ctx.RAW.home.anniversary,
      iphones: ctx.RAW.home.iphones,
      samsung: ctx.RAW.home.samsung,
      laptops: ctx.RAW.home.laptops
    };
    return {
      version: 1,
      updatedAt: ctx.nowISO(),
      settings: {
        storeName: { ar: BN.ar, fr: BN.fr },
        legalName: { ar: B.legalName?.ar || BN.ar, fr: B.legalName?.fr || BN.fr },
        tagline: { ar: B.tagline?.ar || "", fr: B.tagline?.fr || "" },
        logo: B.logo || "assets/img/brand-logo.svg",
        logoWhite: B.logoWhite || "assets/img/brand-logo-white.svg",
        favicon: B.favicon || "assets/img/favicon.svg",
        colors: Object.assign({ primary: "#2563eb", ink: "#0f172a", purple: "#7c3aed", lavender: "#eef2ff" }, B.colors || {}),
        font: B.font || "Montserrat",
        radius: 10,
        country: {
          code: B.country?.code || "MR",
          name: { ar: B.country?.name?.ar || "موريتانيا", fr: B.country?.name?.fr || "Mauritanie" },
          flag: B.country?.flag || "assets/img/flag-mr.svg",
          dial: B.country?.dial || "+222",
          currencyCode: B.country?.currencyCode || "MRU",
          currency: { ar: B.country?.currency?.ar || "أوقية", fr: B.country?.currency?.fr || "MRU" },
          currencyName: { ar: B.country?.currencyName?.ar || "أوقية جديدة", fr: B.country?.currencyName?.fr || "Nouvelle ouguiya" },
          currencyMode: "new"
        },
        city: { ar: B.city?.ar || "نواكشوط", fr: B.city?.fr || "Nouakchott" },
        address: { ar: B.address?.ar || "", fr: B.address?.fr || "" },
        timezone: B.timezone || "Africa/Nouakchott",
        phone: B.phone || "",
        phoneDisplay: B.phoneDisplay || B.phone || "",
        whatsapp: B.whatsapp || "",
        email: B.email || "",
        hours: { open: "00:00", close: "23:59", days: [0, 1, 2, 3, 4, 5, 6], closed: false, maintenance: false },
        announcement: ctx.txt("توصيل مجاني داخل نواكشوط • خصم 10% عند الدفع عبر بنكيلي", "Livraison gratuite à Nouakchott • -10 % avec Bankily"),
        renewalText: bt("ما معنى مجدد من {brand}؟", "Que signifie reconditionné chez {brand} ?"),
        categoriesTitle: ctx.txt("تسوق الإلكترونيات المجددة", "Électronique reconditionnée"),
        serviceTitle: ctx.txt("كل أجهزتنا أصلية ومفحوصة من طرف خبراء", "Tous nos appareils sont originaux et vérifiés par des experts"),
        serviceItems: [
          { icon: "smile", title: ctx.txt("بدون مخاطرة", "Sans risque"), text: ctx.txt("10 أيام لإرجاع الجهاز عند وجود أي مشكلة", "10 jours pour retourner l’appareil en cas de problème") },
          { icon: "badgeCheck", title: ctx.txt("فحص جهازًا بجهاز", "Vérifié un par un"), text: ctx.txt("50 نقطة فحص تشمل الشاشة، البطارية، السرعة والمتانة", "50 points de contrôle : écran, batterie, vitesse et durabilité") },
          { icon: "star", title: ctx.txt("أفضل الموردين فقط", "Seulement les meilleurs"), text: ctx.txt("نقبل موردًا واحدًا من كل أربعة بعد فحص صارم", "Nous acceptons un fournisseur sur quatre après un contrôle strict") },
          { icon: "chat", title: ctx.txt("دائمًا معك", "Toujours là pour vous"), text: ctx.txt("خدمة عملاء تجيب على أسئلتك وتتابع طلبك", "Un service client qui répond et suit votre commande") }
        ],
        trustTitle: ctx.txt("150,000+ عميل يثقون بنا", "150 000+ clients nous font confiance"),
        communityTitle: bt("انضم إلى مجتمع {brand}", "Rejoignez la communauté {brand}"),
        reviewsTitle: ctx.txt("ماذا يقول عملاؤنا", "Ce que disent nos clients"),
        pressTitle: bt("{brand} في الأخبار", "{brand} dans la presse"),
        trustBar: [
          { icon: "truck", label: ctx.txt("توصيل مجاني داخل نواكشوط", "Livraison gratuite à Nouakchott") },
          { icon: "shield", label: ctx.txt("ضمان 12 شهرًا", "Garantie 12 mois") },
          { icon: "return", label: ctx.txt("إرجاع خلال 10 أيام", "Retour sous 10 jours") },
          { icon: "badgeCheck", label: ctx.txt("فحص بواسطة خبراء", "Vérifié par des experts") }
        ],
        paymentOffer: ctx.txt("اشترِ عبر بنكيلي واحصل على خصم 10%", "Payez avec Bankily et obtenez 10 % de réduction"),
        paymentOfferCode: "BANKILY10",
        shippingNote: ctx.txt("رسوم الشحن تُحسب حسب المدينة عند إتمام الطلب.", "Les frais de livraison sont calculés selon la ville lors de la commande."),
        freeShippingOver: 20000,
        cities: DEFAULT_CITIES,
        payments: DEFAULT_PAYMENTS,
        navigation: DEFAULT_NAV,
        footerColumns: [
          { title: ctx.txt("من نحن", "À propos"), links: [
            { label: ctx.txt("من نحن", "À propos"), href: "page.html?slug=about-us" },
            { label: ctx.txt("تسوق الآن", "Boutique"), href: "collection.html?handle=all" },
            { label: ctx.txt("مدونتنا", "Notre blog"), href: "blog.html" },
            { label: ctx.txt("كن بائعًا", "Devenir vendeur"), href: "page.html?slug=become-a-seller" }
          ] },
          { title: ctx.txt("معلومات", "Informations"), links: [
            { label: ctx.txt("مركز المساعدة", "Centre d’aide"), href: "page.html?slug=help" },
            { label: ctx.txt("اتصل بنا", "Contact"), href: "page.html?slug=contact" },
            { label: ctx.txt("الشروط والأحكام", "Conditions générales"), href: "page.html?slug=terms" },
            { label: ctx.txt("سياسة الخصوصية", "Confidentialité"), href: "page.html?slug=privacy" }
          ] },
          { title: ctx.txt("حسابي", "Mon compte"), links: [
            { label: ctx.txt("حسابي", "Mon compte"), href: "account.html" },
            { label: ctx.txt("تتبع الطلب", "Suivre ma commande"), href: "page.html?slug=track-order" },
            { label: ctx.txt("طلب ضمان", "Demande de garantie"), href: "page.html?slug=raise-claim" },
            { label: ctx.txt("متابعة الضمان", "Suivi de garantie"), href: "page.html?slug=track-claim" }
          ] }
        ],
        social: [
          { id: "facebook", href: "https://www.facebook.com/", icon: "facebook" },
          { id: "instagram", href: "https://www.instagram.com/", icon: "instagram" },
          { id: "tiktok", href: "https://www.tiktok.com/", icon: "tiktok" }
        ],
        homeSections: [
          { id: "anniversary", visible: true, order: 1, title: bt("{brand} أنيفرساري", "{brand} Anniversary"), collection: "restore-anniversary", handles: home.anniversary, layout: "plain", promo: "", flame: true },
          { id: "iphones", visible: true, order: 2, title: ctx.txt("آيفون مجدد معتمد", "iPhones reconditionnés certifiés"), collection: "refurbished-iphones", handles: home.iphones, layout: "left", promo: "assets/img/restore/promo-iphone.svg", flame: false },
          { id: "samsung", visible: true, order: 3, title: ctx.txt("سامسونج مجدد معتمد", "Samsung reconditionné certifié"), collection: "used-samsung", handles: home.samsung, layout: "right", promo: "assets/img/restore/promo-samsung.svg", flame: false },
          { id: "laptops", visible: true, order: 4, title: ctx.txt("حواسيب محمولة مجددة", "Ordinateurs portables reconditionnés"), collection: "laptops-used-refurbished", handles: home.laptops, layout: "left", promo: "assets/img/restore/promo-laptops.svg", flame: false }
        ],
        pageSections: [
          { id: "hero", visible: true, order: 1 },
          { id: "trust", visible: true, order: 2 },
          { id: "renewed", visible: true, order: 3 },
          { id: "categories", visible: true, order: 4 },
          { id: "offer", visible: true, order: 5 },
          { id: "products", visible: true, order: 6 },
          { id: "sustain", visible: true, order: 7 },
          { id: "service", visible: true, order: 8 },
          { id: "video", visible: true, order: 9 },
          { id: "reviews", visible: true, order: 10 },
          { id: "press", visible: true, order: 11 }
        ],
        heroSlides: [
          { id: "hero-1", visible: true, title: ctx.txt("تقنية مجددة، ثقة جديدة", "La tech reconditionnée, en toute confiance"), subtitle: ctx.txt("هواتف وحواسيب مفحوصة بضمان 12 شهرًا، وتوصيل لكل موريتانيا.", "Téléphones et ordinateurs contrôlés, garantis 12 mois et livrés partout en Mauritanie."), cta: ctx.txt("تسوق الآن", "Découvrir"), href: "collection.html?handle=all", image: "assets/img/hero-iphone.png", bg: "linear-gradient(135deg,#1f1f2e 0%,#39255b 55%,#ff6400 130%)" },
          { id: "hero-2", visible: true, title: ctx.txt("ماك بوك جاهز للعمل", "MacBook prêt à travailler"), subtitle: ctx.txt("macOS مثبت، بطارية مفحوصة، ولوحة مفاتيح بالعربية أو الفرنسية.", "macOS installé, batterie contrôlée et clavier arabe ou français."), cta: ctx.txt("اكتشف ماك بوك", "Voir les MacBook"), href: "collection.html?handle=refurbished-macbooks", image: "assets/img/hero-macbook.png", bg: "linear-gradient(135deg,#eef3ff 0%,#d9e5ff 45%,#f7c7ff 120%)", dark: false }
        ],
        offers: [
          { id: "bankily", active: true, title: ctx.txt("خصم 10% عند الدفع عبر بنكيلي", "10 % de réduction avec Bankily"), subtitle: ctx.txt("اختر بنكيلي عند إتمام الطلب وسيُطبّق الخصم تلقائيًا.", "Choisissez Bankily au paiement, la réduction s’applique automatiquement."), code: "BANKILY10", href: "collection.html?handle=all", startsAt: "", endsAt: new Date(Date.now() + 7 * 864e5).toISOString() }
        ],
        coupons: [
          { id: "c1", code: (B.couponPrefix || "WELCOME") + "10", type: "percent", value: 10, active: true, minTotal: 0, expiresAt: "" },
          { id: "c2", code: "NOUAKCHOTT5", type: "percent", value: 5, active: true, minTotal: 10000, expiresAt: "" }
        ],
        seo: {
          title: bt("{brand} | إلكترونيات مجددة موثوقة في موريتانيا", "{brand} | Électronique reconditionnée en Mauritanie"),
          description: ctx.txt("اشترِ هواتف وحواسيب مجددة مفحوصة في موريتانيا مع ضمان 12 شهرًا، توصيل سريع ودفع عبر بنكيلي ومصرفي وسداد.", "Achetez téléphones et ordinateurs reconditionnés en Mauritanie avec 12 mois de garantie, livraison rapide et paiement Bankily, Masrvi ou Sedad.")
        },
        pixels: { meta: "", tiktok: "", ga: "" },
        orderTemplate: DEFAULT_ORDER_TEMPLATE,
        whatsappTemplates: DEFAULT_WHATSAPP_TEMPLATES,
        otp: { enabled: false },
        blocklist: [],
        rateLimitSeconds: 60,
        lowStockThreshold: 2,
        autoHideOutOfStock: true,
        pwa: true,
        fakeData: true
      },
      products,
      collections,
      home,
      theme: { categories: DEFAULT_CATEGORIES },
      pages: DEFAULT_PAGES,
      faqs: DEFAULT_FAQS,
      homeReviews: DEFAULT_HOME_REVIEWS,
      press: DEFAULT_PRESS,
      blog: DEFAULT_BLOG,
      reviews: []
    };
  }

  function hydrate(saved) {
    const base = buildState();
    if (!saved) return base;
    const out = ctx.merge(base, saved);
    const baseProducts = new Map(base.products.map((p) => [p.handle, p]));
    out.products = (saved.products || base.products).map((p) => ctx.merge(baseProducts.get(p.handle) || {}, p));
    out.collections = (saved.collections || base.collections).map((c) => {
      const merged = ctx.merge(base.collections.find((x) => x.handle === c.handle) || {}, c);
      if (typeof merged.title === "string") merged.title = COLLECTION_TITLES[merged.handle] || ctx.txt(merged.title, merged.title);
      return merged;
    });
    out.pages = (saved.pages || base.pages).map((p) => ctx.merge(base.pages.find((x) => x.slug === p.slug) || {}, p));
    out.blog = (saved.blog || base.blog).map((b) => ctx.merge(base.blog.find((x) => x.slug === b.slug) || {}, b));
    out.settings.homeSections = (saved.settings?.homeSections || base.settings.homeSections).map((s) => ctx.merge(base.settings.homeSections.find((x) => x.id === s.id) || {}, s));
    out.settings.navigation = (saved.settings?.navigation || base.settings.navigation).map((n) => ctx.merge(base.settings.navigation.find((x) => x.id === n.id) || {}, n));
    out.settings.pageSections = (saved.settings?.pageSections || base.settings.pageSections).map((s) => ctx.merge(base.settings.pageSections.find((x) => x.id === s.id) || {}, s));
    out.products.forEach((p) => {
      if (!p.specs) p.specs = specsFor(p, p.battery || 92);
      if (!p.includes) p.includes = includesFor(p);
      if (!p.description) p.description = productDescriptions(p.type);
      if (!p.colorImages) p.colorImages = {};
      if (!p.colorRemote) p.colorRemote = {};
    });
    return out;
  }
  // I18N moved to ./i18n/ar.js, ./i18n/fr.js (single source of truth)


  const LANG_KEY = "lang";
  ctx.lang = localStorage.getItem(ctx.LS_LANG) === "fr" ? "fr" : "ar";
  ctx.theme = localStorage.getItem(ctx.LS_THEME) === "dark" ? "dark" : "light";

  function t(key, vars = {}) { return tI18n(ctx.lang, key, vars); }
  const L = (value) => LI18n(ctx.lang, value);
  function money(n) {
    return ctx.formatCurrency(n);
  }
  function formatDate(value, opts = { year: "numeric", month: "short", day: "numeric" }) {
    try { return new Intl.DateTimeFormat(ctx.lang === "ar" ? "ar-MR" : "fr-MR", opts).format(new Date(value)); }
    catch { return String(value || ""); }
  }

  function setLang(next) {
    ctx.lang = next === "fr" ? "fr" : "ar";
    localStorage.setItem(ctx.LS_LANG, ctx.lang);
    ctx.applyDocument();
    window.dispatchEvent(new CustomEvent("restore:lang", { detail: ctx.lang }));
  }
  function setTheme(next) {
    ctx.theme = next === "dark" ? "dark" : "light";
    localStorage.setItem(ctx.LS_THEME, ctx.theme);
    ctx.applyDocument();
  }
  Object.assign(ctx, { TYPE_DESCRIPTIONS, DEFAULT_PAGES, DEFAULT_FAQS, DEFAULT_HOME_REVIEWS, DEFAULT_PRESS, DEFAULT_BLOG, DEFAULT_NAV, COLLECTION_TITLES, DEFAULT_CATEGORIES, DEFAULT_PAYMENTS, DEFAULT_CITIES, DEFAULT_ORDER_TEMPLATE, DEFAULT_WHATSAPP_TEMPLATES, LANG_KEY, L });
}
