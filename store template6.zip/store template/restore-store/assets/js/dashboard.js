/* Dashboard router (thin entry) — routes to modular screens; core handles full UI. */
import { initDashboard } from "./ui/dashboard/core.js";

const route = (location.hash || "#overview").slice(1);
window.__dashRoute = route;

// Start dashboard (core wires DOM/events and uses repo-backed data for catalog entities).
initDashboard();
