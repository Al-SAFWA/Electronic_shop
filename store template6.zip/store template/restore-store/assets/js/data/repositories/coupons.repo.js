import { createClient } from "../supabase-client.js";
const T = "restore_coupons";
export function createCouponsRepo(config, getToken) {
  const client = createClient(config);
  const auth = () => (typeof getToken === "function" ? getToken() : getToken) || undefined;
  return {
    async list() { return client.request(`/rest/v1/${T}?select=*&order=code.asc`, { token: auth() }) || []; },
    async upsert(coupon) {
      const body = { ...coupon, code: String(coupon.code || "").toUpperCase().trim(), updated_at: new Date().toISOString() };
      return client.request(`/rest/v1/${T}?on_conflict=code`, { method: "POST", token: auth(), headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body });
    },
    async remove(code) {
      return client.request(`/rest/v1/${T}?code=eq.${encodeURIComponent(String(code).toUpperCase())}`, { method: "DELETE", token: auth() });
    }
  };
}
