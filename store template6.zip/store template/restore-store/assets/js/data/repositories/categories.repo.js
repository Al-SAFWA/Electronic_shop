import { createClient } from "../supabase-client.js";
export function createCategoriesRepo(config, getToken) {
  const client = createClient(config);
  const auth = () => (typeof getToken === "function" ? getToken() : getToken) || undefined;
  const req = (table, path, opts) => client.request(`/rest/v1/${table}${path}`, { token: auth(), ...opts });
  return {
    async listCategories() { return req("restore_categories", "?select=*&order=sort_order.asc,slug.asc") || []; },
    async upsertCategory(row) { return req("restore_categories", "?on_conflict=slug", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: { ...row, updated_at: new Date().toISOString() } }); },
    async removeCategory(slug) { return req("restore_categories", `?slug=eq.${encodeURIComponent(slug)}`, { method: "DELETE" }); },
    async listCollections() { return req("restore_collections", "?select=*&order=handle.asc") || []; },
    async upsertCollection(row) { return req("restore_collections", "?on_conflict=handle", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: { ...row, updated_at: new Date().toISOString() } }); },
    async removeCollection(handle) { return req("restore_collections", `?handle=eq.${encodeURIComponent(handle)}`, { method: "DELETE" }); }
  };
}
