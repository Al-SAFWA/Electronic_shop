import { createClient } from "../supabase-client.js";
const T = "restore_products";
export function createProductsRepo(config, getToken) {
  const client = createClient(config);
  const auth = () => (typeof getToken === "function" ? getToken() : getToken) || undefined;
  return {
    async list({ active, limit = 500 } = {}) {
      const q = active == null ? "" : `&active=eq.${active}`;
      return client.request(`/rest/v1/${T}?select=*,restore_product_variants(*)${q}&order=updated_at.desc&limit=${limit}`, { token: auth() }) || [];
    },
    async getByHandle(handle) {
      if (!handle) return null;
      const rows = await client.request(`/rest/v1/${T}?handle=eq.${encodeURIComponent(handle)}&select=*,restore_product_variants(*)`, { token: auth() });
      return Array.isArray(rows) ? rows[0] || null : null;
    },
    async upsert(product) {
      const body = { ...product, updated_at: new Date().toISOString() };
      return client.request(`/rest/v1/${T}?on_conflict=handle`, { method: "POST", token: auth(), headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body });
    },
    async update(handle, patch) {
      return client.request(`/rest/v1/${T}?handle=eq.${encodeURIComponent(handle)}`, { method: "PATCH", token: auth(), headers: { Prefer: "return=representation" }, body: { ...patch, updated_at: new Date().toISOString() } });
    },
    async remove(handle) {
      return client.request(`/rest/v1/${T}?handle=eq.${encodeURIComponent(handle)}`, { method: "DELETE", token: auth() });
    }
  };
}
