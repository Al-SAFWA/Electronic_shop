// legacy dashboard chunk 1
/* ==========================================================================
   Restore dashboard application
   ========================================================================== */
import { esc, sanitizeRichHTML } from "./core/dom.js";

const _initDashboard = () => {
  "use strict";

  const R = window.RESTORE;
  if (!R) return;
  const app = document.getElementById("dash-app");
  const modalRoot = document.getElementById("dash-modal-root");
  const LS_DASH_LANG = "restore_dash_lang_v1";

  const clone = (value) => R.clone(value);
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const digits = (value) => String(value ?? "").replace(/\D/g, "");
  const money = (value) => R.money(value);
  const fmtDate = (value) => R.formatDate(value);
  const fmtDateTime = (value) => R.formatDate(value, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  const nowIso = () => new Date().toISOString();

  let dashLang = localStorage.getItem(LS_DASH_LANG) === "fr" ? "fr" : "ar";
  const dt = (ar, fr) => (dashLang === "ar" ? ar : fr);
  const lng = (value) => {
    if (value == null) return "";
    if (typeof value === "string") return value;
    if (typeof value === "object") return value[dashLang] ?? value.ar ?? value.fr ?? "";
    return String(value);
  };

  let model = clone(R.draft || R.state);
  let dirty = Boolean(R.draft);
  let session = R.currentSession();
  let route = (location.hash || "#overview").slice(1);
  let currentTab = "";
  let searchTerm = "";
  let saveTimer;
  let orderBadgeSeen = Number(localStorage.getItem("restore_orders_seen_v1") || 0);
  const openEditors = {};

  const ICONS = {
    overview: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="4" rx="1.5"/><rect x="14" y="11" width="7" height="10" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
    orders: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z"/><path d="M9 8h6M9 12h6"/>',
    cart: '<circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M3 4h2l2.4 11h11L21 7H6"/>',
    products: '<path d="M4 7l8-4 8 4-8 4-8-4z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/>',
    categories: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    content: '<path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    palette: '<circle cx="12" cy="12" r="9"/><circle cx="8.5" cy="9" r="1"/><circle cx="15.5" cy="9" r="1"/><circle cx="9" cy="15" r="1"/><path d="M12 21c-1.2-2.3 1-4 3-4 2 0 3.5 1.5 3.5 3.5 0 .5-2.5.5-6.5.5z"/>',
    marketing: '<path d="M4 9v6h4l8 4V5L8 9H4z"/><path d="M20 9a4 4 0 0 1 0 6"/>',
    payment: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M7 15h4"/>',
    team: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="18" cy="9" r="2"/><path d="M17 14c2.5 0 4 1.5 4 4"/>',
    reports: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.9l.06.06-2.12 2.12-.06-.06a1.7 1.7 0 0 0-1.9-.34 1.7 1.7 0 0 0-1 1.55V21h-3v-.09a1.7 1.7 0 0 0-1-1.55 1.7 1.7 0 0 0-1.9.34l-.06.06L4.2 17.6l.06-.06a1.7 1.7 0 0 0 .34-1.9A1.7 1.7 0 0 0 3.1 14H3v-3h.1a1.7 1.7 0 0 0 1.55-1 1.7 1.7 0 0 0-.34-1.9L4.2 8l2.12-2.12.06.06a1.7 1.7 0 0 0 1.9.34A1.7 1.7 0 0 0 9.3 4.7V4.6h3v.1a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.9-.34l.06-.06L17.4 8l-.06.06a1.7 1.7 0 0 0-.34 1.9 1.7 1.7 0 0 0 1.55 1h.09v3h-.09a1.7 1.7 0 0 0-1.55 1z"/>',
    audit: '<path d="M6 3h12v18H6z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    abandoned: '<path d="M4 4h16v12H9l-5 4V4z"/><path d="M8 9h8M8 12h5"/>',
    reviews: '<path d="M12 3l2.7 5.5 6 .9-4.35 4.25 1.03 6L12 16.9l-5.38 2.8 1.03-6L3.3 9.4l6-.9L12 3z"/>',
    blog: '<path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/><path d="M16 16h.01"/>',
    pages: '<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/>',
    preview: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    publish: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    logout: '<path d="M10 4H5v16h5M14 8l4 4-4 4M8 12h10"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    moon: '<path d="M20 15.5A8.5 8.5 0 0 1 8.5 4a8.5 8.5 0 1 0 11.5 11.5z"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    whatsapp: '<path d="M20.5 11.7a8.5 8.5 0 0 1-12.6 7.5L3.5 20.5l1.3-4.3a8.5 8.5 0 1 1 15.7-4.5z"/><path d="M8.4 7.8c.2-.4.4-.4.7-.4h.5c.2 0 .4 0 .5.4l.8 1.9c.1.2 0 .4-.1.6l-.6.7c-.2.2-.1.3 0 .5.7 1.2 1.7 2.2 2.9 2.9.2.1.4.2.5 0l.7-.8c.2-.2.4-.2.6-.1l1.9.9c.3.1.4.3.4.5 0 1-.5 1.8-1.4 2.1-.6.2-1.4.3-2.3.1-3.6-.8-6.4-3.6-7.2-7.2-.2-1-.1-1.8.1-2.4z"/>',
    external: '<path d="M14 3h7v7M10 14L21 3"/><path d="M21 14v7H3V3h7"/>',
    edit: '<path d="M4 20h4L20 8l-4-4L4 16v4z"/><path d="M14 6l4 4"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    down: '<path d="M18 9l-6 6-6-6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    arrows: '<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
    print: '<path d="M6 9V3h12v6M6 18H4v-7h16v7h-2"/><path d="M6 14h12v7H6z"/>',
    refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 9a7 7 0 0 1 11.4-2L20 9M4 15l2.5 2a7 7 0 0 0 11.4-2"/>',
    chevron: '<path d="M9 5l7 7-7 7"/>',
  };
  const icon = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.overview}</svg>`;

  function toast(message, type = "") {
    const node = document.getElementById("dash-toast");
    if (!node) return;
    node.textContent = message;
    node.className = `toast show ${type}`;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { node.className = "toast"; }, 3200);
  }

  function getPath(object, path) {
    return String(path).split(".").reduce((value, key) => value?.[key], object);
  }
  function setPath(object, path, value) {
    const parts = String(path).split(".");
    let cursor = object;
    parts.forEach((key, index) => {
      if (index === parts.length - 1) {
        cursor[key] = value;
        return;
      }
      if (cursor[key] == null || typeof cursor[key] !== "object") cursor[key] = /^\d+$/.test(parts[index + 1]) ? [] : {};
      cursor = cursor[key];
    });
  }

  function orderList() {
    return R.getOrders().slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  function productList() {
    return model.products || [];
  }
  function newOrdersCount() {
    return orderList().filter((order) => order.status === "new").length;
  }
  function orderStatusCount(status) {
    return orderList().filter((order) => order.status === status).length;
  }
  function revenueOfOrders(orders) {
    return orders.filter((order) => order.status !== "cancelled" && order.status !== "returned").reduce((sum, order) => sum + (Number(order.total) || 0), 0);
  }
  function lowStockProducts() {
    return productList().filter((product) => product.active !== false && Number(product.stock) <= Number(model.settings.lowStockThreshold || 2));
  }

  function saveDraftSoon() {
    dirty = true;
    model.updatedAt = nowIso();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      R.saveDraft(model);
      updateDraftState();
    }, 500);
    updateDraftState();
  }
  function saveDraftNow() {
    clearTimeout(saveTimer);
    model.updatedAt = nowIso();
    R.saveDraft(model);
    dirty = true;
    updateDraftState();
  }
  function updateDraftState() {
    const node = $(".dash-save-state");
    if (!node) return;
    node.className = `dash-save-state ${dirty ? "dirty" : "published"}`;
    node.innerHTML = `<i></i>${dirty ? dt("تغييرات غير منشورة", "Modifications non publiées") : dt("متجر محدث", "Boutique à jour")}`;
  }

  function updateCounts() {
    const count = newOrdersCount();
    $$("[data-nav-count='orders']").forEach((node) => {
      node.textContent = count || "";
      node.hidden = !count;
    });
    const badge = $("[data-order-alert]");
    if (badge) {
      const unseen = Math.max(0, count - orderBadgeSeen);
      badge.textContent = unseen || "";
      badge.hidden = !unseen;
    }
  }

  /* --------------------------------------------------------------------------
     Authentication screens
     -------------------------------------------------------------------------- */
  function renderLogin() {
    session = null;
    app.innerHTML = `
      <div class="dash-login">
        <section class="login-brand">
          <div>
            <a class="logo" href="index.html"><img src="${esc(model.settings.logoWhite || "assets/img/restore-logo-white.svg")}" alt="Restore"></a>
            <h1>${dt("أدر متجرك من مكان واحد.", "Gérez votre boutique depuis un seul endroit.")}</h1>
            <p>${dt("الطلبات، المنتجات، المحتوى، الألوان، العروض والتقارير — كل شيء متصل بالمتجر مباشرة.", "Commandes, produits, contenu, couleurs, offres et rapports — tout est connecté à la boutique en direct.")}</p>
            <div class="login-features">
              <span>${dt("نشر فوري", "Publication instantanée")}</span>
              <span>${dt("عربي / فرنسي", "Arabe / Français")}</span>
              <span>${dt("Supabase", "Supabase")}</span>
              <span>PWA</span>
            </div>
          </div>
          <footer>${dt("ريستور موريتانيا", "Restore Mauritanie")} · ${new Date().getFullYear()}</footer>
        </section>
        <section class="login-panel">
          <div class="login-card">
            <div class="login-lang">
              <button type="button" data-dash-lang="ar" class="${dashLang === "ar" ? "active" : ""}">العربية</button>
              <button type="button" data-dash-lang="fr" class="${dashLang === "fr" ? "active" : ""}">Français</button>
            </div>
            <h2>${dt("تسجيل الدخول", "Connexion")}</h2>
            <p>${dt("ادخل إلى لوحة تحكم ريستور.", "Accédez au tableau de bord Restore.")}</p>
            <form id="login-form">
              <div class="field"><label>${dt("البريد الإلكتروني أو اسم المستخدم", "E-mail ou identifiant")}</label><input name="username" type="text" autocomplete="username" required autofocus placeholder="owner@restore.mr"></div>
              <div class="field"><label>${dt("كلمة المرور", "Mot de passe")}</label><input name="password" type="password" autocomplete="current-password" required></div>
              <div class="login-error" id="login-error"></div>
              <button class="btn btn-primary" type="submit">${dt("دخول", "Se connecter")}</button>
            </form>

          </div>
        </section>
      </div>`;
    $("#login-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const error = $("#login-error");
      error.textContent = "";
      try {
        await R.login(data.get("username"), data.get("password"));
        session = R.currentSession();
        R.addAudit(dt("تسجيل دخول إلى لوحة التحكم", "Connexion au tableau de bord"), session?.username);
        if (session?.mustChange) renderPasswordChange();
        else renderShell();
      } catch (err) {
        error.textContent = err.message || String(err);
      }
    });
  }

  function renderPasswordChange() {
    app.innerHTML = `
      <div class="dash-login">
        <section class="login-brand">
          <div>
            <a class="logo" href="index.html"><img src="${esc(model.settings.logoWhite || "assets/img/restore-logo-white.svg")}" alt="Restore"></a>
            <h1>${dt("أمّن متجرك أولًا.", "Sécurisez votre boutique.")}</h1>
            <p>${dt("يجب تغيير كلمة المرور الافتراضية وربط رقم واتساب قبل استعمال لوحة التحكم.", "Changez le mot de passe par défaut et associez un numéro WhatsApp avant d’utiliser le tableau de bord.")}</p>
          </div>
          <footer>${dt("خطوة إلزامية", "Étape obligatoire")}</footer>
        </section>
        <section class="login-panel">
          <div class="login-card">
            <span class="badge-soft orange">${dt("أول تسجيل دخول", "Première connexion")}</span>
            <h2 style="margin-top:10px">${dt("تغيير كلمة المرور", "Changer le mot de passe")}</h2>
            <p>${dt("الحساب", "Compte")}: <strong>${esc(session?.username || "")}</strong></p>
            <form id="password-form">
              <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input name="current" type="password" required></div>
              <div class="field"><label>${dt("كلمة المرور الجديدة", "Nouveau mot de passe")}</label><input name="next" type="password" minlength="8" required></div>
              <div class="field"><label>${dt("تأكيد كلمة المرور", "Confirmer le mot de passe")}</label><input name="confirm" type="password" minlength="8" required></div>
              <div class="field"><label>${dt("رقم واتساب المتجر / المدير", "WhatsApp de la boutique / du gérant")}</label><input name="whatsapp" inputmode="tel" placeholder="22246000000" dir="ltr" required value="${esc(model.settings.whatsapp || "")}"></div>
              <div class="field"><label>${dt("طرق الدفع المطلوبة", "Méthodes de paiement obligatoires")}</label>
                <div class="setup-form" style="margin-top:8px">
                  ${(model.settings.payments || []).map((p, i) => `
                    <label class="toggle-card ${p.active !== false ? "active" : ""}" data-payment="${i}">
                      <input type="checkbox" ${p.active !== false ? "checked" : ""}>
                      <div><strong>${esc(lng(p.name))}</strong><small>${p.discount ? dt("خصم ", "Réduction ") + p.discount + "%" : ""}</small></div>
                    </label>
                  `).join("")}
                </div>
                <p class="form-note">${dt("اختر على الأقل طريقة دفع واحدة", "Sélectionnez au moins un moyen de paiement")}</p>
              </div>
              <div class="login-error" id="password-error"></div>
              <button class="btn btn-primary" type="submit">${dt("حفظ ومتابعة", "Enregistrer et continuer")}</button>
            </form>
          </div>
        </section>
      </div>`;
    $("#logout-must")?.addEventListener("click", () => { R.logout(); renderLogin(); });
    $("#password-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const error = $("#password-error");
      error.textContent = "";
      if (data.get("next") !== data.get("confirm")) { error.textContent = dt("كلمتا المرور غير متطابقتين", "Les mots de passe ne correspondent pas"); return; }
      if (String(data.get("next")).length < 8) { error.textContent = dt("8 أحرف على الأقل", "8 caractères minimum"); return; }
      try {
        await R.changePassword(session.username, data.get("current"), data.get("next"), data.get("whatsapp"));
        session = R.currentSession();
        model = clone(R.state);
        R.addAudit(dt("غيّر كلمة المرور", "Mot de passe modifié"), session?.username);
        toast(dt("تم تحديث كلمة المرور", "Mot de passe mis à jour"), "good");
        renderShell();
      } catch (err) {
        error.textContent = err.message || String(err);
      }
    });
  }

  /* --------------------------------------------------------------------------
     Application shell
     -------------------------------------------------------------------------- */
  const NAV_GROUPS = [
    {
      label: { ar: "نظرة عامة", fr: "Vue d’ensemble" },
      items: [
        { id: "overview", icon: "overview", ar: "نظرة عامة", fr: "Vue d’ensemble" },
        { id: "orders", icon: "orders", ar: "الطلبات", fr: "Commandes", count: true },
        { id: "abandoned", icon: "abandoned", ar: "السلال المتروكة", fr: "Paniers abandonnés" }
      ]
    },
    {
      label: { ar: "المتجر", fr: "Boutique" },
      items: [
        { id: "products", icon: "products", ar: "المنتجات", fr: "Produits" },
        { id: "categories", icon: "categories", ar: "الفئات", fr: "Catégories" },
        { id: "reviews", icon: "reviews", ar: "التقييمات", fr: "Avis" }
      ]
    },
    {
      label: { ar: "المحتوى", fr: "Contenu" },
      items: [
        { id: "content", icon: "content", ar: "نصوص المتجر", fr: "Textes & contenu" },
        { id: "homepage", icon: "home", ar: "الصفحة الرئيسية", fr: "Page d’accueil" },
        { id: "appearance", icon: "palette", ar: "الهوية والألوان", fr: "Identité & couleurs" },
        { id: "marketing", icon: "marketing", ar: "العروض والتسويق", fr: "Offres & marketing" },
        { id: "blog", icon: "blog", ar: "المدونة", fr: "Blog" },
        { id: "pages", icon: "pages", ar: "الصفحات", fr: "Pages" }
      ]
    },
    {
      label: { ar: "العمليات", fr: "Opérations" },
      items: [
        { id: "payments", icon: "payment", ar: "الدفع والتوصيل", fr: "Paiement & livraison" },
        { id: "team", icon: "team", ar: "الفريق", fr: "Équipe" },
        { id: "reports", icon: "reports", ar: "التقارير", fr: "Rapports" },
        { id: "settings", icon: "settings", ar: "الإعدادات", fr: "Réglages" },
        { id: "audit", icon: "audit", ar: "سجل النشاط", fr: "Journal d’activité" }
      ]
    },
    {
      label: { ar: "الحساب", fr: "Compte" },
      items: [
        { id: "profile", icon: "team", ar: "ملفي الشخصي", fr: "Mon profil" }
      ]
    }
  ];
  const OWNER_ONLY_ROUTES = new Set(["team", "settings", "audit"]);
  const ROUTE_TITLES = {
    overview: { ar: "نظرة عامة", fr: "Vue d’ensemble", sub: { ar: "ملخص مباشر لمتجر ريستور", fr: "Résumé en direct de Restore" } },
    orders: { ar: "الطلبات", fr: "Commandes", sub: { ar: "إدارة الطلبات والواتساب والفواتير", fr: "Commandes, WhatsApp et factures" } },
    abandoned: { ar: "السلال المتروكة", fr: "Paniers abandonnés", sub: { ar: "استرجع العملاء الذين لم يكملوا الطلب", fr: "Récupérez les clients qui n’ont pas finalisé" } },
    products: { ar: "المنتجات", fr: "Produits", sub: { ar: "المخزون والأسعار والصور", fr: "Stock, prix et images" } },
    categories: { ar: "الفئات", fr: "Catégories", sub: { ar: "تنظيم مجموعات المتجر", fr: "Organisez les collections" } },
    reviews: { ar: "التقييمات", fr: "Avis clients", sub: { ar: "راجع واعتمد تقييمات العملاء", fr: "Modérez les avis clients" } },
    content: { ar: "نصوص المتجر", fr: "Textes & contenu", sub: { ar: "المحتوى بالعربية والفرنسية", fr: "Contenu en arabe et français" } },
    homepage: { ar: "الصفحة الرئيسية", fr: "Page d’accueil", sub: { ar: "الأقسام، السلايدر والترتيب", fr: "Sections, slider et ordre" } },
    appearance: { ar: "الهوية والألوان", fr: "Identité & couleurs", sub: { ar: "الشعار، الألوان والخطوط", fr: "Logo, couleurs et polices" } },
    marketing: { ar: "العروض والتسويق", fr: "Offres & marketing", sub: { ar: "بنكيلي، الكوبونات والبانرات", fr: "Bankily, coupons et bannières" } },
    blog: { ar: "المدونة", fr: "Blog", sub: { ar: "المقالات والصور المنشورة", fr: "Articles et images publiés" } },
    pages: { ar: "الصفحات", fr: "Pages", sub: { ar: "الصفحات الثابتة والسياسات", fr: "Pages statiques et politiques" } },
    payments: { ar: "الدفع والتوصيل", fr: "Paiement & livraison", sub: { ar: "بنكيلي، مصرفي، سداد، كليك والمدن", fr: "Bankily, Masrvi, Sedad, Click et villes" } },
    team: { ar: "الفريق", fr: "Équipe", sub: { ar: "المديرون وصلاحيات الدخول", fr: "Gérants et accès" } },
    reports: { ar: "التقارير", fr: "Rapports", sub: { ar: "المبيعات، الطلبات والمخزون", fr: "Ventes, commandes et stock" } },
    settings: { ar: "الإعدادات", fr: "Réglages", sub: { ar: "SEO، واتساب، البكسل والحماية", fr: "SEO, WhatsApp, pixels et sécurité" } },
    audit: { ar: "سجل النشاط", fr: "Journal d’activité", sub: { ar: "كل التغييرات المسجلة", fr: "Toutes les modifications" } }
  };

  function renderShell() {
    const displayName = session?.role === "owner" ? dt("مالك المتجر", "Propriétaire") : dt("مدير المتجر", "Gérant");
    const initials = String(displayName || "R").slice(0, 2).toUpperCase();
    const mgr = R.managers.find((item) => item.id === session?.id) || R.managers.find((item) => item.username === session?.username);
    const mgrAvatar = mgr?.avatar && mgr.avatar.trim() ? mgr.avatar : "";
    const remoteLabel = R.remote ? "Supabase" : "";
    app.innerHTML = `
      <div class="dash-shell">
        <aside class="dash-sidebar" id="dash-sidebar">
          <a class="brand" href="index.html"><img src="${esc(model.settings.logoWhite || "assets/img/restore-logo-white.svg")}" alt="Restore"></a>
          <div class="dash-workspace"><span class="dot"></span><div><strong>${esc(lng(model.settings.storeName))}</strong><small>MRU</small></div></div>
          <nav class="dash-nav">
            ${NAV_GROUPS.map((group) => `
              <div class="dash-nav-label">${esc(group.label[dashLang] || group.label.ar)}</div>
              ${group.items.filter((item) => session?.role === "owner" || !OWNER_ONLY_ROUTES.has(item.id)).map((item) => `<a href="#${item.id}" data-route="${item.id}" class="${route === item.id ? "active" : ""}">${icon(item.icon)}<span>${esc(item[dashLang] || item.ar)}</span>${item.count ? `<span class="count" data-nav-count="orders" ${newOrdersCount() ? "" : "hidden"}>${newOrdersCount() || ""}</span>` : ""}</a>`).join("")}
            `).join("")}
          </nav>
          <div class="dash-user">
            <span class="dash-avatar" data-route="profile" title="${dt("ملفي الشخصي", "Mon profil")}">${mgrAvatar ? `<img src="${esc(mgrAvatar)}" alt="">` : esc(initials)}</span>
            <div><strong>${esc(displayName)}</strong><small>${session?.role === "owner" ? dt("المالك", "Propriétaire") : dt("مدير", "Gérant")}</small></div>
            <button type="button" data-action="logout" title="${dt("خروج", "Déconnexion")}">${icon("logout")}</button>
          </div>
        </aside>
        <main class="dash-main">
          <header class="dash-topbar">
