/* extracted dashboard view */
export function viewReports(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const orders = reportOrders();
    const revenue = revenueOfOrders(orders);
    const items = orders.flatMap((order) => order.items || []);
    const itemCount = items.reduce((sum, item) => sum + Number(item.qty || 1), 0);
    const avg = orders.length ? revenue / orders.length : 0;
    const cityMap = {};
    orders.forEach((order) => {
      const city = order.customer?.city || "—";
      cityMap[city] = cityMap[city] || { count: 0, revenue: 0 };
      cityMap[city].count += 1;
      cityMap[city].revenue += Number(order.total) || 0;
    });
    const productMap = {};
    items.forEach((item) => {
      const key = item.handle || item.title;
      productMap[key] = productMap[key] || { title: item.title, image: item.image, qty: 0, revenue: 0 };
      productMap[key].qty += Number(item.qty || 1);
      productMap[key].revenue += Number(item.line || 0);
    });
    const topProducts = Object.values(productMap).sort((a, b) => b.revenue - a.revenue).slice(0, 8);
    const topCities = Object.entries(cityMap).sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 8);
    const maxCity = Math.max(1, ...topCities.map(([, data]) => data.revenue));
    const abandoned = R.getAbandoned().length;
    const conversion = orders.length + abandoned ? Math.round(orders.length / (orders.length + abandoned) * 100) : 0;
    const days = [...Array(7)].map((_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const key = date.toISOString().slice(0, 10);
      const total = orders.filter((order) => String(order.createdAt).slice(0, 10) === key).reduce((sum, order) => sum + Number(order.total || 0), 0);
      return { label: date.toLocaleDateString(dashLang === "ar" ? "ar-MR" : "fr-FR", { weekday: "short" }), total };
    });
    const maxDay = Math.max(1, ...days.map((day) => day.total));
    const low = lowStockProducts().slice(0, 8);
    return `
      <div class="dash-view-head"><div><h2>${dt("التقارير", "Rapports")}</h2><p>${dt("المبيعات والمخزون والأداء.", "Ventes, stock et performance.")}</p></div><div class="dash-view-actions"><div class="segmented">${[["7", "7j"], ["30", "30j"], ["90", "90j"], ["all", dt("الكل", "Tout")]].map(([id, label]) => `<button data-report-range="${id}" class="${reportRange === id ? "active" : ""}">${label}</button>`).join("")}</div><button class="btn btn-soft" data-action="export-orders">${icon("download")} CSV</button></div></div>
      <div class="dash-grid cols-4" style="margin-bottom:14px">
        ${statCard(dt("الإيرادات", "Chiffre d’affaires"), money(revenue), `${orders.length} ${dt("طلب", "commandes")}`, "#128c53", "reports")}
        ${statCard(dt("متوسط الطلب", "Panier moyen"), money(avg), dt("لكل طلب", "par commande"), "#ff6400", "cart")}
        ${statCard(dt("القطع المباعة", "Articles vendus"), itemCount, dt("إجمالي القطع", "total unités"), "#a72396", "products")}
        ${statCard(dt("نسبة التحويل", "Conversion"), `${conversion}%`, `${abandoned} ${dt("سلة متروكة", "paniers")}`, "#0b6fb8", "marketing")}
      </div>
      <div class="dash-grid cols-3">
        <article class="dash-card" style="grid-column:span 2"><div class="dash-card-head"><h3>${dt("الإيرادات آخر 7 أيام", "Revenus 7 jours")}</h3></div><div class="dash-card-body"><div class="report-bars">${days.map((day) => `<div class="bar" style="height:${Math.max(5, Math.round(day.total / maxDay * 100))}%" title="${money(day.total)}"><span>${esc(day.label)}</span></div>`).join("")}</div><div class="report-legend"><span><i></i>${money(days.reduce((sum, day) => sum + day.total, 0))}</span></div></div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أفضل المدن", "Meilleures villes")}</h3></div><div class="dash-card-body">${topCities.length ? topCities.map(([city, data]) => `<div style="margin-bottom:9px"><div style="display:flex;justify-content:space-between;font-size:9px;margin-bottom:4px"><span>${esc(city)}</span><strong>${money(data.revenue)}</strong></div><div class="mini-bar"><i style="width:${Math.round(data.revenue / maxCity * 100)}%"></i></div><small style="font-size:8px;color:var(--soft-muted)">${data.count} ${dt("طلب", "commandes")}</small></div>`).join("") : `<div class="empty-dash">${dt("لا توجد بيانات.", "Aucune donnée.")}</div>`}</div></article>
      </div>
      <div class="dash-grid cols-2" style="margin-top:14px">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("المنتجات الأكثر مبيعًا", "Meilleures ventes")}</h3></div><div class="dash-card-body"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("القطع", "Unités")}</th><th>${dt("الإيراد", "Revenu")}</th></tr></thead><tbody>${topProducts.map((product) => `<tr><td><div class="cell-main"><img src="${esc(product.image)}" alt=""><strong>${esc(product.title)}</strong></div></td><td>${product.qty}</td><td class="price">${money(product.revenue)}</td></tr>`).join("") || `<tr><td colspan="3" class="table-empty">${dt("لا توجد مبيعات.", "Aucune vente.")}</td></tr>`}</tbody></table></div></div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("مخزون منخفض", "Stock faible")}</h3><a href="#products" data-route="products">${dt("إدارة", "Gérer")}</a></div><div class="dash-card-body"><div class="list-editor">${low.map((product) => `<div class="list-row"><span class="image-preview" style="width:32px;height:32px;flex-basis:32px"><img src="${esc(product.image)}" alt=""></span><div class="grow"><strong>${esc(product.title)}</strong><small>${dt("متبقي", "Reste")}: ${product.stock}</small></div><span class="badge-soft ${product.stock <= 0 ? "" : "orange"}">${product.stock <= 0 ? dt("نفد", "Épuisé") : dt("منخفض", "Faible")}</span></div>`).join("") || `<div class="empty-dash">${dt("المخزون جيد.", "Stock correct.")}</div>`}</div></div></article>
      </div>`;
  
  }).call(ctx);
}
