// legacy dashboard chunk 8
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const next = clone(model);
        next.settings.social = next.settings.social || [];
        next.settings.social.push({ platform: "", href: "" });
        model = next;
        saveDraftSoon();
        renderRoute();
        break;
      }
      case "change-own-pwd": {
        const current = $("#sec-current")?.value || "";
        const nextPwd = $("#sec-next")?.value || "";
        const confirm = $("#sec-confirm")?.value || "";
        if (!current || !nextPwd || nextPwd !== confirm) return toast(dt("تحقق من كلمات المرور", "Vérifiez les mots de passe"), "error");
        if (nextPwd.length < 8) return toast(dt("كلمة المرور 8 أحرف على الأقل", "Mot de passe : 8 caractères minimum"), "error");
        (async () => {
          try {
            await R.changePassword(session.username, current, nextPwd, "");
            session = R.currentSession();
            toast(dt("تم تغيير كلمة المرور", "Mot de passe changé"), "good");
            $("#sec-current").value = "";
            $("#sec-next").value = "";
            $("#sec-confirm").value = "";
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      default:
        break;
    }
  });

  document.addEventListener("input", (event) => {
    const node = event.target;
    if (node.id === "order-search") {
      searchTerm = node.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { renderRoute(); const next = $("#order-search"); if (next) { next.focus(); next.setSelectionRange(next.value.length, next.value.length); } }, 320);
      return;
    }
    if (node.id === "product-search") {
      productSearch = node.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { renderRoute(); const next = $("#product-search"); if (next) { next.focus(); next.setSelectionRange(next.value.length, next.value.length); } }, 320);
      return;
    }
    if (node.id === "dash-search") {
      searchTerm = node.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        if (route === "orders" || route === "products") renderRoute();
      }, 380);
      return;
    }
    if (node.matches("[data-edit-path]")) {
      handleField(node);
      const preview = node.closest(".image-field")?.querySelector("img");
      if (preview && node.type !== "file") preview.src = node.value || "assets/img/favicon.svg";
    } else if (node.matches("[data-path]")) {
      handleField(node);
      const preview = node.closest(".image-field")?.querySelector("img");
      if (preview && node.type !== "file") preview.src = node.value || "assets/img/favicon.svg";
    }
  });

  document.addEventListener("change", (event) => {
    const node = event.target;
    if (node.matches("[data-upload-path]")) { handleUpload(node); return; }
    if (node.id === "profile-avatar-upload" && node.files?.[0]) {
      const file = node.files[0];
      (async () => {
        try {
          const dataUrl = await R.resizeImage(file, 256, 0.85);
          const publicUrl = await R.uploadMedia(dataUrl);
          const url = publicUrl || dataUrl;
          R.updateManager(session.id, { avatar: url });
          model = clone(R.state);
          session = R.currentSession();
          localStorage.setItem("restore_session_v1", JSON.stringify(session));
          R.addAudit(`${dt("تحديث الصورة الرمزية", "Avatar mis à jour")}`);
          toast(dt("تم تحديث الصورة", "Image mise à jour"), "good");
          renderRoute();
        } catch (error) { toast(error.message, "error"); }
      })();
      return;
    }
    if (node.matches("[data-lines-path]")) { handleLines(node); return; }
    if (node.matches("[data-currency-mode]")) {
      R.setCurrencyMode(node.value);
      setPath(model, "settings.country.currencyMode", node.value);
      saveDraftSoon();
      toast(dt("تم تغيير العملة المعروضة", "Devise d’affichage modifiée"), "good");
      return;
    }
    if (node.dataset.blocklist != null) {
      model.settings.blocklist = node.value.split("\n").map((line) => digits(line)).filter(Boolean);
      saveDraftSoon();
      return;
    }
    if (node.matches("[data-page-section-visible], [data-home-section-visible], [data-product-active], [data-coupon-active], [data-payment-active], [data-city-active], [data-review-approved]")) {
      handleDirectToggle(node);
      return;
    }
    if (node.matches("[data-order-status]")) {
      handleDirectToggle(node);
      return;
    }
    if (node.matches("[data-product-filter]")) {
      if (node.dataset.productFilter === "category") productCategory = node.value;
      if (node.dataset.productFilter === "stock") productStock = node.value;
      saveDraftNow();
      renderRoute();
      return;
    }
    if (node.matches("[data-edit-path]")) {
      handleField(node);
      return;
    }
    if (node.matches("[data-path]")) {
      handleField(node);
      saveDraftNow();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modalRoot.innerHTML) closeModal();
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveDraftNow();
      toast(dt("تم حفظ المسودة", "Brouillon enregistré"), "good");
    }
  });

  window.addEventListener("hashchange", () => {
    const next = (location.hash || "#overview").slice(1);
    if (ROUTE_TITLES[next] && next !== route) {
      route = next;
      if (session) renderRoute();
    }
  });

  window.addEventListener("restore:orders", () => {
    const count = newOrdersCount();
    updateCounts();
    if (count > lastOrderCount) {
      toast(dt("طلب جديد وصل من المتجر", "Nouvelle commande reçue"), "good");
      try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
          const context = new AudioContext();
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          oscillator.connect(gain); gain.connect(context.destination);
          oscillator.frequency.value = 880; gain.gain.value = 0.03;
          oscillator.start(); oscillator.stop(context.currentTime + 0.16);
        }
      } catch {}
      if (route === "orders" || route === "overview") renderRoute();
    }
    lastOrderCount = count;
  });

  window.addEventListener("restore:changed", () => {
    if (!dirty) {
      model = clone(R.state);
      if (session) renderRoute();
    }
  });

  window.addEventListener("restore:reviews", () => {
    if (session && route === "reviews") renderRoute();
  });

  window.addEventListener("restore:orders", () => {
    if (session && (route === "orders" || route === "overview" || route === "reports")) updateCounts();
  });

  window.addEventListener("beforeunload", () => {
    if (dirty) {
      try { R.saveDraft(model); } catch {}
    }
  });

  /* --------------------------------------------------------------------------
     Boot
     -------------------------------------------------------------------------- */
  function boot() {
    if (!session) { renderLogin(); return; }
    if (session.mustChange) { renderPasswordChange(); return; }
    renderShell();
    if (R.remote) {
      R.loadRemoteState().then((updated) => {
        if (updated && !dirty) { model = clone(R.state); renderRoute(); }
      }).catch(() => {});
    }
  }
  boot();

};
_initDashboard();
