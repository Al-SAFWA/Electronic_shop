// legacy dashboard chunk 5
            ${pending.map((review) => customerRow(review, `
              <button class="btn btn-sm btn-success" data-action="approve-customer-review" data-id="${esc(review.id)}">${icon("check")} ${dt("اعتماد", "Approuver")}</button>
              <button class="btn btn-sm btn-danger" data-action="reject-customer-review" data-id="${esc(review.id)}">${icon("trash")} ${dt("رفض", "Refuser")}</button>`)).join("")}
          </div>` : `<div class="empty-dash">${dt("لا توجد تقييمات معلقة.", "Aucun avis en attente.")}</div>`}
        </div></article>
        ${approved.length ? `<article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("المعتمدة", "Approuvés")}</h3><span class="badge-soft green">${approved.length}</span></div><div class="dash-card-body"><div class="list-editor">
          ${approved.map((review) => customerRow(review, `
            <a class="btn btn-sm btn-soft" href="product.html?handle=${encodeURIComponent(review.productHandle)}" target="_blank" rel="noopener">${icon("external")}</a>
            <button class="btn btn-sm btn-soft" data-action="reject-customer-review" data-id="${esc(review.id)}">${icon("close")} ${dt("إلغاء الاعتماد", "Retirer")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-customer-review" data-id="${esc(review.id)}">${icon("trash")}</button>`)).join("")}
        </div></div></article>` : ""}
        ${rejected.length ? `<article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("المرفوضة", "Rejetés")}</h3><span class="badge-soft">${rejected.length}</span></div><div class="dash-card-body"><div class="list-editor">
          ${rejected.map((review) => customerRow(review, `
            <button class="btn btn-sm btn-success" data-action="approve-customer-review" data-id="${esc(review.id)}">${icon("check")} ${dt("اعتماد", "Approuver")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-customer-review" data-id="${esc(review.id)}">${icon("trash")}</button>`)).join("")}
        </div></div></article>` : ""}
      </div>`;
  }
  let pendingReviewKind = "home";
  let pendingReviewIndex = null;
  function reviewEditor(kind, index) {
    const isNew = index == null;
    const source = kind === "home" ? (model.homeReviews || []) : (model.reviews || []);
    const buffer = isNew ? {
      id: `review-${Date.now().toString(36)}`, name: "", city: { ar: "نواكشوط", fr: "Nouakchott" }, rating: 5,
      title: { ar: "", fr: "" }, body: { ar: "", fr: "" }, color: "#2e7d6f", handle: "", verified: true, approved: true
    } : clone(source[index]);
    editBuffer = buffer;
    pendingReviewKind = kind;
    pendingReviewIndex = isNew ? null : index;
    openModal(isNew ? dt("تقييم جديد", "Nouvel avis") : dt("تعديل التقييم", "Modifier l’avis"), `
      <div class="form-grid">
        <div class="field"><label>${dt("اسم العميل", "Nom")}</label><input data-edit-path="name" value="${esc(buffer.name)}"></div>
        <div class="field"><label>${dt("التقييم", "Note")}</label><select data-edit-path="rating">${[5, 4, 3, 2, 1].map((value) => `<option value="${value}" ${Number(buffer.rating) === value ? "selected" : ""}>${"★".repeat(value)}</option>`).join("")}</select></div>
        ${editBi(dt("المدينة", "Ville"), "city", buffer.city)}
        ${kind === "product" ? `<div class="field"><label>${dt("المنتج", "Produit")}</label><select data-edit-path="handle">${model.products.map((product) => `<option value="${esc(product.handle)}" ${product.handle === buffer.handle ? "selected" : ""}>${esc(product.title)}</option>`).join("")}</select></div>` : `<div class="field"><label>${dt("لون الصورة الرمزية", "Couleur avatar")}</label><input type="color" data-edit-path="color" value="${esc(buffer.color || "#2e7d6f")}"></div>`}
        ${editBi(dt("عنوان التقييم", "Titre"), "title", buffer.title)}
        <div class="span-2">${editBi(dt("نص التقييم", "Contenu"), "body", buffer.body, { type: "textarea", rows: 4 })}</div>
        ${kind === "product" ? `<div class="span-2">${editToggle(dt("شراء موثق", "Achat vérifié"), "verified", buffer.verified !== false)}${editToggle(dt("معتمد للنشر", "Approuvé"), "approved", buffer.approved !== false)}</div>` : ""}
      </div>`, {
      footer: editorFooter(!isNew, "delete-review-buffer")
    });
  }

  function saveReviewEditor() {
    if (!editBuffer) return;
    const list = pendingReviewKind === "home" ? model.homeReviews : (model.reviews || (model.reviews = []));
    if (pendingReviewIndex == null) list.push(editBuffer);
    else list[pendingReviewIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ التقييم", "Avis enregistré"), "good");
  }

  /* --------------------------------------------------------------------------
     Payments and shipping cities
     -------------------------------------------------------------------------- */
  function viewPayments() {
    return `
      <div class="dash-view-head"><div><h2>${dt("الدفع والتوصيل", "Paiement & livraison")}</h2><p>${dt("فعّل طرق الدفع المحلية وحدد رسوم المدن. يمكنك رفع شعار لكل طريقة دفع.", "Activez les paiements locaux et les frais par ville. Vous pouvez télécharger un logo pour chaque moyen de paiement.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="pay-methods">${dt("طرق الدفع", "Moyens de paiement")}</button><button data-dash-tab="pay-cities">${dt("مدن التوصيل", "Villes de livraison")}</button><button data-dash-tab="pay-shipping">${dt("إعدادات الشحن", "Réglages livraison")}</button></div>
      <div class="dash-panel active" data-dash-panel="pay-methods">
        <div class="dash-view-actions" style="justify-content:flex-end;margin-bottom:9px"><button class="btn btn-primary btn-sm" data-action="add-payment">${icon("plus")} ${dt("طريقة دفع", "Moyen de paiement")}</button></div>
        <div class="dash-grid cols-2">
          ${(model.settings.payments || []).map((payment, index) => `<article class="dash-card"><div class="dash-card-body">
            <div style="display:flex;align-items:center;gap:9px;margin-bottom:10px">
              ${(payment.image || payment.logo) ? `<img src="${esc(payment.image || payment.logo)}" alt="" style="width:36px;height:36px;border-radius:9px;object-fit:contain">` : `<span style="width:36px;height:36px;border-radius:9px;background:${esc(payment.color)};color:#fff;display:grid;place-items:center;font-size:10px;font-weight:800">${esc(String(lng(payment.name)).slice(0, 2))}</span>`}
              <div style="flex:1"><strong style="font-size:12px">${esc(lng(payment.name))}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${esc(lng(payment.note))}</small></div>
              <label class="toggle"><input type="checkbox" data-payment-active="${index}" ${payment.active !== false ? "checked" : ""}><span></span></label>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
              <span class="badge-soft ${payment.discount ? "orange" : ""}">${payment.discount ? `-${payment.discount}%` : dt("بدون خصم", "Sans remise")}</span>
              <div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-payment" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-payment" data-index="${index}">${icon("trash")}</button></div>
            </div>
            ${(payment.image || payment.logo) ? `<div class="image-preview" style="margin-top:8px"><img src="${esc(payment.image || payment.logo)}" alt="" style="max-width:100%;max-height:40px;border-radius:6px"></div>` : ""}
          </div></article>`).join("")}
        </div>
        <article class="dash-card" style="margin-top:14px"><div class="dash-card-body">${biField(dt("نص عرض الدفع", "Texte offre paiement"), "settings.paymentOffer", { type: "textarea", rows: 2 })}<p class="form-note" style="margin-top:8px">${dt("يظهر هذا النص في صفحة المنتج وصفحة الدفع. البنكيلي يطبق الخصم المحدد أعلاه تلقائيًا.", "Ce texte apparaît sur la fiche produit et au checkout. Bankily applique automatiquement la remise.")}</p></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pay-cities">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("مدن التوصيل", "Villes de livraison")}</h3><button data-action="add-city">${icon("plus")} ${dt("إضافة مدينة", "Ajouter une ville")}</button></div><div class="dash-card-body"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المدينة", "Ville")}</th><th>${dt("الرسوم", "Frais")}</th><th>${dt("المدة", "Délai")}</th><th>${dt("نشطة", "Active")}</th><th></th></tr></thead><tbody>
          ${(model.settings.cities || []).map((city, index) => `<tr><td><strong>${esc(lng(city.name))}</strong></td><td>${money(city.fee)}</td><td>${esc(lng(city.days))}</td><td><label class="toggle"><input type="checkbox" data-city-active="${index}" ${city.active !== false ? "checked" : ""}><span></span></label></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-city" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-city" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
        </tbody></table></div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pay-shipping">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("إعدادات الشحن", "Réglages livraison")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">${field(dt("الشحن المجاني بعد (MRU)", "Livraison gratuite dès (MRU)"), "settings.freeShippingOver", { type: "number" })}${field(dt("حد المخزون المنخفض", "Seuil stock faible"), "settings.lowStockThreshold", { type: "number" })}</div>
          ${biField(dt("ملاحظة الشحن", "Note livraison"), "settings.shippingNote", { type: "textarea", rows: 2 })}
          ${directToggle(dt("إخفاء المنتجات المنتهية من المتجر", "Masquer les produits épuisés"), "settings.autoHideOutOfStock", model.settings.autoHideOutOfStock)}
          <p class="form-note">${dt("تظهر رسوم كل مدينة في صفحة الدفع ويُضاف الشحن المجاني إذا تجاوز المجموع الحد المحدد.", "Les frais de chaque ville s’affichent au checkout ; la livraison est offerte au-delà du seuil.")}</p>
        </div></article>
      </div>`;
  }

  let pendingPaymentIndex = null;
  function paymentEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `payment-${Date.now().toString(36)}`, name: { ar: "", fr: "" }, image: "", color: "#0b6fb8", active: true, discount: 0, note: { ar: "", fr: "" } } : clone(model.settings.payments[index]);
    editBuffer = buffer;
    pendingPaymentIndex = isNew ? null : index;
    openModal(isNew ? dt("طريقة دفع جديدة", "Nouveau moyen") : lng(buffer.name), `
      <div class="form-grid">
        ${editBi(dt("الاسم", "Nom"), "name", buffer.name)}
        <div class="field"><label>${dt("اللون", "Couleur")}</label><input type="color" data-edit-path="color" value="${esc(buffer.color)}"></div>
        <div class="field"><label>${dt("الخصم %", "Remise %")}</label><input type="number" data-edit-path="discount" value="${esc(buffer.discount || 0)}"></div>
        <div class="field"><label>${dt("ملاحظة", "Note")}</label><input data-edit-path="note.ar" value="${esc(buffer.note?.ar || "")}" dir="rtl"></div>
        <div class="field"><label>Note FR</label><input data-edit-path="note.fr" value="${esc(buffer.note?.fr || "")}" dir="ltr"></div>
        <div class="span-2">${imageEditor(dt("صورة التطبيق", "Image de l’application"), "image", buffer.image || buffer.logo || "")}</div>
        <div class="span-2">${editToggle(dt("مفعلة", "Active"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-payment-buffer")
    });
  }

  function viewPaymentSave() {
    if (!editBuffer) return;
    if (pendingPaymentIndex == null) model.settings.payments.push(editBuffer);
    else model.settings.payments[pendingPaymentIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ طريقة الدفع", "Paiement enregistré"), "good");
  }

  let pendingCityIndex = null;
  function cityEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `city-${Date.now().toString(36)}`, name: { ar: "", fr: "" }, fee: 0, days: { ar: "2–4 أيام", fr: "2–4 jours" }, active: true } : clone(model.settings.cities[index]);
    editBuffer = buffer;
    pendingCityIndex = isNew ? null : index;
    openModal(isNew ? dt("مدينة جديدة", "Nouvelle ville") : lng(buffer.name), `
      <div class="form-grid">
        ${editBi(dt("المدينة", "Ville"), "name", buffer.name)}
        <div class="field"><label>${dt("رسوم الشحن", "Frais")}</label><input type="number" data-edit-path="fee" value="${esc(buffer.fee)}"></div>
        ${editBi(dt("المدة", "Délai"), "days", buffer.days)}
        <div class="span-2">${editToggle(dt("نشطة", "Active"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-city-buffer")
    });
  }

  function viewCitySave() {
    if (!editBuffer) return;
    if (pendingCityIndex == null) model.settings.cities.push(editBuffer);
    else model.settings.cities[pendingCityIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المدينة", "Ville enregistrée"), "good");
  }

  /* --------------------------------------------------------------------------
     Team
     -------------------------------------------------------------------------- */
  function viewProfile() {
    const mgr = R.managers.find((item) => item.id === session?.id) || R.managers.find((item) => item.username === session?.username);
    const currentUser = mgr || { username: session?.username, name: { ar: session?.name, fr: session?.name }, whatsapp: "", email: "" };
    const hasAvatar = currentUser.avatar && currentUser.avatar.trim();
    const avatarSrc = hasAvatar ? currentUser.avatar : "";
    const initials = String(lng(currentUser.name) || session?.username || "U").slice(0, 2).toUpperCase();

    return `
      <div class="dash-view-head"><div><h2>${dt("ملفي الشخصي", "Mon profil")}</h2><p>${dt("إدارة معلومات الحساب والتواصل والدفع", "Gérer les informations du compte, contact et paiement")}</p></div></div>
      <div class="dash-tabs">
        <button class="active" data-dash-tab="profile-info">${dt("معلومات الحساب", "Infos du compte")}</button>
        ${session?.role === "owner" ? `<button data-dash-tab="profile-contact">${dt("التواصل", "Contact")}</button>
        <button data-dash-tab="profile-social">${dt("السوشيال", "Social")}</button>` : ""}
        <button data-dash-tab="profile-security">${dt("الأمان", "Sécurité")}</button>
        <button data-dash-tab="profile-payment">${dt("طرق الدفع", "Moyens de paiement")}</button>
      </div>

      <div class="dash-panel active" data-dash-panel="profile-info">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات الحساب", "Informations du compte")}</h3></div><div class="dash-card-body dash-form">
            <div class="form-grid">
              <div class="field"><label>${dt(R.remote ? "البريد الإلكتروني" : "اسم المستخدم", R.remote ? "E-mail" : "Nom d'utilisateur")}</label><input id="profile-username" value="${esc(session?.username || "")}" ${R.remote || session?.role !== "owner" ? "readonly" : ""} dir="ltr" autocomplete="username"></div>
              <div class="field"><label>${dt("الدور", "Rôle")}</label><input value="${session?.role === 'owner' ? dt('المالك', 'Propriétaire') : dt('مدير', 'Gérant')}" readonly></div>
              <div class="field"><label>${dt("الاسم بالعربية", "Nom en arabe")}</label><input id="profile-name-ar" value="${esc(currentUser.name?.ar || "")}" dir="rtl"></div>
              <div class="field"><label>Nom en français</label><input id="profile-name-fr" value="${esc(currentUser.name?.fr || "")}" dir="ltr"></div>
              <div class="field"><label>${dt("البريد الإلكتروني للتواصل", "E-mail de contact")}</label><input id="profile-email" type="email" value="${esc(currentUser.email || "")}" ${R.remote ? "readonly" : ""} dir="ltr" autocomplete="email"></div>
              <div class="field"><label>${dt("واتساب", "WhatsApp")}</label><input id="profile-whatsapp" value="${esc(currentUser.whatsapp || "")}" dir="ltr" placeholder="222..." inputmode="tel"></div>
            </div>
            ${R.remote ? `<p class="form-note">${dt("لتغيير بريد الدخول، استخدم لوحة Supabase > Authentication.", "Pour changer l’e-mail de connexion, utilisez Supabase > Authentication.")}</p>` : ""}
            <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-profile-info">${icon("check")} ${dt("حفظ المعلومات", "Enregistrer")}</button></div>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("الصورة الرمزية", "Avatar")}</h3></div><div class="dash-card-body" style="display:flex;align-items:center;gap:15px">
            <div class="image-field" style="width:100px;height:100px;border-radius:50%;overflow:hidden;background:linear-gradient(135deg,#ff6400,#a72396);color:#fff;display:grid;place-items:center;font-size:28px;font-weight:700">
              ${avatarSrc ? `<img src="${esc(avatarSrc)}" alt="" style="width:100%;height:100%;object-fit:cover">` : esc(initials)}
            </div>
            <div>
              <label class="upload-btn">${icon("upload")} ${dt("تغيير الصورة", "Changer l'image")}<input type="file" accept="image/*" id="profile-avatar-upload"></label>
              <p class="form-note">${dt("سيتم تحديث الصورة في جميع أنحاء لوحة التحكم والمتجر", "L'image sera mise à jour dans tout le tableau de bord et la boutique")}</p>
            </div>
          </div></div></article>
        </div>
      </div>

      ${session?.role === "owner" ? `<div class="dash-panel" data-dash-panel="profile-contact">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات التواصل للمتجر", "Infos de contact de la boutique")}</h3></div><div class="dash-card-body dash-form">
          ${biField(dt("اسم المتجر", "Nom de la boutique"), "settings.storeName")}
          ${biField(dt("الشعار", "Slogan"), "settings.tagline")}
          <div class="form-grid">${field(dt("واتساب المتجر", "WhatsApp de la boutique"), "settings.whatsapp", { placeholder: "22246000000" })}${field(dt("البريد الإلكتروني", "E-mail"), "settings.email", { placeholder: "contact@restore.mr" })}</div>
          ${biField(dt("العنوان", "Adresse"), "settings.address", { type: "textarea", rows: 2 })}
          ${biField(dt("المدينة", "Ville"), "settings.city")}
          <div class="form-grid">${field(dt("الرقم الظاهر", "Numéro affiché"), "settings.phoneDisplay", { placeholder: "+222 46 00 00 00" })}${field(dt("رقم الهاتف (دولي)", "Téléphone (international)"), "settings.phone", { placeholder: "+22246000000" })}</div>
          <p class="form-note">${dt("هذه المعلومات تظهر في الفوتر وصفحة التواصل وفي رسالة الواتساب للطلب", "Ces infos apparaissent dans le footer, la page contact et le message WhatsApp de commande")}</p>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-owner-contact">${icon("check")} ${dt("حفظ معلومات المتجر", "Enregistrer les infos boutique")}</button></div>
        </div></article>
      </div>` : ""}

      ${session?.role === "owner" ? `<div class="dash-panel" data-dash-panel="profile-social">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("روابط التواصل الاجتماعي", "Liens réseaux sociaux")}</h3></div><div class="dash-card-body dash-form">
          <p class="form-note">${dt("أضف روابط حساباتك على المنصات الاجتماعية. ستظهر في الفوتر وصفحة التواصل.", "Ajoutez les liens de vos comptes sociaux. Ils apparaîtront dans le footer et la page contact.")}</p>
          <div id="social-links-editor">
            ${(model.settings.social || []).map((s, i) => {
              const platform = String(s.platform || s.id || "");
              const options = ["facebook", "instagram", "tiktok", "youtube", "x", "twitter", "snapchat", "whatsapp", "linkedin", "telegram"];
              return `
              <div class="social-row" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;flex-wrap:wrap">
                <select data-social-platform="${i}" style="flex:1;min-width:130px;max-width:170px">
                  <option value="">${dt("اختر المنصة", "Choisir la plateforme")}</option>
                  ${options.map((id) => `<option value="${id}" ${platform === id ? "selected" : ""}>${id}</option>`).join("")}
                </select>
                <input type="url" data-social-url="${i}" value="${esc(s.href || "")}" placeholder="https://..." style="flex:2;min-width:200px" dir="ltr">
                <button type="button" class="btn btn-sm btn-soft" data-action="remove-social" data-index="${i}" style="padding:6px" aria-label="${dt("حذف", "Supprimer")}">${icon("trash")}</button>
              </div>`;
            }).join("")}
          </div>
          <button type="button" class="btn btn-secondary btn-sm" id="add-social-link">${icon("plus")} ${dt("إضافة رابط", "Ajouter un lien")}</button>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-owner-social">${icon("check")} ${dt("حفظ الروابط", "Enregistrer les liens")}</button></div>
        </div></article>
      </div>` : ""}

      <div class="dash-panel" data-dash-panel="profile-security">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تغيير كلمة المرور", "Changer le mot de passe")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">
            <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input id="sec-current" type="password" autocomplete="current-password"></div>
            <div class="field"><label>${dt("الجديدة", "Nouveau")}</label><input id="sec-next" type="password" minlength="8" autocomplete="new-password"></div>
            <div class="field"><label>${dt("التأكيد", "Confirmer")}</label><input id="sec-confirm" type="password" autocomplete="new-password"></div>
          </div>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="change-own-pwd">${icon("check")} ${dt("تغيير كلمة المرور", "Changer le mot de passe")}</button></div>
        </div></article>
        <article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("الجلسات النشطة", "Sessions actives")}</h3></div><div class="dash-card-body">
          <p class="form-note">${dt("سيتم عرض الجلسات قريباً مع إمكانية إلغاء الجلسات البعيدة", "Les sessions s'afficheront bientôt avec possibilité de révoquer les sessions distantes")}</p>
        </div></article>
      </div>

      <div class="dash-panel" data-dash-panel="profile-payment">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("طرق الدفع المفعلة", "Moyens de paiement actifs")}</h3></div><div class="dash-card-body">
          ${(model.settings.payments || []).filter(p => p.active !== false).map((payment) => `<div class="list-row"><div style="display:flex;align-items:center;gap:10px"><span style="width:32px;height:32px;border-radius:8px;background:${esc(payment.color)};color:#fff;display:grid;place-items:center;font-size:9px;font-weight:800">${esc(String(lng(payment.name)).slice(0, 2))}</span><div><strong>${esc(lng(payment.name))}</strong><br><small>${esc(lng(payment.note))}</small></div></div></div>`).join("")}
        </div></article>
      </div>`;
  }
  function viewTeam() {
    return `
      <div class="dash-view-head"><div><h2>${dt("الفريق", "Équipe")}</h2><p>${dt("صلاحيات المالك والمديرين.", "Accès propriétaire et gérants.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="change-own-password">${dt("كلمة مروري", "Mon mot de passe")}</button><button class="btn btn-primary" data-action="add-manager">${icon("plus")} ${dt("مدير جديد", "Nouveau gérant")}</button></div></div>
      <div class="dash-grid cols-2">
        ${R.managers.map((manager) => `<article class="dash-card"><div class="dash-card-body"><div style="display:flex;align-items:center;gap:10px"><span class="dash-avatar" style="background:${manager.role === "owner" ? "linear-gradient(135deg,#ff6400,#a72396)" : "#375e97"}">${esc(String(lng(manager.name) || manager.username).slice(0, 2).toUpperCase())}</span><div style="flex:1"><strong style="font-size:12px">${esc(lng(manager.name) || manager.username)}</strong><br><small style="font-size:8px;color:var(--soft-muted)">@${esc(manager.username)} · ${manager.role === "owner" ? dt("مالك", "Propriétaire") : dt("مدير", "Gérant")}</small></div><span class="badge-soft ${manager.mustChange ? "orange" : "green"}">${manager.mustChange ? dt("تغيير كلمة المرور", "Changer MDP") : dt("نشط", "Actif")}</span></div><div style="margin-top:11px;padding-top:10px;border-top:1px solid var(--border);display:flex;align-items:center;gap:5px"><span style="font-size:8px;color:var(--soft-muted);direction:ltr">${esc(manager.whatsapp || "—")}</span><span style="flex:1"></span>${manager.username !== session?.username ? `<button class="btn btn-sm btn-soft" data-action="force-password" data-id="${manager.id}">${dt("إلزام التغيير", "Forcer MDP")}</button>` : ""}<button class="btn btn-sm btn-soft" data-action="edit-manager" data-id="${manager.id}">${icon("edit")}</button>${manager.role !== "owner" || R.managers.filter((item) => item.role === "owner").length > 1 ? `<button class="btn btn-sm btn-soft" data-action="delete-manager" data-id="${manager.id}">${icon("trash")}</button>` : ""}</div></div></article>`).join("")}
      </div>
      <article class="dash-card" style="margin-top:14px"><div class="dash-card-body"><h3 style="font-size:12px;margin-bottom:7px">${dt("نصائح الأمان", "Conseils de sécurité")}</h3><ul style="list-style:disc;padding-inline-start:17px;font-size:10px;color:var(--muted);line-height:1.9"><li>${dt("يُطلب من كل مدير تغيير كلمة المرور عند أول دخول.", "Chaque gérant doit changer son mot de passe à la première connexion.")}</li><li>${dt("استخدم Supabase Auth في الإنتاج بدل الحسابات المحلية.", "Utilisez Supabase Auth en production au lieu des comptes locaux.")}</li><li>${dt("راجع سجل النشاط بانتظام.", "Consultez régulièrement le journal d’activité.")}</li></ul></div></article>`;
  }

  let pendingManagerId = null;
  function managerEditor(id) {
    const manager = id ? R.managers.find((item) => item.id === id) : null;
    pendingManagerId = id || null;
    const remote = Boolean(R.remote);
    const usernameField = remote
      ? `<div class="field"><label>${dt("البريد الإلكتروني", "E-mail")}</label><input id="manager-email" type="email" value="${esc(manager?.email || "")}" ${manager ? "readonly" : ""} dir="ltr" placeholder="manager@restore.mr" autocomplete="off"></div>`
      : `<div class="field"><label>${dt("اسم المستخدم", "Nom d’utilisateur")}</label><input id="manager-username" value="${esc(manager?.username || "")}" ${manager ? "readonly" : ""} dir="ltr" placeholder="manager2" autocomplete="off"></div>
         <div class="field"><label>${dt("البريد الإلكتروني (اختياري)", "E-mail (optionnel)")}</label><input id="manager-email" type="email" value="${esc(manager?.email || "")}" dir="ltr" placeholder="manager@restore.mr" autocomplete="off"></div>`;
    openModal(manager ? lng(manager.name) : dt("مدير جديد", "Nouveau gérant"), `
      <div class="form-grid">
        ${usernameField}
        <div class="field"><label>${dt("الدور", "Rôle")}</label><select id="manager-role"><option value="manager" ${manager?.role !== "owner" ? "selected" : ""}>${dt("مدير", "Gérant")}</option><option value="owner" ${manager?.role === "owner" ? "selected" : ""}>${dt("مالك", "Propriétaire")}</option></select></div>
        <div class="field"><label>${dt("الاسم بالعربية", "Nom en arabe")}</label><input id="manager-name-ar" value="${esc(manager?.name?.ar || "")}" dir="rtl"></div>
        <div class="field"><label>Nom en français</label><input id="manager-name-fr" value="${esc(manager?.name?.fr || "")}" dir="ltr"></div>
        <div class="field"><label>WhatsApp</label><input id="manager-whatsapp" value="${esc(manager?.whatsapp || "")}" dir="ltr" placeholder="222..." inputmode="tel"></div>
        ${!manager ? `<div class="field"><label>${dt("كلمة مرور مؤقتة (8 أحرف على الأقل)", "Mot de passe temporaire (8 caractères min.)")}</label><input id="manager-password" type="password" minlength="8" placeholder="********" autocomplete="new-password"></div>` : ""}
      </div>
      <p class="form-note" style="margin-top:10px">${remote
        ? dt("يُنشأ الحساب في Supabase عبر دالة المالك الآمنة. سيُطلب من المدير تغيير كلمة المرور عند أول دخول. لا يمكن تغيير البريد بعد الإنشاء من هنا.", "Le compte est créé dans Supabase via la fonction sécurisée du propriétaire. Le gérant devra changer son mot de passe à la première connexion. L’e-mail ne peut plus être modifié ici.")
        : dt("سيُطلب من المدير الجديد تغيير كلمة المرور عند أول دخول.", "Le nouveau gérant devra changer son mot de passe à la première connexion.")}</p>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-manager">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  async function saveManager() {
    const username = $("#manager-username")?.value.trim() || "";
    const email = $("#manager-email")?.value.trim().toLowerCase() || "";
    const role = $("#manager-role")?.value === "owner" ? "owner" : "manager";
    const nameAr = $("#manager-name-ar")?.value.trim();
    const nameFr = $("#manager-name-fr")?.value.trim();
    const whatsapp = $("#manager-whatsapp")?.value.trim();
    try {
      if (!pendingManagerId) {
        const password = $("#manager-password")?.value || "";
        if (password.length < 8) throw new Error(dt("كلمة المرور 8 أحرف على الأقل", "Mot de passe : 8 caractères minimum"));
        if (R.remote && !email) throw new Error(dt("البريد الإلكتروني مطلوب لإنشاء حساب Supabase", "L’e-mail est requis pour un compte Supabase"));
        if (!R.remote && !username) throw new Error(dt("اسم المستخدم مطلوب", "Le nom d’utilisateur est requis"));
        const created = await R.addManager({ username: username || email, email, password, nameAr, nameFr, role, whatsapp });
        if (!R.remote) model = clone(R.state);
        R.addAudit(`${dt("إضافة مدير", "Gérant ajouté")}: ${created?.email || created?.username || email || username}`);
      } else {
        const current = R.managers.find((item) => item.id === pendingManagerId);
        if (current?.role === "owner" && role !== "owner" && R.managers.filter((item) => item.role === "owner").length <= 1) throw new Error(dt("لا يمكن إزالة صلاحية المالك الوحيد", "Impossible de retirer le dernier propriétaire"));
        R.updateManager(pendingManagerId, {
          name: { ar: nameAr || nameFr || current?.username || "", fr: nameFr || nameAr || current?.username || "" },
          role,
          whatsapp,
          ...(!R.remote && email ? { email } : {})
        });
        R.addAudit(`${dt("تعديل مدير", "Gérant modifié")}: ${current?.username || ""}`);
      }
      if (R.remote) await R.refreshStaff().catch(() => {});
      closeModal(); renderRoute(); toast(dt("تم حفظ الفريق", "Équipe enregistrée"), "good");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  function changeOwnPasswordModal() {
    openModal(dt("تغيير كلمة المرور", "Changer le mot de passe"), `
      <div class="dash-form">
        <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input id="own-current" type="password"></div>
        <div class="form-grid"><div class="field"><label>${dt("الجديدة", "Nouveau")}</label><input id="own-next" type="password" minlength="8"></div><div class="field"><label>${dt("التأكيد", "Confirmer")}</label><input id="own-confirm" type="password"></div></div>
        <div class="field"><label>WhatsApp</label><input id="own-whatsapp" value="${esc(R.managers.find((item) => item.username === session?.username)?.whatsapp || "")}" dir="ltr"></div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-own-password">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  async function saveOwnPassword() {
    const next = $("#own-next")?.value || "";
    if (next !== ($("#own-confirm")?.value || "")) return toast(dt("كلمتا المرور غير متطابقتين", "Les mots de passe diffèrent"), "error");
    try {
      await R.changePassword(session.username, $("#own-current")?.value || "", next, $("#own-whatsapp")?.value || "");
      session = R.currentSession();
      closeModal(); toast(dt("تم تحديث كلمة المرور", "Mot de passe mis à jour"), "good");
    } catch (error) { toast(error.message, "error"); }
  }

  /* --------------------------------------------------------------------------
     Reports
     -------------------------------------------------------------------------- */
  let reportRange = "30";
  function reportOrders() {
    const orders = orderList().filter((order) => order.status !== "cancelled" && order.status !== "returned");
    if (reportRange === "all") return orders;
    const days = Number(reportRange) || 30;
    const cutoff = Date.now() - days * 864e5;
    return orders.filter((order) => Date.parse(order.createdAt) >= cutoff);
  }

  function viewReports() {
    const orders = reportOrders();
    const revenue = revenueOfOrders(orders);
    const items = orders.flatMap((order) => order.items || []);
    const itemCount = items.reduce((sum, item) => sum + Number(item.qty || 1), 0);
    const avg = orders.length ? revenue / orders.length : 0;
    const cityMap = {};
    orders.forEach((order) => {
      const city = order.customer?.city || "—";
      cityMap[city] = cityMap[city] || { count: 0, revenue: 0 };
      cityMap[city].count += 1;
      cityMap[city].revenue += Number(order.total) || 0;
    });
    const productMap = {};
    items.forEach((item) => {
      const key = item.handle || item.title;
      productMap[key] = productMap[key] || { title: item.title, image: item.image, qty: 0, revenue: 0 };
      productMap[key].qty += Number(item.qty || 1);
      productMap[key].revenue += Number(item.line || 0);
    });
    const topProducts = Object.values(productMap).sort((a, b) => b.revenue - a.revenue).slice(0, 8);
    const topCities = Object.entries(cityMap).sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 8);
    const maxCity = Math.max(1, ...topCities.map(([, data]) => data.revenue));
    const abandoned = R.getAbandoned().length;
    const conversion = orders.length + abandoned ? Math.round(orders.length / (orders.length + abandoned) * 100) : 0;
    const days = [...Array(7)].map((_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const key = date.toISOString().slice(0, 10);
      const total = orders.filter((order) => String(order.createdAt).slice(0, 10) === key).reduce((sum, order) => sum + Number(order.total || 0), 0);
      return { label: date.toLocaleDateString(dashLang === "ar" ? "ar-MR" : "fr-FR", { weekday: "short" }), total };
    });
    const maxDay = Math.max(1, ...days.map((day) => day.total));
    const low = lowStockProducts().slice(0, 8);
