/* extracted dashboard view */
export function viewSettings(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const settings = model.settings;
    return `
      <div class="dash-view-head"><div><h2>${dt("الإعدادات", "Réglages")}</h2><p>${dt("SEO، واتساب، الحماية والتكامل.", "SEO, WhatsApp, sécurité et intégration.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="discard-draft">${dt("إلغاء المسودة", "Annuler le brouillon")}</button><button class="btn btn-primary" data-action="save-draft">${icon("check")} ${dt("حفظ", "Enregistrer")}</button></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="settings-seo">SEO</button><button data-dash-tab="settings-whatsapp">WhatsApp</button><button data-dash-tab="settings-security">${dt("الحماية", "Sécurité")}</button><button data-dash-tab="settings-advanced">${dt("متقدم", "Avancé")}</button></div>
      <div class="dash-panel active" data-dash-panel="settings-seo">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("محركات البحث", "Référencement")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("عنوان SEO", "Titre SEO"), "settings.seo.title")}
            ${biField(dt("وصف SEO", "Description SEO"), "settings.seo.description", { type: "textarea", rows: 3 })}
            <div class="form-grid">${field(dt("الرابط الأساسي", "URL de base"), "settings.baseUrl", { placeholder: "https://restore.mr" })}${field(dt("صورة المشاركة", "Image de partage"), "settings.seo.image", { placeholder: "assets/img/..." })}</div>
            <p class="form-note">${dt("يُستخدم عنوان ووصف SEO في كل صفحة، وتُضاف بيانات المنتج المنظمة تلقائيًا.", "Titres et descriptions sont appliqués par page ; les données produit structurées sont ajoutées automatiquement.")}</p>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("بكسلات التحليلات", "Pixels analytiques")}</h3></div><div class="dash-card-body dash-form">
            ${field("Meta Pixel ID", "settings.pixels.meta", { placeholder: "1234567890" })}
            ${field("TikTok Pixel ID", "settings.pixels.tiktok", { placeholder: "C..." })}
            ${field("Google Analytics ID", "settings.pixels.ga", { placeholder: "G-XXXXXXX" })}
            <p class="form-note">${dt("تُحمّل الأكواد تلقائيًا في المتجر بعد النشر. لا تضع أكوادًا كاملة، فقط المعرف.", "Les scripts sont chargés automatiquement. Indiquez uniquement l’identifiant.")}</p>
            ${directToggle(dt("تفعيل PWA للجوال", "Activer la PWA mobile"), "settings.pwa", settings.pwa !== false)}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-whatsapp">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("رسالة الطلب", "Message de commande")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("القالب الكامل", "Modèle complet"), "settings.orderTemplate", { type: "textarea", rows: 13 })}
            <p class="form-note">${dt("المتغيرات: {store} {order_id} {name} {phone} {city} {address} {payment} {items} {subtotal} {shipping} {discount} {total} {notes}", "Variables : {store} {order_id} {name} {phone} {city} {address} {payment} {items} {subtotal} {shipping} {discount} {total} {notes}")}</p>
            ${field("WhatsApp", "settings.whatsapp", { hint: dt("الرقم الذي تستقبل عليه الطلبات", "Numéro qui reçoit les commandes") })}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("رسائل المتابعة", "Messages de suivi")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("تأكيد الطلب", "Confirmation"), "settings.whatsappTemplates.confirm", { type: "textarea", rows: 3 })}
            ${biField(dt("تم الشحن", "Expédition"), "settings.whatsappTemplates.shipped", { type: "textarea", rows: 3 })}
            ${biField(dt("تم التسليم", "Livraison"), "settings.whatsappTemplates.delivered", { type: "textarea", rows: 3 })}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-security">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("الحماية من الطلبات المزعجة", "Protection anti-spam")}</h3></div><div class="dash-card-body dash-form">
            ${field(dt("الفاصل الزمني بين الطلبات (ثانية)", "Délai entre commandes (secondes)"), "settings.rateLimitSeconds", { type: "number" })}
            <div class="field"><label>${dt("قائمة الحظر (رقم في كل سطر)", "Liste de blocage (un numéro par ligne)")}</label><textarea data-blocklist rows="7" dir="ltr">${esc((settings.blocklist || []).join("\n"))}</textarea></div>
            <p class="form-note">${dt("تُطبق القائمة على أرقام الهواتف بصيغة 222XXXXXXXX.", "La liste s’applique aux numéros au format 222XXXXXXXX.")}</p>
            ${directToggle(dt("طلب رمز تحقق OTP (قريبًا)", "Vérification OTP (bientôt)"), "settings.otp.enabled", settings.otp?.enabled)}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("المخزون والمنتجات", "Stock & produits")}</h3></div><div class="dash-card-body dash-form">
            ${field(dt("حد المخزون المنخفض", "Seuil de stock faible"), "settings.lowStockThreshold", { type: "number" })}
            ${directToggle(dt("إخفاء المنتجات المنتهية تلقائيًا", "Masquer automatiquement les produits épuisés"), "settings.autoHideOutOfStock", settings.autoHideOutOfStock !== false)}
            ${directToggle(dt("إظهار بيانات تجريبية حتى إدخال بياناتك", "Afficher les données de démo jusqu’à vos données"), "settings.fakeData", settings.fakeData !== false)}
            ${directToggle(dt("الوضع الليلي", "Mode sombre"), "settings.darkMode", settings.darkMode !== false)}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-advanced">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("التكامل والاستضافة", "Intégration & hébergement")}</h3></div><div class="dash-card-body">
            <div class="publish-modal-list">
              <div><span>${dt("وضع البيانات", "Mode données")}</span><strong>${R.remote ? "Supabase" : dt("محلي تجريبي", "Local démo")}</strong></div>
              <div><span>Supabase URL</span><strong dir="ltr" style="font-size:8px">${esc(R.config.supabaseUrl || dt("غير مهيأ", "Non configuré"))}</strong></div>
              <div><span>${dt("المشروع", "Projet")}</span><strong>${dt("ريستور موريتانيا", "Restore Mauritanie")}</strong></div>
              <div><span>${dt("نطاق البيع", "Périmètre")}</span><strong>MRU · Mauritanie</strong></div>
            </div>
            <div class="field" style="margin-top:12px"><label>${dt("العملة المعروضة افتراضيًا", "Affichage de la devise par défaut")}</label><select data-currency-mode>
              <option value="new" ${R.getCurrencyMode() === "new" ? "selected" : ""}>${dt("أوقية جديدة (MRU)", "Nouvelle ouguiya (MRU)")}</option>
              <option value="old" ${R.getCurrencyMode() === "old" ? "selected" : ""}>${dt("أوقية قديمة (MRO) = القيمة × 10", "Ancienne ouguiya (MRO) = valeur × 10")}</option>
            </select><p class="form-note">${dt("يمكن للزائر تبديلها من رأس المتجر. الأسعار محفوظة بالأوقية الجديدة.", "Le visiteur peut la changer dans l’en-tête. Les prix restent en nouvelle ouguiya.")}</p></div>
            <p class="form-note" style="margin-top:11px">${dt("لربط Supabase: ضع URL و anon key في config.js ثم نفّذ ملف supabase/schema.sql. ستتزامن الطلبات والحالة تلقائيًا.", "Pour Supabase : renseignez URL et anon key dans config.js puis exécutez supabase/schema.sql.")}</p>
            <a class="btn btn-soft btn-sm" href="supabase/schema.sql" target="_blank">${dt("عرض ملف SQL", "Voir le fichier SQL")}</a>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("منطقة الخطر", "Zone sensible")}</h3></div><div class="dash-card-body">
            <p style="font-size:10px;color:var(--muted);line-height:1.8;margin-bottom:12px">${dt("إعادة تعيين البيانات التجريبية ستحذف الطلبات والمسودات والحسابات المحلية. لا يمكن التراجع.", "Réinitialiser la démo supprime commandes, brouillons et comptes locaux. Action irréversible.")}</p>
            <div style="display:flex;gap:7px;flex-wrap:wrap"><button class="btn btn-soft btn-sm" data-action="publish">${icon("publish")} ${dt("نشر الآن", "Publier")}</button><button class="btn btn-danger btn-sm" data-action="reset-demo">${icon("trash")} ${dt("إعادة تعيين التجربة", "Réinitialiser la démo")}</button></div>
          </div></article>
        </div>
      </div>`;
  
  }).call(ctx);
}
