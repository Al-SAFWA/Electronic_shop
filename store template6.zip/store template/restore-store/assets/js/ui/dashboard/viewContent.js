/* extracted dashboard view */
export function viewContent(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const settings = model.settings;
    return `
      <div class="dash-view-head">
        <div><h2>${dt("نصوص المتجر", "Textes & contenu")}</h2><p>${dt("كل نص يظهر في المتجر قابل للتعديل هنا بالعربية والفرنسية.", "Chaque texte visible sur la boutique est modifiable ici en arabe et en français.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-primary" data-action="save-draft">${icon("check")} ${dt("حفظ المسودة", "Enregistrer")}</button></div>
      </div>
      <div class="dash-tabs">
        <button class="active" type="button" data-dash-tab="content-main">${dt("الهوية والنصوص", "Identité & textes")}</button>
        <button type="button" data-dash-tab="content-contact">${dt("التواصل والمواعيد", "Contact & horaires")}</button>
        <button type="button" data-dash-tab="content-trust">${dt("شريط الثقة", "Barre de confiance")}</button>
        <button type="button" data-dash-tab="content-nav">${dt("القائمة", "Navigation")}</button>
        <button type="button" data-dash-tab="content-footer">${dt("التذييل", "Pied de page")}</button>
      </div>
      <div class="dash-panel active" data-dash-panel="content-main">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("النصوص الأساسية", "Textes principaux")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("اسم المتجر", "Nom de la boutique"), "settings.storeName")}
            ${biField(dt("الشعار النصي", "Slogan"), "settings.tagline")}
            ${biField(dt("شريط الإعلان", "Bandeau d’annonce"), "settings.announcement", { type: "textarea", rows: 2 })}
            ${biField(dt("عنوان الفئات", "Titre catégories"), "settings.categoriesTitle")}
            ${biField(dt("عنوان خدمة العملاء", "Titre service"), "settings.serviceTitle", { type: "textarea", rows: 2 })}
            ${biField(dt("عنوان آراء العملاء", "Titre avis"), "settings.reviewsTitle")}
            ${biField(dt("عنوان الصحافة", "Titre presse"), "settings.pressTitle")}
            ${biField(dt("نص المجدد", "Texte reconditionné"), "settings.renewalText")}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام مخصصة", "Sections personnalisées")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("عنوان الثقة", "Titre confiance"), "settings.trustTitle")}
            ${biField(dt("عنوان المجتمع", "Titre communauté"), "settings.communityTitle")}
            ${biField(dt("ملاحظة الشحن", "Note livraison"), "settings.shippingNote", { type: "textarea", rows: 2 })}
            ${field(dt("الحد الأدنى للشحن المجاني (MRU)", "Seuil livraison gratuite (MRU)"), "settings.freeShippingOver", { type: "number" })}
            ${field(dt("رقم الهاتف للعرض", "Téléphone affiché"), "settings.phoneDisplay")}
            ${field("WhatsApp", "settings.whatsapp", { hint: dt("أرقام فقط مع رمز الدولة، مثال 22246000000", "Chiffres uniquement avec indicatif, ex. 22246000000") })}
            ${field(dt("البريد الإلكتروني", "E-mail"), "settings.email", { type: "email" })}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="content-contact">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات التواصل", "Coordonnées")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("العنوان", "Adresse"), "settings.address", { type: "textarea", rows: 2 })}
            ${field(dt("الهاتف", "Téléphone"), "settings.phone")}
            ${field(dt("واتساب", "WhatsApp"), "settings.whatsapp")}
            ${field(dt("بريد الدعم", "E-mail support"), "settings.email", { type: "email" })}
            ${field(dt("المنطقة الزمنية", "Fuseau horaire"), "settings.timezone")}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("ساعات العمل والحالة", "Horaires et état")}</h3></div><div class="dash-card-body dash-form">
            <div class="form-grid">${field(dt("الفتح", "Ouverture"), "settings.hours.open", { type: "time" })}${field(dt("الإغلاق", "Fermeture"), "settings.hours.close", { type: "time" })}</div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.hours.closed" data-type="bool" ${settings.hours.closed ? "checked" : ""}><span></span></label><span>${dt("إغلاق المتجر مؤقتًا", "Fermer temporairement")}</span></div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.hours.maintenance" data-type="bool" ${settings.hours.maintenance ? "checked" : ""}><span></span></label><span>${dt("وضع الصيانة", "Mode maintenance")}</span></div>
            ${biField(dt("رسالة الإغلاق", "Message de fermeture"), "settings.closedMessage", { type: "textarea", rows: 2 })}
            <p class="form-note">${dt("تظهر حالة المتجر تلقائيًا للزوار حسب ساعات العمل. الأوقات بتوقيت نواكشوط.", "L’état est calculé selon les horaires. Heure de Nouakchott.")}</p>
            <p class="form-note">${dt("ساعات اليوم", "Aujourd’hui")}: <strong>${R.isStoreOpen() ? dt("مفتوح", "Ouvert") : dt("مغلق", "Fermé")}</strong></p>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="content-trust">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("شريط الثقة", "Barre de confiance")}</h3><button data-action="add-trust">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="dash-form">${(settings.trustBar || []).map((item, index) => `<div class="form-section"><div class="form-grid"><div class="field"><label>${dt("الأيقونة", "Icône")}</label><input data-path="settings.trustBar.${index}.icon" value="${esc(item.icon)}"></div><div class="field"><label>${dt("العربي", "Arabe")}</label><input data-path="settings.trustBar.${index}.label.ar" value="${esc(item.label?.ar || "")}" dir="rtl"></div><div class="field"><label>Français</label><input data-path="settings.trustBar.${index}.label.fr" value="${esc(item.label?.fr || "")}" dir="ltr"></div><div style="display:flex;align-items:flex-end"><button class="btn btn-sm btn-danger" data-action="remove-trust" data-index="${index}">${icon("trash")}</button></div></div></div>`).join("")}</div>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="content-nav">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("قائمة التنقل", "Navigation")}</h3><button data-action="add-nav">${icon("plus")} ${dt("إضافة عنصر", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="list-editor">${(settings.navigation || []).map((item, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(item.label))}</strong><small class="handle">${esc(item.href)}</small></div>${directToggle("", `settings.navigation.${index}.visible`, item.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-nav" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-nav" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
          <p class="form-note" style="margin-top:10px">${dt("كل عنصر يمكن أن يحتوي على قائمة فرعية. استخدم محرر العنصر لإضافة روابط مثل S24 Series أو iPhone 16.", "Chaque entrée peut contenir un sous-menu. Utilisez l’éditeur pour ajouter des liens comme Galaxy S24.")}</p>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="content-footer">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أعمدة التذييل", "Colonnes du pied de page")}</h3></div><div class="dash-card-body dash-form">
          ${(settings.footerColumns || []).map((column, index) => `<div class="form-section"><h4>${dt("عمود", "Colonne")} ${index + 1}</h4><div class="form-grid">${["ar", "fr"].map((language) => `<div class="field"><label>${language.toUpperCase()}</label><input data-path="settings.footerColumns.${index}.title.${language}" value="${esc(column.title?.[language] || "")}" dir="${language === "ar" ? "rtl" : "ltr"}"></div>`).join("")}</div><div class="field" style="margin-top:8px"><label>${dt("روابط (اسم|رابط في كل سطر)", "Liens (nom|URL par ligne)")}</label><textarea rows="4" data-lines-path="settings.footerColumns.${index}.links">${esc((column.links || []).map((link) => `${link.label?.ar || ""}|${link.label?.fr || ""}|${link.href}`).join("\n"))}</textarea></div></div>`).join("")}
          <button class="btn btn-soft" data-action="add-footer-column">${icon("plus")} ${dt("إضافة عمود", "Ajouter une colonne")}</button>
        </div></article>
      </div>`;
  }

  function navEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `nav-${Date.now().toString(36)}`, label: { ar: "عنصر جديد", fr: "Nouvel élément" }, href: "collection.html?handle=all", visible: true, sub: [] } : clone(model.settings.navigation[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("عنصر قائمة", "Élément de navigation") : lng(buffer.label), `
      <div class="form-grid">
        ${editBi(dt("الاسم", "Nom"), "label", buffer.label)}
        ${editInput(dt("الرابط", "Lien"), "href", { value: buffer.href })}
        <div class="field span-2"><label>${dt("قائمة فرعية (اسم عربي|اسم فرنسي|رابط في كل سطر)", "Sous-menu (nom AR|nom FR|URL par ligne)")}</label><textarea rows="6" data-subnav>${esc((buffer.sub || []).map((item) => `${item.label?.ar || ""}|${item.label?.fr || ""}|${item.href}`).join("\n"))}</textarea></div>
        ${editToggle(dt("ظاهر", "Visible"), "visible", buffer.visible !== false)}
      </div>`, {
      footer: editorFooter(!isNew, "delete-nav-buffer"),
      onMount: () => { pendingNavIndex = isNew ? null : index; }
    });
  }
  let pendingNavIndex = null;

  function saveNavEditor() {
    const item = editBuffer;
    if (!item) return;
    const subNode = $("[data-subnav]");
    item.sub = (subNode?.value || "").split("\n").map((line) => {
      const [ar, fr, href] = line.split("|").map((part) => part.trim());
      return ar && href ? { label: { ar, fr: fr || ar }, href } : null;
    }).filter(Boolean);
    if (pendingNavIndex == null) model.settings.navigation.push(item);
    else model.settings.navigation[pendingNavIndex] = item;
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(dt("تم حفظ عنصر القائمة", "Navigation enregistrée"), "good");
  }

  /* --------------------------------------------------------------------------
     Homepage
     -------------------------------------------------------------------------- */
  const PAGE_SECTION_LABELS = {
    hero: { ar: "السلايدر الرئيسي", fr: "Hero / Slider" },
    trust: { ar: "شريط الثقة", fr: "Barre de confiance" },
    renewed: { ar: "ما معنى مجدد", fr: "Reconditionné" },
    categories: { ar: "الفئات", fr: "Catégories" },
    offer: { ar: "عرض بنكيلي", fr: "Offre Bankily" },
    products: { ar: "أقسام المنتجات", fr: "Sections produits" },
    sustain: { ar: "الاستدامة", fr: "Durabilité" },
    service: { ar: "الخدمات", fr: "Services" },
    video: { ar: "المجتمع والفيديو", fr: "Communauté & vidéo" },
    reviews: { ar: "آراء العملاء", fr: "Avis clients" },
    press: { ar: "الصحافة", fr: "Presse" }
  
  }).call(ctx);
}
