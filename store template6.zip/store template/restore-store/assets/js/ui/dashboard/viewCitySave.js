/* extracted dashboard view */
export function viewCitySave(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    if (!editBuffer) return;
    if (pendingCityIndex == null) model.settings.cities.push(editBuffer);
    else model.settings.cities[pendingCityIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المدينة", "Ville enregistrée"), "good");
  
  }).call(ctx);
}
