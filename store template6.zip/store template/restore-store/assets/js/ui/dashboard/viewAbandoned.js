/* extracted dashboard view */
export function viewAbandoned(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const all = R.getAbandoned();
    const list = all.filter((item) => abandonedFilter === "all" || item.status === abandonedFilter);
    return `
      <div class="dash-view-head">
        <div><h2>${dt("السلال المتروكة", "Paniers abandonnés")}</h2><p>${dt("بيانات تُحفظ أثناء ملء العميل لصفحة الدفع.", "Données enregistrées pendant la saisie au checkout.")}</p></div>
      </div>
      <div class="dash-toolbar"><div class="segmented">${[["open", dt("مفتوحة", "Ouverts")], ["contacted", dt("تم التواصل", "Contactés")], ["closed", dt("مغلقة", "Fermés")], ["all", dt("الكل", "Tous")]].map(([id, label]) => `<button data-abandoned-filter="${id}" class="${abandonedFilter === id ? "active" : ""}">${label}</button>`).join("")}</div><div class="spacer"></div><span class="badge-soft orange">${all.filter((item) => item.status === "open").length} ${dt("مفتوحة", "ouverts")}</span></div>
      <div class="dash-card">${list.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("العميل", "Client")}</th><th>${dt("الهاتف", "Téléphone")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("السلة", "Panier")}</th><th>${dt("القيمة", "Valeur")}</th><th>${dt("التاريخ", "Date")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead><tbody>
        ${list.map((item) => `<tr>
          <td><strong>${esc(item.name || dt("زائر", "Visiteur"))}</strong></td>
          <td dir="ltr">${esc(item.phone || "—")}</td>
          <td>${esc(item.city || "—")}</td>
          <td>${(item.items || []).map((product) => `${esc(product.title)} ×${product.qty}`).join("<br>") || "—"}</td>
          <td class="price">${money(item.subtotal || 0)}</td>
          <td>${esc(fmtDateTime(item.updatedAt || item.createdAt))}</td>
          <td><span class="badge-soft">${esc(item.status || "open")}</span></td>
          <td><div class="cell-actions">
            ${item.phone ? `<a class="btn btn-sm btn-soft" href="https://wa.me/${digits(item.phone)}?text=${encodeURIComponent(dt("مرحباً، رأينا أنك لم تكمل طلبك من ريستور. هل نساعدك؟", "Bonjour, nous avons vu que vous n’avez pas finalisé votre commande Restore. Pouvons-nous vous aider ?"))}" target="_blank" rel="noopener">${icon("whatsapp")}</a>` : ""}
            <button class="btn btn-sm btn-soft" data-action="abandoned-status" data-id="${esc(item.id)}" data-status="contacted">${dt("تم التواصل", "Contacté")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-abandoned" data-id="${esc(item.id)}">${icon("trash")}</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>` : `<div class="table-empty">${icon("abandoned")}<p>${dt("لا توجد سلال متروكة.", "Aucun panier abandonné.")}</p></div>`}</div>`;
  }

  /* --------------------------------------------------------------------------
     Products
     -------------------------------------------------------------------------- */
  function filteredProducts() {
    const needle = R.normalizeText(productSearch);
    return productList().filter((product) => {
      if (productCategory !== "all" && !(product.collections || []).includes(productCategory)) return false;
      if (productStock === "low" && Number(product.stock) > Number(model.settings.lowStockThreshold || 2)) return false;
      if (productStock === "out" && Number(product.stock) > 0) return false;
      if (!needle) return true;
      return R.normalizeText([product.title, product.handle, product.vendor, product.type, product.sku].join(" ")).includes(needle);
    });
  
  }).call(ctx);
}
