/* extracted dashboard view */
export function viewCategories(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    return `
      <div class="dash-view-head">
        <div><h2>${dt("الفئات", "Catégories")}</h2><p>${dt("تظهر الفئات في القائمة والصفحة الرئيسية.", "Les catégories apparaissent dans le menu et l’accueil.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-primary" data-action="add-category">${icon("plus")} ${dt("فئة جديدة", "Nouvelle catégorie")}</button></div>
      </div>
      <div class="dash-grid cols-2">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("فئات المتجر", "Catégories boutique")}</h3><span class="badge-soft">${model.theme.categories.length}</span></div><div class="dash-card-body">
          <div class="list-editor">${model.theme.categories.map((category, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(category.label))}</strong><small class="handle">${esc(category.handle)}</small></div><button class="btn btn-sm btn-soft" data-action="edit-category" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-category" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
        </div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("المجموعات", "Collections")}</h3><span class="badge-soft">${model.collections.length}</span></div><div class="dash-card-body">
          <div class="list-editor">${model.collections.map((collection, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(collection.title))}</strong><small class="handle">${esc(collection.handle)}</small></div>${directToggle("", `collections.${index}.visible`, collection.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-collection" data-index="${index}">${icon("edit")}</button></div>`).join("")}</div>
        </div></article>
      </div>`;
  }

  function categoryEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { label: { ar: "فئة جديدة", fr: "Nouvelle catégorie" }, handle: `category-${Date.now().toString(36)}`, image: "assets/img/category-iphone.png" } : clone(model.theme.categories[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("فئة جديدة", "Nouvelle catégorie") : lng(buffer.label), `
      <div class="form-grid">
        ${editBi(dt("اسم الفئة", "Nom"), "label", buffer.label)}
        <div class="field"><label>${dt("المعرف", "Identifiant")}</label><input data-edit-path="handle" value="${esc(buffer.handle)}" dir="ltr"></div>
        <div class="span-2">${imageEditor(dt("صورة الفئة", "Image"), "image", buffer.image)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-category-buffer"),
      onMount: () => { pendingCategoryIndex = isNew ? null : index; }
    });
  }
  let pendingCategoryIndex = null;

  function saveCategoryEditor() {
    const item = editBuffer;
    if (!item) return;
    if (pendingCategoryIndex == null) model.theme.categories.push(item);
    else model.theme.categories[pendingCategoryIndex] = item;
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(dt("تم حفظ الفئة", "Catégorie enregistrée"), "good");
  }

  function collectionEditor(index) {
    const buffer = clone(model.collections[index]);
    editBuffer = buffer;
    openModal(lng(buffer.title), `
      <div class="form-grid">${editBi(dt("اسم المجموعة", "Nom de la collection"), "title", buffer.title)}<div class="field"><label>${dt("المعرف", "Identifiant")}</label><input value="${esc(buffer.handle)}" readonly dir="ltr"></div></div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-collection" data-index="${index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }
  /* --------------------------------------------------------------------------
     Storefront content and navigation
     -------------------------------------------------------------------------- */
  function isoLocal(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const pad = (number) => String(number).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function directImageEditor(label, path, value = "") {
    return `<div class="field"><label>${esc(label)}</label><div class="image-field">
      <span class="image-preview"><img data-preview-for="${esc(path)}" src="${esc(value || "assets/img/favicon.svg")}" alt=""></span>
      <div class="grow">
        <input data-path="${esc(path)}" value="${esc(value)}" placeholder="assets/img/...">
        <label class="upload-btn">${icon("upload")} ${dt("رفع صورة", "Téléverser")}<input type="file" accept="image/*" data-upload-path="${esc(path)}" data-upload-target="direct"></label>
      </div>
    </div></div>`;
  
  }).call(ctx);
}
