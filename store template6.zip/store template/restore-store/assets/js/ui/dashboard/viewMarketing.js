/* extracted dashboard view */
export function viewMarketing(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const offer = (model.settings.offers || []).find((item) => item.id === "bankily") || (model.settings.offers || [])[0] || {};
    return `
      <div class="dash-view-head"><div><h2>${dt("العروض والتسويق", "Offres & marketing")}</h2><p>${dt("كوبونات، عرض بنكيلي والبانر الترويجي.", "Coupons, offre Bankily et bannière promo.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="marketing-offer">${dt("عرض بنكيلي", "Offre Bankily")}</button><button data-dash-tab="marketing-coupons">${dt("الكوبونات", "Coupons")}</button><button data-dash-tab="marketing-banner">${dt("بانر وإعلان", "Bannière & annonce")}</button></div>
      <div class="dash-panel active" data-dash-panel="marketing-offer">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("عرض الدفع عبر بنكيلي", "Offre Bankily")}</h3><span class="badge-soft orange">-10%</span></div><div class="dash-card-body dash-form">
            <div class="form-grid">${biField(dt("العنوان", "Titre"), "settings.offers.0.title")}${biField(dt("الوصف", "Sous-titre"), "settings.offers.0.subtitle", { type: "textarea", rows: 2 })}</div>
            <div class="form-grid">${field(dt("كود الخصم", "Code promo"), "settings.offers.0.code")}${field(dt("نهاية العرض", "Fin de l’offre"), "settings.offers.0.endsAt", { type: "datetime-local" })}</div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.offers.0.active" data-type="bool" ${offer.active !== false ? "checked" : ""}><span></span></label><span>${dt("العرض نشط", "Offre active")}</span></div>
            ${biField(dt("نص عرض الدفع في المنتج", "Texte offre au produit"), "settings.paymentOffer", { type: "textarea", rows: 2 })}
            ${field(dt("كود بانكيلي", "Code Bankily"), "settings.paymentOfferCode")}
            <p class="form-note">${dt("يُعرض العد التنازلي تلقائيًا حتى تاريخ النهاية. الكود يُطبق عند اختيار الدفع عبر بنكيلي.", "Le compte à rebours s’affiche jusqu’à la date de fin. Le code s’applique avec Bankily.")}</p>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معاينة العرض", "Aperçu de l’offre")}</h3></div><div class="dash-card-body">
            <div style="border-radius:14px;padding:24px;background:linear-gradient(135deg,#15151d,#3b2235);color:#fff">
              <span style="font-size:9px;letter-spacing:.1em;color:#ffb38b">BANKILY · -10%</span>
              <h3 style="font-size:21px;margin:9px 0 7px;line-height:1.2">${esc(lng(offer.title))}</h3>
              <p style="font-size:10px;color:rgba(255,255,255,.65);line-height:1.6">${esc(lng(offer.subtitle))}</p>
              <span style="display:inline-block;margin-top:13px;border:1px dashed rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;letter-spacing:.12em">${esc(offer.code || "BANKILY10")}</span>
            </div>
            <p class="form-note" style="margin-top:10px">${dt("ينتهي", "Se termine")}: ${esc(offer.endsAt ? fmtDateTime(offer.endsAt) : "—")}</p>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="marketing-coupons">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("كوبونات الخصم", "Coupons")}</h3><button data-action="add-coupon">${icon("plus")} ${dt("كوبون جديد", "Nouveau coupon")}</button></div><div class="dash-card-body">
          <div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الكود", "Code")}</th><th>${dt("النوع", "Type")}</th><th>${dt("القيمة", "Valeur")}</th><th>${dt("الحد الأدنى", "Minimum")}</th><th>${dt("الانتهاء", "Expiration")}</th><th>${dt("نشط", "Actif")}</th><th></th></tr></thead><tbody>
            ${(model.settings.coupons || []).map((coupon, index) => `<tr><td><strong style="direction:ltr">${esc(coupon.code)}</strong></td><td>${coupon.type === "percent" ? dt("نسبة", "Pourcentage") : dt("ثابت", "Fixe")}</td><td>${coupon.type === "percent" ? `${coupon.value}%` : money(coupon.value)}</td><td>${money(coupon.minTotal || 0)}</td><td>${coupon.expiresAt ? esc(fmtDate(coupon.expiresAt)) : "—"}</td><td><label class="toggle"><input type="checkbox" data-coupon-active="${index}" ${coupon.active !== false ? "checked" : ""}><span></span></label></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-coupon" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-coupon" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
          </tbody></table></div>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="marketing-banner">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("البانر والرسائل", "Bannière & messages")}</h3></div><div class="dash-card-body dash-form">
          ${biField(dt("شريط الإعلان العلوي", "Bandeau haut"), "settings.announcement", { type: "textarea", rows: 2 })}
          <div class="form-grid">${biField(dt("رسالة المتجر المغلق", "Message boutique fermée"), "settings.closedMessage", { type: "textarea", rows: 2 })}${biField(dt("عنوان عرض الرئيسية", "Titre offre accueil"), "settings.paymentOffer", { type: "textarea", rows: 2 })}</div>
          ${biField(dt("عنوان قسم الاستدامة", "Titre durabilité"), "settings.sustainabilityTitle")}
          <p class="form-note">${dt("البانر يعرض تلقائيًا في أعلى كل صفحات المتجر. يمكن إخفاؤه من إعدادات الواجهة.", "La bannière s’affiche en haut du site. Masquable depuis l’apparence.")}</p>
        </div></article>
      </div>`;
  }

  function couponEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `coupon-${Date.now().toString(36)}`, code: "RESTORE10", type: "percent", value: 10, active: true, minTotal: 0, expiresAt: "" } : clone(model.settings.coupons[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("كوبون جديد", "Nouveau coupon") : buffer.code, `
      <div class="form-grid">
        ${editInput(dt("الكود", "Code"), "code", { value: buffer.code })}
        <div class="field"><label>${dt("النوع", "Type")}</label><select data-edit-path="type"><option value="percent" ${buffer.type === "percent" ? "selected" : ""}>${dt("نسبة مئوية", "Pourcentage")}</option><option value="fixed" ${buffer.type === "fixed" ? "selected" : ""}>${dt("مبلغ ثابت", "Montant fixe")}</option></select></div>
        ${editInput(dt("القيمة", "Valeur"), "value", { type: "number", value: buffer.value })}
        ${editInput(dt("الحد الأدنى للطلب", "Minimum de commande"), "minTotal", { type: "number", value: buffer.minTotal || 0 })}
        ${editInput(dt("تاريخ الانتهاء", "Date d’expiration"), "expiresAt", { type: "date", value: buffer.expiresAt ? String(buffer.expiresAt).slice(0, 10) : "" })}
        <div class="span-2">${editToggle(dt("نشط", "Actif"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-coupon" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  
  }).call(ctx);
}
