/* extracted dashboard view */
export function viewTeam(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    return `
      <div class="dash-view-head"><div><h2>${dt("الفريق", "Équipe")}</h2><p>${dt("صلاحيات المالك والمديرين.", "Accès propriétaire et gérants.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="change-own-password">${dt("كلمة مروري", "Mon mot de passe")}</button><button class="btn btn-primary" data-action="add-manager">${icon("plus")} ${dt("مدير جديد", "Nouveau gérant")}</button></div></div>
      <div class="dash-grid cols-2">
        ${R.managers.map((manager) => `<article class="dash-card"><div class="dash-card-body"><div style="display:flex;align-items:center;gap:10px"><span class="dash-avatar" style="background:${manager.role === "owner" ? "linear-gradient(135deg,#ff6400,#a72396)" : "#375e97"}">${esc(String(lng(manager.name) || manager.username).slice(0, 2).toUpperCase())}</span><div style="flex:1"><strong style="font-size:12px">${esc(lng(manager.name) || manager.username)}</strong><br><small style="font-size:8px;color:var(--soft-muted)">@${esc(manager.username)} · ${manager.role === "owner" ? dt("مالك", "Propriétaire") : dt("مدير", "Gérant")}</small></div><span class="badge-soft ${manager.mustChange ? "orange" : "green"}">${manager.mustChange ? dt("تغيير كلمة المرور", "Changer MDP") : dt("نشط", "Actif")}</span></div><div style="margin-top:11px;padding-top:10px;border-top:1px solid var(--border);display:flex;align-items:center;gap:5px"><span style="font-size:8px;color:var(--soft-muted);direction:ltr">${esc(manager.whatsapp || "—")}</span><span style="flex:1"></span>${manager.username !== session?.username ? `<button class="btn btn-sm btn-soft" data-action="force-password" data-id="${manager.id}">${dt("إلزام التغيير", "Forcer MDP")}</button>` : ""}<button class="btn btn-sm btn-soft" data-action="edit-manager" data-id="${manager.id}">${icon("edit")}</button>${manager.role !== "owner" || R.managers.filter((item) => item.role === "owner").length > 1 ? `<button class="btn btn-sm btn-soft" data-action="delete-manager" data-id="${manager.id}">${icon("trash")}</button>` : ""}</div></div></article>`).join("")}
      </div>
      <article class="dash-card" style="margin-top:14px"><div class="dash-card-body"><h3 style="font-size:12px;margin-bottom:7px">${dt("نصائح الأمان", "Conseils de sécurité")}</h3><ul style="list-style:disc;padding-inline-start:17px;font-size:10px;color:var(--muted);line-height:1.9"><li>${dt("يُطلب من كل مدير تغيير كلمة المرور عند أول دخول.", "Chaque gérant doit changer son mot de passe à la première connexion.")}</li><li>${dt("استخدم Supabase Auth في الإنتاج بدل الحسابات المحلية.", "Utilisez Supabase Auth en production au lieu des comptes locaux.")}</li><li>${dt("راجع سجل النشاط بانتظام.", "Consultez régulièrement le journal d’activité.")}</li></ul></div></article>`;
  }

  let pendingManagerId = null;
  function managerEditor(id) {
    const manager = id ? R.managers.find((item) => item.id === id) : null;
    pendingManagerId = id || null;
    const remote = Boolean(R.remote);
    const usernameField = remote
      ? `<div class="field"><label>${dt("البريد الإلكتروني", "E-mail")}</label><input id="manager-email" type="email" value="${esc(manager?.email || "")}" ${manager ? "readonly" : ""} dir="ltr" placeholder="manager@restore.mr" autocomplete="off"></div>`
      : `<div class="field"><label>${dt("اسم المستخدم", "Nom d’utilisateur")}</label><input id="manager-username" value="${esc(manager?.username || "")}" ${manager ? "readonly" : ""} dir="ltr" placeholder="manager2" autocomplete="off"></div>
         <div class="field"><label>${dt("البريد الإلكتروني (اختياري)", "E-mail (optionnel)")}</label><input id="manager-email" type="email" value="${esc(manager?.email || "")}" dir="ltr" placeholder="manager@restore.mr" autocomplete="off"></div>`;
    openModal(manager ? lng(manager.name) : dt("مدير جديد", "Nouveau gérant"), `
      <div class="form-grid">
        ${usernameField}
        <div class="field"><label>${dt("الدور", "Rôle")}</label><select id="manager-role"><option value="manager" ${manager?.role !== "owner" ? "selected" : ""}>${dt("مدير", "Gérant")}</option><option value="owner" ${manager?.role === "owner" ? "selected" : ""}>${dt("مالك", "Propriétaire")}</option></select></div>
        <div class="field"><label>${dt("الاسم بالعربية", "Nom en arabe")}</label><input id="manager-name-ar" value="${esc(manager?.name?.ar || "")}" dir="rtl"></div>
        <div class="field"><label>Nom en français</label><input id="manager-name-fr" value="${esc(manager?.name?.fr || "")}" dir="ltr"></div>
        <div class="field"><label>WhatsApp</label><input id="manager-whatsapp" value="${esc(manager?.whatsapp || "")}" dir="ltr" placeholder="222..." inputmode="tel"></div>
        ${!manager ? `<div class="field"><label>${dt("كلمة مرور مؤقتة (8 أحرف على الأقل)", "Mot de passe temporaire (8 caractères min.)")}</label><input id="manager-password" type="password" minlength="8" placeholder="********" autocomplete="new-password"></div>` : ""}
      </div>
      <p class="form-note" style="margin-top:10px">${remote
        ? dt("يُنشأ الحساب في Supabase عبر دالة المالك الآمنة. سيُطلب من المدير تغيير كلمة المرور عند أول دخول. لا يمكن تغيير البريد بعد الإنشاء من هنا.", "Le compte est créé dans Supabase via la fonction sécurisée du propriétaire. Le gérant devra changer son mot de passe à la première connexion. L’e-mail ne peut plus être modifié ici.")
        : dt("سيُطلب من المدير الجديد تغيير كلمة المرور عند أول دخول.", "Le nouveau gérant devra changer son mot de passe à la première connexion.")}</p>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-manager">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  async function saveManager() {
    const username = $("#manager-username")?.value.trim() || "";
    const email = $("#manager-email")?.value.trim().toLowerCase() || "";
    const role = $("#manager-role")?.value === "owner" ? "owner" : "manager";
    const nameAr = $("#manager-name-ar")?.value.trim();
    const nameFr = $("#manager-name-fr")?.value.trim();
    const whatsapp = $("#manager-whatsapp")?.value.trim();
    try {
      if (!pendingManagerId) {
        const password = $("#manager-password")?.value || "";
        if (password.length < 8) throw new Error(dt("كلمة المرور 8 أحرف على الأقل", "Mot de passe : 8 caractères minimum"));
        if (R.remote && !email) throw new Error(dt("البريد الإلكتروني مطلوب لإنشاء حساب Supabase", "L’e-mail est requis pour un compte Supabase"));
        if (!R.remote && !username) throw new Error(dt("اسم المستخدم مطلوب", "Le nom d’utilisateur est requis"));
        const created = await R.addManager({ username: username || email, email, password, nameAr, nameFr, role, whatsapp });
        if (!R.remote) model = clone(R.state);
        R.addAudit(`${dt("إضافة مدير", "Gérant ajouté")}: ${created?.email || created?.username || email || username}`);
      } else {
        const current = R.managers.find((item) => item.id === pendingManagerId);
        if (current?.role === "owner" && role !== "owner" && R.managers.filter((item) => item.role === "owner").length <= 1) throw new Error(dt("لا يمكن إزالة صلاحية المالك الوحيد", "Impossible de retirer le dernier propriétaire"));
        R.updateManager(pendingManagerId, {
          name: { ar: nameAr || nameFr || current?.username || "", fr: nameFr || nameAr || current?.username || "" },
          role,
          whatsapp,
          ...(!R.remote && email ? { email } : {})
        });
        R.addAudit(`${dt("تعديل مدير", "Gérant modifié")}: ${current?.username || ""}`);
      }
      if (R.remote) await R.refreshStaff().catch(() => {});
      closeModal(); renderRoute(); toast(dt("تم حفظ الفريق", "Équipe enregistrée"), "good");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  function changeOwnPasswordModal() {
    openModal(dt("تغيير كلمة المرور", "Changer le mot de passe"), `
      <div class="dash-form">
        <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input id="own-current" type="password"></div>
        <div class="form-grid"><div class="field"><label>${dt("الجديدة", "Nouveau")}</label><input id="own-next" type="password" minlength="8"></div><div class="field"><label>${dt("التأكيد", "Confirmer")}</label><input id="own-confirm" type="password"></div></div>
        <div class="field"><label>WhatsApp</label><input id="own-whatsapp" value="${esc(R.managers.find((item) => item.username === session?.username)?.whatsapp || "")}" dir="ltr"></div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-own-password">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  async function saveOwnPassword() {
    const next = $("#own-next")?.value || "";
    if (next !== ($("#own-confirm")?.value || "")) return toast(dt("كلمتا المرور غير متطابقتين", "Les mots de passe diffèrent"), "error");
    try {
      await R.changePassword(session.username, $("#own-current")?.value || "", next, $("#own-whatsapp")?.value || "");
      session = R.currentSession();
      closeModal(); toast(dt("تم تحديث كلمة المرور", "Mot de passe mis à jour"), "good");
    } catch (error) { toast(error.message, "error"); }
  }

  /* --------------------------------------------------------------------------
     Reports
     -------------------------------------------------------------------------- */
  let reportRange = "30";
  function reportOrders() {
    const orders = orderList().filter((order) => order.status !== "cancelled" && order.status !== "returned");
    if (reportRange === "all") return orders;
    const days = Number(reportRange) || 30;
    const cutoff = Date.now() - days * 864e5;
    return orders.filter((order) => Date.parse(order.createdAt) >= cutoff);
  
  }).call(ctx);
}
