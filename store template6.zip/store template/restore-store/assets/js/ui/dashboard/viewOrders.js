/* extracted dashboard view */
export function viewOrders(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const orders = filteredOrders();
    const tabs = [{ id: "all", label: dt("الكل", "Toutes"), count: orderList().length }, ...R.statuses.map((status) => ({ id: status, label: lng(R.statusMeta(status).label), count: orderStatusCount(status) }))];
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الطلبات", "Commandes")}</h2><p>${dt("كل طلب يصل من المتجر يظهر هنا فورًا.", "Chaque commande de la boutique apparaît ici en direct.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" type="button" data-action="export-orders">${icon("download")} ${dt("تصدير CSV", "Exporter CSV")}</button></div>
      </div>
      <div class="dash-toolbar">
        <div class="segmented" style="flex-wrap:wrap">${tabs.map((tab) => `<button type="button" data-order-filter="${tab.id}" class="${orderFilter === tab.id ? "active" : ""}">${esc(tab.label)} ${tab.count ? `(${tab.count})` : ""}</button>`).join("")}</div>
        <div class="spacer"></div>
        <label class="field" style="min-width:210px"><input id="order-search" placeholder="${dt("بحث بالرقم، الاسم أو الهاتف", "N°, nom ou téléphone")}" value="${esc(searchTerm)}"></label>
      </div>
      <div class="dash-card">${ordersTable(orders)}</div>`;
  }

  function orderMessage(order, type = "confirm") {
    const template = model.settings.whatsappTemplates?.[type];
    if (!template) return "";
    let text = lng(template)
      .replaceAll("{name}", order.customer?.name || "")
      .replaceAll("{order_id}", order.id)
      .replaceAll("{store}", lng(model.settings.storeName));
    return text;
  }

  function printOrder(order, mode) {
    const invoice = mode === "invoice";
    const win = window.open("", "_blank", "width=820,height=980");
    if (!win) { toast(dt("اسمح بالنوافذ المنبثقة للطباعة", "Autorisez les pop-ups pour imprimer"), "error"); return; }
    const itemRows = (order.items || []).map((item) => `<tr><td>${esc(item.title)}<br><small>${esc(item.variantTitle || "")} ${esc(item.specsText || "")}</small></td><td>${item.qty}</td><td>${money(item.price)}</td><td>${money(item.line)}</td></tr>`).join("");
    win.document.write(`<!doctype html><html lang="${dashLang}" dir="${dashLang === "ar" ? "rtl" : "ltr"}"><head><meta charset="utf-8"><title>${invoice ? dt("فاتورة", "Facture") : dt("ملصق شحن", "Étiquette")} ${esc(order.id)}</title><style>
      @page{size:A4;margin:16mm}*{box-sizing:border-box}body{font-family:Tahoma,Arial,sans-serif;color:#111;font-size:12px;line-height:1.6}header{display:flex;justify-content:space-between;border-bottom:2px solid #ff6400;padding-bottom:12px;margin-bottom:18px}h1{font-size:22px;margin:0}img{width:120px}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:start;font-size:11px}th{background:#f5f5f5}small{color:#666;font-size:9px}.total{font-size:16px;font-weight:bold;text-align:end;margin-top:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.box{border:1px solid #ddd;padding:10px;border-radius:6px}.label{border:2px solid #111;padding:22px;margin-top:20px}.label h2{font-size:26px;margin:0 0 10px}.label .addr{font-size:17px;line-height:1.8}.barcode{margin-top:16px;font-family:monospace;font-size:13px;letter-spacing:2px}</style></head><body>
      <header><div><img src="${location.origin}${location.pathname.replace(/[^/]*$/, "")}${esc(model.settings.logo || "assets/img/restore-logo.svg")}" alt="Restore"><h1>${invoice ? dt("فاتورة", "Facture") : dt("ملصق شحن", "Étiquette d’expédition")}</h1></div><div style="text-align:end"><strong>${esc(model.settings.mapPhone || model.settings.phoneDisplay || "")}</strong><br>${esc(lng(model.settings.address))}<br>${esc(model.settings.email || "")}</div></header>
      ${invoice ? `<div class="grid"><div class="box"><strong>${dt("فاتورة", "Facture")}: ${esc(order.id)}</strong><br>${esc(fmtDate(order.createdAt))}<br>${dt("الحالة", "Statut")}: ${esc(lng(R.statusMeta(order.status).label))}</div><div class="box"><strong>${dt("العميل", "Client")}</strong><br>${esc(order.customer?.name || "")}<br>${esc(order.customer?.phone || "")}<br>${esc(order.customer?.city || "")} — ${esc(order.customer?.address || "")}</div></div>
      <table><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("الكمية", "Qté")}</th><th>${dt("السعر", "Prix")}</th><th>${dt("المجموع", "Total")}</th></tr></thead><tbody>${itemRows}</tbody></table>
      <div class="total">${dt("المجموع الكلي", "Total")}: ${money(order.total)}</div>` : `<div class="label"><h2>${esc(model.settings.storeName?.[dashLang] || "Restore")}</h2><div class="addr"><strong>${esc(order.customer?.name || "")}</strong><br>${esc(order.customer?.phone || "")}<br>${esc(order.customer?.address || "")}<br>${esc(order.customer?.city || "")} — ${dt("موريتانيا", "Mauritanie")}</div><div class="barcode">${esc(order.id)} · ${esc(digits(order.customer?.phone).slice(-8))}</div></div>`}
      <p style="margin-top:24px;font-size:9px;color:#888">${dt("تم إنشاء هذا المستند من لوحة تحكم ريستور.", "Document généré depuis le tableau de bord Restore.")}</p>
      </body></html>`);
    win.document.close();
    setTimeout(() => { win.focus(); win.print(); }, 350);
  
  }).call(ctx);
}
