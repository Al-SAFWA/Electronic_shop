/* extracted dashboard view */
export function viewProfile(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const mgr = R.managers.find((item) => item.id === session?.id) || R.managers.find((item) => item.username === session?.username);
    const currentUser = mgr || { username: session?.username, name: { ar: session?.name, fr: session?.name }, whatsapp: "", email: "" };
    const hasAvatar = currentUser.avatar && currentUser.avatar.trim();
    const avatarSrc = hasAvatar ? currentUser.avatar : "";
    const initials = String(lng(currentUser.name) || session?.username || "U").slice(0, 2).toUpperCase();

    return `
      <div class="dash-view-head"><div><h2>${dt("ملفي الشخصي", "Mon profil")}</h2><p>${dt("إدارة معلومات الحساب والتواصل والدفع", "Gérer les informations du compte, contact et paiement")}</p></div></div>
      <div class="dash-tabs">
        <button class="active" data-dash-tab="profile-info">${dt("معلومات الحساب", "Infos du compte")}</button>
        ${session?.role === "owner" ? `<button data-dash-tab="profile-contact">${dt("التواصل", "Contact")}</button>
        <button data-dash-tab="profile-social">${dt("السوشيال", "Social")}</button>` : ""}
        <button data-dash-tab="profile-security">${dt("الأمان", "Sécurité")}</button>
        <button data-dash-tab="profile-payment">${dt("طرق الدفع", "Moyens de paiement")}</button>
      </div>

      <div class="dash-panel active" data-dash-panel="profile-info">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات الحساب", "Informations du compte")}</h3></div><div class="dash-card-body dash-form">
            <div class="form-grid">
              <div class="field"><label>${dt(R.remote ? "البريد الإلكتروني" : "اسم المستخدم", R.remote ? "E-mail" : "Nom d'utilisateur")}</label><input id="profile-username" value="${esc(session?.username || "")}" ${R.remote || session?.role !== "owner" ? "readonly" : ""} dir="ltr" autocomplete="username"></div>
              <div class="field"><label>${dt("الدور", "Rôle")}</label><input value="${session?.role === 'owner' ? dt('المالك', 'Propriétaire') : dt('مدير', 'Gérant')}" readonly></div>
              <div class="field"><label>${dt("الاسم بالعربية", "Nom en arabe")}</label><input id="profile-name-ar" value="${esc(currentUser.name?.ar || "")}" dir="rtl"></div>
              <div class="field"><label>Nom en français</label><input id="profile-name-fr" value="${esc(currentUser.name?.fr || "")}" dir="ltr"></div>
              <div class="field"><label>${dt("البريد الإلكتروني للتواصل", "E-mail de contact")}</label><input id="profile-email" type="email" value="${esc(currentUser.email || "")}" ${R.remote ? "readonly" : ""} dir="ltr" autocomplete="email"></div>
              <div class="field"><label>${dt("واتساب", "WhatsApp")}</label><input id="profile-whatsapp" value="${esc(currentUser.whatsapp || "")}" dir="ltr" placeholder="222..." inputmode="tel"></div>
            </div>
            ${R.remote ? `<p class="form-note">${dt("لتغيير بريد الدخول، استخدم لوحة Supabase > Authentication.", "Pour changer l’e-mail de connexion, utilisez Supabase > Authentication.")}</p>` : ""}
            <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-profile-info">${icon("check")} ${dt("حفظ المعلومات", "Enregistrer")}</button></div>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("الصورة الرمزية", "Avatar")}</h3></div><div class="dash-card-body" style="display:flex;align-items:center;gap:15px">
            <div class="image-field" style="width:100px;height:100px;border-radius:50%;overflow:hidden;background:linear-gradient(135deg,#ff6400,#a72396);color:#fff;display:grid;place-items:center;font-size:28px;font-weight:700">
              ${avatarSrc ? `<img src="${esc(avatarSrc)}" alt="" style="width:100%;height:100%;object-fit:cover">` : esc(initials)}
            </div>
            <div>
              <label class="upload-btn">${icon("upload")} ${dt("تغيير الصورة", "Changer l'image")}<input type="file" accept="image/*" id="profile-avatar-upload"></label>
              <p class="form-note">${dt("سيتم تحديث الصورة في جميع أنحاء لوحة التحكم والمتجر", "L'image sera mise à jour dans tout le tableau de bord et la boutique")}</p>
            </div>
          </div></div></article>
        </div>
      </div>

      ${session?.role === "owner" ? `<div class="dash-panel" data-dash-panel="profile-contact">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات التواصل للمتجر", "Infos de contact de la boutique")}</h3></div><div class="dash-card-body dash-form">
          ${biField(dt("اسم المتجر", "Nom de la boutique"), "settings.storeName")}
          ${biField(dt("الشعار", "Slogan"), "settings.tagline")}
          <div class="form-grid">${field(dt("واتساب المتجر", "WhatsApp de la boutique"), "settings.whatsapp", { placeholder: "22246000000" })}${field(dt("البريد الإلكتروني", "E-mail"), "settings.email", { placeholder: "contact@restore.mr" })}</div>
          ${biField(dt("العنوان", "Adresse"), "settings.address", { type: "textarea", rows: 2 })}
          ${biField(dt("المدينة", "Ville"), "settings.city")}
          <div class="form-grid">${field(dt("الرقم الظاهر", "Numéro affiché"), "settings.phoneDisplay", { placeholder: "+222 46 00 00 00" })}${field(dt("رقم الهاتف (دولي)", "Téléphone (international)"), "settings.phone", { placeholder: "+22246000000" })}</div>
          <p class="form-note">${dt("هذه المعلومات تظهر في الفوتر وصفحة التواصل وفي رسالة الواتساب للطلب", "Ces infos apparaissent dans le footer, la page contact et le message WhatsApp de commande")}</p>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-owner-contact">${icon("check")} ${dt("حفظ معلومات المتجر", "Enregistrer les infos boutique")}</button></div>
        </div></article>
      </div>` : ""}

      ${session?.role === "owner" ? `<div class="dash-panel" data-dash-panel="profile-social">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("روابط التواصل الاجتماعي", "Liens réseaux sociaux")}</h3></div><div class="dash-card-body dash-form">
          <p class="form-note">${dt("أضف روابط حساباتك على المنصات الاجتماعية. ستظهر في الفوتر وصفحة التواصل.", "Ajoutez les liens de vos comptes sociaux. Ils apparaîtront dans le footer et la page contact.")}</p>
          <div id="social-links-editor">
            ${(model.settings.social || []).map((s, i) => {
              const platform = String(s.platform || s.id || "");
              const options = ["facebook", "instagram", "tiktok", "youtube", "x", "twitter", "snapchat", "whatsapp", "linkedin", "telegram"];
              return `
              <div class="social-row" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;flex-wrap:wrap">
                <select data-social-platform="${i}" style="flex:1;min-width:130px;max-width:170px">
                  <option value="">${dt("اختر المنصة", "Choisir la plateforme")}</option>
                  ${options.map((id) => `<option value="${id}" ${platform === id ? "selected" : ""}>${id}</option>`).join("")}
                </select>
                <input type="url" data-social-url="${i}" value="${esc(s.href || "")}" placeholder="https://..." style="flex:2;min-width:200px" dir="ltr">
                <button type="button" class="btn btn-sm btn-soft" data-action="remove-social" data-index="${i}" style="padding:6px" aria-label="${dt("حذف", "Supprimer")}">${icon("trash")}</button>
              </div>`;
            }).join("")}
          </div>
          <button type="button" class="btn btn-secondary btn-sm" id="add-social-link">${icon("plus")} ${dt("إضافة رابط", "Ajouter un lien")}</button>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-owner-social">${icon("check")} ${dt("حفظ الروابط", "Enregistrer les liens")}</button></div>
        </div></article>
      </div>` : ""}

      <div class="dash-panel" data-dash-panel="profile-security">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تغيير كلمة المرور", "Changer le mot de passe")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">
            <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input id="sec-current" type="password" autocomplete="current-password"></div>
            <div class="field"><label>${dt("الجديدة", "Nouveau")}</label><input id="sec-next" type="password" minlength="8" autocomplete="new-password"></div>
            <div class="field"><label>${dt("التأكيد", "Confirmer")}</label><input id="sec-confirm" type="password" autocomplete="new-password"></div>
          </div>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="change-own-pwd">${icon("check")} ${dt("تغيير كلمة المرور", "Changer le mot de passe")}</button></div>
        </div></article>
        <article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("الجلسات النشطة", "Sessions actives")}</h3></div><div class="dash-card-body">
          <p class="form-note">${dt("سيتم عرض الجلسات قريباً مع إمكانية إلغاء الجلسات البعيدة", "Les sessions s'afficheront bientôt avec possibilité de révoquer les sessions distantes")}</p>
        </div></article>
      </div>

      <div class="dash-panel" data-dash-panel="profile-payment">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("طرق الدفع المفعلة", "Moyens de paiement actifs")}</h3></div><div class="dash-card-body">
          ${(model.settings.payments || []).filter(p => p.active !== false).map((payment) => `<div class="list-row"><div style="display:flex;align-items:center;gap:10px"><span style="width:32px;height:32px;border-radius:8px;background:${esc(payment.color)};color:#fff;display:grid;place-items:center;font-size:9px;font-weight:800">${esc(String(lng(payment.name)).slice(0, 2))}</span><div><strong>${esc(lng(payment.name))}</strong><br><small>${esc(lng(payment.note))}</small></div></div></div>`).join("")}
        </div></article>
      </div>`;
  
  }).call(ctx);
}
