// legacy dashboard chunk 7
        if (confirm(dt("إعادة تعيين البيانات التجريبية وحذف كل الطلبات؟", "Réinitialiser la démo et supprimer toutes les commandes ?"))) {
          if (confirm(dt("تأكيد أخير: لا يمكن التراجع.", "Dernière confirmation : irréversible."))) R.resetLocalDemo();
        }
        break;
      case "close-modal":
        closeModal();
        break;
      case "modal-backdrop":
        if (event.target === actionNode) closeModal();
        break;
      case "view-order":
        viewOrderModal(id);
        break;
      case "save-order": {
        const order = R.getOrders().find((item) => item.id === id);
        if (order) {
          const status = $(`.dash-modal [data-order-status="${CSS.escape(id)}"]`)?.value || order.status;
          const note = $(`.dash-modal [data-order-note="${CSS.escape(id)}"]`)?.value || "";
          R.updateOrder(id, { status, internalNote: note });
          R.addAudit(`${dt("تحديث الطلب", "Commande modifiée")} ${id}: ${status}`);
          toast(dt("تم حفظ الطلب", "Commande enregistrée"), "good");
        }
        closeModal(); renderRoute();
        break;
      }
      case "print-invoice":
        printOrder(R.getOrders().find((order) => order.id === id), "invoice");
        break;
      case "print-label":
        printOrder(R.getOrders().find((order) => order.id === id), "label");
        break;
      case "export-orders":
        exportOrdersCsv();
        break;
      case "abandoned-status": {
        const rows = R.getAbandoned().map((item) => item.id === id ? { ...item, status: actionNode.dataset.status || "contacted", contactedAt: nowIso() } : item);
        localStorage.setItem("restore_abandoned_v1", JSON.stringify(rows));
        window.dispatchEvent(new CustomEvent("restore:orders"));
        renderRoute(); toast(dt("تم تحديث السلة", "Panier mis à jour"), "good");
        break;
      }
      case "delete-abandoned":
        if (confirm(dt("حذف السلة المتروكة؟", "Supprimer ce panier ?"))) { R.removeAbandoned(id); renderRoute(); }
        break;
      case "add-product":
        editorKind = "product"; productEditor(null);
        break;
      case "edit-product":
        editorKind = "product"; productEditor(index);
        break;
      case "delete-product":
        deleteProduct(index);
        break;
      case "delete-product-buffer":
        deleteProduct(null, true);
        break;
      case "bulk-price":
        bulkPriceModal();
        break;
      case "apply-bulk-price":
        applyBulkPrice();
        break;
      case "save-editor":
        if (editorKind === "product") saveProductEditor();
        else if (editorKind === "category") saveCategoryEditor();
        else if (editorKind === "nav") saveNavEditor();
        else if (editorKind === "hero") saveHeroEditor();
        else if (editorKind === "review") saveReviewEditor();
        else if (editorKind === "payment") viewPaymentSave();
        else if (editorKind === "city") viewCitySave();
        break;
      case "add-category":
        editorKind = "category"; categoryEditor(null);
        break;
      case "edit-category":
        editorKind = "category"; categoryEditor(index);
        break;
      case "delete-category":
        if (confirm(dt("حذف الفئة؟", "Supprimer la catégorie ?"))) { model.theme.categories.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "delete-category-buffer":
        if (confirm(dt("حذف الفئة؟", "Supprimer la catégorie ?"))) { model.theme.categories = model.theme.categories.filter((item) => item.handle !== editBuffer.handle); saveDraftNow(); closeModal(); renderRoute(); }
        break;
      case "edit-collection":
        collectionEditor(index);
        break;
      case "save-collection":
        if (editBuffer) { model.collections[index] = editBuffer; saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المجموعة", "Collection enregistrée"), "good"); }
        break;
      case "add-trust":
        model.settings.trustBar.push({ icon: "truck", label: { ar: "", fr: "" } }); saveDraftNow(); renderRoute();
        break;
      case "remove-trust":
        model.settings.trustBar.splice(index, 1); saveDraftNow(); renderRoute();
        break;
      case "add-nav":
        editorKind = "nav"; navEditor(null);
        break;
      case "edit-nav":
        editorKind = "nav"; navEditor(index);
        break;
      case "delete-nav":
        if (confirm(dt("حذف عنصر القائمة؟", "Supprimer cet élément ?"))) { model.settings.navigation.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "delete-nav-buffer":
        model.settings.navigation = model.settings.navigation.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute();
        break;
      case "add-footer-column":
        model.settings.footerColumns.push({ title: { ar: "روابط", fr: "Liens" }, links: [] }); saveDraftNow(); renderRoute();
        break;
      case "add-hero":
        editorKind = "hero"; heroEditor(null);
        break;
      case "edit-hero":
        editorKind = "hero"; heroEditor(index);
        break;
      case "delete-hero":
        if (confirm(dt("حذف الشريحة؟", "Supprimer la diapositive ?"))) { model.settings.heroSlides.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "delete-hero-buffer":
        model.settings.heroSlides = model.settings.heroSlides.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute();
        break;
      case "page-section-up": {
        const sections = [...model.settings.pageSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index > 0) { [sections[index - 1], sections[index]] = [sections[index], sections[index - 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "page-section-down": {
        const sections = [...model.settings.pageSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index >= 0 && index < sections.length - 1) { [sections[index + 1], sections[index]] = [sections[index], sections[index + 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "home-section-up": {
        const sections = [...model.settings.homeSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index > 0) { [sections[index - 1], sections[index]] = [sections[index], sections[index - 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "home-section-down": {
        const sections = [...model.settings.homeSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index >= 0 && index < sections.length - 1) { [sections[index + 1], sections[index]] = [sections[index], sections[index + 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "edit-home-section":
        homeSectionEditor(id);
        break;
      case "save-home-section": {
        if (!editBuffer) return;
        const index = model.settings.homeSections.findIndex((section) => section.id === id);
        if (index >= 0) model.settings.homeSections[index] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ قسم المنتجات", "Section enregistrée"), "good");
        break;
      }
      case "add-home-section": {
        const collection = model.collections[0]?.handle || "all";
        model.settings.homeSections.push({ id: `section-${Date.now().toString(36)}`, visible: true, order: model.settings.homeSections.length + 1, title: { ar: "منتجات مختارة", fr: "Produits sélectionnés" }, collection, layout: "left", promo: "", flame: false });
        saveDraftNow(); renderRoute(); break;
      }
      case "add-coupon":
        couponEditor(null);
        break;
      case "edit-coupon":
        couponEditor(index);
        break;
      case "delete-coupon":
        model.settings.coupons.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "save-coupon":
        if (!editBuffer) return;
        if (actionNode.dataset.index === "") model.settings.coupons.push(editBuffer);
        else model.settings.coupons[Number(actionNode.dataset.index)] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ الكوبون", "Coupon enregistré"), "good"); break;
      case "add-payment":
        editorKind = "payment"; paymentEditor(null); break;
      case "edit-payment":
        editorKind = "payment"; paymentEditor(index); break;
      case "delete-payment":
        if (model.settings.payments.length <= 1) { toast(dt("يجب ترك طريقة دفع واحدة على الأقل", "Gardez au moins un moyen de paiement"), "error"); break; }
        model.settings.payments.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "delete-payment-buffer":
        model.settings.payments = model.settings.payments.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute(); break;
      case "add-city":
        editorKind = "city"; cityEditor(null); break;
      case "edit-city":
        editorKind = "city"; cityEditor(index); break;
      case "delete-city":
        model.settings.cities.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "delete-city-buffer":
        model.settings.cities = model.settings.cities.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute(); break;
      case "add-manager":
        managerEditor(null); break;
      case "edit-manager":
        managerEditor(id); break;
      case "delete-manager":
        if (confirm(dt("حذف حساب المدير؟", "Supprimer ce gérant ?"))) {
          try { R.deleteManager(id); renderRoute(); toast(dt("تم حذف المدير", "Gérant supprimé"), "good"); } catch (error) { toast(error.message, "error"); }
        }
        break;
      case "force-password":
        R.updateManager(id, { mustChange: true }); renderRoute(); toast(dt("سيُطلب تغيير كلمة المرور", "Changement de mot de passe requis"), "good"); break;
      case "save-manager":
        saveManager(); break;
      case "change-own-password":
        changeOwnPasswordModal(); break;
      case "save-own-password":
        saveOwnPassword(); break;
      case "add-post":
        postEditor(null); break;
      case "edit-post":
        postEditor(index); break;
      case "delete-post":
        if (confirm(dt("حذف المقال؟", "Supprimer l’article ?"))) { model.blog.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "save-post":
        if (!editBuffer) return;
        if (pendingPostIndex == null) model.blog.push(editBuffer); else model.blog[pendingPostIndex] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المقال", "Article enregistré"), "good"); break;
      case "add-page":
        pageEditor(null); break;
      case "edit-page":
        pageEditor(index); break;
      case "delete-page":
        if (confirm(dt("حذف الصفحة؟", "Supprimer la page ?"))) { model.pages.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "save-page":
        savePageEditor(); break;
      case "add-faq":
        faqEditor(null); break;
      case "edit-faq":
        faqEditor(index); break;
      case "delete-faq":
        if (confirm(dt("حذف السؤال؟", "Supprimer la question ?"))) { model.faqs.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "save-faq":
        if (!editBuffer) return;
        if (actionNode.dataset.index === "") model.faqs.push(editBuffer); else model.faqs[Number(actionNode.dataset.index)] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ السؤال", "Question enregistrée"), "good"); break;
      case "add-home-review":
        editorKind = "review"; reviewEditor("home", null); break;
      case "edit-home-review":
        editorKind = "review"; reviewEditor("home", index); break;
      case "delete-home-review":
        model.homeReviews.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "add-product-review":
        editorKind = "review"; reviewEditor("product", null); break;
      case "edit-product-review":
        editorKind = "review"; reviewEditor("product", index); break;
      case "delete-product-review":
        model.reviews.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "delete-review-buffer":
        if (pendingReviewKind === "home") model.homeReviews = model.homeReviews.filter((item) => item.id !== editBuffer.id);
        else model.reviews = model.reviews.filter((item) => item.id !== editBuffer.id);
        saveDraftNow(); closeModal(); renderRoute(); break;
      case "approve-customer-review": {
        R.moderateReview(id, "approve").then(() => {
          R.addAudit(`${dt("اعتماد تقييم عميل", "Avis client approuvé")}: ${id}`);
          renderRoute();
          toast(dt("تم اعتماد التقييم", "Avis approuvé"), "good");
        }).catch((error) => toast(error.message, "error"));
        break;
      }
      case "reject-customer-review": {
        R.moderateReview(id, "reject").then(() => {
          R.addAudit(`${dt("رفض تقييم عميل", "Avis client refusé")}: ${id}`);
          renderRoute();
          toast(dt("تم رفض التقييم", "Avis refusé"), "good");
        }).catch((error) => toast(error.message, "error"));
        break;
      }
      case "delete-customer-review": {
        if (confirm(dt("حذف التقييم نهائيًا؟", "Supprimer définitivement cet avis ?"))) {
          R.deleteCustomerReview(id).then(() => {
            R.addAudit(`${dt("حذف تقييم عميل", "Avis client supprimé")}: ${id}`);
            renderRoute();
            toast(dt("تم حذف التقييم", "Avis supprimé"), "good");
          }).catch((error) => toast(error.message, "error"));
        }
        break;
      }
      case "clear-audit":
        if (confirm(dt("مسح كل سجل النشاط؟", "Effacer tout le journal ?"))) { localStorage.removeItem("restore_audit_v1"); renderRoute(); }
        break;
      case "save-profile-info": {
        const username = $("#profile-username")?.value.trim();
        const nameAr = $("#profile-name-ar")?.value.trim();
        const nameFr = $("#profile-name-fr")?.value.trim();
        const email = $("#profile-email")?.value.trim();
        const whatsapp = $("#profile-whatsapp")?.value.trim();
        (async () => {
          try {
            if (!session?.id) throw new Error(dt("الجلسة منتهية. أعد تسجيل الدخول.", "Session expirée. Reconnectez-vous."));
            if (!R.remote && username && username !== session.username) {
              if (!/^[a-z0-9._@-]{3,64}$/.test(username)) throw new Error(dt("اسم مستخدم غير صالح", "Identifiant invalide"));
              if (R.managers.some((m) => m.username === username && m.id !== session.id)) throw new Error(dt("اسم المستخدم مستخدم", "Identifiant déjà utilisé"));
              R.updateManager(session.id, { username });
              session = { ...session, username };
              localStorage.setItem("restore_session_v1", JSON.stringify(session));
            }
            if (nameAr || nameFr) R.updateManager(session.id, { name: { ar: nameAr || nameFr, fr: nameFr || nameAr } });
            if (email && !R.remote) R.updateManager(session.id, { email });
            if (whatsapp) {
              const digitsOnly = whatsapp.replace(/\D/g, "");
              if (digitsOnly && digitsOnly.length !== 8 && digitsOnly.length !== 11) throw new Error(dt("رقم واتساب غير صالح", "Numéro WhatsApp invalide"));
              R.updateManager(session.id, { whatsapp: digitsOnly });
            }
            if (R.remote) await R.refreshStaff().catch(() => {});
            R.addAudit(`${dt("تحديث الملف الشخصي", "Profil mis à jour")}: ${session?.username}`);
            toast(dt("تم حفظ المعلومات", "Informations enregistrées"), "good");
            renderRoute();
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      case "save-owner-contact": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const allowed = new Set(["storeName", "legalName", "tagline", "email", "whatsapp", "phone", "phoneDisplay", "address", "city", "hours"]);
        const patch = {};
        document.querySelectorAll("[data-dash-panel='profile-contact'] [data-edit-path]").forEach((inp) => {
          const raw = String(inp.dataset.editPath || "");
          if (!raw.startsWith("settings.")) return;
          const key = raw.slice("settings.".length);
          if (!allowed.has(key.split(".")[0])) return;
          const val = inp.type === "checkbox" ? inp.checked : inp.value;
          setPath(patch, key, typeof val === "string" ? val.trim() : val);
        });
        (async () => {
          try {
            const saved = await R.updateOwnerSettings(patch);
            const next = clone(model);
            Object.entries(patch).forEach(([key, value]) => setPath(next, `settings.${key}`, value));
            model = next;
            saveDraftNow();
            R.addAudit(`${dt("تحديث تواصل المتجر", "Contact boutique mis à jour")}`);
            toast(dt("تم حفظ معلومات المتجر ونشرها", "Infos boutique enregistrées et publiées"), "good");
            renderRoute();
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      case "save-owner-social": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const allowed = new Set(["facebook", "instagram", "tiktok", "youtube", "x", "twitter", "snapchat", "whatsapp", "linkedin", "telegram"]);
        const socials = [];
        const rows = document.querySelectorAll("[data-dash-panel='profile-social'] .social-row");
        for (const row of rows) {
          const platform = String(row.querySelector("[data-social-platform]")?.value || "").trim().toLowerCase();
          let href = String(row.querySelector("[data-social-url]")?.value || "").trim();
          if (!platform && !href) continue;
          if (!allowed.has(platform)) return toast(dt("اختر منصة صالحة لكل رابط", "Choisissez une plateforme valide pour chaque lien"), "error");
          if (href && !/^https?:\/\//i.test(href)) href = `https://${href}`;
          if (!/^https:\/\//i.test(href)) return toast(dt("روابط السوشيال يجب أن تبدأ بـ https://", "Les liens doivent commencer par https://"), "error");
          socials.push({ platform, href });
        }
        (async () => {
          try {
            const saved = await R.updateOwnerSettings({ social: socials });
            const next = clone(model);
            next.settings.social = Array.isArray(saved.social) ? saved.social : socials.map((item) => ({ ...item, id: item.platform, icon: item.platform }));
            model = next;
            saveDraftNow();
            R.addAudit(`${dt("تحديث روابط السوشيال", "Liens sociaux mis à jour")}`);
            toast(dt("حُفظت الروابط ونُشرت", "Liens enregistrés et publiés"), "good");
            renderRoute();
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      case "remove-social": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const idx = Number(actionNode.dataset.index);
        const next = clone(model);
        if (next.settings.social) next.settings.social.splice(idx, 1);
        model = next;
        saveDraftSoon();
        renderRoute();
        break;
      }
      case "add-social-link": {
