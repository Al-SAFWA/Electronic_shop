/* extracted dashboard view */
export function viewProducts(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const list = filteredProducts();
    const shown = list.slice(0, 80);
    return `
      <div class="dash-view-head">
        <div><h2>${dt("المنتجات", "Produits")}</h2><p>${list.length} ${dt("منتج في المخزون", "produits en stock")} · ${lowStockProducts().length} ${dt("بحاجة لتعبئة", "à réapprovisionner")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" data-action="bulk-price">${icon("edit")} ${dt("تعديل أسعار جماعي", "Prix groupés")}</button><button class="btn btn-primary" data-action="add-product">${icon("plus")} ${dt("منتج جديد", "Nouveau produit")}</button></div>
      </div>
      <div class="dash-toolbar">
        <label class="field" style="min-width:210px"><input id="product-search" placeholder="${dt("بحث عن منتج...", "Rechercher un produit...")}" value="${esc(productSearch)}"></label>
        <label class="field"><select data-product-filter="category"><option value="all">${dt("كل الفئات", "Toutes catégories")}</option>${model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${productCategory === collection.handle ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("")}</select></label>
        <label class="field"><select data-product-filter="stock"><option value="all">${dt("كل المخزون", "Tout le stock")}</option><option value="low" ${productStock === "low" ? "selected" : ""}>${dt("مخزون منخفض", "Stock faible")}</option><option value="out" ${productStock === "out" ? "selected" : ""}>${dt("نفد المخزون", "Épuisé")}</option></select></label>
        <div class="spacer"></div>
        <span class="badge-soft">${shown.length}/${list.length}</span>
        ${directToggle(dt("إخفاء المنتجات المنتهية من المتجر", "Masquer les produits épuisés"), "settings.autoHideOutOfStock", model.settings.autoHideOutOfStock)}
      </div>
      <div class="dash-card">
        ${shown.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("SKU", "SKU")}</th><th>${dt("الفئة", "Catégorie")}</th><th>${dt("السعر", "Prix")}</th><th>${dt("المخزون", "Stock")}</th><th>${dt("الحالة", "Statut")}</th><th>${dt("المتجر", "Boutique")}</th><th></th></tr></thead><tbody>
          ${shown.map((product) => {
            const productIndex = model.products.indexOf(product);
            const category = model.collections.find((collection) => (product.collections || []).includes(collection.handle));
            const isLow = Number(product.stock) <= Number(model.settings.lowStockThreshold || 2);
            return `<tr>
              <td><div class="cell-main"><img src="${esc(product.image)}" alt=""><div><strong>${esc(product.title)}</strong><small>${esc(product.type || "")} · ${esc(product.condition || "")}</small></div></div></td>
              <td style="direction:ltr">${esc(product.sku || product.handle)}</td>
              <td>${esc(category ? lng(category.title) : (product.collections?.[0] || "—"))}</td>
              <td class="price">${money(product.price)}${product.compare > product.price ? `<br><small style="text-decoration:line-through;color:var(--soft-muted)">${money(product.compare)}</small>` : ""}</td>
              <td><div style="display:flex;flex-direction:column;gap:3px"><strong style="font-size:9px;color:${Number(product.stock) <= 0 ? "var(--danger)" : isLow ? "#e67e22" : "inherit"}">${product.stock}</strong><div class="mini-bar" style="--bar:${isLow ? "#e67e22" : "#25a55f"};min-width:50px"><i style="width:${Math.min(100, Math.max(3, Number(product.stock) / 20 * 100))}%"></i></div></div></td>
              <td><span class="badge-soft ${product.active !== false ? "green" : ""}">${product.active !== false ? dt("نشط", "Actif") : dt("مخفي", "Masqué")}</span></td>
              <td><label class="toggle"><input type="checkbox" data-product-active="${productIndex}" ${product.active !== false ? "checked" : ""}><span></span></label></td>
              <td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-product" data-index="${productIndex}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-product" data-index="${productIndex}">${icon("trash")}</button></div></td>
            </tr>`;
          }).join("")}</tbody></table></div>` : `<div class="table-empty">${icon("products")}<p>${dt("لا توجد منتجات مطابقة.", "Aucun produit correspondant.")}</p></div>`}
      </div>`;
  }

  function productEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? {
      handle: `restore-${Date.now().toString(36)}`, title: { ar: "منتج جديد", fr: "Nouveau produit" }, vendor: "Restore",
      type: "Smartphone", condition: "Good", price: 0, compare: 0, stock: 1, battery: 90, active: true,
      image: "assets/products/iphone-13-pro-max-1.png", images: ["assets/products/iphone-13-pro-max-1.png"],
      description: { ar: "", fr: "" }, includes: [], specs: {}, colors: [], colorImages: {}, variants: [],
      collections: [], sku: "", warrantyMonths: 12
    } : clone(model.products[index]);
    editBuffer = buffer;
    const categoryOptions = model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${buffer.collections?.includes(collection.handle) ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("");
    openModal(isNew ? dt("منتج جديد", "Nouveau produit") : buffer.title?.ar || buffer.title, `
      <div class="dash-tabs"><button class="active" type="button">${dt("المعلومات", "Informations")}</button><button type="button" data-product-tab="media">${dt("الصور والألوان", "Images & couleurs")}</button><button type="button" data-product-tab="specs">${dt("المواصفات", "Spécifications")}</button></div>
      <div class="dash-panel active" data-product-panel="main">
        <div class="form-grid">
          ${editBi(dt("اسم المنتج", "Nom du produit"), "title", buffer.title)}
          <div class="field"><label>${dt("المعرف", "Identifiant")}</label><input data-edit-path="handle" value="${esc(buffer.handle)}" dir="ltr" ${isNew ? "" : "readonly"}></div>
          <div class="field"><label>${dt("الفئة", "Catégorie")}</label><select data-edit-path="collections.0"><option value="">—</option>${categoryOptions}</select></div>
          <div class="field"><label>Vendor</label><input data-edit-path="vendor" value="${esc(buffer.vendor)}"></div>
          <div class="field"><label>${dt("النوع", "Type")}</label><select data-edit-path="type">${["Smartphone", "Macbook", "Laptop", "Tablets", "Apple Watch", "Playstation", "Accessories"].map((type) => `<option ${buffer.type === type ? "selected" : ""}>${type}</option>`).join("")}</select></div>
          <div class="field"><label>${dt("الحالة", "État")}</label><select data-edit-path="condition">${["Like New", "Excellent", "Very Good", "Good", "Fair", "New"].map((condition) => `<option ${buffer.condition === condition ? "selected" : ""}>${condition}</option>`).join("")}</select></div>
          <div class="field"><label>${dt("السعر (MRU)", "Prix (MRU)")}</label><input type="number" data-edit-path="price" value="${esc(buffer.price)}"></div>
          <div class="field"><label>${dt("السعر قبل الخصم", "Prix barré")}</label><input type="number" data-edit-path="compare" value="${esc(buffer.compare)}"></div>
          <div class="field"><label>${dt("المخزون", "Stock")}</label><input type="number" data-edit-path="stock" value="${esc(buffer.stock)}"></div>
          <div class="field"><label>${dt("صحة البطارية %", "Santé batterie %")}</label><input type="number" data-edit-path="battery" value="${esc(buffer.battery)}"></div>
          <div class="field"><label>${dt("الضمان (أشهر)", "Garantie (mois)")}</label><input type="number" data-edit-path="warrantyMonths" value="${esc(buffer.warrantyMonths || 12)}"></div>
          <div class="field"><label>SKU</label><input data-edit-path="sku" value="${esc(buffer.sku || "")}"></div>
          ${editBi(dt("الوصف", "Description"), "description", buffer.description, { type: "textarea", rows: 4 })}
          <div class="span-2">${editToggle(dt("إظهار المنتج في المتجر", "Afficher dans la boutique"), "active", buffer.active !== false)}</div>
        </div>
      </div>
      <div class="dash-panel" data-product-panel="media">
        <div class="form-grid">
          ${imageEditor(dt("الصورة الرئيسية", "Image principale"), "image", buffer.image)}
          <div class="field span-2"><label>${dt("صور إضافية (رابط في كل سطر)", "Images supplémentaires (une URL par ligne)")}</label><textarea data-edit-path="images" rows="4" data-json="array">${esc((buffer.images || []).join("\n"))}</textarea></div>
          <div class="field"><label>${dt("ألوان (اسم:لون:#hex)", "Couleurs (nom:couleur:#hex)")}</label><textarea data-edit-path="colors" rows="4" data-colors>${esc((buffer.colors || []).map((color) => `${color.name}:${color.hex}`).join("\n"))}</textarea></div>
          <div class="field"><label>${dt("صور الألوان (اسم:رابط)", "Images couleurs (nom:URL)")}</label><textarea data-edit-path="colorImages" rows="4" data-colormap>${esc(Object.entries(buffer.colorImages || {}).map(([key, value]) => `${key}:${value}`).join("\n"))}</textarea></div>
          <div class="field span-2"><label>${dt("المتغيرات (JSON متقدم)", "Variantes (JSON avancé)")}</label><textarea data-edit-path="variants" rows="5" data-json="raw">${esc(JSON.stringify(buffer.variants || [], null, 2))}</textarea></div>
        </div>
      </div>
      <div class="dash-panel" data-product-panel="specs">
        <div class="form-grid">
          <div class="field span-2"><label>${dt("المواصفات (JSON)", "Spécifications (JSON)")}</label><textarea data-edit-path="specs" rows="14" data-json="raw">${esc(JSON.stringify(buffer.specs || {}, null, 2))}</textarea><p class="form-note">${dt("أمثلة: cpu, ram, storage, screen, condition, keyboard, battery. كل قيمة تحتوي label و value و choices.", "Exemples : cpu, ram, storage, screen, condition, keyboard, battery. Chaque valeur contient label, value et choices.")}</p></div>
          <div class="field span-2"><label>${dt("ماذا يوجد في العلبة (JSON)", "Contenu de la boîte (JSON)")}</label><textarea data-edit-path="includes" rows="7" data-json="raw">${esc(JSON.stringify(buffer.includes || [], null, 2))}</textarea></div>
        </div>
      </div>`, {
      wide: true,
      footer: editorFooter(!isNew, "delete-product-buffer"),
      onMount: (root) => {
        root.querySelectorAll("[data-product-tab]").forEach((tab) => tab.addEventListener("click", () => {
          root.querySelectorAll("[data-product-tab]").forEach((item) => item.classList.toggle("active", item === tab));
          root.querySelectorAll("[data-product-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.productPanel === tab.dataset.productTab));
        }));
      }
    });
    // Attach save specifically through the shared action, while preserving the newly created index.
    pendingProductIndex = isNew ? null : index;
  }
  let pendingProductIndex = null;

  function saveProductEditor() {
    const item = editBuffer;
    if (!item) return;
    // Parse the structured fields that use helper textareas.
    const editingModal = $(".dash-modal");
    editingModal?.querySelectorAll("[data-colors]").forEach((node) => {
      item.colors = node.value.split("\n").map((line) => {
        const parts = line.split(":").map((part) => part.trim());
        return parts[0] ? { name: parts[0], hex: parts[1]?.startsWith("#") ? parts[1] : `#${parts[1] || "999999"}` } : null;
      }).filter(Boolean);
    });
    editingModal?.querySelectorAll("[data-colormap]").forEach((node) => {
      item.colorImages = Object.fromEntries(node.value.split("\n").map((line) => line.split(":")).filter((parts) => parts.length >= 2).map((parts) => [parts[0].trim(), parts.slice(1).join(":").trim()]));
    });
    editingModal?.querySelectorAll("[data-json]").forEach((node) => {
      const path = node.dataset.editPath;
      if (path === "images") {
        item.images = node.value.split("\n").map((line) => line.trim()).filter(Boolean);
        if (item.images[0]) item.image = item.images[0];
        return;
      }
      try {
        if (!node.value.trim()) { setPath(item, path, node.dataset.json === "array" ? [] : null); return; }
        const parsed = JSON.parse(node.value);
        setPath(item, path, parsed);
      } catch {
        toast(`${dt("JSON غير صالح في", "JSON invalide dans")} ${path}`, "error");
      }
    });
    item.price = Number(item.price) || 0;
    item.compare = Number(item.compare) || 0;
    item.stock = Number(item.stock) || 0;
    item.battery = Number(item.battery) || 0;
    item.warrantyMonths = Number(item.warrantyMonths) || 12;
    if (item.active == null) item.active = true;
    if (pendingProductIndex == null) {
      if (model.products.some((product) => product.handle === item.handle)) { toast(dt("المعرف مستخدم مسبقًا", "Identifiant déjà utilisé"), "error"); return; }
      model.products.unshift(item);
    } else {
      model.products[pendingProductIndex] = item;
    }
    saveDraftNow();
    closeModal();
    R.addAudit(`${dt("حفظ منتج", "Produit enregistré")}: ${item.title?.ar || item.handle}`);
    toast(dt("تم حفظ المنتج في المسودة", "Produit enregistré dans le brouillon"), "good");
    renderRoute();
  }

  function bulkPriceModal() {
    openModal(dt("تعديل الأسعار الجماعي", "Modification groupée des prix"), `
      <div class="field"><label>${dt("الفئة", "Catégorie")}</label><select id="bulk-category"><option value="all">${dt("كل الفئات", "Toutes")}</option>${model.collections.map((collection) => `<option value="${esc(collection.handle)}">${esc(lng(collection.title))}</option>`).join("")}</select></div>
      <div class="form-grid" style="margin-top:10px"><div class="field"><label>${dt("نسبة التغيير %", "Pourcentage")}</label><input id="bulk-percent" type="number" value="5" placeholder="5"></div><div class="field"><label>${dt("الاتجاه", "Sens")}</label><select id="bulk-direction"><option value="up">${dt("زيادة", "Augmenter")}</option><option value="down">${dt("تخفيض", "Diminuer")}</option></select></div></div>
      <p class="form-note" style="margin-top:10px">${dt("سيتم تحديث السعر الأخير مع الحفاظ على السعر المشطوب كما هو. يمكنك التراجع بعدم النشر.", "Le prix sera ajusté. Le prix barré reste inchangé. Vous pouvez annuler avant publication.")}</p>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="apply-bulk-price">${dt("تطبيق", "Appliquer")}</button>`
    });
  }

  function applyBulkPrice() {
    const category = $("#bulk-category")?.value || "all";
    const percent = Number($("#bulk-percent")?.value) || 0;
    const direction = $("#bulk-direction")?.value || "up";
    let count = 0;
    model.products.forEach((product) => {
      if (product.active === false) return;
      if (category !== "all" && !(product.collections || []).includes(category)) return;
      const factor = direction === "up" ? 1 + percent / 100 : 1 - percent / 100;
      product.price = Math.max(0, Math.round(Number(product.price) * factor / 5) * 5);
      count += 1;
    });
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(`${count} ${dt("منتجًا تم تحديث سعره", "produits mis à jour")}`, "good");
  }

  function deleteProduct(index, fromBuffer = false) {
    const product = fromBuffer ? editBuffer : model.products[index];
    if (!product) return;
    if (!confirm(`${dt("حذف", "Supprimer")} ${product.title?.ar || product.handle}?`)) return;
    if (fromBuffer) model.products = model.products.filter((item) => item.handle !== product.handle);
    else model.products.splice(index, 1);
    saveDraftNow();
    closeModal();
    R.addAudit(`${dt("حذف منتج", "Produit supprimé")}: ${product.handle}`);
    renderRoute();
    toast(dt("تم حذف المنتج من المسودة", "Produit supprimé du brouillon"), "good");
  
  }).call(ctx);
}
