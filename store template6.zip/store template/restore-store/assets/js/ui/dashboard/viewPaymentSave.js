/* extracted dashboard view */
export function viewPaymentSave(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    if (!editBuffer) return;
    if (pendingPaymentIndex == null) model.settings.payments.push(editBuffer);
    else model.settings.payments[pendingPaymentIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ طريقة الدفع", "Paiement enregistré"), "good");
  }

  let pendingCityIndex = null;
  function cityEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `city-${Date.now().toString(36)}`, name: { ar: "", fr: "" }, fee: 0, days: { ar: "2–4 أيام", fr: "2–4 jours" }, active: true } : clone(model.settings.cities[index]);
    editBuffer = buffer;
    pendingCityIndex = isNew ? null : index;
    openModal(isNew ? dt("مدينة جديدة", "Nouvelle ville") : lng(buffer.name), `
      <div class="form-grid">
        ${editBi(dt("المدينة", "Ville"), "name", buffer.name)}
        <div class="field"><label>${dt("رسوم الشحن", "Frais")}</label><input type="number" data-edit-path="fee" value="${esc(buffer.fee)}"></div>
        ${editBi(dt("المدة", "Délai"), "days", buffer.days)}
        <div class="span-2">${editToggle(dt("نشطة", "Active"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-city-buffer")
    });
  
  }).call(ctx);
}
