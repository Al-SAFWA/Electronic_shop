// legacy dashboard chunk 4
          <div class="list-editor">${(settings.navigation || []).map((item, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(item.label))}</strong><small class="handle">${esc(item.href)}</small></div>${directToggle("", `settings.navigation.${index}.visible`, item.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-nav" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-nav" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
          <p class="form-note" style="margin-top:10px">${dt("كل عنصر يمكن أن يحتوي على قائمة فرعية. استخدم محرر العنصر لإضافة روابط مثل S24 Series أو iPhone 16.", "Chaque entrée peut contenir un sous-menu. Utilisez l’éditeur pour ajouter des liens comme Galaxy S24.")}</p>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="content-footer">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أعمدة التذييل", "Colonnes du pied de page")}</h3></div><div class="dash-card-body dash-form">
          ${(settings.footerColumns || []).map((column, index) => `<div class="form-section"><h4>${dt("عمود", "Colonne")} ${index + 1}</h4><div class="form-grid">${["ar", "fr"].map((language) => `<div class="field"><label>${language.toUpperCase()}</label><input data-path="settings.footerColumns.${index}.title.${language}" value="${esc(column.title?.[language] || "")}" dir="${language === "ar" ? "rtl" : "ltr"}"></div>`).join("")}</div><div class="field" style="margin-top:8px"><label>${dt("روابط (اسم|رابط في كل سطر)", "Liens (nom|URL par ligne)")}</label><textarea rows="4" data-lines-path="settings.footerColumns.${index}.links">${esc((column.links || []).map((link) => `${link.label?.ar || ""}|${link.label?.fr || ""}|${link.href}`).join("\n"))}</textarea></div></div>`).join("")}
          <button class="btn btn-soft" data-action="add-footer-column">${icon("plus")} ${dt("إضافة عمود", "Ajouter une colonne")}</button>
        </div></article>
      </div>`;
  }

  function navEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `nav-${Date.now().toString(36)}`, label: { ar: "عنصر جديد", fr: "Nouvel élément" }, href: "collection.html?handle=all", visible: true, sub: [] } : clone(model.settings.navigation[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("عنصر قائمة", "Élément de navigation") : lng(buffer.label), `
      <div class="form-grid">
        ${editBi(dt("الاسم", "Nom"), "label", buffer.label)}
        ${editInput(dt("الرابط", "Lien"), "href", { value: buffer.href })}
        <div class="field span-2"><label>${dt("قائمة فرعية (اسم عربي|اسم فرنسي|رابط في كل سطر)", "Sous-menu (nom AR|nom FR|URL par ligne)")}</label><textarea rows="6" data-subnav>${esc((buffer.sub || []).map((item) => `${item.label?.ar || ""}|${item.label?.fr || ""}|${item.href}`).join("\n"))}</textarea></div>
        ${editToggle(dt("ظاهر", "Visible"), "visible", buffer.visible !== false)}
      </div>`, {
      footer: editorFooter(!isNew, "delete-nav-buffer"),
      onMount: () => { pendingNavIndex = isNew ? null : index; }
    });
  }
  let pendingNavIndex = null;

  function saveNavEditor() {
    const item = editBuffer;
    if (!item) return;
    const subNode = $("[data-subnav]");
    item.sub = (subNode?.value || "").split("\n").map((line) => {
      const [ar, fr, href] = line.split("|").map((part) => part.trim());
      return ar && href ? { label: { ar, fr: fr || ar }, href } : null;
    }).filter(Boolean);
    if (pendingNavIndex == null) model.settings.navigation.push(item);
    else model.settings.navigation[pendingNavIndex] = item;
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(dt("تم حفظ عنصر القائمة", "Navigation enregistrée"), "good");
  }

  /* --------------------------------------------------------------------------
     Homepage
     -------------------------------------------------------------------------- */
  const PAGE_SECTION_LABELS = {
    hero: { ar: "السلايدر الرئيسي", fr: "Hero / Slider" },
    trust: { ar: "شريط الثقة", fr: "Barre de confiance" },
    renewed: { ar: "ما معنى مجدد", fr: "Reconditionné" },
    categories: { ar: "الفئات", fr: "Catégories" },
    offer: { ar: "عرض بنكيلي", fr: "Offre Bankily" },
    products: { ar: "أقسام المنتجات", fr: "Sections produits" },
    sustain: { ar: "الاستدامة", fr: "Durabilité" },
    service: { ar: "الخدمات", fr: "Services" },
    video: { ar: "المجتمع والفيديو", fr: "Communauté & vidéo" },
    reviews: { ar: "آراء العملاء", fr: "Avis clients" },
    press: { ar: "الصحافة", fr: "Presse" }
  };

  function viewHomepage() {
    const sections = [...(model.settings.pageSections || [])].sort((a, b) => Number(a.order) - Number(b.order));
    const productSections = [...(model.settings.homeSections || [])].sort((a, b) => Number(a.order) - Number(b.order));
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الصفحة الرئيسية", "Page d’accueil")}</h2><p>${dt("أعد ترتيب الأقسام، أخفِ أي قسم، وعدّل السلايدر والعروض.", "Réorganisez les sections, masquez-en et modifiez le slider.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" data-action="preview">${icon("preview")} ${dt("معاينة", "Aperçu")}</button></div>
      </div>
      <div class="dash-tabs"><button class="active" data-dash-tab="home-sections">${dt("ترتيب الأقسام", "Ordre des sections")}</button><button data-dash-tab="home-hero">${dt("السلايدر", "Slider")}</button><button data-dash-tab="home-products">${dt("أقسام المنتجات", "Sections produits")}</button></div>
      <div class="dash-panel active" data-dash-panel="home-sections">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام الصفحة", "Sections de la page")}</h3><span class="badge-soft">${sections.filter((section) => section.visible !== false).length}/${sections.length}</span></div><div class="dash-card-body"><div class="list-editor">
            ${sections.map((section, index) => `<div class="list-row"><span class="drag">${icon("arrows")}</span><div class="grow"><strong>${esc(PAGE_SECTION_LABELS[section.id]?.[dashLang] || section.id)}</strong><small>${section.id}</small></div><div class="row-actions"><button class="btn btn-sm btn-soft" data-action="page-section-up" data-id="${section.id}" ${index === 0 ? "disabled" : ""}>${icon("up")}</button><button class="btn btn-sm btn-soft" data-action="page-section-down" data-id="${section.id}" ${index === sections.length - 1 ? "disabled" : ""}>${icon("down")}</button><label class="toggle"><input type="checkbox" data-page-section-visible="${section.id}" ${section.visible !== false ? "checked" : ""}><span></span></label></div></div>`).join("")}
          </div><p class="form-note" style="margin-top:10px">${dt("التغييرات تظهر في المعاينة فورًا وتُنشر عند الضغط على نشر.", "Les changements apparaissent dans l’aperçu et sont publiés via Publier.")}</p></div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معاينة الترتيب", "Aperçu de l’ordre")}</h3></div><div class="dash-card-body">
            <div style="border:1px solid var(--border);border-radius:10px;padding:10px;display:grid;gap:5px;background:var(--surface-2)">
              ${sections.filter((section) => section.visible !== false).map((section, index) => `<div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:7px 9px;font-size:9px;display:flex;justify-content:space-between"><span>${index + 1}. ${esc(PAGE_SECTION_LABELS[section.id]?.[dashLang] || section.id)}</span><span style="color:var(--soft-muted)">${section.id}</span></div>`).join("")}
            </div>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="home-hero">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("شرائح السلايدر", "Diapositives")}</h3><button data-action="add-hero">${icon("plus")} ${dt("إضافة شريحة", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="list-editor">${(model.settings.heroSlides || []).map((slide, index) => `<div class="list-row"><span class="image-preview" style="width:44px;height:44px;flex-basis:44px"><img src="${esc(slide.image)}" alt=""></span><div class="grow"><strong>${esc(lng(slide.title))}</strong><small>${esc(slide.href)}</small></div>${directToggle("", `settings.heroSlides.${index}.visible`, slide.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-hero" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-hero" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
          <p class="form-note" style="margin-top:10px">${dt("ضع صورة بخلفية شفافة للحصول على أفضل نتيجة. يمكن استخدام رابط أو رفع صورة.", "Utilisez une image à fond transparent. URL ou téléversement.")}</p>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="home-products">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام المنتجات على الرئيسية", "Sections produits")}</h3></div><div class="dash-card-body">
          <div class="list-editor">${productSections.map((section, index) => `<div class="list-row"><span class="drag">${icon("arrows")}</span><div class="grow"><strong>${esc(lng(section.title))}</strong><small class="handle">${esc(section.collection || "")} · ${esc(section.layout)}</small></div><div class="row-actions"><button class="btn btn-sm btn-soft" data-action="home-section-up" data-id="${section.id}" ${index === 0 ? "disabled" : ""}>${icon("up")}</button><button class="btn btn-sm btn-soft" data-action="home-section-down" data-id="${section.id}" ${index === productSections.length - 1 ? "disabled" : ""}>${icon("down")}</button><label class="toggle"><input type="checkbox" data-home-section-visible="${section.id}" ${section.visible !== false ? "checked" : ""}><span></span></label><button class="btn btn-sm btn-soft" data-action="edit-home-section" data-id="${section.id}">${icon("edit")}</button></div></div>`).join("")}</div>
          <button class="btn btn-soft" style="margin-top:10px" data-action="add-home-section">${icon("plus")} ${dt("إضافة قسم منتجات", "Ajouter une section")}</button>
        </div></article>
      </div>`;
  }

  let pendingHeroIndex = null;
  function heroEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `hero-${Date.now().toString(36)}`, visible: true, title: { ar: "", fr: "" }, subtitle: { ar: "", fr: "" }, cta: { ar: "تسوق الآن", fr: "Découvrir" }, href: "collection.html?handle=all", image: "assets/img/hero-iphone.png", bg: "linear-gradient(135deg,#1f1f2e 0%,#39255b 55%,#ff6400 130%)", dark: true } : clone(model.settings.heroSlides[index]);
    editBuffer = buffer;
    pendingHeroIndex = isNew ? null : index;
    openModal(isNew ? dt("شريحة جديدة", "Nouvelle diapositive") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        ${editBi(dt("العنوان الفرعي", "Sous-titre"), "subtitle", buffer.subtitle, { type: "textarea", rows: 3 })}
        ${editBi(dt("زر الدعوة", "Bouton"), "cta", buffer.cta)}
        ${editInput(dt("رابط الزر", "Lien du bouton"), "href", { value: buffer.href })}
        <div class="field span-2"><label>CSS background</label><input data-edit-path="bg" value="${esc(buffer.bg)}" dir="ltr"></div>
        <div class="field span-2">${imageEditor(dt("صورة الجهاز", "Image appareil"), "image", buffer.image)}</div>
        <div class="span-2">${editToggle(dt("نص داكن على خلفية فاتحة", "Texte foncé sur fond clair"), "dark", buffer.dark === false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-hero-buffer")
    });
  }
  function saveHeroEditor() {
    if (!editBuffer) return;
    if (pendingHeroIndex == null) model.settings.heroSlides.push(editBuffer);
    else model.settings.heroSlides[pendingHeroIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ السلايدر", "Slider enregistré"), "good");
  }

  function homeSectionEditor(id) {
    const index = model.settings.homeSections.findIndex((section) => section.id === id);
    if (index < 0) return;
    const buffer = clone(model.settings.homeSections[index]);
    editBuffer = buffer;
    openModal(lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("المجموعة", "Collection")}</label><select data-edit-path="collection">${model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${collection.handle === buffer.collection ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("")}</select></div>
        <div class="field"><label>${dt("التخطيط", "Disposition")}</label><select data-edit-path="layout">${["plain", "left", "right"].map((layout) => `<option ${buffer.layout === layout ? "selected" : ""}>${layout}</option>`).join("")}</select></div>
        <div class="field span-2">${imageEditor(dt("صورة البانر الجانبي", "Image promo"), "promo", buffer.promo || "")}</div>
        <div class="span-2">${editToggle(dt("إظهار شعلة", "Afficher la flamme"), "flame", Boolean(buffer.flame))}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-home-section" data-id="${id}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function moveInArray(array, index, direction) {
    const target = index + direction;
    if (target < 0 || target >= array.length) return;
    [array[index], array[target]] = [array[target], array[index]];
    array.forEach((item, position) => { item.order = position + 1; });
  }

  /* --------------------------------------------------------------------------
     Appearance
     -------------------------------------------------------------------------- */
  function viewAppearance() {
    const colors = model.settings.colors || {};
    const fonts = ["Montserrat", "Tajawal", "Cairo", "Inter", "Poppins", "DM Sans"];
    return `
      <div class="dash-view-head"><div><h2>${dt("الهوية والألوان", "Identité & couleurs")}</h2><p>${dt("غيّر الشعار والألوان والخط. تظهر التغييرات في المتجر بعد النشر.", "Changez logo, couleurs et police. Les changements sont publiés sur la boutique.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="preview">${icon("preview")} ${dt("معاينة مباشرة", "Aperçu")}</button></div></div>
      <div class="dash-grid cols-2">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الشعار والأيقونات", "Logo & icônes")}</h3></div><div class="dash-card-body dash-form">
          ${directImageEditor(dt("الشعار الأساسي", "Logo principal"), "settings.logo", model.settings.logo)}
          ${directImageEditor(dt("الشعار الأبيض", "Logo blanc"), "settings.logoWhite", model.settings.logoWhite)}
          ${directImageEditor(dt("أيقونة الموقع", "Favicon"), "settings.favicon", model.settings.favicon)}
          <div class="form-grid">${field(dt("الانحناء (px)", "Arrondi (px)"), "settings.radius", { type: "number" })}<div class="field"><label>${dt("خط الواجهة", "Police")}</label><select data-path="settings.font">${fonts.map((font) => `<option value="${font}" ${model.settings.font === font ? "selected" : ""}>${font}</option>`).join("")}</select></div></div>
        </div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("ألوان العلامة", "Couleurs de marque")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">
            ${field(dt("اللون الأساسي", "Couleur principale"), "settings.colors.primary", { type: "color" })}
            ${field(dt("اللون الثانوي", "Couleur secondaire"), "settings.colors.purple", { type: "color" })}
            ${field(dt("لون النص", "Couleur texte"), "settings.colors.ink", { type: "color" })}
            ${field(dt("الخلفية الفاتحة", "Fond clair"), "settings.colors.lavender", { type: "color" })}
          </div>
          <div style="border-radius:12px;padding:18px;background:var(--surface-2);border:1px solid var(--border);margin-top:4px">
            <span class="eyebrow">${dt("معاينة", "Aperçu")}</span>
            <h3 style="font-size:22px;margin:8px 0 6px">${esc(lng(model.settings.storeName))}</h3>
            <p style="font-size:11px;color:var(--muted);margin-bottom:12px">${esc(lng(model.settings.tagline))}</p>
            <button class="btn btn-primary btn-sm" type="button">${dt("تسوق الآن", "Découvrir")}</button>
            <button class="btn btn-soft btn-sm" type="button" style="margin-inline-start:5px">${dt("معرفة المزيد", "En savoir plus")}</button>
          </div>
          <p class="form-note">${dt("يوفر المتجر الوضع الفاتح والداكن تلقائيًا. الألوان تُطبّق على الأزرار، الشريط العلوي والعروض.", "Le mode clair/sombre est automatique. Les couleurs s’appliquent aux boutons, au header et aux offres.")}</p>
        </div></article>
      </div>
      <article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("الوضع الليلي والحركات", "Mode sombre et animations")}</h3></div><div class="dash-card-body"><div class="form-grid">${directToggle(dt("تفعيل الوضع الليلي للزوار", "Activer le mode sombre"), "settings.darkMode", model.settings.darkMode !== false)}${directToggle(dt("تفعيل الحركات", "Activer les animations"), "settings.animations", model.settings.animations !== false)}${directToggle(dt("تفعيل PWA", "Activer la PWA"), "settings.pwa", model.settings.pwa !== false)}</div></div></article>`;
  }

  /* --------------------------------------------------------------------------
     Marketing / coupons
     -------------------------------------------------------------------------- */
  function viewMarketing() {
    const offer = (model.settings.offers || []).find((item) => item.id === "bankily") || (model.settings.offers || [])[0] || {};
    return `
      <div class="dash-view-head"><div><h2>${dt("العروض والتسويق", "Offres & marketing")}</h2><p>${dt("كوبونات، عرض بنكيلي والبانر الترويجي.", "Coupons, offre Bankily et bannière promo.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="marketing-offer">${dt("عرض بنكيلي", "Offre Bankily")}</button><button data-dash-tab="marketing-coupons">${dt("الكوبونات", "Coupons")}</button><button data-dash-tab="marketing-banner">${dt("بانر وإعلان", "Bannière & annonce")}</button></div>
      <div class="dash-panel active" data-dash-panel="marketing-offer">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("عرض الدفع عبر بنكيلي", "Offre Bankily")}</h3><span class="badge-soft orange">-10%</span></div><div class="dash-card-body dash-form">
            <div class="form-grid">${biField(dt("العنوان", "Titre"), "settings.offers.0.title")}${biField(dt("الوصف", "Sous-titre"), "settings.offers.0.subtitle", { type: "textarea", rows: 2 })}</div>
            <div class="form-grid">${field(dt("كود الخصم", "Code promo"), "settings.offers.0.code")}${field(dt("نهاية العرض", "Fin de l’offre"), "settings.offers.0.endsAt", { type: "datetime-local" })}</div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.offers.0.active" data-type="bool" ${offer.active !== false ? "checked" : ""}><span></span></label><span>${dt("العرض نشط", "Offre active")}</span></div>
            ${biField(dt("نص عرض الدفع في المنتج", "Texte offre au produit"), "settings.paymentOffer", { type: "textarea", rows: 2 })}
            ${field(dt("كود بانكيلي", "Code Bankily"), "settings.paymentOfferCode")}
            <p class="form-note">${dt("يُعرض العد التنازلي تلقائيًا حتى تاريخ النهاية. الكود يُطبق عند اختيار الدفع عبر بنكيلي.", "Le compte à rebours s’affiche jusqu’à la date de fin. Le code s’applique avec Bankily.")}</p>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معاينة العرض", "Aperçu de l’offre")}</h3></div><div class="dash-card-body">
            <div style="border-radius:14px;padding:24px;background:linear-gradient(135deg,#15151d,#3b2235);color:#fff">
              <span style="font-size:9px;letter-spacing:.1em;color:#ffb38b">BANKILY · -10%</span>
              <h3 style="font-size:21px;margin:9px 0 7px;line-height:1.2">${esc(lng(offer.title))}</h3>
              <p style="font-size:10px;color:rgba(255,255,255,.65);line-height:1.6">${esc(lng(offer.subtitle))}</p>
              <span style="display:inline-block;margin-top:13px;border:1px dashed rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;letter-spacing:.12em">${esc(offer.code || "BANKILY10")}</span>
            </div>
            <p class="form-note" style="margin-top:10px">${dt("ينتهي", "Se termine")}: ${esc(offer.endsAt ? fmtDateTime(offer.endsAt) : "—")}</p>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="marketing-coupons">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("كوبونات الخصم", "Coupons")}</h3><button data-action="add-coupon">${icon("plus")} ${dt("كوبون جديد", "Nouveau coupon")}</button></div><div class="dash-card-body">
          <div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الكود", "Code")}</th><th>${dt("النوع", "Type")}</th><th>${dt("القيمة", "Valeur")}</th><th>${dt("الحد الأدنى", "Minimum")}</th><th>${dt("الانتهاء", "Expiration")}</th><th>${dt("نشط", "Actif")}</th><th></th></tr></thead><tbody>
            ${(model.settings.coupons || []).map((coupon, index) => `<tr><td><strong style="direction:ltr">${esc(coupon.code)}</strong></td><td>${coupon.type === "percent" ? dt("نسبة", "Pourcentage") : dt("ثابت", "Fixe")}</td><td>${coupon.type === "percent" ? `${coupon.value}%` : money(coupon.value)}</td><td>${money(coupon.minTotal || 0)}</td><td>${coupon.expiresAt ? esc(fmtDate(coupon.expiresAt)) : "—"}</td><td><label class="toggle"><input type="checkbox" data-coupon-active="${index}" ${coupon.active !== false ? "checked" : ""}><span></span></label></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-coupon" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-coupon" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
          </tbody></table></div>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="marketing-banner">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("البانر والرسائل", "Bannière & messages")}</h3></div><div class="dash-card-body dash-form">
          ${biField(dt("شريط الإعلان العلوي", "Bandeau haut"), "settings.announcement", { type: "textarea", rows: 2 })}
          <div class="form-grid">${biField(dt("رسالة المتجر المغلق", "Message boutique fermée"), "settings.closedMessage", { type: "textarea", rows: 2 })}${biField(dt("عنوان عرض الرئيسية", "Titre offre accueil"), "settings.paymentOffer", { type: "textarea", rows: 2 })}</div>
          ${biField(dt("عنوان قسم الاستدامة", "Titre durabilité"), "settings.sustainabilityTitle")}
          <p class="form-note">${dt("البانر يعرض تلقائيًا في أعلى كل صفحات المتجر. يمكن إخفاؤه من إعدادات الواجهة.", "La bannière s’affiche en haut du site. Masquable depuis l’apparence.")}</p>
        </div></article>
      </div>`;
  }

  function couponEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `coupon-${Date.now().toString(36)}`, code: "RESTORE10", type: "percent", value: 10, active: true, minTotal: 0, expiresAt: "" } : clone(model.settings.coupons[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("كوبون جديد", "Nouveau coupon") : buffer.code, `
      <div class="form-grid">
        ${editInput(dt("الكود", "Code"), "code", { value: buffer.code })}
        <div class="field"><label>${dt("النوع", "Type")}</label><select data-edit-path="type"><option value="percent" ${buffer.type === "percent" ? "selected" : ""}>${dt("نسبة مئوية", "Pourcentage")}</option><option value="fixed" ${buffer.type === "fixed" ? "selected" : ""}>${dt("مبلغ ثابت", "Montant fixe")}</option></select></div>
        ${editInput(dt("القيمة", "Valeur"), "value", { type: "number", value: buffer.value })}
        ${editInput(dt("الحد الأدنى للطلب", "Minimum de commande"), "minTotal", { type: "number", value: buffer.minTotal || 0 })}
        ${editInput(dt("تاريخ الانتهاء", "Date d’expiration"), "expiresAt", { type: "date", value: buffer.expiresAt ? String(buffer.expiresAt).slice(0, 10) : "" })}
        <div class="span-2">${editToggle(dt("نشط", "Actif"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-coupon" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  /* --------------------------------------------------------------------------
     Blog and pages
     -------------------------------------------------------------------------- */
  function viewBlog() {
    return `
      <div class="dash-view-head"><div><h2>${dt("المدونة", "Blog")}</h2><p>${dt("مقالات تساعد العملاء وتقوي SEO.", "Des articles utiles et bons pour le SEO.")}</p></div><div class="dash-view-actions"><button class="btn btn-primary" data-action="add-post">${icon("plus")} ${dt("مقال جديد", "Nouvel article")}</button></div></div>
      <div class="dash-card"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المقال", "Article")}</th><th>${dt("الرابط", "Slug")}</th><th>${dt("التاريخ", "Date")}</th><th>${dt("منشور", "Publié")}</th><th></th></tr></thead><tbody>
        ${(model.blog || []).map((post, index) => `<tr><td><div class="cell-main"><img src="${esc(post.image)}" alt=""><div><strong>${esc(lng(post.title))}</strong><small>${esc(lng(post.excerpt))}</small></div></div></td><td class="handle" style="direction:ltr">${esc(post.slug)}</td><td>${esc(post.date)}</td><td><span class="badge-soft ${post.published !== false ? "green" : ""}">${post.published !== false ? dt("منشور", "Publié") : dt("مسودة", "Brouillon")}</span></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-post" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-post" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
      </tbody></table></div></div>`;
  }

  let pendingPostIndex = null;
  function postEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `post-${Date.now().toString(36)}`, slug: `post-${Date.now().toString(36)}`, title: { ar: "", fr: "" }, excerpt: { ar: "", fr: "" }, body: { ar: "", fr: "" }, image: "assets/img/category-iphone.png", date: new Date().toISOString().slice(0, 10), published: true } : clone(model.blog[index]);
    editBuffer = buffer;
    pendingPostIndex = isNew ? null : index;
    openModal(isNew ? dt("مقال جديد", "Nouvel article") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("الرابط", "Slug")}</label><input data-edit-path="slug" value="${esc(buffer.slug)}" dir="ltr"></div>
        <div class="field"><label>${dt("التاريخ", "Date")}</label><input type="date" data-edit-path="date" value="${esc(buffer.date)}"></div>
        ${editBi(dt("المقتطف", "Extrait"), "excerpt", buffer.excerpt, { type: "textarea", rows: 2 })}
        <div class="span-2">${imageEditor(dt("الصورة", "Image"), "image", buffer.image)}</div>
        ${editBi(dt("المحتوى", "Contenu"), "body", buffer.body, { type: "textarea", rows: 10 })}
        <div class="span-2">${editToggle(dt("نشر المقال", "Publier"), "published", buffer.published !== false)}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-post" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function viewPages() {
    return `
      <div class="dash-view-head"><div><h2>${dt("الصفحات", "Pages")}</h2><p>${dt("الصفحات الثابتة والأسئلة الشائعة.", "Pages statiques et FAQ.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="pages-static">${dt("الصفحات", "Pages")}</button><button data-dash-tab="pages-faq">${dt("الأسئلة الشائعة", "FAQ")}</button></div>
      <div class="dash-panel active" data-dash-panel="pages-static">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الصفحات الثابتة", "Pages statiques")}</h3><button data-action="add-page">${icon("plus")} ${dt("صفحة جديدة", "Nouvelle page")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.pages || []).map((page, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(page.title))}</strong><small class="handle">${esc(page.slug)}</small></div>${directToggle("", `pages.${index}.visible`, page.visible !== false)}<a class="btn btn-sm btn-soft" href="page.html?slug=${encodeURIComponent(page.slug)}" target="_blank" rel="noopener" title="${dt("معاينة", "Aperçu")}">${icon("external")}</a><button class="btn btn-sm btn-soft" data-action="edit-page" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-page" data-index="${index}">${icon("trash")}</button></div>`).join("")}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pages-faq">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الأسئلة الشائعة", "FAQ")}</h3><button data-action="add-faq">${icon("plus")} ${dt("سؤال جديد", "Nouvelle question")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.faqs || []).map((faq, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(faq.q))}</strong><small>${esc(lng(faq.a)).slice(0, 90)}</small></div><button class="btn btn-sm btn-soft" data-action="edit-faq" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-faq" data-index="${index}">${icon("trash")}</button></div>`).join("")}
        </div></div></article>
      </div>`;
  }

  let pendingPageIndex = null;
  function pageEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { slug: `page-${Date.now().toString(36)}`, title: { ar: "", fr: "" }, body: { ar: "", fr: "" }, visible: true, seoTitle: { ar: "", fr: "" }, seoDescription: { ar: "", fr: "" } } : clone(model.pages[index]);
    editBuffer = buffer;
    pendingPageIndex = isNew ? null : index;
    openModal(isNew ? dt("صفحة جديدة", "Nouvelle page") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("الرابط", "Slug")}</label><input data-edit-path="slug" value="${esc(buffer.slug)}" dir="ltr"></div>
        ${editBi(dt("محتوى الصفحة", "Contenu"), "body", buffer.body, { type: "textarea", rows: 12 })}
        ${editBi(dt("عنوان SEO", "Titre SEO"), "seoTitle", buffer.seoTitle)}
        ${editBi(dt("وصف SEO", "Description SEO"), "seoDescription", buffer.seoDescription, { type: "textarea", rows: 2 })}
        <p class="form-note span-2">${dt("الرابط يستخدم حروفًا إنجليزية صغيرة وأرقامًا وشرطات فقط. يظهر المحتوى في المتجر مباشرة بعد النشر.", "Le slug utilise des minuscules, chiffres et tirets. Le contenu apparaît après publication.")}</p>
        ${editToggle(dt("ظاهرة", "Visible"), "visible", buffer.visible !== false)}
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-page" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function savePageEditor() {
    if (!editBuffer) return;
    const slug = String(editBuffer.slug || "").trim().toLowerCase();
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 80) {
      return toast(dt("الرابط: حروف إنجليزية صغيرة وأرقام وشرطات فقط", "Slug : minuscules, chiffres et tirets uniquement"), "error");
    }
    const duplicate = (model.pages || []).some((page, index) => page.slug === slug && index !== pendingPageIndex);
    if (duplicate) return toast(dt("هذا الرابط مستخدم لصفحة أخرى", "Ce slug est déjà utilisé"), "error");
    if (!String(editBuffer.title?.ar || editBuffer.title?.fr || "").trim()) return toast(dt("عنوان الصفحة مطلوب", "Le titre est requis"), "error");
    editBuffer.slug = slug;
    editBuffer.seoTitle = editBuffer.seoTitle || editBuffer.title;
    if (pendingPageIndex == null) model.pages.push(editBuffer);
    else model.pages[pendingPageIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ الصفحة في المسودة. انشر لتظهر للزوار.", "Page enregistrée en brouillon. Publiez pour la rendre visible."), "good");
  }

  function faqEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `faq-${Date.now().toString(36)}`, q: { ar: "", fr: "" }, a: { ar: "", fr: "" } } : clone(model.faqs[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("سؤال جديد", "Nouvelle question") : lng(buffer.q), `
      <div class="dash-form">${editBi(dt("السؤال", "Question"), "q", buffer.q)}${editBi(dt("الجواب", "Réponse"), "a", buffer.a, { type: "textarea", rows: 4 })}</div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-faq" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }
  /* --------------------------------------------------------------------------
     Reviews
     -------------------------------------------------------------------------- */
    function viewReviews() {
    if (!Array.isArray(model.reviews)) model.reviews = [];
    const home = model.homeReviews || [];
    const allCustomer = R.getAllCustomerReviews();
    const pending = allCustomer.filter((review) => review.status === "pending");
    const approved = allCustomer.filter((review) => review.status === "approved");
    const rejected = allCustomer.filter((review) => review.status === "rejected");
    if (!viewReviews.refreshed) {
      viewReviews.refreshed = true;
      R.refreshReviews().catch(() => {});
    }
    const customerRow = (review, actions) => `<div class="list-row review-pending-row">
      <div class="grow">
        <strong>${esc(review.customerName)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong>
        <small>${esc(review.productHandle)} — ${esc(L(review.title))}</small>
        <p class="review-body-preview">${esc(String(L(review.body)).slice(0, 160))}${String(L(review.body)).length > 160 ? "…" : ""}</p>
        <small class="review-date">${esc(R.formatDate(review.createdAt))}${review.email ? ` · ${esc(review.email)}` : ""}</small>
      </div>
      <div class="cell-actions">${actions}</div>
    </div>`;
    return `
      <div class="dash-view-head"><div><h2>${dt("التقييمات", "Avis clients")}</h2><p>${dt("إدارة تقييمات الصفحة الرئيسية، المنتجات، وتقييمات العملاء.", "Gestion des avis accueil, produits et avis clients.")}</p></div></div>
      <div class="dash-tabs">
        <button class="active" data-dash-tab="reviews-home">${dt("الرئيسية", "Accueil")} <span class="badge-soft">${home.length}</span></button>
        <button data-dash-tab="reviews-products">${dt("المنتجات", "Produits")} <span class="badge-soft">${(model.reviews || []).length}</span></button>
        <button data-dash-tab="reviews-customers">${dt("العملاء", "Clients")} <span class="badge-soft ${pending.length ? "orange" : ""}">${pending.length}</span></button>
      </div>
      <div class="dash-panel active" data-dash-panel="reviews-home">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("آراء الصفحة الرئيسية", "Avis page d’accueil")}</h3><button class="btn btn-primary btn-sm" data-action="add-home-review">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${home.map((review, index) => `<div class="list-row"><div class="grow"><strong>${esc(review.name)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong><small>${esc(L(review.title))} — ${esc(L(review.city))}</small></div><button class="btn btn-sm btn-soft" data-action="edit-home-review" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-home-review" data-index="${index}">${icon("trash")}</button></div>`).join("") || `<div class="empty-dash">${dt("لا توجد تقييمات.", "Aucun avis.")}</div>`}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="reviews-products">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تقييمات المنتجات", "Avis produits")}</h3><button class="btn btn-soft" data-action="add-product-review">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.reviews || []).map((review, index) => `<div class="list-row"><div class="grow"><strong>${esc(review.name)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong><small>${esc(review.handle)} — ${esc(L(review.title))}</small></div><label class="toggle"><input type="checkbox" data-review-approved="${index}" ${review.approved !== false ? "checked" : ""}><span></span></label><button class="btn btn-sm btn-soft" data-action="edit-product-review" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-product-review" data-index="${index}">${icon("trash")}</button></div>`).join("") || `<div class="empty-dash">${dt("لا توجد تقييمات منتجات مخصصة.", "Aucun avis produit dédié.")}</div>`}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="reviews-customers">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تقييمات العملاء المعلقة", "Avis clients en attente")}</h3><span class="badge-soft orange">${pending.length}</span></div><div class="dash-card-body">
          ${pending.length ? `<div class="list-editor">
