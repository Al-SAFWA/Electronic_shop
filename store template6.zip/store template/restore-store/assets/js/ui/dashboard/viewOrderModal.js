/* extracted dashboard view */
export function viewOrderModal(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const order = R.getOrders().find((item) => item.id === id);
    if (!order) return;
    const status = R.statusMeta(order.status);
    const wa = `https://wa.me/${digits(order.customer?.phone)}?text=${encodeURIComponent(orderMessage(order, "confirm"))}`;
    openModal(`${dt("الطلب", "Commande")} ${order.id}`, `
      <div class="order-detail">
        <div>
          <div class="order-detail-section">
            <h4>${dt("المنتجات", "Articles")}</h4>
            ${(order.items || []).map((item) => `<div class="order-item-row"><img src="${esc(item.image || "assets/img/favicon.svg")}" alt=""><div class="grow"><strong>${esc(item.title)}</strong><small>${esc(item.variantTitle || "")} ${item.specsText ? `· ${esc(item.specsText)}` : ""}</small></div><span>×${item.qty}</span><strong>${money(item.line)}</strong></div>`).join("")}
            <div class="order-totals">
              <div><span>${dt("المجموع الفرعي", "Sous-total")}</span><span>${money(order.subtotal)}</span></div>
              <div><span>${dt("الشحن", "Livraison")}</span><span>${money(order.shipping)}</span></div>
              <div><span>${dt("الخصم", "Réduction")}</span><span>${money(order.discount)}</span></div>
              <div class="total"><span>${dt("المجموع", "Total")}</span><span>${money(order.total)}</span></div>
            </div>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("ملاحظات العميل", "Notes du client")}</h4>
            <p>${esc(order.customer?.notes || dt("لا توجد ملاحظات", "Aucune note"))}</p>
          </div>
        </div>
        <div>
          <div class="order-detail-section">
            <h4>${dt("العميل", "Client")}</h4>
            <p><strong>${esc(order.customer?.name || "")}</strong><br><span dir="ltr">${esc(order.customer?.phone || "")}</span><br>${esc(order.customer?.city || "")}<br>${esc(order.customer?.address || "")}<br>${esc(order.customer?.email || "")}</p>
            <div style="display:flex;gap:5px;margin-top:9px;flex-wrap:wrap"><a class="btn btn-sm btn-whatsapp" href="${wa}" target="_blank" rel="noopener">${icon("whatsapp")} ${dt("واتساب", "WhatsApp")}</a><a class="btn btn-sm btn-soft" href="tel:${esc(order.customer?.phone)}">${dt("اتصال", "Appeler")}</a></div>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("إدارة الطلب", "Gestion")}</h4>
            <div class="field"><label>${dt("الحالة", "Statut")}</label><select data-order-status="${esc(order.id)}">${statusOptions(order.status)}</select></div>
            <div class="field" style="margin-top:8px"><label>${dt("ملاحظة داخلية", "Note interne")}</label><textarea rows="3" data-order-note="${esc(order.id)}">${esc(order.internalNote || "")}</textarea></div>
            <p class="form-note" style="margin-top:8px">${dt("الدفع", "Paiement")}: <strong>${esc(order.payment?.name || "")}</strong> · ${dt("المصدر", "Source")}: ${esc(order.source || "whatsapp")}</p>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("المستندات", "Documents")}</h4>
            <div style="display:flex;gap:5px;flex-wrap:wrap"><button class="btn btn-sm btn-soft" data-action="print-invoice" data-id="${esc(order.id)}">${icon("print")} ${dt("فاتورة", "Facture")}</button><button class="btn btn-sm btn-soft" data-action="print-label" data-id="${esc(order.id)}">${dt("ملصق شحن", "Étiquette")}</button></div>
            <div style="margin-top:12px"><span class="status-pill" style="--status:${status.color}">${esc(lng(status.label))}</span></div>
          </div>
        </div>
      </div>`, {
      wide: true,
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إغلاق", "Fermer")}</button><button class="btn btn-primary btn-sm" data-action="save-order" data-id="${esc(order.id)}">${icon("check")} ${dt("حفظ التغييرات", "Enregistrer")}</button>`
    });
  }

  function exportOrdersCsv() {
    const orders = orderList();
    const rows = [
      ["order_id", "date", "status", "name", "phone", "city", "address", "payment", "items", "subtotal", "shipping", "discount", "total", "currency", "coupon", "notes"],
      ...orders.map((order) => [
        order.id, order.createdAt, order.status, order.customer?.name, order.customer?.phone, order.customer?.city, order.customer?.address,
        order.payment?.name, (order.items || []).map((item) => `${item.title} x${item.qty}`).join(" | "),
        order.subtotal, order.shipping, order.discount, order.total, order.currency || "MRU", order.coupon || "", order.customer?.notes || ""
      ])
    ];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `restore-orders-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
    toast(dt("تم تصدير الطلبات", "Commandes exportées"), "good");
  
  }).call(ctx);
}
