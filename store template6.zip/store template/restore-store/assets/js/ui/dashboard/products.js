import { createProductsRepo } from "../../data/repositories/products.repo.js";
export function createProductsScreen(ctx) {
  const { R, esc, dt, lng, money, token, toast } = ctx;
  const repo = createProductsRepo(R.config, token);
  let items = [], search = "", cat = "all", stock = "all";
  const audit = (action, product) => R.addAudit(`${dt("منتج","Produit")}: ${action} — ${product?.title?.ar || product?.handle || product?.id || ""}`, R.currentSession?.()?.username);
  async function load() { try { items = await repo.list({ limit: 500 }) || []; } catch(e){ console.warn(e); items = R.store?.products || []; } }
  function filtered() {
    return items.filter(p => {
      const q = search.trim().toLowerCase(); if (q && !`${p.handle} ${p.title?.ar||""} ${p.title?.fr||""}`.toLowerCase().includes(q)) return false;
      if (cat !== "all" && !(p.collections||[]).includes(cat) && p.category_id !== cat) return false;
      if (stock === "low") return Number(p.stock) > 0 && Number(p.stock) <= 3;
      if (stock === "out") return Number(p.stock) <= 0;
      return true;
    });
  }
  async function save(product) { await repo.upsert(product); audit("save", product); toast(dt("تم حفظ المنتج","Produit enregistré"),"good"); await load(); }
  async function remove(handle) { await repo.remove(handle); audit("delete", { handle, title:{ar:handle} }); toast(dt("تم حذف المنتج","Produit supprimé"),"good"); await load(); }
  async function toggleActive(handle, active) { await repo.update(handle, { active }); audit(active?"activate":"deactivate", { handle, title:{ar:handle} }); }
  function render() {
    const list = filtered().slice(0,80);
    return `
      <div class="dash-view-head"><div><h2>${dt("المنتجات","Produits")}</h2><p>${items.length} ${dt("منتج","produits")} · ${dt("مصدر علائقي","source relationnelle")} restore_products</p></div>
      <div class="dash-view-actions"><button class="btn btn-primary" data-action="repo-add-product">${dt("منتج جديد","Nouveau produit")}</button></div></div>
      <div class="dash-toolbar"><input id="repo-product-search" class="input" placeholder="${dt("بحث...","Recherche...")}" value="${esc(search)}"></div>
      <div class="dash-card"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المنتج","Produit")}</th><th>${dt("السعر","Prix")}</th><th>${dt("المخزون","Stock")}</th><th>${dt("نشط","Actif")}</th><th></th></tr></thead><tbody>
      ${list.map(p=>`<tr><td><div class="cell-main"><div><strong>${esc(lng(p.title)||p.handle)}</strong><small>${esc(p.handle)}</small></div></div></td><td>${money(p.price)}</td><td>${esc(p.stock)}</td><td><input type="checkbox" data-repo-product-active="${esc(p.handle)}" ${p.active!==false?"checked":""}></td><td><button class="btn btn-sm btn-soft" data-repo-edit-product="${esc(p.handle)}">${dt("تعديل","Modifier")}</button> <button class="btn btn-sm btn-soft" data-repo-delete-product="${esc(p.handle)}">${dt("حذف","Supprimer")}</button></td></tr>`).join("") || `<tr><td colspan="5">${dt("لا منتجات","Aucun produit")}</td></tr>`}
      </tbody></table></div></div>`;
  }
  return { load, render, save, remove, toggleActive, get items(){return items;}, setSearch(v){search=v;}, repo };
}
