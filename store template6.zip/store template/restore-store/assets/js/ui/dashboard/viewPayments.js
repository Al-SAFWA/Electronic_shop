/* extracted dashboard view */
export function viewPayments(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    return `
      <div class="dash-view-head"><div><h2>${dt("الدفع والتوصيل", "Paiement & livraison")}</h2><p>${dt("فعّل طرق الدفع المحلية وحدد رسوم المدن. يمكنك رفع شعار لكل طريقة دفع.", "Activez les paiements locaux et les frais par ville. Vous pouvez télécharger un logo pour chaque moyen de paiement.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="pay-methods">${dt("طرق الدفع", "Moyens de paiement")}</button><button data-dash-tab="pay-cities">${dt("مدن التوصيل", "Villes de livraison")}</button><button data-dash-tab="pay-shipping">${dt("إعدادات الشحن", "Réglages livraison")}</button></div>
      <div class="dash-panel active" data-dash-panel="pay-methods">
        <div class="dash-view-actions" style="justify-content:flex-end;margin-bottom:9px"><button class="btn btn-primary btn-sm" data-action="add-payment">${icon("plus")} ${dt("طريقة دفع", "Moyen de paiement")}</button></div>
        <div class="dash-grid cols-2">
          ${(model.settings.payments || []).map((payment, index) => `<article class="dash-card"><div class="dash-card-body">
            <div style="display:flex;align-items:center;gap:9px;margin-bottom:10px">
              ${(payment.image || payment.logo) ? `<img src="${esc(payment.image || payment.logo)}" alt="" style="width:36px;height:36px;border-radius:9px;object-fit:contain">` : `<span style="width:36px;height:36px;border-radius:9px;background:${esc(payment.color)};color:#fff;display:grid;place-items:center;font-size:10px;font-weight:800">${esc(String(lng(payment.name)).slice(0, 2))}</span>`}
              <div style="flex:1"><strong style="font-size:12px">${esc(lng(payment.name))}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${esc(lng(payment.note))}</small></div>
              <label class="toggle"><input type="checkbox" data-payment-active="${index}" ${payment.active !== false ? "checked" : ""}><span></span></label>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
              <span class="badge-soft ${payment.discount ? "orange" : ""}">${payment.discount ? `-${payment.discount}%` : dt("بدون خصم", "Sans remise")}</span>
              <div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-payment" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-payment" data-index="${index}">${icon("trash")}</button></div>
            </div>
            ${(payment.image || payment.logo) ? `<div class="image-preview" style="margin-top:8px"><img src="${esc(payment.image || payment.logo)}" alt="" style="max-width:100%;max-height:40px;border-radius:6px"></div>` : ""}
          </div></article>`).join("")}
        </div>
        <article class="dash-card" style="margin-top:14px"><div class="dash-card-body">${biField(dt("نص عرض الدفع", "Texte offre paiement"), "settings.paymentOffer", { type: "textarea", rows: 2 })}<p class="form-note" style="margin-top:8px">${dt("يظهر هذا النص في صفحة المنتج وصفحة الدفع. البنكيلي يطبق الخصم المحدد أعلاه تلقائيًا.", "Ce texte apparaît sur la fiche produit et au checkout. Bankily applique automatiquement la remise.")}</p></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pay-cities">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("مدن التوصيل", "Villes de livraison")}</h3><button data-action="add-city">${icon("plus")} ${dt("إضافة مدينة", "Ajouter une ville")}</button></div><div class="dash-card-body"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المدينة", "Ville")}</th><th>${dt("الرسوم", "Frais")}</th><th>${dt("المدة", "Délai")}</th><th>${dt("نشطة", "Active")}</th><th></th></tr></thead><tbody>
          ${(model.settings.cities || []).map((city, index) => `<tr><td><strong>${esc(lng(city.name))}</strong></td><td>${money(city.fee)}</td><td>${esc(lng(city.days))}</td><td><label class="toggle"><input type="checkbox" data-city-active="${index}" ${city.active !== false ? "checked" : ""}><span></span></label></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-city" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-city" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
        </tbody></table></div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pay-shipping">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("إعدادات الشحن", "Réglages livraison")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">${field(dt("الشحن المجاني بعد (MRU)", "Livraison gratuite dès (MRU)"), "settings.freeShippingOver", { type: "number" })}${field(dt("حد المخزون المنخفض", "Seuil stock faible"), "settings.lowStockThreshold", { type: "number" })}</div>
          ${biField(dt("ملاحظة الشحن", "Note livraison"), "settings.shippingNote", { type: "textarea", rows: 2 })}
          ${directToggle(dt("إخفاء المنتجات المنتهية من المتجر", "Masquer les produits épuisés"), "settings.autoHideOutOfStock", model.settings.autoHideOutOfStock)}
          <p class="form-note">${dt("تظهر رسوم كل مدينة في صفحة الدفع ويُضاف الشحن المجاني إذا تجاوز المجموع الحد المحدد.", "Les frais de chaque ville s’affichent au checkout ; la livraison est offerte au-delà du seuil.")}</p>
        </div></article>
      </div>`;
  }

  let pendingPaymentIndex = null;
  function paymentEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `payment-${Date.now().toString(36)}`, name: { ar: "", fr: "" }, image: "", color: "#0b6fb8", active: true, discount: 0, note: { ar: "", fr: "" } } : clone(model.settings.payments[index]);
    editBuffer = buffer;
    pendingPaymentIndex = isNew ? null : index;
    openModal(isNew ? dt("طريقة دفع جديدة", "Nouveau moyen") : lng(buffer.name), `
      <div class="form-grid">
        ${editBi(dt("الاسم", "Nom"), "name", buffer.name)}
        <div class="field"><label>${dt("اللون", "Couleur")}</label><input type="color" data-edit-path="color" value="${esc(buffer.color)}"></div>
        <div class="field"><label>${dt("الخصم %", "Remise %")}</label><input type="number" data-edit-path="discount" value="${esc(buffer.discount || 0)}"></div>
        <div class="field"><label>${dt("ملاحظة", "Note")}</label><input data-edit-path="note.ar" value="${esc(buffer.note?.ar || "")}" dir="rtl"></div>
        <div class="field"><label>Note FR</label><input data-edit-path="note.fr" value="${esc(buffer.note?.fr || "")}" dir="ltr"></div>
        <div class="span-2">${imageEditor(dt("صورة التطبيق", "Image de l’application"), "image", buffer.image || buffer.logo || "")}</div>
        <div class="span-2">${editToggle(dt("مفعلة", "Active"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-payment-buffer")
    });
  
  }).call(ctx);
}
