/* extracted dashboard view */
export function viewOverview(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const orders = orderList();
    const totalRevenue = revenueOfOrders(orders);
    const delivered = orders.filter((order) => order.status === "delivered").length;
    const newCount = orders.filter((order) => order.status === "new").length;
    const cancelled = orders.filter((order) => order.status === "cancelled" || order.status === "returned").length;
    const low = lowStockProducts();
    const abandoned = R.getAbandoned().filter((item) => item.status === "open");
    const recent = orders.slice(0, 6);
    const days = [...Array(7)].map((_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const key = date.toISOString().slice(0, 10);
      const total = orders.filter((order) => String(order.createdAt).slice(0, 10) === key).reduce((sum, order) => sum + Number(order.total || 0), 0);
      return { label: date.toLocaleDateString(dashLang === "ar" ? "ar-MR" : "fr-FR", { weekday: "short" }), total };
    });
    const maxDay = Math.max(1, ...days.map((day) => day.total));
    const statusRows = ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled"].map((status) => {
      const meta = R.statusMeta(status);
      return { status, label: lng(meta.label), color: meta.color, count: orderStatusCount(status) };
    });
    const displayName = session?.role === "owner" ? dt("مالك المتجر", "Propriétaire") : dt("مدير المتجر", "Gérant");
    return `
      <div class="dash-view-head">
        <div><h2>${dt("مرحبًا", "Bonjour")} ${esc(displayName)} 👋</h2><p>${dt("هذا ملخص مباشر لأداء متجرك.", "Voici un résumé en direct de votre boutique.")}</p></div>
        <div class="dash-view-actions">
          <a class="btn btn-primary" href="#products" data-route="products">${icon("plus")} ${dt("إضافة منتج", "Ajouter un produit")}</a>
          <a class="btn btn-soft" href="#reports" data-route="reports">${dt("عرض التقارير", "Voir les rapports")}</a>
        </div>
      </div>
      <div class="dash-grid cols-4" style="margin-bottom:14px">
        ${statCard(dt("إجمالي الطلبات", "Commandes totales"), orders.length, dt("كل الطلبات المسجلة", "Toutes les commandes"), "#ff6400", "orders", newCount ? `+${newCount} ${dt("جديد", "nouveau")}` : "")}
        ${statCard(dt("الإيرادات", "Chiffre d’affaires"), money(totalRevenue), dt("دون الملغاة والمرتجعة", "Hors annulées et retours"), "#128c53", "reports")}
        ${statCard(dt("طلبات جديدة", "Nouvelles commandes"), newCount, dt("تحتاج إلى تأكيد", "À confirmer"), "#a72396", "bell")}
        ${statCard(dt("مخزون منخفض", "Stock faible"), low.length, dt("منتجات تحتاج متابعة", "Produits à suivre"), "#e67e22", "products")}
      </div>
      <div class="dash-grid cols-3" style="margin-bottom:14px">
        <article class="dash-card" style="grid-column:span 2">
          <div class="dash-card-head"><h3>${dt("آخر الطلبات", "Dernières commandes")}</h3><a href="#orders" data-route="orders">${dt("عرض الكل", "Tout voir")}</a></div>
          <div class="dash-card-body" style="padding-top:10px">
            ${recent.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الطلب", "Commande")}</th><th>${dt("العميل", "Client")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("المجموع", "Total")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead><tbody>
              ${recent.map((order) => {
                const status = R.statusMeta(order.status);
                return `<tr>
                  <td><strong>${esc(order.id)}</strong><br><small>${esc(fmtDate(order.createdAt))}</small></td>
                  <td>${esc(order.customer?.name || "")}<br><small dir="ltr">${esc(order.customer?.phone || "")}</small></td>
                  <td>${esc(order.customer?.city || "")}</td>
                  <td class="price">${money(order.total)}</td>
                  <td><span class="status-pill" style="--status:${status.color}">${esc(lng(status.label))}</span></td>
                  <td><button class="btn btn-sm btn-soft" type="button" data-action="view-order" data-id="${esc(order.id)}">${dt("تفاصيل", "Détails")}</button></td>
                </tr>`;
              }).join("")}</tbody></table></div>` : `<div class="empty-dash">${icon("orders")}<p>${dt("لا توجد طلبات بعد. ستظهر الطلبات القادمة من المتجر هنا مباشرة.", "Aucune commande. Les commandes de la boutique apparaîtront ici.")}</p></div>`}
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("حالة المتجر", "État de la boutique")}</h3><a href="#settings" data-route="settings">${dt("إعدادات", "Réglages")}</a></div>
          <div class="dash-card-body">
            <div style="display:flex;align-items:center;gap:9px;padding:9px 0;border-bottom:1px solid var(--border)"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${R.isStoreOpen() ? "#25a55f" : "#c0392b"}"></span><div><strong style="font-size:10px">${R.isStoreOpen() ? dt("المتجر مفتوح", "Boutique ouverte") : dt("المتجر مغلق", "Boutique fermée")}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${model.settings.hours.open} — ${model.settings.hours.close} · ${esc(model.settings.timezone)}</small></div></div>

            <div style="display:flex;align-items:center;gap:9px;padding:9px 0"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${dirty ? "#e67e22" : "#25a55f"}"></span><div><strong style="font-size:10px">${dirty ? dt("مسودة غير منشورة", "Brouillon non publié") : dt("كل التغييرات منشورة", "Tout est publié")}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${dt("آخر تحديث", "Dernière mise à jour")}: ${esc(fmtDateTime(model.updatedAt))}</small></div></div>
            <button class="btn btn-primary btn-block btn-sm" type="button" data-action="preview" style="margin-top:8px">${icon("preview")} ${dt("معاينة المتجر", "Prévisualiser")}</button>
          </div>
        </article>
      </div>
      <div class="dash-grid cols-3">
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("الطلبات في آخر 7 أيام", "Commandes des 7 jours")}</h3></div>
          <div class="dash-card-body">
            <div class="report-bars">${days.map((day) => `<div class="bar" style="height:${Math.max(5, Math.round(day.total / maxDay * 100))}%" title="${money(day.total)}"><span>${esc(day.label)}</span></div>`).join("")}</div>
            <div class="report-legend"><span><i></i>${money(days.reduce((sum, day) => sum + day.total, 0))} ${dt("هذا الأسبوع", "cette semaine")}</span></div>
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("توزيع حالات الطلبات", "Répartition des statuts")}</h3></div>
          <div class="dash-card-body">
            ${statusRows.map((row) => `<div style="display:grid;grid-template-columns:65px 1fr 22px;align-items:center;gap:7px;margin-bottom:8px"><small style="font-size:8px;color:var(--muted)">${esc(row.label)}</small><div class="mini-bar" style="--bar:${row.color}"><i style="width:${orders.length ? Math.max(3, row.count / orders.length * 100) : 0}%"></i></div><strong style="font-size:9px">${row.count}</strong></div>`).join("")}
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("تحتاج انتباهك", "À surveiller")}</h3></div>
          <div class="dash-card-body">
            <div class="list-editor">
              <div class="list-row"><div class="grow"><strong>${low.length} ${dt("منتجات بمخزون منخفض", "produits en stock faible")}</strong><small>${dt("حد التنبيه", "Seuil")}: ${model.settings.lowStockThreshold}</small></div><a class="btn btn-sm btn-soft" href="#products" data-route="products">${dt("إدارة", "Gérer")}</a></div>
              <div class="list-row"><div class="grow"><strong>${abandoned.length} ${dt("سلة متروكة", "paniers abandonnés")}</strong><small>${dt("فرص استرجاع", "Opportunités")}</small></div><a class="btn btn-sm btn-soft" href="#abandoned" data-route="abandoned">${dt("عرض", "Voir")}</a></div>
              <div class="list-row"><div class="grow"><strong>${cancelled} ${dt("طلبات ملغاة/مرتجعة", "annulées/retournées")}</strong><small>${dt("راجع الأسباب", "Vérifiez les causes")}</small></div><a class="btn btn-sm btn-soft" href="#orders" data-route="orders">${dt("الطلبات", "Commandes")}</a></div>
            </div>
          </div>
        </article>
      </div>`;
  }
  /* --------------------------------------------------------------------------
     Shared modal / field helpers
     -------------------------------------------------------------------------- */
  let editBuffer = null;
  let orderFilter = "all";
  let productSearch = "";
  let productCategory = "all";
  let productStock = "all";
  let abandonedFilter = "open";

  function openModal(title, body, { wide = false, footer = "", onMount = null } = {}) {
    modalRoot.innerHTML = `
      <div class="dash-modal-backdrop" data-action="modal-backdrop">
        <section class="dash-modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
          <div class="dash-modal-head"><h3>${esc(title)}</h3><button type="button" data-action="close-modal" aria-label="${dt("إغلاق", "Fermer")}">${icon("close")}</button></div>
          <div class="dash-modal-body">${body}</div>
          ${footer ? `<div class="dash-modal-foot">${footer}</div>` : ""}
        </section>
      </div>`;
    document.body.classList.add("no-scroll");
    if (onMount) onMount(modalRoot);
  }
  function closeModal() {
    modalRoot.innerHTML = "";
    document.body.classList.remove("no-scroll");
    editBuffer = null;
  }

  function field(label, path, { type = "text", value, placeholder = "", hint = "", rows = 3, options = null, disabled = false } = {}) {
    let actual = value !== undefined ? value : getPath(model, path);
    if (type === "datetime-local") actual = isoLocal(actual);
    if (options) {
      return `<div class="field"><label>${esc(label)}</label><select data-path="${esc(path)}" ${disabled ? "disabled" : ""}>${options.map((option) => {
        const optionValue = typeof option === "object" ? option.value : option;
        const optionLabel = typeof option === "object" ? option.label : option;
        return `<option value="${esc(optionValue)}" ${String(optionValue) === String(actual) ? "selected" : ""}>${esc(optionLabel)}</option>`;
      }).join("")}</select>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
    }
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><textarea data-path="${esc(path)}" rows="${rows}" placeholder="${esc(placeholder)}" ${disabled ? "disabled" : ""}>${esc(actual ?? "")}</textarea>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
    return `<div class="field"><label>${esc(label)}</label><input type="${type}" data-path="${esc(path)}" value="${esc(actual ?? "")}" placeholder="${esc(placeholder)}" ${disabled ? "disabled" : ""}>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
  }

  function biField(label, path, { type = "text", rows = 3 } = {}) {
    const value = getPath(model, path) || {};
    if (type === "textarea") {
      return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><textarea data-path="${esc(path)}.ar" rows="${rows}" dir="rtl" placeholder="العربية">${esc(value.ar ?? "")}</textarea><textarea data-path="${esc(path)}.fr" rows="${rows}" dir="ltr" placeholder="Français">${esc(value.fr ?? "")}</textarea></div></div>`;
    }
    return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><input data-path="${esc(path)}.ar" value="${esc(value.ar ?? "")}" dir="rtl" placeholder="العربية"><input data-path="${esc(path)}.fr" value="${esc(value.fr ?? "")}" dir="ltr" placeholder="Français"></div></div>`;
  }

  function editInput(label, path, { type = "text", value = "", placeholder = "", rows = 3, help = "" } = {}) {
    const suffix = `data-edit-path="${esc(path)}"`;
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><textarea ${suffix} rows="${rows}" placeholder="${esc(placeholder)}">${esc(value ?? "")}</textarea>${help ? `<p class="form-note">${esc(help)}</p>` : ""}</div>`;
    return `<div class="field"><label>${esc(label)}</label><input type="${type}" ${suffix} value="${esc(value ?? "")}" placeholder="${esc(placeholder)}">${help ? `<p class="form-note">${esc(help)}</p>` : ""}</div>`;
  }
  function editBi(label, path, value = {}, { type = "text", rows = 3 } = {}) {
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><textarea data-edit-path="${esc(path)}.ar" rows="${rows}" dir="rtl">${esc(value?.ar ?? "")}</textarea><textarea data-edit-path="${esc(path)}.fr" rows="${rows}" dir="ltr">${esc(value?.fr ?? "")}</textarea></div></div>`;
    return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><input data-edit-path="${esc(path)}.ar" value="${esc(value?.ar ?? "")}" dir="rtl"><input data-edit-path="${esc(path)}.fr" value="${esc(value?.fr ?? "")}" dir="ltr"></div></div>`;
  }
  function editToggle(label, path, checked) {
    return `<div class="check-row"><label class="toggle"><input type="checkbox" data-edit-path="${esc(path)}" ${checked ? "checked" : ""}><span></span></label><span>${esc(label)}</span></div>`;
  }
  function directToggle(label, path, checked) {
    return `<div class="check-row"><label class="toggle"><input type="checkbox" data-path="${esc(path)}" data-type="bool" ${checked ? "checked" : ""}><span></span></label><span>${esc(label)}</span></div>`;
  }
  function imageEditor(label, path, value = "") {
    return `<div class="field"><label>${esc(label)}</label><div class="image-field">
      <span class="image-preview"><img src="${esc(value || "assets/img/favicon.svg")}" alt=""></span>
      <div class="grow">
        <input data-edit-path="${esc(path)}" value="${esc(value)}" placeholder="assets/img/...">
        <label class="upload-btn">${icon("upload")} ${dt("رفع صورة", "Téléverser")}<input type="file" accept="image/*" data-upload-path="${esc(path)}"></label>
      </div>
    </div></div>`;
  }
  function editorFooter(canDelete = false, deleteAction = "") {
    return `${canDelete ? `<button class="btn btn-danger btn-sm" type="button" data-action="${esc(deleteAction)}">${icon("trash")} ${dt("حذف", "Supprimer")}</button>` : ""}<span style="flex:1"></span><button class="btn btn-soft btn-sm" type="button" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" type="button" data-action="save-editor">${icon("check")} ${dt("حفظ", "Enregistrer")}</button>`;
  }

  function statusOptions(selected) {
    return R.statuses.map((status) => {
      const meta = R.statusMeta(status);
      return `<option value="${status}" ${status === selected ? "selected" : ""}>${esc(lng(meta.label))}</option>`;
    }).join("");
  }

  /* --------------------------------------------------------------------------
     Orders
     -------------------------------------------------------------------------- */
  function filteredOrders() {
    const needle = R.normalizeText(searchTerm);
    return orderList().filter((order) => {
      if (orderFilter !== "all" && order.status !== orderFilter) return false;
      if (!needle) return true;
      const haystack = R.normalizeText([order.id, order.customer?.name, order.customer?.phone, order.customer?.city, order.customer?.address, ...(order.items || []).map((item) => item.title)].join(" "));
      return haystack.includes(needle);
    });
  }

  function ordersTable(orders) {
    if (!orders.length) return `<div class="table-empty">${icon("orders")}<p>${dt("لا توجد طلبات مطابقة.", "Aucune commande correspondante.")}</p></div>`;
    return `<div class="dash-table-wrap"><table class="dash-table">
      <thead><tr><th>${dt("الطلب", "Commande")}</th><th>${dt("العميل", "Client")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("المنتجات", "Articles")}</th><th>${dt("الدفع", "Paiement")}</th><th>${dt("المجموع", "Total")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead>
      <tbody>${orders.map((order) => {
        const status = R.statusMeta(order.status);
        return `<tr>
          <td><strong style="font-size:9px">${esc(order.id)}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${esc(fmtDateTime(order.createdAt))}</small></td>
          <td><strong style="font-size:10px">${esc(order.customer?.name || "")}</strong><br><small dir="ltr" style="font-size:8px;color:var(--soft-muted)">${esc(order.customer?.phone || "")}</small></td>
          <td>${esc(order.customer?.city || "")}</td>
          <td>${(order.items || []).reduce((sum, item) => sum + Number(item.qty || 1), 0)}</td>
          <td>${esc(order.payment?.name || "")}</td>
          <td class="price">${money(order.total)}</td>
          <td><select class="dash-field" data-order-status="${esc(order.id)}" style="min-width:95px;height:28px;padding:2px 6px;font-size:9px;border-color:${status.color}">${statusOptions(order.status)}</select></td>
          <td><div class="cell-actions">
            <button class="btn btn-sm btn-soft" type="button" data-action="view-order" data-id="${esc(order.id)}">${dt("عرض", "Voir")}</button>
            <a class="btn btn-sm btn-soft" href="https://wa.me/${digits(order.customer?.phone)}" target="_blank" rel="noopener" title="WhatsApp">${icon("whatsapp")}</a>
          </div></td>
        </tr>`;
      }).join("")}</tbody>
    </table></div>`;
  
  }).call(ctx);
}
