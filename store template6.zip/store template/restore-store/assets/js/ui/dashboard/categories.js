import { createCategoriesRepo } from "../../data/repositories/categories.repo.js";
export function createCategoriesScreen(ctx) {
  const { R, esc, dt, lng, token, toast } = ctx;
  const repo = createCategoriesRepo(R.config, token);
  let categories = [], collections = [];
  async function load() {
    try { categories = await repo.listCategories() || []; collections = await repo.listCollections() || []; }
    catch(e){ categories = R.store?.theme?.categories || []; collections = R.store?.collections || []; }
  }
  async function saveCategory(row){ await repo.upsertCategory(row); R.addAudit(`${dt("فئة","Catégorie")}: save — ${row.slug||row.id}`, R.currentSession?.()?.username); toast(dt("تم حفظ الفئة","Catégorie enregistrée"),"good"); await load(); }
  async function saveCollection(row){ await repo.upsertCollection(row); R.addAudit(`${dt("مجموعة","Collection")}: save — ${row.handle}`, R.currentSession?.()?.username); toast(dt("تم حفظ المجموعة","Collection enregistrée"),"good"); await load(); }
  function render() {
    return `<div class="dash-view-head"><div><h2>${dt("الفئات","Catégories")}</h2><p>restore_categories / restore_collections</p></div></div>
    <div class="dash-grid cols-2">
      <article class="dash-card"><div class="dash-card-head"><h3>${dt("الفئات","Catégories")}</h3></div><div class="dash-card-body"><div class="list-editor">${categories.map(c=>`<div class="list-row"><div class="grow"><strong>${esc(lng(c.title)||c.slug)}</strong><small class="handle">${esc(c.slug||c.id)}</small></div></div>`).join("")||dt("فارغ","Vide")}</div></div></article>
      <article class="dash-card"><div class="dash-card-head"><h3>${dt("المجموعات","Collections")}</h3></div><div class="dash-card-body"><div class="list-editor">${collections.map(c=>`<div class="list-row"><div class="grow"><strong>${esc(lng(c.title)||c.handle)}</strong><small class="handle">${esc(c.handle)}</small></div></div>`).join("")||dt("فارغ","Vide")}</div></div></article>
    </div>`;
  }
  return { load, render, saveCategory, saveCollection };
}
