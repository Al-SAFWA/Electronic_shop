// legacy dashboard chunk 6
    return `
      <div class="dash-view-head"><div><h2>${dt("التقارير", "Rapports")}</h2><p>${dt("المبيعات والمخزون والأداء.", "Ventes, stock et performance.")}</p></div><div class="dash-view-actions"><div class="segmented">${[["7", "7j"], ["30", "30j"], ["90", "90j"], ["all", dt("الكل", "Tout")]].map(([id, label]) => `<button data-report-range="${id}" class="${reportRange === id ? "active" : ""}">${label}</button>`).join("")}</div><button class="btn btn-soft" data-action="export-orders">${icon("download")} CSV</button></div></div>
      <div class="dash-grid cols-4" style="margin-bottom:14px">
        ${statCard(dt("الإيرادات", "Chiffre d’affaires"), money(revenue), `${orders.length} ${dt("طلب", "commandes")}`, "#128c53", "reports")}
        ${statCard(dt("متوسط الطلب", "Panier moyen"), money(avg), dt("لكل طلب", "par commande"), "#ff6400", "cart")}
        ${statCard(dt("القطع المباعة", "Articles vendus"), itemCount, dt("إجمالي القطع", "total unités"), "#a72396", "products")}
        ${statCard(dt("نسبة التحويل", "Conversion"), `${conversion}%`, `${abandoned} ${dt("سلة متروكة", "paniers")}`, "#0b6fb8", "marketing")}
      </div>
      <div class="dash-grid cols-3">
        <article class="dash-card" style="grid-column:span 2"><div class="dash-card-head"><h3>${dt("الإيرادات آخر 7 أيام", "Revenus 7 jours")}</h3></div><div class="dash-card-body"><div class="report-bars">${days.map((day) => `<div class="bar" style="height:${Math.max(5, Math.round(day.total / maxDay * 100))}%" title="${money(day.total)}"><span>${esc(day.label)}</span></div>`).join("")}</div><div class="report-legend"><span><i></i>${money(days.reduce((sum, day) => sum + day.total, 0))}</span></div></div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أفضل المدن", "Meilleures villes")}</h3></div><div class="dash-card-body">${topCities.length ? topCities.map(([city, data]) => `<div style="margin-bottom:9px"><div style="display:flex;justify-content:space-between;font-size:9px;margin-bottom:4px"><span>${esc(city)}</span><strong>${money(data.revenue)}</strong></div><div class="mini-bar"><i style="width:${Math.round(data.revenue / maxCity * 100)}%"></i></div><small style="font-size:8px;color:var(--soft-muted)">${data.count} ${dt("طلب", "commandes")}</small></div>`).join("") : `<div class="empty-dash">${dt("لا توجد بيانات.", "Aucune donnée.")}</div>`}</div></article>
      </div>
      <div class="dash-grid cols-2" style="margin-top:14px">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("المنتجات الأكثر مبيعًا", "Meilleures ventes")}</h3></div><div class="dash-card-body"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("القطع", "Unités")}</th><th>${dt("الإيراد", "Revenu")}</th></tr></thead><tbody>${topProducts.map((product) => `<tr><td><div class="cell-main"><img src="${esc(product.image)}" alt=""><strong>${esc(product.title)}</strong></div></td><td>${product.qty}</td><td class="price">${money(product.revenue)}</td></tr>`).join("") || `<tr><td colspan="3" class="table-empty">${dt("لا توجد مبيعات.", "Aucune vente.")}</td></tr>`}</tbody></table></div></div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("مخزون منخفض", "Stock faible")}</h3><a href="#products" data-route="products">${dt("إدارة", "Gérer")}</a></div><div class="dash-card-body"><div class="list-editor">${low.map((product) => `<div class="list-row"><span class="image-preview" style="width:32px;height:32px;flex-basis:32px"><img src="${esc(product.image)}" alt=""></span><div class="grow"><strong>${esc(product.title)}</strong><small>${dt("متبقي", "Reste")}: ${product.stock}</small></div><span class="badge-soft ${product.stock <= 0 ? "" : "orange"}">${product.stock <= 0 ? dt("نفد", "Épuisé") : dt("منخفض", "Faible")}</span></div>`).join("") || `<div class="empty-dash">${dt("المخزون جيد.", "Stock correct.")}</div>`}</div></div></article>
      </div>`;
  }
  /* --------------------------------------------------------------------------
     Settings
     -------------------------------------------------------------------------- */
  function viewSettings() {
    const settings = model.settings;
    return `
      <div class="dash-view-head"><div><h2>${dt("الإعدادات", "Réglages")}</h2><p>${dt("SEO، واتساب، الحماية والتكامل.", "SEO, WhatsApp, sécurité et intégration.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="discard-draft">${dt("إلغاء المسودة", "Annuler le brouillon")}</button><button class="btn btn-primary" data-action="save-draft">${icon("check")} ${dt("حفظ", "Enregistrer")}</button></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="settings-seo">SEO</button><button data-dash-tab="settings-whatsapp">WhatsApp</button><button data-dash-tab="settings-security">${dt("الحماية", "Sécurité")}</button><button data-dash-tab="settings-advanced">${dt("متقدم", "Avancé")}</button></div>
      <div class="dash-panel active" data-dash-panel="settings-seo">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("محركات البحث", "Référencement")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("عنوان SEO", "Titre SEO"), "settings.seo.title")}
            ${biField(dt("وصف SEO", "Description SEO"), "settings.seo.description", { type: "textarea", rows: 3 })}
            <div class="form-grid">${field(dt("الرابط الأساسي", "URL de base"), "settings.baseUrl", { placeholder: "https://restore.mr" })}${field(dt("صورة المشاركة", "Image de partage"), "settings.seo.image", { placeholder: "assets/img/..." })}</div>
            <p class="form-note">${dt("يُستخدم عنوان ووصف SEO في كل صفحة، وتُضاف بيانات المنتج المنظمة تلقائيًا.", "Titres et descriptions sont appliqués par page ; les données produit structurées sont ajoutées automatiquement.")}</p>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("بكسلات التحليلات", "Pixels analytiques")}</h3></div><div class="dash-card-body dash-form">
            ${field("Meta Pixel ID", "settings.pixels.meta", { placeholder: "1234567890" })}
            ${field("TikTok Pixel ID", "settings.pixels.tiktok", { placeholder: "C..." })}
            ${field("Google Analytics ID", "settings.pixels.ga", { placeholder: "G-XXXXXXX" })}
            <p class="form-note">${dt("تُحمّل الأكواد تلقائيًا في المتجر بعد النشر. لا تضع أكوادًا كاملة، فقط المعرف.", "Les scripts sont chargés automatiquement. Indiquez uniquement l’identifiant.")}</p>
            ${directToggle(dt("تفعيل PWA للجوال", "Activer la PWA mobile"), "settings.pwa", settings.pwa !== false)}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-whatsapp">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("رسالة الطلب", "Message de commande")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("القالب الكامل", "Modèle complet"), "settings.orderTemplate", { type: "textarea", rows: 13 })}
            <p class="form-note">${dt("المتغيرات: {store} {order_id} {name} {phone} {city} {address} {payment} {items} {subtotal} {shipping} {discount} {total} {notes}", "Variables : {store} {order_id} {name} {phone} {city} {address} {payment} {items} {subtotal} {shipping} {discount} {total} {notes}")}</p>
            ${field("WhatsApp", "settings.whatsapp", { hint: dt("الرقم الذي تستقبل عليه الطلبات", "Numéro qui reçoit les commandes") })}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("رسائل المتابعة", "Messages de suivi")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("تأكيد الطلب", "Confirmation"), "settings.whatsappTemplates.confirm", { type: "textarea", rows: 3 })}
            ${biField(dt("تم الشحن", "Expédition"), "settings.whatsappTemplates.shipped", { type: "textarea", rows: 3 })}
            ${biField(dt("تم التسليم", "Livraison"), "settings.whatsappTemplates.delivered", { type: "textarea", rows: 3 })}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-security">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("الحماية من الطلبات المزعجة", "Protection anti-spam")}</h3></div><div class="dash-card-body dash-form">
            ${field(dt("الفاصل الزمني بين الطلبات (ثانية)", "Délai entre commandes (secondes)"), "settings.rateLimitSeconds", { type: "number" })}
            <div class="field"><label>${dt("قائمة الحظر (رقم في كل سطر)", "Liste de blocage (un numéro par ligne)")}</label><textarea data-blocklist rows="7" dir="ltr">${esc((settings.blocklist || []).join("\n"))}</textarea></div>
            <p class="form-note">${dt("تُطبق القائمة على أرقام الهواتف بصيغة 222XXXXXXXX.", "La liste s’applique aux numéros au format 222XXXXXXXX.")}</p>
            ${directToggle(dt("طلب رمز تحقق OTP (قريبًا)", "Vérification OTP (bientôt)"), "settings.otp.enabled", settings.otp?.enabled)}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("المخزون والمنتجات", "Stock & produits")}</h3></div><div class="dash-card-body dash-form">
            ${field(dt("حد المخزون المنخفض", "Seuil de stock faible"), "settings.lowStockThreshold", { type: "number" })}
            ${directToggle(dt("إخفاء المنتجات المنتهية تلقائيًا", "Masquer automatiquement les produits épuisés"), "settings.autoHideOutOfStock", settings.autoHideOutOfStock !== false)}
            ${directToggle(dt("إظهار بيانات تجريبية حتى إدخال بياناتك", "Afficher les données de démo jusqu’à vos données"), "settings.fakeData", settings.fakeData !== false)}
            ${directToggle(dt("الوضع الليلي", "Mode sombre"), "settings.darkMode", settings.darkMode !== false)}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-advanced">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("التكامل والاستضافة", "Intégration & hébergement")}</h3></div><div class="dash-card-body">
            <div class="publish-modal-list">
              <div><span>${dt("وضع البيانات", "Mode données")}</span><strong>${R.remote ? "Supabase" : dt("محلي تجريبي", "Local démo")}</strong></div>
              <div><span>Supabase URL</span><strong dir="ltr" style="font-size:8px">${esc(R.config.supabaseUrl || dt("غير مهيأ", "Non configuré"))}</strong></div>
              <div><span>${dt("المشروع", "Projet")}</span><strong>${dt("ريستور موريتانيا", "Restore Mauritanie")}</strong></div>
              <div><span>${dt("نطاق البيع", "Périmètre")}</span><strong>MRU · Mauritanie</strong></div>
            </div>
            <div class="field" style="margin-top:12px"><label>${dt("العملة المعروضة افتراضيًا", "Affichage de la devise par défaut")}</label><select data-currency-mode>
              <option value="new" ${R.getCurrencyMode() === "new" ? "selected" : ""}>${dt("أوقية جديدة (MRU)", "Nouvelle ouguiya (MRU)")}</option>
              <option value="old" ${R.getCurrencyMode() === "old" ? "selected" : ""}>${dt("أوقية قديمة (MRO) = القيمة × 10", "Ancienne ouguiya (MRO) = valeur × 10")}</option>
            </select><p class="form-note">${dt("يمكن للزائر تبديلها من رأس المتجر. الأسعار محفوظة بالأوقية الجديدة.", "Le visiteur peut la changer dans l’en-tête. Les prix restent en nouvelle ouguiya.")}</p></div>
            <p class="form-note" style="margin-top:11px">${dt("لربط Supabase: ضع URL و anon key في config.js ثم نفّذ ملف supabase/schema.sql. ستتزامن الطلبات والحالة تلقائيًا.", "Pour Supabase : renseignez URL et anon key dans config.js puis exécutez supabase/schema.sql.")}</p>
            <a class="btn btn-soft btn-sm" href="supabase/schema.sql" target="_blank">${dt("عرض ملف SQL", "Voir le fichier SQL")}</a>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("منطقة الخطر", "Zone sensible")}</h3></div><div class="dash-card-body">
            <p style="font-size:10px;color:var(--muted);line-height:1.8;margin-bottom:12px">${dt("إعادة تعيين البيانات التجريبية ستحذف الطلبات والمسودات والحسابات المحلية. لا يمكن التراجع.", "Réinitialiser la démo supprime commandes, brouillons et comptes locaux. Action irréversible.")}</p>
            <div style="display:flex;gap:7px;flex-wrap:wrap"><button class="btn btn-soft btn-sm" data-action="publish">${icon("publish")} ${dt("نشر الآن", "Publier")}</button><button class="btn btn-danger btn-sm" data-action="reset-demo">${icon("trash")} ${dt("إعادة تعيين التجربة", "Réinitialiser la démo")}</button></div>
          </div></article>
        </div>
      </div>`;
  }

  /* --------------------------------------------------------------------------
     Audit log
     -------------------------------------------------------------------------- */
  function viewAudit() {
    const logs = R.getAudit();
    return `
      <div class="dash-view-head"><div><h2>${dt("سجل النشاط", "Journal d’activité")}</h2><p>${dt("آخر 500 عملية في لوحة التحكم.", "Les 500 dernières actions du tableau de bord.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="clear-audit">${icon("trash")} ${dt("مسح السجل", "Effacer")}</button></div></div>
      <article class="dash-card"><div class="dash-card-body">${logs.length ? `<div class="list-editor">${logs.map((log) => `<div class="audit-row"><span class="audit-dot"></span><div><strong>${esc(log.action)}</strong><small>${esc(fmtDateTime(log.at))} · ${esc(log.actor || "system")}</small></div></div>`).join("")}</div>` : `<div class="empty-dash">${icon("audit")}<p>${dt("لا توجد عمليات مسجلة بعد.", "Aucune action enregistrée.")}</p></div>`}</div></article>`;
  }

  /* --------------------------------------------------------------------------
     Publish, preview and draft lifecycle
     -------------------------------------------------------------------------- */
  /* ==========================================================================
     First-time Setup Modal
     ========================================================================== */
  function openPublishModal() {
    saveDraftNow();
    const products = model.products.length;
    const draftHours = model.updatedAt ? Math.max(0, Math.round((Date.now() - Date.parse(model.updatedAt)) / 3600000)) : 0;
    openModal(dt("نشر التغييرات", "Publier les changements"), `
      <div class="publish-modal-list">
        <div><span>${dt("المنتجات", "Produits")}</span><strong>${products}</strong></div>
        <div><span>${dt("الأقسام", "Sections")}</span><strong>${(model.settings.pageSections || []).filter((section) => section.visible !== false).length}</strong></div>
        <div><span>${dt("الطلبات", "Commandes")}</span><strong>${R.getOrders().length}</strong></div>
        <div><span>${dt("آخر تعديل", "Dernière modification")}</span><strong>${esc(fmtDateTime(model.updatedAt))}</strong></div>
        <div><span>${dt("مساحة المتجر", "Boutique")}</span><strong>${R.remote ? "Supabase" : dt("محلي", "Local")} · MRU</strong></div>
      </div>
      <div style="display:flex;align-items:flex-start;gap:8px;background:var(--surface-2);border-radius:8px;padding:11px;margin-top:13px;font-size:10px;color:var(--muted);line-height:1.6">${icon("info")}<span>${dt("سيظهر المحتوى والألوان والمنتجات للزوار خلال ثوانٍ. يمكنك فتح المعاينة أولًا للتأكد.", "Le contenu, les couleurs et les produits seront visibles en quelques secondes. Ouvrez l’aperçu pour vérifier.")}</span></div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-soft btn-sm" data-action="preview">${icon("preview")} ${dt("معاينة", "Aperçu")}</button><button class="btn btn-primary btn-sm" data-action="confirm-publish">${icon("publish")} ${dt("نشر", "Publier")}</button>`
    });
  }

  async function publishNow() {
    const button = $("[data-action='confirm-publish']");
    if (button) { button.disabled = true; button.textContent = dt("جارٍ النشر...", "Publication..."); }
    try {
      const published = await R.publish(model);
      model = clone(published);
      dirty = false;
      closeModal();
      renderRoute();
      updateDraftState();
      R.addAudit(dt("نشر تحديث المتجر", "Publication de la boutique"));
      toast(dt("تم نشر التغييرات في المتجر", "Changements publiés sur la boutique"), "good");
    } catch (error) {
      toast(error.message || String(error), "error");
      if (button) { button.disabled = false; button.textContent = dt("نشر", "Publier"); }
    }
  }

  /* --------------------------------------------------------------------------
     Event delegation
     -------------------------------------------------------------------------- */
  let editorKind = null;
  let lastOrderCount = newOrdersCount();
  let searchTimer;

  function applyLiveColor(path) {
    const html = document.documentElement;
    const map = { "settings.colors.primary": "--orange", "settings.colors.purple": "--purple", "settings.colors.ink": "--ink", "settings.colors.lavender": "--lav" };
    if (map[path]) html.style.setProperty(map[path], getPath(model, path));
    if (path === "settings.font") {
      const font = getPath(model, path);
      html.style.setProperty("--font-main", `"${font}", "Noto Sans Arabic", Tahoma, sans-serif`);
    }
  }

  function handleField(node) {
    const editPath = node.dataset.editPath;
    const path = node.dataset.path;
    if (!editPath && !path) return;
    let value = node.type === "checkbox" ? node.checked : node.value;
    if (node.dataset.type === "bool") value = node.checked;
    if (node.type === "number" || node.dataset.type === "number") value = value === "" ? 0 : Number(value);
    if (node.type === "datetime-local" && value) value = new Date(value).toISOString();
    const target = editPath ? editBuffer : model;
    if (!target) return;
    setPath(target, editPath || path, value);
    if (!editPath) {
      applyLiveColor(path);
      saveDraftSoon();
      if (path.startsWith("settings.") || path.startsWith("pages.") || path.startsWith("collections.")) {
        // no DOM re-render while typing; the draft is saved in the background
      }
    }
  }

  function handleDirectToggle(node) {
    if (node.dataset.pageSectionVisible) {
      const section = model.settings.pageSections.find((item) => item.id === node.dataset.pageSectionVisible);
      if (section) { section.visible = node.checked; saveDraftSoon(); }
    }
    if (node.dataset.homeSectionVisible) {
      const section = model.settings.homeSections.find((item) => item.id === node.dataset.homeSectionVisible);
      if (section) { section.visible = node.checked; saveDraftSoon(); }
    }
    if (node.dataset.productActive != null) {
      const product = model.products[Number(node.dataset.productActive)];
      if (product) { product.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.couponActive != null) {
      const coupon = model.settings.coupons[Number(node.dataset.couponActive)];
      if (coupon) { coupon.active = node.checked; saveDraftNow(); }
    }
    if (node.dataset.paymentActive != null) {
      const payment = model.settings.payments[Number(node.dataset.paymentActive)];
      if (payment) { payment.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.cityActive != null) {
      const city = model.settings.cities[Number(node.dataset.cityActive)];
      if (city) { city.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.reviewApproved != null) {
      const review = model.reviews[Number(node.dataset.reviewApproved)];
      if (review) { review.approved = node.checked; saveDraftNow(); }
    }
    if (node.dataset.orderStatus) {
      const order = R.getOrders().find((item) => item.id === node.dataset.orderStatus);
      if (order) {
        R.updateOrder(order.id, { status: node.value });
        R.addAudit(`${dt("تحديث حالة طلب", "Statut commande")} ${order.id}: ${node.value}`);
        toast(dt("تم تحديث حالة الطلب", "Statut mis à jour"), "good");
        if (route === "overview" || route === "orders") renderRoute();
      }
    }
  }

  function handleLines(node) {
    const path = node.dataset.linesPath;
    if (!path) return;
    const rows = node.value.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
      const parts = line.split("|").map((part) => part.trim());
      if (parts.length >= 3) return { label: { ar: parts[0], fr: parts[1] }, href: parts.slice(2).join("|") };
      return { label: { ar: parts[0], fr: parts[0] }, href: parts[1] || "#" };
    });
    setPath(model, path, rows);
    saveDraftSoon();
  }

  function resizeImage(file) {
    return new Promise((resolve, reject) => {
      if (file.size > 4 * 1024 * 1024) { reject(new Error(dt("الصورة أكبر من 4MB", "Image supérieure à 4 Mo"))); return; }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(dt("تعذر قراءة الصورة", "Impossible de lire l’image")));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error(dt("صورة غير صالحة", "Image invalide")));
        image.onload = () => {
          const max = 900;
          const scale = Math.min(1, max / Math.max(image.width, image.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.width * scale));
          canvas.height = Math.max(1, Math.round(image.height * scale));
          const context = canvas.getContext("2d");
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL("image/webp", 0.82));
        };
        image.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  async function handleUpload(input) {
    const file = input.files?.[0];
    if (!file) return;
    const path = input.dataset.uploadPath;
    const direct = input.dataset.uploadTarget === "direct";
    try {
      let data = await resizeImage(file);
      const target = direct ? model : editBuffer;
      if (!target) return;
      if (R.remote) {
        try {
          const publicUrl = await R.uploadMedia(data);
          if (publicUrl) data = publicUrl;
        } catch (uploadError) {
          toast(`${dt("تعذر رفع الصورة إلى Supabase", "Échec du téléversement Supabase")}: ${uploadError.message}`, "error");
          return;
        }
      }
      setPath(target, path, data);
      const field = input.closest(".image-field");
      const inputNode = field?.querySelector("input[data-edit-path], input[data-path]");
      if (inputNode) inputNode.value = data;
      const preview = field?.querySelector("img");
      if (preview) preview.src = data;
      if (direct) saveDraftSoon();
      toast(dt("تم رفع الصورة", "Image importée"), "good");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  document.addEventListener("click", (event) => {
    const link = event.target.closest("[data-route]");
    if (link) {
      event.preventDefault();
      route = link.dataset.route;
      if (location.hash !== `#${route}`) history.replaceState(null, "", `#${route}`);
      $("#dash-sidebar")?.classList.remove("open");
      renderRoute();
      return;
    }
    const langButton = event.target.closest("[data-dash-lang]");
    if (langButton) {
      dashLang = langButton.dataset.dashLang === "fr" ? "fr" : "ar";
      localStorage.setItem(LS_DASH_LANG, dashLang);
      document.documentElement.lang = dashLang;
      document.documentElement.dir = dashLang === "ar" ? "rtl" : "ltr";
      if (session?.mustChange) renderPasswordChange();
      else if (session) renderShell();
      else renderLogin();
      return;
    }
    const tab = event.target.closest("[data-dash-tab]");
    if (tab) {
      const tabs = tab.parentElement;
      tabs.querySelectorAll("[data-dash-tab]").forEach((item) => item.classList.toggle("active", item === tab));
      const container = tabs.parentElement;
      container.querySelectorAll("[data-dash-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.dashPanel === tab.dataset.dashTab));
      return;
    }
    const filterButton = event.target.closest("[data-order-filter]");
    if (filterButton) { orderFilter = filterButton.dataset.orderFilter; renderRoute(); return; }
    const abandonedButton = event.target.closest("[data-abandoned-filter]");
    if (abandonedButton) { abandonedFilter = abandonedButton.dataset.abandonedFilter; renderRoute(); return; }
    const reportButton = event.target.closest("[data-report-range]");
    if (reportButton) { reportRange = reportButton.dataset.reportRange; renderRoute(); return; }
    const productFilter = event.target.closest("[data-product-filter]");
    if (productFilter) { /* handled in change */ }


    const actionNode = event.target.closest("[data-action]");
    if (!actionNode) return;
    const action = actionNode.dataset.action;
    const index = actionNode.dataset.index != null ? Number(actionNode.dataset.index) : null;
    const id = actionNode.dataset.id || "";

    switch (action) {
      case "logout":
        R.addAudit(dt("تسجيل خروج", "Déconnexion"), session?.username);
        R.logout();
        renderLogin();
        break;
      case "profile":
        route = "profile"; history.replaceState(null, "", "#profile"); renderRoute();
        break;
      case "toggle-sidebar":
        $("#dash-sidebar")?.classList.toggle("open");
        break;
      case "theme": {
        const next = R.theme === "dark" ? "light" : "dark";
        R.setTheme(next);
        actionNode.innerHTML = icon(next === "dark" ? "sun" : "moon");
        break;
      }
      case "orders-alert":
        route = "orders"; history.replaceState(null, "", "#orders");
        orderBadgeSeen = newOrdersCount();
        localStorage.setItem("restore_orders_seen_v1", String(orderBadgeSeen));
        updateCounts(); renderRoute();
        break;
      case "save-draft":
        saveDraftNow(); toast(dt("تم حفظ المسودة", "Brouillon enregistré"), "good");
        break;
      case "preview":
        if (dirty) saveDraftNow();
        window.open("index.html?preview=1", "_blank", "noopener");
        break;
      case "publish":
        openPublishModal();
        break;
      case "confirm-publish":
        publishNow();
        break;
      case "discard-draft":
        if (confirm(dt("إلغاء كل التغييرات غير المنشورة؟", "Annuler toutes les modifications non publiées ?"))) {
          R.discardDraft(); model = clone(R.state); dirty = false; closeModal(); renderRoute(); toast(dt("تم إلغاء المسودة", "Brouillon annulé"));
        }
        break;
      case "reset-demo":
        if (session?.role !== "owner") { toast(dt("للمالك فقط", "Propriétaire uniquement"), "error"); break; }
