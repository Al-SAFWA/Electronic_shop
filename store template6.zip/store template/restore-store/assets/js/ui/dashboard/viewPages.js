/* extracted dashboard view */
export function viewPages(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    return `
      <div class="dash-view-head"><div><h2>${dt("الصفحات", "Pages")}</h2><p>${dt("الصفحات الثابتة والأسئلة الشائعة.", "Pages statiques et FAQ.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="pages-static">${dt("الصفحات", "Pages")}</button><button data-dash-tab="pages-faq">${dt("الأسئلة الشائعة", "FAQ")}</button></div>
      <div class="dash-panel active" data-dash-panel="pages-static">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الصفحات الثابتة", "Pages statiques")}</h3><button data-action="add-page">${icon("plus")} ${dt("صفحة جديدة", "Nouvelle page")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.pages || []).map((page, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(page.title))}</strong><small class="handle">${esc(page.slug)}</small></div>${directToggle("", `pages.${index}.visible`, page.visible !== false)}<a class="btn btn-sm btn-soft" href="page.html?slug=${encodeURIComponent(page.slug)}" target="_blank" rel="noopener" title="${dt("معاينة", "Aperçu")}">${icon("external")}</a><button class="btn btn-sm btn-soft" data-action="edit-page" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-page" data-index="${index}">${icon("trash")}</button></div>`).join("")}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pages-faq">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الأسئلة الشائعة", "FAQ")}</h3><button data-action="add-faq">${icon("plus")} ${dt("سؤال جديد", "Nouvelle question")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.faqs || []).map((faq, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(faq.q))}</strong><small>${esc(lng(faq.a)).slice(0, 90)}</small></div><button class="btn btn-sm btn-soft" data-action="edit-faq" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-faq" data-index="${index}">${icon("trash")}</button></div>`).join("")}
        </div></div></article>
      </div>`;
  }

  let pendingPageIndex = null;
  function pageEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { slug: `page-${Date.now().toString(36)}`, title: { ar: "", fr: "" }, body: { ar: "", fr: "" }, visible: true, seoTitle: { ar: "", fr: "" }, seoDescription: { ar: "", fr: "" } } : clone(model.pages[index]);
    editBuffer = buffer;
    pendingPageIndex = isNew ? null : index;
    openModal(isNew ? dt("صفحة جديدة", "Nouvelle page") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("الرابط", "Slug")}</label><input data-edit-path="slug" value="${esc(buffer.slug)}" dir="ltr"></div>
        ${editBi(dt("محتوى الصفحة", "Contenu"), "body", buffer.body, { type: "textarea", rows: 12 })}
        ${editBi(dt("عنوان SEO", "Titre SEO"), "seoTitle", buffer.seoTitle)}
        ${editBi(dt("وصف SEO", "Description SEO"), "seoDescription", buffer.seoDescription, { type: "textarea", rows: 2 })}
        <p class="form-note span-2">${dt("الرابط يستخدم حروفًا إنجليزية صغيرة وأرقامًا وشرطات فقط. يظهر المحتوى في المتجر مباشرة بعد النشر.", "Le slug utilise des minuscules, chiffres et tirets. Le contenu apparaît après publication.")}</p>
        ${editToggle(dt("ظاهرة", "Visible"), "visible", buffer.visible !== false)}
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-page" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function savePageEditor() {
    if (!editBuffer) return;
    const slug = String(editBuffer.slug || "").trim().toLowerCase();
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 80) {
      return toast(dt("الرابط: حروف إنجليزية صغيرة وأرقام وشرطات فقط", "Slug : minuscules, chiffres et tirets uniquement"), "error");
    }
    const duplicate = (model.pages || []).some((page, index) => page.slug === slug && index !== pendingPageIndex);
    if (duplicate) return toast(dt("هذا الرابط مستخدم لصفحة أخرى", "Ce slug est déjà utilisé"), "error");
    if (!String(editBuffer.title?.ar || editBuffer.title?.fr || "").trim()) return toast(dt("عنوان الصفحة مطلوب", "Le titre est requis"), "error");
    editBuffer.slug = slug;
    editBuffer.seoTitle = editBuffer.seoTitle || editBuffer.title;
    if (pendingPageIndex == null) model.pages.push(editBuffer);
    else model.pages[pendingPageIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ الصفحة في المسودة. انشر لتظهر للزوار.", "Page enregistrée en brouillon. Publiez pour la rendre visible."), "good");
  }

  function faqEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `faq-${Date.now().toString(36)}`, q: { ar: "", fr: "" }, a: { ar: "", fr: "" } } : clone(model.faqs[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("سؤال جديد", "Nouvelle question") : lng(buffer.q), `
      <div class="dash-form">${editBi(dt("السؤال", "Question"), "q", buffer.q)}${editBi(dt("الجواب", "Réponse"), "a", buffer.a, { type: "textarea", rows: 4 })}</div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-faq" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }
  /* --------------------------------------------------------------------------
     Reviews
     -------------------------------------------------------------------------- */
    function viewReviews() {
    if (!Array.isArray(model.reviews)) model.reviews = [];
    const home = model.homeReviews || [];
    const allCustomer = R.getAllCustomerReviews();
    const pending = allCustomer.filter((review) => review.status === "pending");
    const approved = allCustomer.filter((review) => review.status === "approved");
    const rejected = allCustomer.filter((review) => review.status === "rejected");
    if (!viewReviews.refreshed) {
      viewReviews.refreshed = true;
      R.refreshReviews().catch(() => {});
    }
    const customerRow = (review, actions) => `<div class="list-row review-pending-row">
      <div class="grow">
        <strong>${esc(review.customerName)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong>
        <small>${esc(review.productHandle)} — ${esc(L(review.title))}</small>
        <p class="review-body-preview">${esc(String(L(review.body)).slice(0, 160))}${String(L(review.body)).length > 160 ? "…" : ""}</p>
        <small class="review-date">${esc(R.formatDate(review.createdAt))}${review.email ? ` · ${esc(review.email)}` : ""}</small>
      </div>
      <div class="cell-actions">${actions}</div>
    </div>`;
    return `
      <div class="dash-view-head"><div><h2>${dt("التقييمات", "Avis clients")}</h2><p>${dt("إدارة تقييمات الصفحة الرئيسية، المنتجات، وتقييمات العملاء.", "Gestion des avis accueil, produits et avis clients.")}</p></div></div>
      <div class="dash-tabs">
        <button class="active" data-dash-tab="reviews-home">${dt("الرئيسية", "Accueil")} <span class="badge-soft">${home.length}</span></button>
        <button data-dash-tab="reviews-products">${dt("المنتجات", "Produits")} <span class="badge-soft">${(model.reviews || []).length}</span></button>
        <button data-dash-tab="reviews-customers">${dt("العملاء", "Clients")} <span class="badge-soft ${pending.length ? "orange" : ""}">${pending.length}</span></button>
      </div>
      <div class="dash-panel active" data-dash-panel="reviews-home">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("آراء الصفحة الرئيسية", "Avis page d’accueil")}</h3><button class="btn btn-primary btn-sm" data-action="add-home-review">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${home.map((review, index) => `<div class="list-row"><div class="grow"><strong>${esc(review.name)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong><small>${esc(L(review.title))} — ${esc(L(review.city))}</small></div><button class="btn btn-sm btn-soft" data-action="edit-home-review" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-home-review" data-index="${index}">${icon("trash")}</button></div>`).join("") || `<div class="empty-dash">${dt("لا توجد تقييمات.", "Aucun avis.")}</div>`}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="reviews-products">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تقييمات المنتجات", "Avis produits")}</h3><button class="btn btn-soft" data-action="add-product-review">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.reviews || []).map((review, index) => `<div class="list-row"><div class="grow"><strong>${esc(review.name)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong><small>${esc(review.handle)} — ${esc(L(review.title))}</small></div><label class="toggle"><input type="checkbox" data-review-approved="${index}" ${review.approved !== false ? "checked" : ""}><span></span></label><button class="btn btn-sm btn-soft" data-action="edit-product-review" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-product-review" data-index="${index}">${icon("trash")}</button></div>`).join("") || `<div class="empty-dash">${dt("لا توجد تقييمات منتجات مخصصة.", "Aucun avis produit dédié.")}</div>`}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="reviews-customers">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تقييمات العملاء المعلقة", "Avis clients en attente")}</h3><span class="badge-soft orange">${pending.length}</span></div><div class="dash-card-body">
          ${pending.length ? `<div class="list-editor">
            ${pending.map((review) => customerRow(review, `
              <button class="btn btn-sm btn-success" data-action="approve-customer-review" data-id="${esc(review.id)}">${icon("check")} ${dt("اعتماد", "Approuver")}</button>
              <button class="btn btn-sm btn-danger" data-action="reject-customer-review" data-id="${esc(review.id)}">${icon("trash")} ${dt("رفض", "Refuser")}</button>`)).join("")}
          </div>` : `<div class="empty-dash">${dt("لا توجد تقييمات معلقة.", "Aucun avis en attente.")}</div>`}
        </div></article>
        ${approved.length ? `<article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("المعتمدة", "Approuvés")}</h3><span class="badge-soft green">${approved.length}</span></div><div class="dash-card-body"><div class="list-editor">
          ${approved.map((review) => customerRow(review, `
            <a class="btn btn-sm btn-soft" href="product.html?handle=${encodeURIComponent(review.productHandle)}" target="_blank" rel="noopener">${icon("external")}</a>
            <button class="btn btn-sm btn-soft" data-action="reject-customer-review" data-id="${esc(review.id)}">${icon("close")} ${dt("إلغاء الاعتماد", "Retirer")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-customer-review" data-id="${esc(review.id)}">${icon("trash")}</button>`)).join("")}
        </div></div></article>` : ""}
        ${rejected.length ? `<article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("المرفوضة", "Rejetés")}</h3><span class="badge-soft">${rejected.length}</span></div><div class="dash-card-body"><div class="list-editor">
          ${rejected.map((review) => customerRow(review, `
            <button class="btn btn-sm btn-success" data-action="approve-customer-review" data-id="${esc(review.id)}">${icon("check")} ${dt("اعتماد", "Approuver")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-customer-review" data-id="${esc(review.id)}">${icon("trash")}</button>`)).join("")}
        </div></div></article>` : ""}
      </div>`;
  }
  let pendingReviewKind = "home";
  let pendingReviewIndex = null;
  function reviewEditor(kind, index) {
    const isNew = index == null;
    const source = kind === "home" ? (model.homeReviews || []) : (model.reviews || []);
    const buffer = isNew ? {
      id: `review-${Date.now().toString(36)}`, name: "", city: { ar: "نواكشوط", fr: "Nouakchott" }, rating: 5,
      title: { ar: "", fr: "" }, body: { ar: "", fr: "" }, color: "#2e7d6f", handle: "", verified: true, approved: true
    } : clone(source[index]);
    editBuffer = buffer;
    pendingReviewKind = kind;
    pendingReviewIndex = isNew ? null : index;
    openModal(isNew ? dt("تقييم جديد", "Nouvel avis") : dt("تعديل التقييم", "Modifier l’avis"), `
      <div class="form-grid">
        <div class="field"><label>${dt("اسم العميل", "Nom")}</label><input data-edit-path="name" value="${esc(buffer.name)}"></div>
        <div class="field"><label>${dt("التقييم", "Note")}</label><select data-edit-path="rating">${[5, 4, 3, 2, 1].map((value) => `<option value="${value}" ${Number(buffer.rating) === value ? "selected" : ""}>${"★".repeat(value)}</option>`).join("")}</select></div>
        ${editBi(dt("المدينة", "Ville"), "city", buffer.city)}
        ${kind === "product" ? `<div class="field"><label>${dt("المنتج", "Produit")}</label><select data-edit-path="handle">${model.products.map((product) => `<option value="${esc(product.handle)}" ${product.handle === buffer.handle ? "selected" : ""}>${esc(product.title)}</option>`).join("")}</select></div>` : `<div class="field"><label>${dt("لون الصورة الرمزية", "Couleur avatar")}</label><input type="color" data-edit-path="color" value="${esc(buffer.color || "#2e7d6f")}"></div>`}
        ${editBi(dt("عنوان التقييم", "Titre"), "title", buffer.title)}
        <div class="span-2">${editBi(dt("نص التقييم", "Contenu"), "body", buffer.body, { type: "textarea", rows: 4 })}</div>
        ${kind === "product" ? `<div class="span-2">${editToggle(dt("شراء موثق", "Achat vérifié"), "verified", buffer.verified !== false)}${editToggle(dt("معتمد للنشر", "Approuvé"), "approved", buffer.approved !== false)}</div>` : ""}
      </div>`, {
      footer: editorFooter(!isNew, "delete-review-buffer")
    });
  }

  function saveReviewEditor() {
    if (!editBuffer) return;
    const list = pendingReviewKind === "home" ? model.homeReviews : (model.reviews || (model.reviews = []));
    if (pendingReviewIndex == null) list.push(editBuffer);
    else list[pendingReviewIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ التقييم", "Avis enregistré"), "good");
  
  }).call(ctx);
}
