export function createCtx(R) {
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const digits = (v) => String(v ?? "").replace(/\D/g, "");
  const money = (v) => R.money(v);
  const fmtDate = (v) => R.formatDate(v);
  const fmtDateTime = (v) => R.formatDate(v, { year:"numeric", month:"short", day:"numeric", hour:"2-digit", minute:"2-digit" });
  let dashLang = localStorage.getItem("restore_dash_lang_v1")==="fr" ? "fr" : "ar";
  const dt = (ar, fr) => (dashLang === "ar" ? ar : fr);
  const lng = (v) => (v==null ? "" : typeof v==="string" ? v : (v[dashLang] ?? v.ar ?? v.fr ?? ""));
  const token = () => R.currentSession?.()?.accessToken || window.__restoreAccessToken || null;
  const toast = (msg, type="") => {
    const n = document.getElementById("dash-toast"); if(!n) return;
    n.textContent = msg; n.className = `toast show ${type}`;
    clearTimeout(toast._t); toast._t = setTimeout(()=> n.className="toast", 3200);
  };
  return { R, esc, $, $$, digits, money, fmtDate, fmtDateTime, get dashLang(){return dashLang;}, setDashLang(v){dashLang=v; localStorage.setItem("restore_dash_lang_v1",v);}, dt, lng, token, toast };
}
