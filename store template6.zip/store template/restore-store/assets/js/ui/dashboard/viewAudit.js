/* extracted dashboard view */
export function viewAudit(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const logs = R.getAudit();
    return `
      <div class="dash-view-head"><div><h2>${dt("سجل النشاط", "Journal d’activité")}</h2><p>${dt("آخر 500 عملية في لوحة التحكم.", "Les 500 dernières actions du tableau de bord.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="clear-audit">${icon("trash")} ${dt("مسح السجل", "Effacer")}</button></div></div>
      <article class="dash-card"><div class="dash-card-body">${logs.length ? `<div class="list-editor">${logs.map((log) => `<div class="audit-row"><span class="audit-dot"></span><div><strong>${esc(log.action)}</strong><small>${esc(fmtDateTime(log.at))} · ${esc(log.actor || "system")}</small></div></div>`).join("")}</div>` : `<div class="empty-dash">${icon("audit")}<p>${dt("لا توجد عمليات مسجلة بعد.", "Aucune action enregistrée.")}</p></div>`}</div></article>`;
  }

  /* --------------------------------------------------------------------------
     Publish, preview and draft lifecycle
     -------------------------------------------------------------------------- */
  /* ==========================================================================
     First-time Setup Modal
     ========================================================================== */
  function openPublishModal() {
    saveDraftNow();
    const products = model.products.length;
    const draftHours = model.updatedAt ? Math.max(0, Math.round((Date.now() - Date.parse(model.updatedAt)) / 3600000)) : 0;
    openModal(dt("نشر التغييرات", "Publier les changements"), `
      <div class="publish-modal-list">
        <div><span>${dt("المنتجات", "Produits")}</span><strong>${products}</strong></div>
        <div><span>${dt("الأقسام", "Sections")}</span><strong>${(model.settings.pageSections || []).filter((section) => section.visible !== false).length}</strong></div>
        <div><span>${dt("الطلبات", "Commandes")}</span><strong>${R.getOrders().length}</strong></div>
        <div><span>${dt("آخر تعديل", "Dernière modification")}</span><strong>${esc(fmtDateTime(model.updatedAt))}</strong></div>
        <div><span>${dt("مساحة المتجر", "Boutique")}</span><strong>${R.remote ? "Supabase" : dt("محلي", "Local")} · MRU</strong></div>
      </div>
      <div style="display:flex;align-items:flex-start;gap:8px;background:var(--surface-2);border-radius:8px;padding:11px;margin-top:13px;font-size:10px;color:var(--muted);line-height:1.6">${icon("info")}<span>${dt("سيظهر المحتوى والألوان والمنتجات للزوار خلال ثوانٍ. يمكنك فتح المعاينة أولًا للتأكد.", "Le contenu, les couleurs et les produits seront visibles en quelques secondes. Ouvrez l’aperçu pour vérifier.")}</span></div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-soft btn-sm" data-action="preview">${icon("preview")} ${dt("معاينة", "Aperçu")}</button><button class="btn btn-primary btn-sm" data-action="confirm-publish">${icon("publish")} ${dt("نشر", "Publier")}</button>`
    });
  }

  async function publishNow() {
    const button = $("[data-action='confirm-publish']");
    if (button) { button.disabled = true; button.textContent = dt("جارٍ النشر...", "Publication..."); }
    try {
      const published = await R.publish(model);
      model = clone(published);
      dirty = false;
      closeModal();
      renderRoute();
      updateDraftState();
      R.addAudit(dt("نشر تحديث المتجر", "Publication de la boutique"));
      toast(dt("تم نشر التغييرات في المتجر", "Changements publiés sur la boutique"), "good");
    } catch (error) {
      toast(error.message || String(error), "error");
      if (button) { button.disabled = false; button.textContent = dt("نشر", "Publier"); }
    }
  }

  /* --------------------------------------------------------------------------
     Event delegation
     -------------------------------------------------------------------------- */
  let editorKind = null;
  let lastOrderCount = newOrdersCount();
  let searchTimer;

  function applyLiveColor(path) {
    const html = document.documentElement;
    const map = { "settings.colors.primary": "--orange", "settings.colors.purple": "--purple", "settings.colors.ink": "--ink", "settings.colors.lavender": "--lav" };
    if (map[path]) html.style.setProperty(map[path], getPath(model, path));
    if (path === "settings.font") {
      const font = getPath(model, path);
      html.style.setProperty("--font-main", `"${font}", "Noto Sans Arabic", Tahoma, sans-serif`);
    }
  }

  function handleField(node) {
    const editPath = node.dataset.editPath;
    const path = node.dataset.path;
    if (!editPath && !path) return;
    let value = node.type === "checkbox" ? node.checked : node.value;
    if (node.dataset.type === "bool") value = node.checked;
    if (node.type === "number" || node.dataset.type === "number") value = value === "" ? 0 : Number(value);
    if (node.type === "datetime-local" && value) value = new Date(value).toISOString();
    const target = editPath ? editBuffer : model;
    if (!target) return;
    setPath(target, editPath || path, value);
    if (!editPath) {
      applyLiveColor(path);
      saveDraftSoon();
      if (path.startsWith("settings.") || path.startsWith("pages.") || path.startsWith("collections.")) {
        // no DOM re-render while typing; the draft is saved in the background
      }
    }
  }

  function handleDirectToggle(node) {
    if (node.dataset.pageSectionVisible) {
      const section = model.settings.pageSections.find((item) => item.id === node.dataset.pageSectionVisible);
      if (section) { section.visible = node.checked; saveDraftSoon(); }
    }
    if (node.dataset.homeSectionVisible) {
      const section = model.settings.homeSections.find((item) => item.id === node.dataset.homeSectionVisible);
      if (section) { section.visible = node.checked; saveDraftSoon(); }
    }
    if (node.dataset.productActive != null) {
      const product = model.products[Number(node.dataset.productActive)];
      if (product) { product.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.couponActive != null) {
      const coupon = model.settings.coupons[Number(node.dataset.couponActive)];
      if (coupon) { coupon.active = node.checked; saveDraftNow(); }
    }
    if (node.dataset.paymentActive != null) {
      const payment = model.settings.payments[Number(node.dataset.paymentActive)];
      if (payment) { payment.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.cityActive != null) {
      const city = model.settings.cities[Number(node.dataset.cityActive)];
      if (city) { city.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.reviewApproved != null) {
      const review = model.reviews[Number(node.dataset.reviewApproved)];
      if (review) { review.approved = node.checked; saveDraftNow(); }
    }
    if (node.dataset.orderStatus) {
      const order = R.getOrders().find((item) => item.id === node.dataset.orderStatus);
      if (order) {
        R.updateOrder(order.id, { status: node.value });
        R.addAudit(`${dt("تحديث حالة طلب", "Statut commande")} ${order.id}: ${node.value}`);
        toast(dt("تم تحديث حالة الطلب", "Statut mis à jour"), "good");
        if (route === "overview" || route === "orders") renderRoute();
      }
    }
  }

  function handleLines(node) {
    const path = node.dataset.linesPath;
    if (!path) return;
    const rows = node.value.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
      const parts = line.split("|").map((part) => part.trim());
      if (parts.length >= 3) return { label: { ar: parts[0], fr: parts[1] }, href: parts.slice(2).join("|") };
      return { label: { ar: parts[0], fr: parts[0] }, href: parts[1] || "#" };
    });
    setPath(model, path, rows);
    saveDraftSoon();
  }

  function resizeImage(file) {
    return new Promise((resolve, reject) => {
      if (file.size > 4 * 1024 * 1024) { reject(new Error(dt("الصورة أكبر من 4MB", "Image supérieure à 4 Mo"))); return; }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(dt("تعذر قراءة الصورة", "Impossible de lire l’image")));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error(dt("صورة غير صالحة", "Image invalide")));
        image.onload = () => {
          const max = 900;
          const scale = Math.min(1, max / Math.max(image.width, image.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.width * scale));
          canvas.height = Math.max(1, Math.round(image.height * scale));
          const context = canvas.getContext("2d");
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL("image/webp", 0.82));
        };
        image.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  async function handleUpload(input) {
    const file = input.files?.[0];
    if (!file) return;
    const path = input.dataset.uploadPath;
    const direct = input.dataset.uploadTarget === "direct";
    try {
      let data = await resizeImage(file);
      const target = direct ? model : editBuffer;
      if (!target) return;
      if (R.remote) {
        try {
          const publicUrl = await R.uploadMedia(data);
          if (publicUrl) data = publicUrl;
        } catch (uploadError) {
          toast(`${dt("تعذر رفع الصورة إلى Supabase", "Échec du téléversement Supabase")}: ${uploadError.message}`, "error");
          return;
        }
      }
      setPath(target, path, data);
      const field = input.closest(".image-field");
      const inputNode = field?.querySelector("input[data-edit-path], input[data-path]");
      if (inputNode) inputNode.value = data;
      const preview = field?.querySelector("img");
      if (preview) preview.src = data;
      if (direct) saveDraftSoon();
      toast(dt("تم رفع الصورة", "Image importée"), "good");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  document.addEventListener("click", (event) => {
    const link = event.target.closest("[data-route]");
    if (link) {
      event.preventDefault();
      route = link.dataset.route;
      if (location.hash !== `#${route}`) history.replaceState(null, "", `#${route}`);
      $("#dash-sidebar")?.classList.remove("open");
      renderRoute();
      return;
    }
    const langButton = event.target.closest("[data-dash-lang]");
    if (langButton) {
      dashLang = langButton.dataset.dashLang === "fr" ? "fr" : "ar";
      localStorage.setItem(LS_DASH_LANG, dashLang);
      document.documentElement.lang = dashLang;
      document.documentElement.dir = dashLang === "ar" ? "rtl" : "ltr";
      if (session?.mustChange) renderPasswordChange();
      else if (session) renderShell();
      else renderLogin();
      return;
    }
    const tab = event.target.closest("[data-dash-tab]");
    if (tab) {
      const tabs = tab.parentElement;
      tabs.querySelectorAll("[data-dash-tab]").forEach((item) => item.classList.toggle("active", item === tab));
      const container = tabs.parentElement;
      container.querySelectorAll("[data-dash-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.dashPanel === tab.dataset.dashTab));
      return;
    }
    const filterButton = event.target.closest("[data-order-filter]");
    if (filterButton) { orderFilter = filterButton.dataset.orderFilter; renderRoute(); return; }
    const abandonedButton = event.target.closest("[data-abandoned-filter]");
    if (abandonedButton) { abandonedFilter = abandonedButton.dataset.abandonedFilter; renderRoute(); return; }
    const reportButton = event.target.closest("[data-report-range]");
    if (reportButton) { reportRange = reportButton.dataset.reportRange; renderRoute(); return; }
    const productFilter = event.target.closest("[data-product-filter]");
    if (productFilter) { /* handled in change */ }


    const actionNode = event.target.closest("[data-action]");
    if (!actionNode) return;
    const action = actionNode.dataset.action;
    const index = actionNode.dataset.index != null ? Number(actionNode.dataset.index) : null;
    const id = actionNode.dataset.id || "";

    switch (action) {
      case "logout":
        R.addAudit(dt("تسجيل خروج", "Déconnexion"), session?.username);
        R.logout();
        renderLogin();
        break;
      case "profile":
        route = "profile"; history.replaceState(null, "", "#profile"); renderRoute();
        break;
      case "toggle-sidebar":
        $("#dash-sidebar")?.classList.toggle("open");
        break;
      case "theme": {
        const next = R.theme === "dark" ? "light" : "dark";
        R.setTheme(next);
        actionNode.innerHTML = icon(next === "dark" ? "sun" : "moon");
        break;
      }
      case "orders-alert":
        route = "orders"; history.replaceState(null, "", "#orders");
        orderBadgeSeen = newOrdersCount();
        localStorage.setItem("restore_orders_seen_v1", String(orderBadgeSeen));
        updateCounts(); renderRoute();
        break;
      case "save-draft":
        saveDraftNow(); toast(dt("تم حفظ المسودة", "Brouillon enregistré"), "good");
        break;
      case "preview":
        if (dirty) saveDraftNow();
        window.open("index.html?preview=1", "_blank", "noopener");
        break;
      case "publish":
        openPublishModal();
        break;
      case "confirm-publish":
        publishNow();
        break;
      case "discard-draft":
        if (confirm(dt("إلغاء كل التغييرات غير المنشورة؟", "Annuler toutes les modifications non publiées ?"))) {
          R.discardDraft(); model = clone(R.state); dirty = false; closeModal(); renderRoute(); toast(dt("تم إلغاء المسودة", "Brouillon annulé"));
        }
        break;
      case "reset-demo":
        if (session?.role !== "owner") { toast(dt("للمالك فقط", "Propriétaire uniquement"), "error"); break; }
        if (confirm(dt("إعادة تعيين البيانات التجريبية وحذف كل الطلبات؟", "Réinitialiser la démo et supprimer toutes les commandes ?"))) {
          if (confirm(dt("تأكيد أخير: لا يمكن التراجع.", "Dernière confirmation : irréversible."))) R.resetLocalDemo();
        }
        break;
      case "close-modal":
        closeModal();
        break;
      case "modal-backdrop":
        if (event.target === actionNode) closeModal();
        break;
      case "view-order":
        viewOrderModal(id);
        break;
      case "save-order": {
        const order = R.getOrders().find((item) => item.id === id);
        if (order) {
          const status = $(`.dash-modal [data-order-status="${CSS.escape(id)}"]`)?.value || order.status;
          const note = $(`.dash-modal [data-order-note="${CSS.escape(id)}"]`)?.value || "";
          R.updateOrder(id, { status, internalNote: note });
          R.addAudit(`${dt("تحديث الطلب", "Commande modifiée")} ${id}: ${status}`);
          toast(dt("تم حفظ الطلب", "Commande enregistrée"), "good");
        }
        closeModal(); renderRoute();
        break;
      }
      case "print-invoice":
        printOrder(R.getOrders().find((order) => order.id === id), "invoice");
        break;
      case "print-label":
        printOrder(R.getOrders().find((order) => order.id === id), "label");
        break;
      case "export-orders":
        exportOrdersCsv();
        break;
      case "abandoned-status": {
        const rows = R.getAbandoned().map((item) => item.id === id ? { ...item, status: actionNode.dataset.status || "contacted", contactedAt: nowIso() } : item);
        localStorage.setItem("restore_abandoned_v1", JSON.stringify(rows));
        window.dispatchEvent(new CustomEvent("restore:orders"));
        renderRoute(); toast(dt("تم تحديث السلة", "Panier mis à jour"), "good");
        break;
      }
      case "delete-abandoned":
        if (confirm(dt("حذف السلة المتروكة؟", "Supprimer ce panier ?"))) { R.removeAbandoned(id); renderRoute(); }
        break;
      case "add-product":
        editorKind = "product"; productEditor(null);
        break;
      case "edit-product":
        editorKind = "product"; productEditor(index);
        break;
      case "delete-product":
        deleteProduct(index);
        break;
      case "delete-product-buffer":
        deleteProduct(null, true);
        break;
      case "bulk-price":
        bulkPriceModal();
        break;
      case "apply-bulk-price":
        applyBulkPrice();
        break;
      case "save-editor":
  }).call(ctx);
}
