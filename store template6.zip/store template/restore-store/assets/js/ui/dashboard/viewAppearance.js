/* extracted dashboard view */
export function viewAppearance(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const colors = model.settings.colors || {};
    const fonts = ["Montserrat", "Tajawal", "Cairo", "Inter", "Poppins", "DM Sans"];
    return `
      <div class="dash-view-head"><div><h2>${dt("الهوية والألوان", "Identité & couleurs")}</h2><p>${dt("غيّر الشعار والألوان والخط. تظهر التغييرات في المتجر بعد النشر.", "Changez logo, couleurs et police. Les changements sont publiés sur la boutique.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="preview">${icon("preview")} ${dt("معاينة مباشرة", "Aperçu")}</button></div></div>
      <div class="dash-grid cols-2">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الشعار والأيقونات", "Logo & icônes")}</h3></div><div class="dash-card-body dash-form">
          ${directImageEditor(dt("الشعار الأساسي", "Logo principal"), "settings.logo", model.settings.logo)}
          ${directImageEditor(dt("الشعار الأبيض", "Logo blanc"), "settings.logoWhite", model.settings.logoWhite)}
          ${directImageEditor(dt("أيقونة الموقع", "Favicon"), "settings.favicon", model.settings.favicon)}
          <div class="form-grid">${field(dt("الانحناء (px)", "Arrondi (px)"), "settings.radius", { type: "number" })}<div class="field"><label>${dt("خط الواجهة", "Police")}</label><select data-path="settings.font">${fonts.map((font) => `<option value="${font}" ${model.settings.font === font ? "selected" : ""}>${font}</option>`).join("")}</select></div></div>
        </div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("ألوان العلامة", "Couleurs de marque")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">
            ${field(dt("اللون الأساسي", "Couleur principale"), "settings.colors.primary", { type: "color" })}
            ${field(dt("اللون الثانوي", "Couleur secondaire"), "settings.colors.purple", { type: "color" })}
            ${field(dt("لون النص", "Couleur texte"), "settings.colors.ink", { type: "color" })}
            ${field(dt("الخلفية الفاتحة", "Fond clair"), "settings.colors.lavender", { type: "color" })}
          </div>
          <div style="border-radius:12px;padding:18px;background:var(--surface-2);border:1px solid var(--border);margin-top:4px">
            <span class="eyebrow">${dt("معاينة", "Aperçu")}</span>
            <h3 style="font-size:22px;margin:8px 0 6px">${esc(lng(model.settings.storeName))}</h3>
            <p style="font-size:11px;color:var(--muted);margin-bottom:12px">${esc(lng(model.settings.tagline))}</p>
            <button class="btn btn-primary btn-sm" type="button">${dt("تسوق الآن", "Découvrir")}</button>
            <button class="btn btn-soft btn-sm" type="button" style="margin-inline-start:5px">${dt("معرفة المزيد", "En savoir plus")}</button>
          </div>
          <p class="form-note">${dt("يوفر المتجر الوضع الفاتح والداكن تلقائيًا. الألوان تُطبّق على الأزرار، الشريط العلوي والعروض.", "Le mode clair/sombre est automatique. Les couleurs s’appliquent aux boutons, au header et aux offres.")}</p>
        </div></article>
      </div>
      <article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("الوضع الليلي والحركات", "Mode sombre et animations")}</h3></div><div class="dash-card-body"><div class="form-grid">${directToggle(dt("تفعيل الوضع الليلي للزوار", "Activer le mode sombre"), "settings.darkMode", model.settings.darkMode !== false)}${directToggle(dt("تفعيل الحركات", "Activer les animations"), "settings.animations", model.settings.animations !== false)}${directToggle(dt("تفعيل PWA", "Activer la PWA"), "settings.pwa", model.settings.pwa !== false)}</div></div></article>`;
  
  }).call(ctx);
}
