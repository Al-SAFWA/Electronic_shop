// legacy dashboard chunk 2
            <button class="dash-menu-btn" type="button" data-action="toggle-sidebar">${icon("menu")}</button>
            <div class="dash-title"><h1 id="dash-title">${esc(ROUTE_TITLES[route]?.[dashLang] || ROUTE_TITLES[route]?.ar || "")}</h1><small id="dash-subtitle">${esc(ROUTE_TITLES[route]?.sub?.[dashLang] || "")}</small></div>
            <label class="dash-search">${icon("search")}<input id="dash-search" placeholder="${dt("بحث في الطلبات والمنتجات...", "Rechercher commandes, produits...")}" value="${esc(searchTerm)}"></label>
            <div class="dash-top-actions">
              <span class="dash-save-state ${dirty ? "dirty" : "published"}"><i></i>${dirty ? dt("تغييرات غير منشورة", "Modifications non publiées") : dt("متجر محدث", "Boutique à jour")}</span>
              <button class="dash-lang" type="button" data-dash-lang="${dashLang === "ar" ? "fr" : "ar"}">${dashLang === "ar" ? "FR" : "AR"}</button>
              <button class="dash-icon-btn" type="button" data-action="theme" title="${dt("الوضع الليلي", "Mode sombre")}">${icon(R.theme === "dark" ? "sun" : "moon")}</button>
              <a class="dash-icon-btn" href="index.html" target="_blank" rel="noopener" title="${dt("عرض المتجر", "Voir la boutique")}">${icon("external")}</a>
              <button class="dash-icon-btn" type="button" data-action="orders-alert" title="${dt("طلبات جديدة", "Nouvelles commandes")}">${icon("bell")}<span class="alert-dot" data-order-alert ${Math.max(0, newOrdersCount() - orderBadgeSeen) ? "" : "hidden"}>${Math.max(0, newOrdersCount() - orderBadgeSeen) || ""}</span></button>
              <div class="dash-publish">
                <button class="btn btn-soft" type="button" data-action="preview" title="${dt("معاينة", "Aperçu")}">${icon("preview")}<span>${dt("معاينة", "Aperçu")}</span></button>
                <button class="btn btn-primary" type="button" data-action="publish" title="${dt("نشر", "Publier")}">${icon("publish")}<span>${dt("نشر", "Publier")}</span></button>
              </div>
            </div>
          </header>
          <div class="dash-view" id="dash-view"></div>
        </main>
      </div>`;
    renderRoute();
    updateCounts();
  }

  function renderRoute() {
    if (!session) { renderLogin(); return; }
    if (session.mustChange) { renderPasswordChange(); return; }
    if (!ROUTE_TITLES[route]) route = "overview";
    if (OWNER_ONLY_ROUTES.has(route) && session.role !== "owner") {
      route = "overview";
      toast(dt("هذه الصفحة متاحة للمالك فقط", "Cette page est réservée au propriétaire"), "error");
    }
    const view = $("#dash-view");
    if (!view) { renderShell(); return; }
    const views = {
      overview: viewOverview,
      orders: viewOrders,
      abandoned: viewAbandoned,
      products: viewProducts,
      categories: viewCategories,
      reviews: viewReviews,
      content: viewContent,
      homepage: viewHomepage,
      appearance: viewAppearance,
      marketing: viewMarketing,
      blog: viewBlog,
      pages: viewPages,
      payments: viewPayments,
      team: viewTeam,
      reports: viewReports,
      settings: viewSettings,
      audit: viewAudit,
      profile: viewProfile
    };
    view.innerHTML = (views[route] || viewOverview)();
    $$(".dash-nav a").forEach((link) => link.classList.toggle("active", link.dataset.route === route));
    const title = $("#dash-title");
    const subtitle = $("#dash-subtitle");
    if (title) title.textContent = ROUTE_TITLES[route]?.[dashLang] || ROUTE_TITLES[route]?.ar || "";
    if (subtitle) subtitle.textContent = ROUTE_TITLES[route]?.sub?.[dashLang] || "";
    const search = $("#dash-search");
    if (search && search.value !== searchTerm) search.value = searchTerm;
    updateDraftState();
    updateCounts();
    if (route === "orders" || route === "reports") setTimeout(() => localStorage.setItem("restore_orders_seen_v1", String(newOrdersCount())), 800);
  }

  /* --------------------------------------------------------------------------
     Overview
     -------------------------------------------------------------------------- */
  function statCard(label, value, note, accent, iconName, trend = "") {
    return `<article class="dash-card stat-card" style="--accent:${accent}">
      <div class="stat-top"><span class="stat-label">${esc(label)}</span><span class="stat-icon">${icon(iconName)}</span></div>
      <strong>${value}</strong><small>${trend ? `<span class="trend">${esc(trend)}</span> · ` : ""}${esc(note)}</small>
    </article>`;
  }

  function viewOverview() {
    const orders = orderList();
    const totalRevenue = revenueOfOrders(orders);
    const delivered = orders.filter((order) => order.status === "delivered").length;
    const newCount = orders.filter((order) => order.status === "new").length;
    const cancelled = orders.filter((order) => order.status === "cancelled" || order.status === "returned").length;
    const low = lowStockProducts();
    const abandoned = R.getAbandoned().filter((item) => item.status === "open");
    const recent = orders.slice(0, 6);
    const days = [...Array(7)].map((_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const key = date.toISOString().slice(0, 10);
      const total = orders.filter((order) => String(order.createdAt).slice(0, 10) === key).reduce((sum, order) => sum + Number(order.total || 0), 0);
      return { label: date.toLocaleDateString(dashLang === "ar" ? "ar-MR" : "fr-FR", { weekday: "short" }), total };
    });
    const maxDay = Math.max(1, ...days.map((day) => day.total));
    const statusRows = ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled"].map((status) => {
      const meta = R.statusMeta(status);
      return { status, label: lng(meta.label), color: meta.color, count: orderStatusCount(status) };
    });
    const displayName = session?.role === "owner" ? dt("مالك المتجر", "Propriétaire") : dt("مدير المتجر", "Gérant");
    return `
      <div class="dash-view-head">
        <div><h2>${dt("مرحبًا", "Bonjour")} ${esc(displayName)} 👋</h2><p>${dt("هذا ملخص مباشر لأداء متجرك.", "Voici un résumé en direct de votre boutique.")}</p></div>
        <div class="dash-view-actions">
          <a class="btn btn-primary" href="#products" data-route="products">${icon("plus")} ${dt("إضافة منتج", "Ajouter un produit")}</a>
          <a class="btn btn-soft" href="#reports" data-route="reports">${dt("عرض التقارير", "Voir les rapports")}</a>
        </div>
      </div>
      <div class="dash-grid cols-4" style="margin-bottom:14px">
        ${statCard(dt("إجمالي الطلبات", "Commandes totales"), orders.length, dt("كل الطلبات المسجلة", "Toutes les commandes"), "#ff6400", "orders", newCount ? `+${newCount} ${dt("جديد", "nouveau")}` : "")}
        ${statCard(dt("الإيرادات", "Chiffre d’affaires"), money(totalRevenue), dt("دون الملغاة والمرتجعة", "Hors annulées et retours"), "#128c53", "reports")}
        ${statCard(dt("طلبات جديدة", "Nouvelles commandes"), newCount, dt("تحتاج إلى تأكيد", "À confirmer"), "#a72396", "bell")}
        ${statCard(dt("مخزون منخفض", "Stock faible"), low.length, dt("منتجات تحتاج متابعة", "Produits à suivre"), "#e67e22", "products")}
      </div>
      <div class="dash-grid cols-3" style="margin-bottom:14px">
        <article class="dash-card" style="grid-column:span 2">
          <div class="dash-card-head"><h3>${dt("آخر الطلبات", "Dernières commandes")}</h3><a href="#orders" data-route="orders">${dt("عرض الكل", "Tout voir")}</a></div>
          <div class="dash-card-body" style="padding-top:10px">
            ${recent.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الطلب", "Commande")}</th><th>${dt("العميل", "Client")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("المجموع", "Total")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead><tbody>
              ${recent.map((order) => {
                const status = R.statusMeta(order.status);
                return `<tr>
                  <td><strong>${esc(order.id)}</strong><br><small>${esc(fmtDate(order.createdAt))}</small></td>
                  <td>${esc(order.customer?.name || "")}<br><small dir="ltr">${esc(order.customer?.phone || "")}</small></td>
                  <td>${esc(order.customer?.city || "")}</td>
                  <td class="price">${money(order.total)}</td>
                  <td><span class="status-pill" style="--status:${status.color}">${esc(lng(status.label))}</span></td>
                  <td><button class="btn btn-sm btn-soft" type="button" data-action="view-order" data-id="${esc(order.id)}">${dt("تفاصيل", "Détails")}</button></td>
                </tr>`;
              }).join("")}</tbody></table></div>` : `<div class="empty-dash">${icon("orders")}<p>${dt("لا توجد طلبات بعد. ستظهر الطلبات القادمة من المتجر هنا مباشرة.", "Aucune commande. Les commandes de la boutique apparaîtront ici.")}</p></div>`}
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("حالة المتجر", "État de la boutique")}</h3><a href="#settings" data-route="settings">${dt("إعدادات", "Réglages")}</a></div>
          <div class="dash-card-body">
            <div style="display:flex;align-items:center;gap:9px;padding:9px 0;border-bottom:1px solid var(--border)"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${R.isStoreOpen() ? "#25a55f" : "#c0392b"}"></span><div><strong style="font-size:10px">${R.isStoreOpen() ? dt("المتجر مفتوح", "Boutique ouverte") : dt("المتجر مغلق", "Boutique fermée")}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${model.settings.hours.open} — ${model.settings.hours.close} · ${esc(model.settings.timezone)}</small></div></div>

            <div style="display:flex;align-items:center;gap:9px;padding:9px 0"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${dirty ? "#e67e22" : "#25a55f"}"></span><div><strong style="font-size:10px">${dirty ? dt("مسودة غير منشورة", "Brouillon non publié") : dt("كل التغييرات منشورة", "Tout est publié")}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${dt("آخر تحديث", "Dernière mise à jour")}: ${esc(fmtDateTime(model.updatedAt))}</small></div></div>
            <button class="btn btn-primary btn-block btn-sm" type="button" data-action="preview" style="margin-top:8px">${icon("preview")} ${dt("معاينة المتجر", "Prévisualiser")}</button>
          </div>
        </article>
      </div>
      <div class="dash-grid cols-3">
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("الطلبات في آخر 7 أيام", "Commandes des 7 jours")}</h3></div>
          <div class="dash-card-body">
            <div class="report-bars">${days.map((day) => `<div class="bar" style="height:${Math.max(5, Math.round(day.total / maxDay * 100))}%" title="${money(day.total)}"><span>${esc(day.label)}</span></div>`).join("")}</div>
            <div class="report-legend"><span><i></i>${money(days.reduce((sum, day) => sum + day.total, 0))} ${dt("هذا الأسبوع", "cette semaine")}</span></div>
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("توزيع حالات الطلبات", "Répartition des statuts")}</h3></div>
          <div class="dash-card-body">
            ${statusRows.map((row) => `<div style="display:grid;grid-template-columns:65px 1fr 22px;align-items:center;gap:7px;margin-bottom:8px"><small style="font-size:8px;color:var(--muted)">${esc(row.label)}</small><div class="mini-bar" style="--bar:${row.color}"><i style="width:${orders.length ? Math.max(3, row.count / orders.length * 100) : 0}%"></i></div><strong style="font-size:9px">${row.count}</strong></div>`).join("")}
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("تحتاج انتباهك", "À surveiller")}</h3></div>
          <div class="dash-card-body">
            <div class="list-editor">
              <div class="list-row"><div class="grow"><strong>${low.length} ${dt("منتجات بمخزون منخفض", "produits en stock faible")}</strong><small>${dt("حد التنبيه", "Seuil")}: ${model.settings.lowStockThreshold}</small></div><a class="btn btn-sm btn-soft" href="#products" data-route="products">${dt("إدارة", "Gérer")}</a></div>
              <div class="list-row"><div class="grow"><strong>${abandoned.length} ${dt("سلة متروكة", "paniers abandonnés")}</strong><small>${dt("فرص استرجاع", "Opportunités")}</small></div><a class="btn btn-sm btn-soft" href="#abandoned" data-route="abandoned">${dt("عرض", "Voir")}</a></div>
              <div class="list-row"><div class="grow"><strong>${cancelled} ${dt("طلبات ملغاة/مرتجعة", "annulées/retournées")}</strong><small>${dt("راجع الأسباب", "Vérifiez les causes")}</small></div><a class="btn btn-sm btn-soft" href="#orders" data-route="orders">${dt("الطلبات", "Commandes")}</a></div>
            </div>
          </div>
        </article>
      </div>`;
  }
  /* --------------------------------------------------------------------------
     Shared modal / field helpers
     -------------------------------------------------------------------------- */
  let editBuffer = null;
  let orderFilter = "all";
  let productSearch = "";
  let productCategory = "all";
  let productStock = "all";
  let abandonedFilter = "open";

  function openModal(title, body, { wide = false, footer = "", onMount = null } = {}) {
    modalRoot.innerHTML = `
      <div class="dash-modal-backdrop" data-action="modal-backdrop">
        <section class="dash-modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
          <div class="dash-modal-head"><h3>${esc(title)}</h3><button type="button" data-action="close-modal" aria-label="${dt("إغلاق", "Fermer")}">${icon("close")}</button></div>
          <div class="dash-modal-body">${body}</div>
          ${footer ? `<div class="dash-modal-foot">${footer}</div>` : ""}
        </section>
      </div>`;
    document.body.classList.add("no-scroll");
    if (onMount) onMount(modalRoot);
  }
  function closeModal() {
    modalRoot.innerHTML = "";
    document.body.classList.remove("no-scroll");
    editBuffer = null;
  }

  function field(label, path, { type = "text", value, placeholder = "", hint = "", rows = 3, options = null, disabled = false } = {}) {
    let actual = value !== undefined ? value : getPath(model, path);
    if (type === "datetime-local") actual = isoLocal(actual);
    if (options) {
      return `<div class="field"><label>${esc(label)}</label><select data-path="${esc(path)}" ${disabled ? "disabled" : ""}>${options.map((option) => {
        const optionValue = typeof option === "object" ? option.value : option;
        const optionLabel = typeof option === "object" ? option.label : option;
        return `<option value="${esc(optionValue)}" ${String(optionValue) === String(actual) ? "selected" : ""}>${esc(optionLabel)}</option>`;
      }).join("")}</select>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
    }
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><textarea data-path="${esc(path)}" rows="${rows}" placeholder="${esc(placeholder)}" ${disabled ? "disabled" : ""}>${esc(actual ?? "")}</textarea>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
    return `<div class="field"><label>${esc(label)}</label><input type="${type}" data-path="${esc(path)}" value="${esc(actual ?? "")}" placeholder="${esc(placeholder)}" ${disabled ? "disabled" : ""}>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
  }

  function biField(label, path, { type = "text", rows = 3 } = {}) {
    const value = getPath(model, path) || {};
    if (type === "textarea") {
      return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><textarea data-path="${esc(path)}.ar" rows="${rows}" dir="rtl" placeholder="العربية">${esc(value.ar ?? "")}</textarea><textarea data-path="${esc(path)}.fr" rows="${rows}" dir="ltr" placeholder="Français">${esc(value.fr ?? "")}</textarea></div></div>`;
    }
    return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><input data-path="${esc(path)}.ar" value="${esc(value.ar ?? "")}" dir="rtl" placeholder="العربية"><input data-path="${esc(path)}.fr" value="${esc(value.fr ?? "")}" dir="ltr" placeholder="Français"></div></div>`;
  }

  function editInput(label, path, { type = "text", value = "", placeholder = "", rows = 3, help = "" } = {}) {
    const suffix = `data-edit-path="${esc(path)}"`;
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><textarea ${suffix} rows="${rows}" placeholder="${esc(placeholder)}">${esc(value ?? "")}</textarea>${help ? `<p class="form-note">${esc(help)}</p>` : ""}</div>`;
    return `<div class="field"><label>${esc(label)}</label><input type="${type}" ${suffix} value="${esc(value ?? "")}" placeholder="${esc(placeholder)}">${help ? `<p class="form-note">${esc(help)}</p>` : ""}</div>`;
  }
  function editBi(label, path, value = {}, { type = "text", rows = 3 } = {}) {
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><textarea data-edit-path="${esc(path)}.ar" rows="${rows}" dir="rtl">${esc(value?.ar ?? "")}</textarea><textarea data-edit-path="${esc(path)}.fr" rows="${rows}" dir="ltr">${esc(value?.fr ?? "")}</textarea></div></div>`;
    return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><input data-edit-path="${esc(path)}.ar" value="${esc(value?.ar ?? "")}" dir="rtl"><input data-edit-path="${esc(path)}.fr" value="${esc(value?.fr ?? "")}" dir="ltr"></div></div>`;
  }
  function editToggle(label, path, checked) {
    return `<div class="check-row"><label class="toggle"><input type="checkbox" data-edit-path="${esc(path)}" ${checked ? "checked" : ""}><span></span></label><span>${esc(label)}</span></div>`;
  }
  function directToggle(label, path, checked) {
    return `<div class="check-row"><label class="toggle"><input type="checkbox" data-path="${esc(path)}" data-type="bool" ${checked ? "checked" : ""}><span></span></label><span>${esc(label)}</span></div>`;
  }
  function imageEditor(label, path, value = "") {
    return `<div class="field"><label>${esc(label)}</label><div class="image-field">
      <span class="image-preview"><img src="${esc(value || "assets/img/favicon.svg")}" alt=""></span>
      <div class="grow">
        <input data-edit-path="${esc(path)}" value="${esc(value)}" placeholder="assets/img/...">
        <label class="upload-btn">${icon("upload")} ${dt("رفع صورة", "Téléverser")}<input type="file" accept="image/*" data-upload-path="${esc(path)}"></label>
      </div>
    </div></div>`;
  }
  function editorFooter(canDelete = false, deleteAction = "") {
    return `${canDelete ? `<button class="btn btn-danger btn-sm" type="button" data-action="${esc(deleteAction)}">${icon("trash")} ${dt("حذف", "Supprimer")}</button>` : ""}<span style="flex:1"></span><button class="btn btn-soft btn-sm" type="button" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" type="button" data-action="save-editor">${icon("check")} ${dt("حفظ", "Enregistrer")}</button>`;
  }

  function statusOptions(selected) {
    return R.statuses.map((status) => {
      const meta = R.statusMeta(status);
      return `<option value="${status}" ${status === selected ? "selected" : ""}>${esc(lng(meta.label))}</option>`;
    }).join("");
  }

  /* --------------------------------------------------------------------------
     Orders
     -------------------------------------------------------------------------- */
  function filteredOrders() {
    const needle = R.normalizeText(searchTerm);
    return orderList().filter((order) => {
      if (orderFilter !== "all" && order.status !== orderFilter) return false;
      if (!needle) return true;
      const haystack = R.normalizeText([order.id, order.customer?.name, order.customer?.phone, order.customer?.city, order.customer?.address, ...(order.items || []).map((item) => item.title)].join(" "));
      return haystack.includes(needle);
    });
  }

  function ordersTable(orders) {
    if (!orders.length) return `<div class="table-empty">${icon("orders")}<p>${dt("لا توجد طلبات مطابقة.", "Aucune commande correspondante.")}</p></div>`;
    return `<div class="dash-table-wrap"><table class="dash-table">
      <thead><tr><th>${dt("الطلب", "Commande")}</th><th>${dt("العميل", "Client")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("المنتجات", "Articles")}</th><th>${dt("الدفع", "Paiement")}</th><th>${dt("المجموع", "Total")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead>
      <tbody>${orders.map((order) => {
        const status = R.statusMeta(order.status);
        return `<tr>
          <td><strong style="font-size:9px">${esc(order.id)}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${esc(fmtDateTime(order.createdAt))}</small></td>
          <td><strong style="font-size:10px">${esc(order.customer?.name || "")}</strong><br><small dir="ltr" style="font-size:8px;color:var(--soft-muted)">${esc(order.customer?.phone || "")}</small></td>
          <td>${esc(order.customer?.city || "")}</td>
          <td>${(order.items || []).reduce((sum, item) => sum + Number(item.qty || 1), 0)}</td>
          <td>${esc(order.payment?.name || "")}</td>
          <td class="price">${money(order.total)}</td>
          <td><select class="dash-field" data-order-status="${esc(order.id)}" style="min-width:95px;height:28px;padding:2px 6px;font-size:9px;border-color:${status.color}">${statusOptions(order.status)}</select></td>
          <td><div class="cell-actions">
            <button class="btn btn-sm btn-soft" type="button" data-action="view-order" data-id="${esc(order.id)}">${dt("عرض", "Voir")}</button>
            <a class="btn btn-sm btn-soft" href="https://wa.me/${digits(order.customer?.phone)}" target="_blank" rel="noopener" title="WhatsApp">${icon("whatsapp")}</a>
          </div></td>
        </tr>`;
      }).join("")}</tbody>
    </table></div>`;
  }

  function viewOrders() {
    const orders = filteredOrders();
    const tabs = [{ id: "all", label: dt("الكل", "Toutes"), count: orderList().length }, ...R.statuses.map((status) => ({ id: status, label: lng(R.statusMeta(status).label), count: orderStatusCount(status) }))];
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الطلبات", "Commandes")}</h2><p>${dt("كل طلب يصل من المتجر يظهر هنا فورًا.", "Chaque commande de la boutique apparaît ici en direct.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" type="button" data-action="export-orders">${icon("download")} ${dt("تصدير CSV", "Exporter CSV")}</button></div>
      </div>
      <div class="dash-toolbar">
        <div class="segmented" style="flex-wrap:wrap">${tabs.map((tab) => `<button type="button" data-order-filter="${tab.id}" class="${orderFilter === tab.id ? "active" : ""}">${esc(tab.label)} ${tab.count ? `(${tab.count})` : ""}</button>`).join("")}</div>
        <div class="spacer"></div>
        <label class="field" style="min-width:210px"><input id="order-search" placeholder="${dt("بحث بالرقم، الاسم أو الهاتف", "N°, nom ou téléphone")}" value="${esc(searchTerm)}"></label>
      </div>
      <div class="dash-card">${ordersTable(orders)}</div>`;
  }

  function orderMessage(order, type = "confirm") {
    const template = model.settings.whatsappTemplates?.[type];
    if (!template) return "";
    let text = lng(template)
      .replaceAll("{name}", order.customer?.name || "")
      .replaceAll("{order_id}", order.id)
      .replaceAll("{store}", lng(model.settings.storeName));
    return text;
  }

  function printOrder(order, mode) {
    const invoice = mode === "invoice";
    const win = window.open("", "_blank", "width=820,height=980");
    if (!win) { toast(dt("اسمح بالنوافذ المنبثقة للطباعة", "Autorisez les pop-ups pour imprimer"), "error"); return; }
    const itemRows = (order.items || []).map((item) => `<tr><td>${esc(item.title)}<br><small>${esc(item.variantTitle || "")} ${esc(item.specsText || "")}</small></td><td>${item.qty}</td><td>${money(item.price)}</td><td>${money(item.line)}</td></tr>`).join("");
    win.document.write(`<!doctype html><html lang="${dashLang}" dir="${dashLang === "ar" ? "rtl" : "ltr"}"><head><meta charset="utf-8"><title>${invoice ? dt("فاتورة", "Facture") : dt("ملصق شحن", "Étiquette")} ${esc(order.id)}</title><style>
      @page{size:A4;margin:16mm}*{box-sizing:border-box}body{font-family:Tahoma,Arial,sans-serif;color:#111;font-size:12px;line-height:1.6}header{display:flex;justify-content:space-between;border-bottom:2px solid #ff6400;padding-bottom:12px;margin-bottom:18px}h1{font-size:22px;margin:0}img{width:120px}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:start;font-size:11px}th{background:#f5f5f5}small{color:#666;font-size:9px}.total{font-size:16px;font-weight:bold;text-align:end;margin-top:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.box{border:1px solid #ddd;padding:10px;border-radius:6px}.label{border:2px solid #111;padding:22px;margin-top:20px}.label h2{font-size:26px;margin:0 0 10px}.label .addr{font-size:17px;line-height:1.8}.barcode{margin-top:16px;font-family:monospace;font-size:13px;letter-spacing:2px}</style></head><body>
      <header><div><img src="${location.origin}${location.pathname.replace(/[^/]*$/, "")}${esc(model.settings.logo || "assets/img/restore-logo.svg")}" alt="Restore"><h1>${invoice ? dt("فاتورة", "Facture") : dt("ملصق شحن", "Étiquette d’expédition")}</h1></div><div style="text-align:end"><strong>${esc(model.settings.mapPhone || model.settings.phoneDisplay || "")}</strong><br>${esc(lng(model.settings.address))}<br>${esc(model.settings.email || "")}</div></header>
      ${invoice ? `<div class="grid"><div class="box"><strong>${dt("فاتورة", "Facture")}: ${esc(order.id)}</strong><br>${esc(fmtDate(order.createdAt))}<br>${dt("الحالة", "Statut")}: ${esc(lng(R.statusMeta(order.status).label))}</div><div class="box"><strong>${dt("العميل", "Client")}</strong><br>${esc(order.customer?.name || "")}<br>${esc(order.customer?.phone || "")}<br>${esc(order.customer?.city || "")} — ${esc(order.customer?.address || "")}</div></div>
      <table><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("الكمية", "Qté")}</th><th>${dt("السعر", "Prix")}</th><th>${dt("المجموع", "Total")}</th></tr></thead><tbody>${itemRows}</tbody></table>
      <div class="total">${dt("المجموع الكلي", "Total")}: ${money(order.total)}</div>` : `<div class="label"><h2>${esc(model.settings.storeName?.[dashLang] || "Restore")}</h2><div class="addr"><strong>${esc(order.customer?.name || "")}</strong><br>${esc(order.customer?.phone || "")}<br>${esc(order.customer?.address || "")}<br>${esc(order.customer?.city || "")} — ${dt("موريتانيا", "Mauritanie")}</div><div class="barcode">${esc(order.id)} · ${esc(digits(order.customer?.phone).slice(-8))}</div></div>`}
      <p style="margin-top:24px;font-size:9px;color:#888">${dt("تم إنشاء هذا المستند من لوحة تحكم ريستور.", "Document généré depuis le tableau de bord Restore.")}</p>
      </body></html>`);
    win.document.close();
    setTimeout(() => { win.focus(); win.print(); }, 350);
  }

  function viewOrderModal(id) {
    const order = R.getOrders().find((item) => item.id === id);
    if (!order) return;
    const status = R.statusMeta(order.status);
    const wa = `https://wa.me/${digits(order.customer?.phone)}?text=${encodeURIComponent(orderMessage(order, "confirm"))}`;
    openModal(`${dt("الطلب", "Commande")} ${order.id}`, `
      <div class="order-detail">
        <div>
          <div class="order-detail-section">
            <h4>${dt("المنتجات", "Articles")}</h4>
            ${(order.items || []).map((item) => `<div class="order-item-row"><img src="${esc(item.image || "assets/img/favicon.svg")}" alt=""><div class="grow"><strong>${esc(item.title)}</strong><small>${esc(item.variantTitle || "")} ${item.specsText ? `· ${esc(item.specsText)}` : ""}</small></div><span>×${item.qty}</span><strong>${money(item.line)}</strong></div>`).join("")}
            <div class="order-totals">
              <div><span>${dt("المجموع الفرعي", "Sous-total")}</span><span>${money(order.subtotal)}</span></div>
              <div><span>${dt("الشحن", "Livraison")}</span><span>${money(order.shipping)}</span></div>
              <div><span>${dt("الخصم", "Réduction")}</span><span>${money(order.discount)}</span></div>
              <div class="total"><span>${dt("المجموع", "Total")}</span><span>${money(order.total)}</span></div>
            </div>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("ملاحظات العميل", "Notes du client")}</h4>
            <p>${esc(order.customer?.notes || dt("لا توجد ملاحظات", "Aucune note"))}</p>
          </div>
        </div>
        <div>
          <div class="order-detail-section">
            <h4>${dt("العميل", "Client")}</h4>
            <p><strong>${esc(order.customer?.name || "")}</strong><br><span dir="ltr">${esc(order.customer?.phone || "")}</span><br>${esc(order.customer?.city || "")}<br>${esc(order.customer?.address || "")}<br>${esc(order.customer?.email || "")}</p>
            <div style="display:flex;gap:5px;margin-top:9px;flex-wrap:wrap"><a class="btn btn-sm btn-whatsapp" href="${wa}" target="_blank" rel="noopener">${icon("whatsapp")} ${dt("واتساب", "WhatsApp")}</a><a class="btn btn-sm btn-soft" href="tel:${esc(order.customer?.phone)}">${dt("اتصال", "Appeler")}</a></div>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("إدارة الطلب", "Gestion")}</h4>
            <div class="field"><label>${dt("الحالة", "Statut")}</label><select data-order-status="${esc(order.id)}">${statusOptions(order.status)}</select></div>
            <div class="field" style="margin-top:8px"><label>${dt("ملاحظة داخلية", "Note interne")}</label><textarea rows="3" data-order-note="${esc(order.id)}">${esc(order.internalNote || "")}</textarea></div>
            <p class="form-note" style="margin-top:8px">${dt("الدفع", "Paiement")}: <strong>${esc(order.payment?.name || "")}</strong> · ${dt("المصدر", "Source")}: ${esc(order.source || "whatsapp")}</p>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("المستندات", "Documents")}</h4>
            <div style="display:flex;gap:5px;flex-wrap:wrap"><button class="btn btn-sm btn-soft" data-action="print-invoice" data-id="${esc(order.id)}">${icon("print")} ${dt("فاتورة", "Facture")}</button><button class="btn btn-sm btn-soft" data-action="print-label" data-id="${esc(order.id)}">${dt("ملصق شحن", "Étiquette")}</button></div>
            <div style="margin-top:12px"><span class="status-pill" style="--status:${status.color}">${esc(lng(status.label))}</span></div>
          </div>
        </div>
      </div>`, {
      wide: true,
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إغلاق", "Fermer")}</button><button class="btn btn-primary btn-sm" data-action="save-order" data-id="${esc(order.id)}">${icon("check")} ${dt("حفظ التغييرات", "Enregistrer")}</button>`
    });
  }

  function exportOrdersCsv() {
    const orders = orderList();
    const rows = [
      ["order_id", "date", "status", "name", "phone", "city", "address", "payment", "items", "subtotal", "shipping", "discount", "total", "currency", "coupon", "notes"],
