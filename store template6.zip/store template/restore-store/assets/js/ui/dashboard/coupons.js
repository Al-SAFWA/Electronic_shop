import { createCouponsRepo } from "../../data/repositories/coupons.repo.js";
export function createCouponsScreen(ctx) {
  const { R, esc, dt, money, token, toast } = ctx;
  const repo = createCouponsRepo(R.config, token);
  let items = [];
  async function load() { try { items = await repo.list() || []; } catch(e){ items = R.store?.settings?.coupons || []; } }
  async function save(coupon) { await repo.upsert(coupon); R.addAudit(`${dt("كوبون","Coupon")}: save — ${coupon.code}`, R.currentSession?.()?.username); toast(dt("تم حفظ الكوبون","Coupon enregistré"),"good"); await load(); }
  async function remove(code) { await repo.remove(code); R.addAudit(`${dt("كوبون","Coupon")}: delete — ${code}`, R.currentSession?.()?.username); toast(dt("تم حذف الكوبون","Coupon supprimé"),"good"); await load(); }
  function render() {
    return `<div class="dash-view-head"><div><h2>${dt("الكوبونات","Coupons")}</h2><p>restore_coupons</p></div><div class="dash-view-actions"><button class="btn btn-primary" data-repo-add-coupon">${dt("كوبون جديد","Nouveau coupon")}</button></div></div>
    <div class="dash-card"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الكود","Code")}</th><th>${dt("النوع","Type")}</th><th>${dt("القيمة","Valeur")}</th><th>${dt("نشط","Actif")}</th><th></th></tr></thead><tbody>
    ${items.map(c=>`<tr><td><strong>${esc(c.code)}</strong></td><td>${esc(c.type)}</td><td>${c.type==='percent'?esc(c.value)+'%':money(c.value)}</td><td>${c.active!==false?'✓':''}</td><td><button class="btn btn-sm btn-soft" data-repo-delete-coupon="${esc(c.code)}">${dt("حذف","Supprimer")}</button></td></tr>`).join("") || `<tr><td colspan="5">${dt("لا كوبونات","Aucun coupon")}</td></tr>`}
    </tbody></table></div></div>`;
  }
  return { load, render, save, remove, get items(){return items;} };
}
