/* extracted dashboard view */
export function viewBlog(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    return `
      <div class="dash-view-head"><div><h2>${dt("المدونة", "Blog")}</h2><p>${dt("مقالات تساعد العملاء وتقوي SEO.", "Des articles utiles et bons pour le SEO.")}</p></div><div class="dash-view-actions"><button class="btn btn-primary" data-action="add-post">${icon("plus")} ${dt("مقال جديد", "Nouvel article")}</button></div></div>
      <div class="dash-card"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المقال", "Article")}</th><th>${dt("الرابط", "Slug")}</th><th>${dt("التاريخ", "Date")}</th><th>${dt("منشور", "Publié")}</th><th></th></tr></thead><tbody>
        ${(model.blog || []).map((post, index) => `<tr><td><div class="cell-main"><img src="${esc(post.image)}" alt=""><div><strong>${esc(lng(post.title))}</strong><small>${esc(lng(post.excerpt))}</small></div></div></td><td class="handle" style="direction:ltr">${esc(post.slug)}</td><td>${esc(post.date)}</td><td><span class="badge-soft ${post.published !== false ? "green" : ""}">${post.published !== false ? dt("منشور", "Publié") : dt("مسودة", "Brouillon")}</span></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-post" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-post" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
      </tbody></table></div></div>`;
  }

  let pendingPostIndex = null;
  function postEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `post-${Date.now().toString(36)}`, slug: `post-${Date.now().toString(36)}`, title: { ar: "", fr: "" }, excerpt: { ar: "", fr: "" }, body: { ar: "", fr: "" }, image: "assets/img/category-iphone.png", date: new Date().toISOString().slice(0, 10), published: true } : clone(model.blog[index]);
    editBuffer = buffer;
    pendingPostIndex = isNew ? null : index;
    openModal(isNew ? dt("مقال جديد", "Nouvel article") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("الرابط", "Slug")}</label><input data-edit-path="slug" value="${esc(buffer.slug)}" dir="ltr"></div>
        <div class="field"><label>${dt("التاريخ", "Date")}</label><input type="date" data-edit-path="date" value="${esc(buffer.date)}"></div>
        ${editBi(dt("المقتطف", "Extrait"), "excerpt", buffer.excerpt, { type: "textarea", rows: 2 })}
        <div class="span-2">${imageEditor(dt("الصورة", "Image"), "image", buffer.image)}</div>
        ${editBi(dt("المحتوى", "Contenu"), "body", buffer.body, { type: "textarea", rows: 10 })}
        <div class="span-2">${editToggle(dt("نشر المقال", "Publier"), "published", buffer.published !== false)}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-post" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  
  }).call(ctx);
}
