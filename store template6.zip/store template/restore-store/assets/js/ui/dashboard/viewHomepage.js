/* extracted dashboard view */
export function viewHomepage(ctx, ...args) {
  const {R,model,esc,$,$$,dt,lng,money,fmtDate,fmtDateTime,icon,directToggle,editorFooter,editBi,editInput,editToggle,imageEditor,editBufferRef,openModal,closeModal,renderRoute,saveDraftNow,toast,session,orderList,lowStockProducts,statCard,dashLang} = ctx;
  let editBuffer = ctx.editBuffer;
  // delegate to original logic shape via ctx
  return (function(){

    const sections = [...(model.settings.pageSections || [])].sort((a, b) => Number(a.order) - Number(b.order));
    const productSections = [...(model.settings.homeSections || [])].sort((a, b) => Number(a.order) - Number(b.order));
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الصفحة الرئيسية", "Page d’accueil")}</h2><p>${dt("أعد ترتيب الأقسام، أخفِ أي قسم، وعدّل السلايدر والعروض.", "Réorganisez les sections, masquez-en et modifiez le slider.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" data-action="preview">${icon("preview")} ${dt("معاينة", "Aperçu")}</button></div>
      </div>
      <div class="dash-tabs"><button class="active" data-dash-tab="home-sections">${dt("ترتيب الأقسام", "Ordre des sections")}</button><button data-dash-tab="home-hero">${dt("السلايدر", "Slider")}</button><button data-dash-tab="home-products">${dt("أقسام المنتجات", "Sections produits")}</button></div>
      <div class="dash-panel active" data-dash-panel="home-sections">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام الصفحة", "Sections de la page")}</h3><span class="badge-soft">${sections.filter((section) => section.visible !== false).length}/${sections.length}</span></div><div class="dash-card-body"><div class="list-editor">
            ${sections.map((section, index) => `<div class="list-row"><span class="drag">${icon("arrows")}</span><div class="grow"><strong>${esc(PAGE_SECTION_LABELS[section.id]?.[dashLang] || section.id)}</strong><small>${section.id}</small></div><div class="row-actions"><button class="btn btn-sm btn-soft" data-action="page-section-up" data-id="${section.id}" ${index === 0 ? "disabled" : ""}>${icon("up")}</button><button class="btn btn-sm btn-soft" data-action="page-section-down" data-id="${section.id}" ${index === sections.length - 1 ? "disabled" : ""}>${icon("down")}</button><label class="toggle"><input type="checkbox" data-page-section-visible="${section.id}" ${section.visible !== false ? "checked" : ""}><span></span></label></div></div>`).join("")}
          </div><p class="form-note" style="margin-top:10px">${dt("التغييرات تظهر في المعاينة فورًا وتُنشر عند الضغط على نشر.", "Les changements apparaissent dans l’aperçu et sont publiés via Publier.")}</p></div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معاينة الترتيب", "Aperçu de l’ordre")}</h3></div><div class="dash-card-body">
            <div style="border:1px solid var(--border);border-radius:10px;padding:10px;display:grid;gap:5px;background:var(--surface-2)">
              ${sections.filter((section) => section.visible !== false).map((section, index) => `<div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:7px 9px;font-size:9px;display:flex;justify-content:space-between"><span>${index + 1}. ${esc(PAGE_SECTION_LABELS[section.id]?.[dashLang] || section.id)}</span><span style="color:var(--soft-muted)">${section.id}</span></div>`).join("")}
            </div>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="home-hero">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("شرائح السلايدر", "Diapositives")}</h3><button data-action="add-hero">${icon("plus")} ${dt("إضافة شريحة", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="list-editor">${(model.settings.heroSlides || []).map((slide, index) => `<div class="list-row"><span class="image-preview" style="width:44px;height:44px;flex-basis:44px"><img src="${esc(slide.image)}" alt=""></span><div class="grow"><strong>${esc(lng(slide.title))}</strong><small>${esc(slide.href)}</small></div>${directToggle("", `settings.heroSlides.${index}.visible`, slide.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-hero" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-hero" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
          <p class="form-note" style="margin-top:10px">${dt("ضع صورة بخلفية شفافة للحصول على أفضل نتيجة. يمكن استخدام رابط أو رفع صورة.", "Utilisez une image à fond transparent. URL ou téléversement.")}</p>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="home-products">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام المنتجات على الرئيسية", "Sections produits")}</h3></div><div class="dash-card-body">
          <div class="list-editor">${productSections.map((section, index) => `<div class="list-row"><span class="drag">${icon("arrows")}</span><div class="grow"><strong>${esc(lng(section.title))}</strong><small class="handle">${esc(section.collection || "")} · ${esc(section.layout)}</small></div><div class="row-actions"><button class="btn btn-sm btn-soft" data-action="home-section-up" data-id="${section.id}" ${index === 0 ? "disabled" : ""}>${icon("up")}</button><button class="btn btn-sm btn-soft" data-action="home-section-down" data-id="${section.id}" ${index === productSections.length - 1 ? "disabled" : ""}>${icon("down")}</button><label class="toggle"><input type="checkbox" data-home-section-visible="${section.id}" ${section.visible !== false ? "checked" : ""}><span></span></label><button class="btn btn-sm btn-soft" data-action="edit-home-section" data-id="${section.id}">${icon("edit")}</button></div></div>`).join("")}</div>
          <button class="btn btn-soft" style="margin-top:10px" data-action="add-home-section">${icon("plus")} ${dt("إضافة قسم منتجات", "Ajouter une section")}</button>
        </div></article>
      </div>`;
  }

  let pendingHeroIndex = null;
  function heroEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `hero-${Date.now().toString(36)}`, visible: true, title: { ar: "", fr: "" }, subtitle: { ar: "", fr: "" }, cta: { ar: "تسوق الآن", fr: "Découvrir" }, href: "collection.html?handle=all", image: "assets/img/hero-iphone.png", bg: "linear-gradient(135deg,#1f1f2e 0%,#39255b 55%,#ff6400 130%)", dark: true } : clone(model.settings.heroSlides[index]);
    editBuffer = buffer;
    pendingHeroIndex = isNew ? null : index;
    openModal(isNew ? dt("شريحة جديدة", "Nouvelle diapositive") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        ${editBi(dt("العنوان الفرعي", "Sous-titre"), "subtitle", buffer.subtitle, { type: "textarea", rows: 3 })}
        ${editBi(dt("زر الدعوة", "Bouton"), "cta", buffer.cta)}
        ${editInput(dt("رابط الزر", "Lien du bouton"), "href", { value: buffer.href })}
        <div class="field span-2"><label>CSS background</label><input data-edit-path="bg" value="${esc(buffer.bg)}" dir="ltr"></div>
        <div class="field span-2">${imageEditor(dt("صورة الجهاز", "Image appareil"), "image", buffer.image)}</div>
        <div class="span-2">${editToggle(dt("نص داكن على خلفية فاتحة", "Texte foncé sur fond clair"), "dark", buffer.dark === false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-hero-buffer")
    });
  }
  function saveHeroEditor() {
    if (!editBuffer) return;
    if (pendingHeroIndex == null) model.settings.heroSlides.push(editBuffer);
    else model.settings.heroSlides[pendingHeroIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ السلايدر", "Slider enregistré"), "good");
  }

  function homeSectionEditor(id) {
    const index = model.settings.homeSections.findIndex((section) => section.id === id);
    if (index < 0) return;
    const buffer = clone(model.settings.homeSections[index]);
    editBuffer = buffer;
    openModal(lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("المجموعة", "Collection")}</label><select data-edit-path="collection">${model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${collection.handle === buffer.collection ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("")}</select></div>
        <div class="field"><label>${dt("التخطيط", "Disposition")}</label><select data-edit-path="layout">${["plain", "left", "right"].map((layout) => `<option ${buffer.layout === layout ? "selected" : ""}>${layout}</option>`).join("")}</select></div>
        <div class="field span-2">${imageEditor(dt("صورة البانر الجانبي", "Image promo"), "promo", buffer.promo || "")}</div>
        <div class="span-2">${editToggle(dt("إظهار شعلة", "Afficher la flamme"), "flame", Boolean(buffer.flame))}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-home-section" data-id="${id}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function moveInArray(array, index, direction) {
    const target = index + direction;
    if (target < 0 || target >= array.length) return;
    [array[index], array[target]] = [array[target], array[index]];
    array.forEach((item, position) => { item.order = position + 1; });
  
  }).call(ctx);
}
