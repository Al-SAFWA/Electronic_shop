/** Isolated 3D packshot for each catalogue item (files in /public/products). */
const BY_NAME: Record<string, string> = {
  "iPhone 15 Pro Max": "/products/iphone-15-pro-max.png",
  "iPhone 15": "/products/iphone-15.png",
  "iPhone 14 Pro": "/products/iphone-14-pro.png",
  "iPhone 13": "/products/iphone-13.png",
  "iPhone 12 Pro Max": "/products/iphone-12-pro-max.png",
  "iPhone 12": "/products/iphone-12.png",
  "iPhone 11": "/products/iphone-11.png",
  "Galaxy S24 Ultra": "/products/galaxy-s24-ultra.png",
  "Galaxy S23 Ultra": "/products/galaxy-s23-ultra.png",
  "Galaxy S23 FE": "/products/galaxy-s23-fe.png",
  "Galaxy Z Flip5": "/products/galaxy-z-flip5.png",
  "Galaxy A54 5G": "/products/galaxy-a54.png",
  'MacBook Air 13" M2': "/products/macbook-air-m2.png",
  'MacBook Pro 14" M1 Pro': "/products/macbook-pro-14.png",
  'MacBook Air 13" M1': "/products/macbook-air-m1.png",
  "Dell XPS 13 9310": "/products/dell-xps-13.png",
  "ThinkPad X1 Carbon Gen 9": "/products/thinkpad-x1.png",
  "HP EliteBook 840 G8": "/products/hp-elitebook.png",
  "Acer Swift 3": "/products/acer-swift.png",
  'iPad Pro 11" M2': "/products/ipad-pro.png",
  "iPad Air 5th Gen": "/products/ipad-air.png",
  "iPad 9th Gen": "/products/ipad-9.png",
  "Galaxy Tab S8": "/products/galaxy-tab-s8.png",
  "Apple Watch Series 9 45mm": "/products/apple-watch-s9.png",
  "Apple Watch Series 8 41mm": "/products/apple-watch-s8.png",
  "Apple Watch SE 2": "/products/apple-watch-se.png",
  "Galaxy Watch 6 44mm": "/products/galaxy-watch-6.png",
  "AirPods Pro 2": "/products/airpods-pro-2.png",
  "AirPods 3rd Gen": "/products/airpods-3.png",
  "Sony WH-1000XM4": "/products/sony-wh-1000xm4.png",
  "JBL Flip 6": "/products/jbl-flip-6.png",
  "35W Dual USB-C Power Adapter": "/products/charger.png",
  "240W USB-C Charge Cable 2m": "/products/cable.png",
  "Shockproof Clear Case": "/products/case.png",
};

export const CATEGORY_IMAGE: Record<string, string> = {
  iphones: "/products/iphone-15-pro-max.png",
  samsung: "/products/galaxy-s24-ultra.png",
  laptops: "/products/macbook-air-m2.png",
  tablets: "/products/ipad-pro.png",
  watches: "/products/apple-watch-s9.png",
  audio: "/products/airpods-pro-2.png",
  accessories: "/products/charger.png",
};

export function imageFor(name: string) {
  return BY_NAME[name] ?? "/products/iphone-15.png";
}

/** Representative 3D model for each category tile. */
export const CATEGORY_SAMPLE: Record<string, string> = {
  iphones: "iPhone 15 Pro Max",
  samsung: "Galaxy S24 Ultra",
  laptops: 'MacBook Air 13" M2',
  tablets: 'iPad Pro 11" M2',
  watches: "Apple Watch Series 9 45mm",
  audio: "AirPods Pro 2",
  accessories: "35W Dual USB-C Power Adapter",
};
