import { cookies } from "next/headers";
import { LANG_COOKIE, makeI18n, normLang, type Lang } from "./i18n";

export async function getLang(): Promise<Lang> {
  const c = await cookies();
  return normLang(c.get(LANG_COOKIE)?.value);
}

export async function getI18n() {
  return makeI18n(await getLang());
}
