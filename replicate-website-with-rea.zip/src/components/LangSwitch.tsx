"use client";

import { useRouter } from "next/navigation";
import { useI18n } from "./I18nProvider";

export default function LangSwitch({ className = "" }: { className?: string }) {
  const { lang } = useI18n();
  const router = useRouter();
  const next = lang === "ar" ? "fr" : "ar";

  function switchLang() {
    document.cookie = `lang=${next}; path=/; max-age=31536000; samesite=lax`;
    document.documentElement.lang = next;
    document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
    router.refresh();
  }

  return (
    <button
      onClick={switchLang}
      className={`flex items-center gap-1.5 rounded-full border-2 border-line px-3.5 py-2 text-sm font-bold transition hover:border-brand hover:text-brand ${className}`}
      aria-label={lang === "ar" ? "Passer en français" : "التبديل إلى العربية"}
      lang={next}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" />
      </svg>
      {lang === "ar" ? "Français" : "العربية"}
    </button>
  );
}
