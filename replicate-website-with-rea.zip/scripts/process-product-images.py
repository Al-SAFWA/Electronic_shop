#!/usr/bin/env python3
"""Cut generated packshots out of their white (or black) studio backdrop,
square-pad them, and build color variants plus a few accessory stills."""
from __future__ import annotations

from pathlib import Path

from collections import deque

from PIL import Image, ImageDraw, ImageFilter, ImageEnhance

ROOT = Path("public/products")
RAW = ROOT / "raw"
OUT = ROOT
SIZE = 1000


def flood_cut(im: Image.Image, fuzz: int = 28) -> Image.Image:
    """Erase pixels connected to the edges that match the corner backdrop."""
    im = im.convert("RGBA")
    pix = im.load()
    w, h = im.size
    corners = [pix[1, 1][:3], pix[w - 2, 1][:3], pix[1, h - 2][:3], pix[w - 2, h - 2][:3]]
    bg = tuple(sum(c[i] for c in corners) // 4 for i in range(3))

    def near(p) -> bool:
        return abs(p[0] - bg[0]) <= fuzz and abs(p[1] - bg[1]) <= fuzz and abs(p[2] - bg[2]) <= fuzz

    seen = bytearray(w * h)
    q: deque[tuple[int, int]] = deque()
    for x in range(0, w, 4):
        q.append((x, 0))
        q.append((x, h - 1))
    for y in range(0, h, 4):
        q.append((0, y))
        q.append((w - 1, y))

    while q:
        x, y = q.popleft()
        if x < 0 or y < 0 or x >= w or y >= h:
            continue
        i = y * w + x
        if seen[i]:
            continue
        seen[i] = 1
        p = pix[x, y]
        if not near(p):
            continue
        pix[x, y] = (p[0], p[1], p[2], 0)
        q.append((x + 1, y))
        q.append((x - 1, y))
        q.append((x, y + 1))
        q.append((x, y - 1))
    return im


def cutout(src: Path, dst: Path, fuzz: int = 28, dark: bool = False) -> None:
    del dark  # backdrop is sampled from the corners
    im = Image.open(src)
    im = flood_cut(im, fuzz=fuzz)
    im = tighten_alpha(im)
    im = pad_square(im, SIZE)
    dst.parent.mkdir(parents=True, exist_ok=True)
    im.save(dst, "PNG", optimize=True)


def tighten_alpha(im: Image.Image) -> Image.Image:
    r, g, b, a = im.split()
    # Slightly erode the matte so white halos disappear
    a = a.filter(ImageFilter.MinFilter(3))
    im = Image.merge("RGBA", (r, g, b, a))
    return im


def pad_square(im: Image.Image, size: int, pad: float = 0.10) -> Image.Image:
    im = im.convert("RGBA")
    # Trim fully-transparent borders
    bbox = im.getbbox()
    if bbox:
        im = im.crop(bbox)
    w, h = im.size
    inner = int(size * (1 - 2 * pad))
    scale = min(inner / w, inner / h)
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.paste(im, ((size - nw) // 2, (size - nh) // 2), im)
    return canvas


def hex_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def tint(src: Path, dst: Path, color: str, amount: float = 0.28, brightness: float = 1.0) -> None:
    im = Image.open(src).convert("RGBA")
    if brightness != 1.0:
        rgb = ImageEnhance.Brightness(im.convert("RGB")).enhance(brightness)
        a = im.split()[-1]
        im = rgb.convert("RGBA")
        im.putalpha(a)
    overlay = Image.new("RGB", im.size, hex_rgb(color))
    base = im.convert("RGB")
    blended = Image.blend(base, overlay, amount)
    out = blended.convert("RGBA")
    out.putalpha(im.split()[-1])
    dst.parent.mkdir(parents=True, exist_ok=True)
    out.save(dst, "PNG", optimize=True)


def copy(src: Path, dst: Path) -> None:
    Image.open(src).convert("RGBA").save(dst, "PNG", optimize=True)


# --- hand-drawn isolated accessories (simple 3D packshots, transparent bg) ---

def rounded_rect(draw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def draw_charger(path: Path) -> None:
    im = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # body
    x0, y0, x1, y1 = 310, 250, 690, 720
    rounded_rect(d, (x0 + 18, y0 + 18, x1 + 18, y1 + 18), 48, (210, 210, 216, 40))  # soft contact shadow
    rounded_rect(d, (x0, y0, x1, y1), 48, (248, 248, 250, 255), (230, 230, 235), 2)
    # top highlight
    d.rounded_rectangle((x0 + 20, y0 + 18, x1 - 20, y0 + 90), 20, fill=(255, 255, 255, 180))
    # two USB-C ports
    for cx in (430, 570):
        d.rounded_rectangle((cx - 28, 430, cx + 28, 458), 10, fill=(40, 42, 48, 255))
        d.rounded_rectangle((cx - 18, 436, cx + 18, 452), 6, fill=(20, 20, 24, 255))
    # pins
    d.rounded_rectangle((430, 720, 455, 790), 4, fill=(196, 196, 200, 255))
    d.rounded_rectangle((545, 720, 570, 790), 4, fill=(196, 196, 200, 255))
    im = im.filter(ImageFilter.SMOOTH)
    pad_square(im, SIZE, 0.08).save(path, "PNG", optimize=True)


def draw_cable(path: Path) -> None:
    im = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # coiled cable
    d.arc((250, 280, 750, 780), 200, 510, fill=(28, 28, 32, 255), width=22)
    d.arc((300, 330, 700, 730), 20, 250, fill=(28, 28, 32, 255), width=22)
    # connectors
    d.rounded_rectangle((180, 430, 280, 500), 12, fill=(188, 192, 196, 255))
    d.rounded_rectangle((155, 448, 190, 482), 6, fill=(40, 40, 44, 255))
    d.rounded_rectangle((720, 510, 820, 580), 12, fill=(188, 192, 196, 255))
    d.rounded_rectangle((810, 528, 845, 562), 6, fill=(40, 40, 44, 255))
    im = im.filter(ImageFilter.SMOOTH)
    pad_square(im, SIZE, 0.08).save(path, "PNG", optimize=True)


def draw_case(path: Path) -> None:
    im = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # translucent body
    d.rounded_rectangle((320, 140, 680, 860), 90, fill=(220, 230, 235, 70), outline=(180, 190, 198, 180), width=6)
    # camera cutout
    d.rounded_rectangle((360, 190, 520, 350), 48, fill=(30, 32, 36, 40), outline=(160, 168, 176, 160), width=4)
    d.ellipse((390, 220, 450, 280), outline=(160, 168, 176, 160), width=3)
    d.ellipse((430, 260, 490, 320), outline=(160, 168, 176, 160), width=3)
    # buttons
    d.rounded_rectangle((312, 320, 322, 400), 4, fill=(190, 198, 204, 200))
    d.rounded_rectangle((678, 360, 688, 430), 4, fill=(190, 198, 204, 200))
    pad_square(im, SIZE, 0.06).save(path, "PNG", optimize=True)


def draw_speaker(path: Path) -> None:
    """Teal portable Bluetooth speaker, isolated, 3/4 view-ish."""
    im = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # body capsule
    d.rounded_rectangle((180, 360, 820, 680), 150, fill=(18, 140, 138, 255))
    d.rounded_rectangle((200, 380, 800, 660), 140, fill=(28, 154, 152, 255))
    # grille dots
    for i in range(14):
        for j in range(4):
            x = 280 + i * 32
            y = 450 + j * 36
            d.ellipse((x, y, x + 10, y + 10), fill=(10, 90, 88, 200))
    # fabric stripe
    d.rounded_rectangle((250, 420, 750, 620), 80, fill=(12, 110, 108, 80))
    # LED
    d.rounded_rectangle((460, 400, 540, 414), 6, fill=(198, 244, 50, 255))
    # end cap highlight
    d.ellipse((175, 400, 250, 640), fill=(40, 170, 166, 90))
    im = im.filter(ImageFilter.SMOOTH)
    pad_square(im, SIZE, 0.08).save(path, "PNG", optimize=True)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    # Generated packshots (white studio)
    specs = {
        "iphone-15-pro-max.png": ("iphone-15-pro-max.png", 32),
        "iphone-15.png": ("iphone-15-blue.png", 32),
        "iphone-13.png": ("iphone-13-midnight.png", 32),
        "galaxy-s24-ultra.png": ("galaxy-s24-ultra.png", 32),
        "galaxy-z-flip5.png": ("galaxy-z-flip5.png", 34),
        "macbook-air-m2.png": ("macbook-air-m2.png", 30),
        "macbook-pro-14.png": ("macbook-pro-14.png", 30),
        "ipad-pro.png": ("ipad-pro.png", 32),
        "apple-watch-s9.png": ("apple-watch-s9.png", 30),
        "airpods-pro-2.png": ("airpods-pro-2.png", 14),  # white product — low fuzz
    }
    for out_name, (raw_name, fuzz) in specs.items():
        src = RAW / raw_name
        dst = OUT / out_name
        print("cut", out_name)
        cutout(src, dst, fuzz=fuzz)

    hp = Path("/tmp/extra/e1.png")
    if hp.exists():
        print("cut sony headphones")
        cutout(hp, OUT / "sony-wh-1000xm4.png", fuzz=40)

    # Color / brightness variants of the isolated packshots
    variants = [
        # (src, dest, color, amount, brightness)
        ("iphone-15-pro-max.png", "iphone-14-pro.png", "#5b4b6e", 0.34, 0.92),
        ("iphone-13.png", "iphone-12-pro-max.png", "#2f4a5e", 0.30, 1.05),
        ("iphone-13.png", "iphone-12.png", "#8fbfa4", 0.38, 1.12),
        ("iphone-13.png", "iphone-11.png", "#1a1a1c", 0.22, 0.90),
        ("galaxy-s24-ultra.png", "galaxy-s23-ultra.png", "#1a1c20", 0.28, 0.88),
        ("galaxy-s24-ultra.png", "galaxy-s23-fe.png", "#9ed8b6", 0.36, 1.10),
        ("galaxy-s24-ultra.png", "galaxy-a54.png", "#c5dc6a", 0.40, 1.12),
        ("macbook-air-m2.png", "macbook-air-m1.png", "#d5d8dc", 0.42, 1.25),
        ("macbook-air-m2.png", "dell-xps-13.png", "#c8ccd1", 0.38, 1.18),
        ("macbook-pro-14.png", "thinkpad-x1.png", "#1c1e22", 0.40, 0.78),
        ("macbook-air-m1.png", "hp-elitebook.png", "#b9bec4", 0.22, 1.05),
        ("macbook-air-m1.png", "acer-swift.png", "#cfd3d8", 0.18, 1.08),
        ("ipad-pro.png", "ipad-air.png", "#8fb4d4", 0.36, 1.08),
        ("ipad-pro.png", "ipad-9.png", "#d8dadd", 0.40, 1.20),
        ("ipad-pro.png", "galaxy-tab-s8.png", "#3a3c42", 0.32, 0.86),
        ("apple-watch-s9.png", "apple-watch-s8.png", "#e6dccb", 0.40, 1.18),
        ("apple-watch-s9.png", "apple-watch-se.png", "#d0d2d6", 0.38, 1.22),
        ("apple-watch-s9.png", "galaxy-watch-6.png", "#2a2c32", 0.34, 0.82),
    ]
    # airpods 3 shares the Pro packshot (same white buds family)
    copy(OUT / "airpods-pro-2.png", OUT / "airpods-3.png")

    for src, dest, color, amt, br in variants:
        print("tint", dest)
        tint(OUT / src, OUT / dest, color, amt, br)

    print("draw accessories")
    draw_charger(OUT / "charger.png")
    draw_cable(OUT / "cable.png")
    draw_case(OUT / "case.png")
    draw_speaker(OUT / "jbl-flip-6.png")

    print("done")
    for p in sorted(OUT.glob("*.png")):
        print(f"  {p.name:28} {p.stat().st_size // 1024:5}k")


if __name__ == "__main__":
    main()
