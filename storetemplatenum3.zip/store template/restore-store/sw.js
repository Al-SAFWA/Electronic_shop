/* Restore storefront service worker: fast repeat visits without stale prices. */
const CACHE = "restore-shell-v7";
const SHELL = [
  "./",
  "index.html",
  "collection.html",
  "product.html",
  "checkout.html",
  "wishlist.html",
  "account.html",
  "blog.html",
  "blog-post.html",
  "page.html",
  "manifest.webmanifest",
  "assets/css/styles.css",
  "assets/css/restore.css",
  "assets/js/config.js",
  "assets/js/state.js",
  "assets/js/app.js",
  "assets/js/data.js",
  "assets/js/theme-init.js",
  "assets/js/pixels.js",
  "assets/img/favicon.svg",
  "assets/img/restore-logo.svg",
  "assets/img/restore-logo-white.svg",
  "assets/img/pwa-192.png",
  "assets/img/pwa-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE)
      .then((cache) => cache.addAll(SHELL))
      .then(() => self.skipWaiting())
      .catch((error) => console.warn("Restore SW pre-cache:", error))
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

async function networkFirst(request) {
  const cache = await caches.open(CACHE);
  try {
    const response = await fetch(request);
    if (response.ok) cache.put(request, response.clone());
    return response;
  } catch {
    return (await cache.match(request)) || (await cache.match("index.html"));
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(CACHE);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((response) => {
      if (response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => null);
  return cached || (await network) || Response.error();
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.endsWith("/dashboard.html")) return;
  if (request.mode === "navigate") {
    event.respondWith(networkFirst(request));
    return;
  }
  if (/\.(?:css|js|webmanifest)$/.test(url.pathname)) {
    event.respondWith(networkFirst(request));
    return;
  }
  if (url.pathname.includes("/assets/")) {
    event.respondWith(staleWhileRevalidate(request));
  }
});
