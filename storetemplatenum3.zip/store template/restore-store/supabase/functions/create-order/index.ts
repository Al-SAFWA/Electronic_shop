import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type RateState = { count: number; resetAt: number };
const rateMap = new Map<string, RateState>();
const WINDOW_MS = 60_000;
const MAX_REQ = 12;

function allowedOrigins() {
  return String(Deno.env.get("ALLOWED_ORIGIN") || Deno.env.get("SITE_URL") || "")
    .split(",").map((s) => s.trim().replace(/\/$/, "")).filter(Boolean);
}
function corsHeaders(origin: string | null) {
  const allow = allowedOrigins();
  const ok = !origin || allow.length === 0 || allow.includes(origin.replace(/\/$/, "")) || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin);
  return {
    "Access-Control-Allow-Origin": ok && origin ? origin : (allow[0] || "*"),
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  } as Record<string, string>;
}
function json(body: unknown, status = 200, origin: string | null = null) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders(origin), "Content-Type": "application/json" } });
}
function clientIp(req: Request) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("cf-connecting-ip") || "unknown";
}
function rateLimit(key: string) {
  const now = Date.now();
  const cur = rateMap.get(key);
  if (!cur || cur.resetAt <= now) { rateMap.set(key, { count: 1, resetAt: now + WINDOW_MS }); return true; }
  if (cur.count >= MAX_REQ) return false;
  cur.count += 1;
  return true;
}
async function verifyTurnstile(token: string | undefined, ip: string) {
  const secret = Deno.env.get("TURNSTILE_SECRET_KEY");
  if (!secret) return true; // optional; configure in production for stronger abuse protection
  if (!token) return false;
  const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ secret, response: token, remoteip: ip }),
  });
  const data = await res.json().catch(() => ({}));
  return Boolean(data?.success);
}

serve(async (req) => {
  const origin = req.headers.get("origin");
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders(origin) });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405, origin);

  const ip = clientIp(req);
  if (!rateLimit(`${ip}:${origin || ""}`)) return json({ ok: false, error: "Too many requests. Please try again shortly." }, 429, origin);

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );
    const body = await req.json().catch(() => ({}));
    if (!(await verifyTurnstile(body?.turnstileToken, ip))) {
      return json({ ok: false, error: "Security check failed" }, 403, origin);
    }
    const draft = body?.order && typeof body.order === "object" ? body.order : body;
    const itemsIn = Array.isArray(draft?.items) ? draft.items : [];
    if (!itemsIn.length || itemsIn.length > 50) return json({ ok: false, error: "Order items are required" }, 400, origin);
    const name = String(draft?.customer?.name || "").trim();
    const phone = String(draft?.customer?.phone || "").replace(/\D/g, "");
    if (!name || phone.length < 8) return json({ ok: false, error: "Customer details are required" }, 400, origin);

    const { data, error } = await supabase.rpc("restore_create_order", { p_order: draft });
    if (error) return json({ ok: false, error: String(error.message || error) }, 400, origin);

    return json({ ok: true, order: data }, 200, origin);
  } catch (e) {
    return json({ ok: false, error: String((e as any)?.message || e) }, 400, origin);
  }
});
