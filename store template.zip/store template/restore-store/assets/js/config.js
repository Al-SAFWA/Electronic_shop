/* Restore storefront configuration.
   Local demo mode works with no configuration.
   To enable Supabase, fill supabaseUrl and supabaseAnonKey (the anon key is public).
   On Vercel, these values can be generated from environment variables by
   `node scripts/build-config.mjs` — see README.md. */
window.RESTORE_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  mode: "auto",                 // "auto" | "local" | "supabase"
  stateTable: "restore_state",
  ordersTable: "restore_orders",
  abandonedTable: "restore_abandoned",
  auditTable: "restore_audit",
  mediaBucket: "restore-media",
  pollMs: 5000,
  demoOwner: {
    username: "owner",
    password: "Restore@2026"
  }
};
