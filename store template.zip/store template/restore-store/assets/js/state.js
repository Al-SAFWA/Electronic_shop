/* ==========================================================================
   Restore — shared store state, local/Supabase sync, language and utilities
   ========================================================================== */
(() => {
  "use strict";

  const RAW = window.STORE;
  if (!RAW) return;

  const CFG = Object.assign({
    supabaseUrl: "",
    supabaseAnonKey: "",
    mode: "auto",
    stateTable: "restore_state",
    ordersTable: "restore_orders",
    abandonedTable: "restore_abandoned",
    auditTable: "restore_audit",
    customersTable: "restore_customers",
    reviewsTable: "restore_reviews",
    mediaBucket: "restore-media",
    pollMs: 5000,
    demoOwner: { username: "owner", password: "Restore@2026" }
  }, window.RESTORE_CONFIG || {});

  const REMOTE = CFG.mode !== "local" && Boolean(CFG.supabaseUrl && CFG.supabaseAnonKey);
  const LS_STATE = "restore_state_v1";
  const LS_DRAFT = "restore_draft_v1";
  const LS_MANAGERS = "restore_managers_v1";
  const LS_ORDERS = "restore_orders_v1";
  const LS_ABANDONED = "restore_abandoned_v1";
  const LS_AUDIT = "restore_audit_v1";
  const LS_SESSION = "restore_session_v1";
  const LS_CUSTOMER = "restore_customer_v1";
  const LS_CUSTOMERS = "restore_customers_v1";
  const LS_REVIEWS = "restore_reviews_v1";
  const LS_LANG = "restore_lang_v1";
  const LS_THEME = "restore_theme_v1";
  const SYNC_CHANNEL = "restore_sync_v1";
  const CURRENCY_RATE = 10.6;
  const SALT = "restore-salt:";

  const clone = (v) => JSON.parse(JSON.stringify(v));
  const nowISO = () => new Date().toISOString();
  const roundMRU = (n) => Math.max(0, Math.round((Number(n) || 0) * CURRENCY_RATE / 5) * 5);
  const uid = (prefix = "id") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }
  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.warn("Restore: storage write failed", err);
      return false;
    }
  }
  function isPlainObject(v) {
    return v && typeof v === "object" && !Array.isArray(v);
  }
  function merge(base, override) {
    if (Array.isArray(override)) return clone(override);
    if (!isPlainObject(override)) return override === undefined ? base : override;
    const out = isPlainObject(base) ? clone(base) : {};
    for (const [key, value] of Object.entries(override)) out[key] = merge(base?.[key], value);
    return out;
  }

  const txt = (ar, fr) => ({ ar, fr });
  const name = (ar, fr) => ({ ar, fr });

  /* ------------------------------------------------------------------------
     Default content
     ------------------------------------------------------------------------ */
  const TYPE_DESCRIPTIONS = {
    Smartphone: txt(
      "هاتف مجدد بالكامل، تم فحصه وتنظيفه واختباره من طرف خبراء ريستور. يعمل بكفاءة عالية ويأتي بضمان 12 شهرًا.",
      "Téléphone entièrement reconditionné, inspecté, nettoyé et testé par les experts Restore. Il fonctionne parfaitement et bénéficie d’une garantie de 12 mois."
    ),
    Laptop: txt(
      "حاسوب محمول مجدد تم اختباره مكونًا بمكون. يصلح للعمل والدراسة والاستخدام اليومي، مع ضمان 12 شهرًا.",
      "Ordinateur portable reconditionné, testé composant par composant. Idéal pour le travail, les études et l’usage quotidien, avec 12 mois de garantie."
    ),
    Macbook: txt(
      "MacBook مجدد مع macOS مثبت وجاهز للاستخدام. تم فحص البطارية ولوحة المفاتيح والمنافذ بواسطة خبراء ريستور.",
      "MacBook reconditionné avec macOS installé et prêt à l’emploi. Batterie, clavier et ports vérifiés par les experts Restore."
    ),
    Tablets: txt(
      "جهاز لوحي مجدد تم فحصه بالكامل، مناسب للقراءة والعمل والترفيه، ويأتي بضمان 12 شهرًا.",
      "Tablette reconditionnée entièrement vérifiée, idéale pour lire, travailler et se divertir, avec 12 mois de garantie."
    ),
    Playstation: txt(
      "جهاز ألعاب مجدد تم اختباره وتنظيفه، ويأتي مع ملحقاته الأساسية وضمان 12 شهرًا.",
      "Console de jeu reconditionnée, testée et nettoyée, livrée avec ses accessoires essentiels et 12 mois de garantie."
    ),
    "Apple Watch": txt(
      "ساعة Apple مجددة تم فحص البطارية والشاشة والحساسات، وتأتي بضمان 12 شهرًا.",
      "Apple Watch reconditionnée : batterie, écran et capteurs vérifiés, avec 12 mois de garantie."
    ),
    Accessories: txt(
      "ملحق أصلي مجدد أو جديد، تم فحصه لضمان التوافق والجودة.",
      "Accessoire d’origine reconditionné ou neuf, contrôlé pour garantir compatibilité et qualité."
    )
  };

  const DEFAULT_PAGES = [
    ["about-us", "من نحن", "À propos", "ريستور متجر موريتاني متخصص في الإلكترونيات المجددة. نشتري الأجهزة المستعملة، نفحصها ونعيد تأهيلها ثم نبيعها بأسعار عادلة مع ضمان واضح.\nنعمل من نواكشوط ونوصل إلى جميع ولايات موريتانيا.\nهدفنا أن يحصل كل شخص على تقنية موثوقة بدون أن يدفع ثمن جهاز جديد.", "Restore est une boutique mauritanienne spécialisée dans l’électronique reconditionnée. Nous rachetons, contrôlons et remettons en état les appareils avant de les revendre à un prix juste avec une garantie claire.\nNous travaillons depuis Nouakchott et livrons dans toutes les wilayas de Mauritanie.\nNotre objectif : rendre la technologie fiable accessible sans payer le prix du neuf."],
    ["help", "مركز المساعدة والأسئلة الشائعة", "Centre d’aide et FAQ", "تحتاج مساعدة؟ فريق ريستور متاح من الأحد إلى الخميس، من 9:00 إلى 19:00.\nراسلنا على واتساب أو اتصل على الرقم المؤقت +222 46 00 00 00.\nيمكنك أيضًا زيارة صفحة تتبع الطلب أو تقديم طلب ضمان.", "Besoin d’aide ? L’équipe Restore est disponible du dimanche au jeudi, de 9h00 à 19h00.\nÉcrivez-nous sur WhatsApp ou appelez le numéro temporaire +222 46 00 00 00.\nVous pouvez aussi suivre une commande ou ouvrir une demande de garantie."],
    ["contact", "اتصل بنا", "Contact", "العنوان: نواكشوط، موريتانيا\nواتساب: +222 46 00 00 00\nالبريد: hello@restore.mr\nساعات العمل: 9:00 صباحًا إلى 19:00 مساءً", "Adresse : Nouakchott, Mauritanie\nWhatsApp : +222 46 00 00 00\nE-mail : hello@restore.mr\nHoraires : 9h00 à 19h00"],
    ["terms", "الشروط والأحكام", "Conditions générales", "باستخدامك موقع ريستور فإنك توافق على شروط البيع هذه. الأسعار معروضة بالأوقية الجديدة وتشمل الضريبة حيث تنطبق.\nيتم تأكيد كل طلب عبر واتساب قبل الشحن. تحتفظ ريستور بحق إلغاء أي طلب إذا لم يتوفر المنتج أو إذا كانت المعلومات غير صحيحة.\nالصور توضيحية وقد يختلف لون الجهاز قليلًا.", "En utilisant le site Restore, vous acceptez les présentes conditions de vente. Les prix sont affichés en nouvelle ouguiya et incluent les taxes applicables.\nChaque commande est confirmée via WhatsApp avant expédition. Restore peut annuler une commande en cas de rupture de stock ou d’informations erronées.\nLes photos sont indicatives ; la teinte de l’appareil peut légèrement varier."],
    ["legal", "السياسة القانونية", "Mentions légales", "ريستور اسم تجاري لمتجر إلكترونيات مجدد في موريتانيا. جميع العلامات التجارية المذكورة مملوكة لأصحابها.\nمحتوى هذا الموقع وصوره وبياناته قابلة للتعديل من لوحة التحكم. يجب مراجعة النصوص القانونية مع مستشار مختص قبل الإطلاق التجاري.", "Restore est une enseigne d’électronique reconditionnée en Mauritanie. Toutes les marques citées appartiennent à leurs propriétaires.\nLe contenu, les images et les données du site peuvent être modifiés depuis le tableau de bord. Faites réviser les textes juridiques par un professionnel avant un lancement commercial."],
    ["privacy", "سياسة الخصوصية", "Politique de confidentialité", "نجمع فقط المعلومات اللازمة لمعالجة طلبك: الاسم، رقم الهاتف، المدينة والعنوان.\nتُرسل بيانات الطلب إلى واتساب المتجر. لا نبيع بياناتك لأي طرف ثالث.\nيمكنك طلب حذف بياناتك بمراسلتنا على hello@restore.mr.", "Nous collectons uniquement les informations nécessaires au traitement de votre commande : nom, téléphone, ville et adresse.\nLes données de commande sont envoyées au WhatsApp de la boutique. Nous ne vendons pas vos données à des tiers.\nVous pouvez demander leur suppression en écrivant à hello@restore.mr."],
    ["track-order", "تتبع طلبك", "Suivre votre commande", "بعد تأكيد الطلب عبر واتساب سنرسل لك رقم التتبع ورابط شركة الشحن.\nإذا لم يصلك أي تحديث خلال 24 ساعة، راسلنا على واتساب مع رقم الطلب.", "Après confirmation de la commande sur WhatsApp, nous vous envoyons le numéro de suivi et le lien du transporteur.\nSi vous n’avez aucune nouvelle sous 24 heures, écrivez-nous sur WhatsApp avec votre numéro de commande."],
    ["raise-claim", "تقديم طلب ضمان", "Ouvrir une demande de garantie", "كل جهاز مشمول بضمان 12 شهرًا يغطي عيوب التصنيع أو الأعطال غير الناتجة عن سوء الاستخدام.\nأرسل رقم الطلب، وصف العطل، وصورة أو فيديو قصير عبر واتساب.", "Chaque appareil bénéficie d’une garantie de 12 mois couvrant les défauts de fabrication ou les pannes non liées à un mauvais usage.\nEnvoyez le numéro de commande, une description du problème et une courte photo ou vidéo via WhatsApp."],
    ["track-claim", "متابعة طلب الضمان", "Suivi de garantie", "بعد فتح طلب الضمان ستحصل على رقم متابعة. مدة المعالجة المعتادة من 3 إلى 7 أيام عمل.\nراسل الدعم على واتساب إذا احتجت تحديثًا.", "Après l’ouverture d’une demande de garantie, vous recevez un numéro de suivi. Le délai habituel est de 3 à 7 jours ouvrés.\nContactez le support sur WhatsApp pour toute mise à jour."],
    ["blog", "مدونة ريستور", "Le blog Restore", "نصائح لاختيار هاتف مجدد، مقارنات بين الأجهزة، وطرق العناية بالبطارية.\nاقرأ أحدث المقالات من لوحة التحكم أو من قسم المدونة.", "Conseils pour choisir un téléphone reconditionné, comparatifs et astuces pour préserver la batterie.\nRetrouvez les derniers articles dans la section blog."],
    ["become-a-seller", "كن بائعًا معنا", "Devenir vendeur", "هل لديك أجهزة إلكترونية تريد بيعها؟ نشتري الهواتف والحواسيب والأجهزة اللوحية بعد فحصها.\nراسلنا على واتساب مع نوع الجهاز وحالته وصور له.", "Vous avez des appareils à revendre ? Nous rachetons téléphones, ordinateurs et tablettes après contrôle.\nContactez-nous sur WhatsApp avec le modèle, l’état et quelques photos."],
    ["for-businesses", "حلول للشركات", "Solutions entreprises", "نوفر أجهزة مجددة للشركات والمدارس والمنظمات بأسعار خاصة وضمان موحد.\nاطلب عرض سعر لكمية من 10 أجهزة أو أكثر.", "Nous fournissons des appareils reconditionnés aux entreprises, écoles et organisations à tarifs préférentiels avec une garantie unique.\nDemandez un devis pour 10 appareils ou plus."],
    ["renewed", "ما معنى مجدد من ريستور؟", "Que signifie reconditionné chez Restore ?", "الجهاز المجدد هو جهاز مستعمل تم فحصه وتنظيفه وإصلاح ما يلزم فيه ليعمل كجهاز جديد.\nنفحص الشاشة، البطارية، الكاميرا، الصوت، المنافذ والاتصال، ثم نمسح البيانات ونثبت النظام.\nكل جهاز يأتي بضمان 12 شهرًا، توصيل مجاني داخل نواكشوط، وإمكانية الإرجاع خلال 10 أيام.", "Un appareil reconditionné est un appareil d’occasion contrôlé, nettoyé et réparé si nécessaire pour fonctionner comme neuf.\nNous vérifions l’écran, la batterie, les caméras, le son, les ports et la connectivité, puis nous effaçons les données et installons le système.\nChaque appareil est livré avec 12 mois de garantie, la livraison gratuite à Nouakchott et un retour possible sous 10 jours."],
    ["shipping", "الشحن والتوصيل", "Livraison", "التوصيل مجاني داخل نواكشوط. إلى المدن الأخرى تُضاف رسوم حسب الولاية وتظهر عند إتمام الطلب.\nالطلبات المؤكدة قبل الساعة 16:00 تُجهز عادة في نفس اليوم، والتوصيل داخل نواكشوط من 1 إلى 2 يوم عمل.", "La livraison est gratuite à Nouakchott. Pour les autres villes, des frais selon la wilaya sont ajoutés et affichés au moment de la commande.\nLes commandes confirmées avant 16h00 sont généralement préparées le jour même ; la livraison à Nouakchott prend 1 à 2 jours ouvrés."],
    ["returns", "الإرجاع والضمان", "Retours et garantie", "لديك 10 أيام لاختبار الجهاز وإرجاعه إذا لم يعجبك، بشرط أن يكون في حالته الأصلية.\nالضمان 12 شهرًا يغطي الأعطال التقنية، ولا يغطي الكسر أو دخول الماء أو سوء الاستخدام.\nلبدء الإرجاع راسلنا على واتساب مع رقم الطلب.", "Vous disposez de 10 jours pour tester l’appareil et le retourner s’il ne vous convient pas, à condition qu’il soit dans son état d’origine.\nLa garantie de 12 mois couvre les pannes techniques, hors casse, dégâts d’eau ou mauvais usage.\nPour un retour, contactez-nous sur WhatsApp avec votre numéro de commande."]
  ].map(([slug, ar, fr, bodyAr, bodyFr]) => ({
    slug, title: name(ar, fr), body: txt(bodyAr, bodyFr), visible: true, seoTitle: name(ar, fr)
  }));

  const DEFAULT_FAQS = [
    { id: "faq-1", q: txt("هل الأجهزة جديدة أم مستعملة؟", "Les appareils sont-ils neufs ou d’occasion ?"), a: txt("الأجهزة مجددة: مستعملة، لكنها مفحوصة ومصلحة ومعاد تأهيلها لتكون جاهزة للاستخدام.", "Les appareils sont reconditionnés : d’occasion, mais contrôlés, réparés et remis en état pour être prêts à l’emploi.") },
    { id: "faq-2", q: txt("ما مدة الضمان؟", "Quelle est la durée de la garantie ?"), a: txt("كل جهاز يأتي بضمان 12 شهرًا يغطي الأعطال التقنية غير الناتجة عن سوء الاستخدام.", "Chaque appareil bénéficie de 12 mois de garantie couvrant les pannes techniques hors mauvais usage.") },
    { id: "faq-3", q: txt("هل يمكنني الإرجاع؟", "Puis-je retourner l’appareil ?"), a: txt("نعم، لديك 10 أيام لإرجاع الجهاز في حالته الأصلية إذا لم يعجبك.", "Oui, vous avez 10 jours pour retourner l’appareil dans son état d’origine s’il ne vous convient pas.") },
    { id: "faq-4", q: txt("هل التوصيل مجاني؟", "La livraison est-elle gratuite ?"), a: txt("التوصيل مجاني داخل نواكشوط. المدن الأخرى لها رسوم تظهر عند إتمام الطلب.", "La livraison est gratuite à Nouakchott. Les autres villes ont des frais affichés lors de la commande.") },
    { id: "faq-5", q: txt("كيف أدفع؟", "Comment payer ?"), a: txt("يمكنك الدفع عبر بنكيلي، مصرفي، سداد، كليك أو نقدًا عند الاستلام. الدفع عبر بنكيلي يمنحك خصمًا 10%.", "Vous pouvez payer via Bankily, Masrvi, Sedad, Click ou en espèces à la livraison. Le paiement Bankily offre 10 % de réduction.") },
    { id: "faq-6", q: txt("هل البطارية أصلية؟", "La batterie est-elle d’origine ?"), a: txt("نفحص صحة البطارية ونعرض النسبة على صفحة المنتج. البطاريات المستبدلة تكون معتمدة ومضمونة.", "Nous contrôlons la santé de la batterie et affichons le pourcentage sur la fiche produit. Les batteries remplacées sont certifiées et garanties.") }
  ];

  const DEFAULT_HOME_REVIEWS = [
    { id: "r1", name: "أحمد ولد محمد", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("جهاز نظيف وخدمة سريعة", "Appareil impeccable et service rapide"), body: txt("وصلني الآيفون في حالة ممتازة، البطارية 96% والدفع عبر بنكيلي كان سهلًا.", "J’ai reçu l’iPhone en excellent état, batterie à 96 %, et le paiement Bankily était simple."), color: "#2e7d6f" },
    { id: "r2", name: "مريم بنت أحمد", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("أفضل تجربة شراء", "Ma meilleure expérience d’achat"), body: txt("طلبت ماك بوك للدراسة، وصل بسرعة ومع macOS مثبت. أنصح به بشدة.", "J’ai commandé un MacBook pour mes études, livré rapidement avec macOS installé. Je recommande."), color: "#6c5ce7" },
    { id: "r3", name: "الشيخ ولد سيدي", city: txt("نواذيبو", "Nouadhibou"), rating: 4, title: txt("قيمة ممتازة", "Excellent rapport qualité-prix"), body: txt("اللابتوب يعمل بشكل جيد جدًا، والتوصيل إلى نواذيبو أخذ يومين.", "Le laptop fonctionne très bien, la livraison à Nouadhibou a pris deux jours."), color: "#b06ab3" },
    { id: "r4", name: "فاطمة بنت عبد الله", city: txt("كيفة", "Kiffa"), rating: 5, title: txt("ثقة وشفافية", "Confiance et transparence"), body: txt("أعجبني أنهم يظهرون نسبة البطارية والحالة قبل الشراء. الجهاز مطابق للوصف.", "J’aime qu’ils affichent la santé de la batterie et l’état avant l’achat. L’appareil correspond à la description."), color: "#e17055" },
    { id: "r5", name: "محمد الأمين", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("خدمة واتساب رائعة", "Service WhatsApp au top"), body: txt("أجابوني على كل الأسئلة عبر واتساب وأرسلوا لي صورًا إضافية للجهاز.", "Ils ont répondu à toutes mes questions sur WhatsApp et m’ont envoyé des photos supplémentaires."), color: "#1e6fd9" },
    { id: "r6", name: "عائشة بنت بابا", city: txt("روصو", "Rosso"), rating: 4, title: txt("سأشتري مرة أخرى", "Je rachèterai"), body: txt("الساعة وصلت بحالة جيدة، فقط التغليف كان بسيطًا. الخدمة تستحق التجربة.", "La montre est arrivée en bon état, l’emballage était simple. Le service mérite le détour."), color: "#2d3436" },
    { id: "r7", name: "سيدي محمد", city: txt("أطار", "Atar"), rating: 5, title: txt("جهاز موثوق", "Appareil fiable"), body: txt("حاسوب Dell مجدد يعمل بسرعة، والضمان أعطاني راحة البال.", "Le Dell reconditionné est rapide, et la garantie me rassure."), color: "#00b894" },
    { id: "r8", name: "خديجة بنت المختار", city: txt("نواكشوط", "Nouakchott"), rating: 5, title: txt("أنصح الجميع", "Je recommande à tous"), body: txt("اشتريت جهازين للعائلة، كلاهما ممتاز والسعر أفضل من الجديد.", "J’ai acheté deux appareils pour la famille, tous deux excellents et bien moins chers que le neuf."), color: "#d63031" }
  ];

  const DEFAULT_PRESS = [
    { id: "p1", outlet: txt("تِك صحارى", "Tech Sahara"), quote: txt("ريستور يعيد تعريف سوق الإلكترونيات المجددة في موريتانيا بأسعار شفافة وضمان حقيقي.", "Restore redéfinit le marché du reconditionné en Mauritanie avec des prix transparents et une vraie garantie.") },
    { id: "p2", outlet: txt("نواكشوط بيزنس", "Nouakchott Business"), quote: txt("منصة محلية تربط المستهلك بأجهزة موثوقة وتقلل النفايات الإلكترونية.", "Une plateforme locale qui connecte les consommateurs à des appareils fiables et réduit les déchets électroniques.") },
    { id: "p3", outlet: txt("الرؤية", "La Vision"), quote: txt("تجربة شراء رقمية بالعربية والفرنسية مع دفع محلي وتوصيل لكل الولايات.", "Une expérience d’achat numérique en arabe et en français, avec paiement local et livraison dans toutes les wilayas.") }
  ];

  const DEFAULT_BLOG = [
    { id: "b1", slug: "choisir-telephone-reconditionne", title: txt("كيف تختار هاتفًا مجددًا دون أن تقع في الفخ؟", "Comment choisir un téléphone reconditionné sans se tromper ?"), excerpt: txt("خمسة معايير مهمة قبل الشراء: البطارية، الحالة، الضمان، المصدر، وسياسة الإرجاع.", "Cinq critères essentiels : batterie, état, garantie, provenance et politique de retour."), body: txt("ابدأ دائمًا بصحة البطارية. نسبة 85% فما فوق جيدة للاستخدام اليومي.\nتأكد من وجود ضمان مكتوب وسياسة إرجاع واضحة.\nاسأل عن الحالة الفعلية للجهاز واطلب صورًا حقيقية.\nقارن السعر بالسوق ولا تنسَ تكلفة الشحن.", "Commencez toujours par la santé de la batterie. Au-dessus de 85 %, elle convient à un usage quotidien.\nExigez une garantie écrite et une politique de retour claire.\nDemandez l’état réel de l’appareil et des photos authentiques.\nComparez le prix au marché et pensez aux frais de livraison."), image: "assets/img/category-iphone.png", date: "2026-09-12", published: true },
    { id: "b2", slug: "macbook-ou-pc-portable", title: txt("ماك بوك أم حاسوب ويندوز؟ دليل مبسط", "MacBook ou PC portable ? Le guide simple"), excerpt: txt("أيهما يناسب الدراسة والعمل والبرامج التي تحتاجها؟", "Lequel convient aux études, au travail et à vos logiciels ?"), body: txt("اختر MacBook إذا كنت تعمل على التصميم أو المونتاج أو تريد عمر بطارية طويل.\nاختر حاسوب ويندوز إذا كنت تحتاج برامج هندسية أو محاسبية خاصة أو ميزانية أقل.\nفي الحالتين، تحقق من صحة البطارية والمنافذ ولوحة المفاتيح.", "Choisissez un MacBook pour le design, le montage ou une longue autonomie.\nChoisissez un PC Windows pour certains logiciels d’ingénierie, de comptabilité ou un budget plus serré.\nDans les deux cas, vérifiez la batterie, les ports et le clavier."), image: "assets/img/category-macbooks.png", date: "2026-08-28", published: true },
    { id: "b3", slug: "entretenir-batterie", title: txt("سبع عادات تطيل عمر بطارية هاتفك", "Sept habitudes qui prolongent la batterie de votre téléphone"), excerpt: txt("نصائح عملية لشحن أذكى واستخدام أطول.", "Des conseils concrets pour charger plus intelligemment."), body: txt("حافظ على الشحن بين 20% و80% عندما يكون ذلك ممكنًا.\nتجنب الحرارة العالية أثناء الشحن.\nاستخدم شاحنًا أصليًا أو معتمدًا.\nلا تترك الهاتف مشحونًا 100% طوال الليل.", "Gardez la charge entre 20 % et 80 % lorsque c’est possible.\nÉvitez la chaleur pendant la charge.\nUtilisez un chargeur d’origine ou certifié.\nNe laissez pas le téléphone à 100 % toute la nuit."), image: "assets/img/category-chargers.png", date: "2026-07-19", published: true }
  ];

  const DEFAULT_NAV = [
    { id: "anniversary", label: txt("ريستور أنيفرساري", "Anniversaire Restore"), href: "collection.html?handle=restore-anniversary", flame: true, visible: true },
    { id: "iphones", label: txt("آيفون", "iPhones"), href: "collection.html?handle=refurbished-iphones", visible: true, sub: [
      { label: txt("سلسلة iPhone 16", "iPhone 16"), href: "collection.html?q=iPhone%2016" },
      { label: txt("سلسلة iPhone 15", "iPhone 15"), href: "collection.html?q=iPhone%2015" },
      { label: txt("سلسلة iPhone 14", "iPhone 14"), href: "collection.html?q=iPhone%2014" },
      { label: txt("سلسلة iPhone 13", "iPhone 13"), href: "collection.html?q=iPhone%2013" },
      { label: txt("سلسلة iPhone 12", "iPhone 12"), href: "collection.html?q=iPhone%2012" },
      { label: txt("سلسلة iPhone 11", "iPhone 11"), href: "collection.html?q=iPhone%2011" }
    ] },
    { id: "samsung", label: txt("سامسونج", "Samsung"), href: "collection.html?handle=used-samsung", visible: true, sub: [
      { label: txt("سلسلة Galaxy S24", "Galaxy S24"), href: "collection.html?q=S24" },
      { label: txt("سلسلة Galaxy S23", "Galaxy S23"), href: "collection.html?q=S23" },
      { label: txt("سلسلة Galaxy S22", "Galaxy S22"), href: "collection.html?q=S22" },
      { label: txt("سلسلة Galaxy S21", "Galaxy S21"), href: "collection.html?q=S21" },
      { label: txt("سلسلة Galaxy S20", "Galaxy S20"), href: "collection.html?q=S20" },
      { label: txt("سلسلة Galaxy Z", "Galaxy Z"), href: "collection.html?q=Z%20Fold" },
      { label: txt("سلسلة Galaxy Note", "Galaxy Note"), href: "collection.html?q=Note" }
    ] },
    { id: "macbooks", label: txt("ماك بوك", "MacBooks"), href: "collection.html?handle=refurbished-macbooks", visible: true, sub: [
      { label: txt("MacBook Pro", "MacBook Pro"), href: "collection.html?q=MacBook%20Pro" },
      { label: txt("MacBook Air", "MacBook Air"), href: "collection.html?q=MacBook%20Air" },
      { label: txt("iMac", "iMac"), href: "collection.html?q=iMac" }
    ] },
    { id: "laptops", label: txt("حواسيب محمولة", "Laptops"), href: "collection.html?handle=laptops-used-refurbished", visible: true, sub: [
      { label: "Lenovo", href: "collection.html?q=Lenovo" },
      { label: "Dell", href: "collection.html?q=Dell" },
      { label: "HP", href: "collection.html?q=HP" },
      { label: "Acer", href: "collection.html?q=Acer" }
    ] },
    { id: "ipads", label: txt("آيباد", "iPads"), href: "collection.html?handle=ipads", visible: true },
    { id: "accessories", label: txt("ملحقات وصوتيات", "Accessoires et audio"), href: "collection.html?handle=audio", visible: true, sub: [
      { label: txt("صوتيات", "Audio"), href: "collection.html?handle=audio" },
      { label: txt("شواحن وكابلات", "Chargeurs et câbles"), href: "collection.html?handle=chargers-power-banks-cables" },
      { label: txt("ألعاب", "Gaming"), href: "collection.html?handle=gaming" },
      { label: txt("ملحقات", "Accessoires"), href: "collection.html?handle=cases-screen-protectors" }
    ] },
    { id: "watches", label: txt("ساعة آبل", "Apple Watch"), href: "collection.html?handle=apple-watches", visible: true },
    { id: "business", label: txt("للشركات", "Entreprises"), href: "page.html?slug=for-businesses", visible: true },
    { id: "help", label: txt("تحتاج مساعدة؟", "Besoin d’aide ?"), href: "page.html?slug=help", visible: true },
    { id: "seller", label: txt("كن بائعًا", "Devenir vendeur"), href: "page.html?slug=become-a-seller", visible: true }
  ];

  const COLLECTION_TITLES = {
    "restore-anniversary": txt("ريستور أنيفرساري", "Anniversaire Restore"),
    "refurbished-iphones": txt("آيفون مجدد معتمد", "iPhone reconditionnés certifiés"),
    "used-samsung": txt("سامسونج مجدد معتمد", "Samsung reconditionnés certifiés"),
    "laptops-used-refurbished": txt("حواسيب محمولة مجددة", "Ordinateurs portables reconditionnés"),
    "refurbished-macbooks": txt("ماك بوك مجدد", "MacBook reconditionnés"),
    "ipads": txt("آيباد مجدد", "iPad reconditionnés"),
    "apple-watches": txt("ساعات آبل", "Montres Apple"),
    "audio": txt("صوتيات", "Audio"),
    "chargers-power-banks-cables": txt("شواحن وبطاريات وكابلات", "Chargeurs, batteries et câbles"),
    "gaming": txt("ألعاب", "Gaming"),
    "cases-screen-protectors": txt("محافظ وواقيات شاشة", "Coques et protections d’écran")
  };

  const DEFAULT_CATEGORIES = [
    { label: txt("ريستور أنيفرساري", "Restore Anniversary"), handle: "restore-anniversary", image: "assets/img/category-anniversary.webp" },
    { label: txt("آيفون", "iPhone"), handle: "refurbished-iphones", image: "assets/img/category-iphone.png" },
    { label: txt("سامسونج", "Samsung"), handle: "used-samsung", image: "assets/img/category-samsung.png" },
    { label: txt("ماك بوك", "MacBooks"), handle: "refurbished-macbooks", image: "assets/img/category-macbooks.png" },
    { label: txt("حواسيب محمولة", "Laptops"), handle: "laptops-used-refurbished", image: "assets/img/category-laptops.png" },
    { label: txt("آيباد", "iPads"), handle: "ipads", image: "assets/img/category-ipads.png" },
    { label: txt("ساعات آبل", "Apple Watches"), handle: "apple-watches", image: "assets/img/category-watches.png" },
    { label: txt("صوتيات", "Audio"), handle: "audio", image: "assets/img/category-audio.png" },
    { label: txt("شواحن وكابلات", "Chargeurs et câbles"), handle: "chargers-power-banks-cables", image: "assets/img/category-chargers.png" },
    { label: txt("ألعاب", "Gaming"), handle: "gaming", image: "assets/img/category-gaming.png" },
    { label: txt("ملحقات", "Accessoires"), handle: "cases-screen-protectors", image: "assets/img/category-accessories.png" }
  ];

  const DEFAULT_PAYMENTS = [
    { id: "bankily", name: txt("بنكيلي", "Bankily"), color: "#00a651", active: true, discount: 10, note: txt("خصم 10% عند الدفع عبر بنكيلي", "10 % de réduction avec Bankily") },
    { id: "masrvi", name: txt("مصرفي", "Masrvi"), color: "#0b6fb8", active: true, discount: 0, note: txt("تحويل فوري عبر مصرفي", "Paiement instantané via Masrvi") },
    { id: "sedad", name: txt("سداد", "Sedad"), color: "#6f42c1", active: true, discount: 0, note: txt("الدفع عبر تطبيق سداد", "Paiement avec l’application Sedad") },
    { id: "click", name: txt("كليك", "Click"), color: "#e67e22", active: true, discount: 0, note: txt("الدفع عبر كليك", "Paiement avec Click") },
    { id: "cod", name: txt("الدفع عند الاستلام", "Paiement à la livraison"), color: "#2d3436", active: true, discount: 0, note: txt("ادفع نقدًا عند استلام طلبك", "Payez en espèces à la réception") }
  ]
  const DEFAULT_CITIES = [
    { id: "nouakchott", name: txt("نواكشوط", "Nouakchott"), fee: 0, days: txt("1–2 أيام", "1–2 jours"), active: true },
    { id: "nouadhibou", name: txt("نواذيبو", "Nouadhibou"), fee: 500, days: txt("2–3 أيام", "2–3 jours"), active: true },
    { id: "rosso", name: txt("روصو", "Rosso"), fee: 600, days: txt("2–3 أيام", "2–3 jours"), active: true },
    { id: "kiffa", name: txt("كيفة", "Kiffa"), fee: 800, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "kaedi", name: txt("كيهيدي", "Kaédi"), fee: 700, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "atar", name: txt("أطار", "Atar"), fee: 900, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "zouerat", name: txt("الزويرات", "Zouérat"), fee: 1200, days: txt("4–6 أيام", "4–6 jours"), active: true },
    { id: "nema", name: txt("النعمة", "Néma"), fee: 1200, days: txt("4–7 أيام", "4–7 jours"), active: true },
    { id: "tidjikja", name: txt("تجكجة", "Tidjikja"), fee: 1000, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "selibaby", name: txt("سيليبابي", "Sélibaby"), fee: 900, days: txt("4–6 أيام", "4–6 jours"), active: true },
    { id: "aleg", name: txt("ألاك", "Aleg"), fee: 700, days: txt("3–5 أيام", "3–5 jours"), active: true },
    { id: "boutilimit", name: txt("بوتلميت", "Boutilimit"), fee: 500, days: txt("2–4 أيام", "2–4 jours"), active: true }
  ];

  const DEFAULT_ORDER_TEMPLATE = {
    ar: "مرحباً {store} 👋\nأريد تأكيد هذا الطلب:\n\nرقم الطلب: {order_id}\nالاسم: {name}\nالهاتف: {phone}\nالمدينة: {city}\nالعنوان: {address}\nطريقة الدفع: {payment}\n\nالمنتجات:\n{items}\n\nالمجموع الفرعي: {subtotal}\nالشحن: {shipping}\nالخصم: {discount}\nالإجمالي: {total}\n\nملاحظات: {notes}",
    fr: "Bonjour {store} 👋\nJe souhaite confirmer cette commande :\n\nN° de commande : {order_id}\nNom : {name}\nTéléphone : {phone}\nVille : {city}\nAdresse : {address}\nPaiement : {payment}\n\nProduits :\n{items}\n\nSous-total : {subtotal}\nLivraison : {shipping}\nRéduction : {discount}\nTotal : {total}\n\nNotes : {notes}"
  };

  const DEFAULT_WHATSAPP_TEMPLATES = {
    confirm: {
      ar: "مرحباً {name}، تم تأكيد طلبك {order_id} من {store}. سنبدأ تجهيزه ونخبرك عند الشحن. شكراً لثقتك!",
      fr: "Bonjour {name}, votre commande {order_id} chez {store} est confirmée. Nous préparons votre colis et vous informerons dès l’expédition. Merci !"
    },
    shipped: {
      ar: "مرحباً {name}، طلبك {order_id} تم شحنه وهو في الطريق إليك. سنوافيك برقم التتبع قريباً.",
      fr: "Bonjour {name}, votre commande {order_id} a été expédiée et est en route. Nous vous enverrons le numéro de suivi très bientôt."
    },
    delivered: {
      ar: "مرحباً {name}، نأمل أن تكون راضياً عن طلبك {order_id}. إذا احتجت أي مساعدة أو ضمان، راسلنا هنا.",
      fr: "Bonjour {name}, nous espérons que votre commande {order_id} vous satisfait. Pour toute aide ou garantie, écrivez-nous ici."
    }
  };

  function productDescriptions(type) {
    return TYPE_DESCRIPTIONS[type] || txt(
      "جهاز مجدد تم فحصه واختباره من طرف خبراء ريستور، ويأتي بضمان 12 شهرًا.",
      "Appareil reconditionné, inspecté et testé par les experts Restore, avec 12 mois de garantie."
    );
  }

  function hashHandle(handle) {
    let h = 0;
    for (let i = 0; i < handle.length; i++) h = (h * 31 + handle.charCodeAt(i)) >>> 0;
    return h;
  }

  function includesFor(p) {
    const map = {
      Macbook: [txt("جهاز MacBook", "MacBook"), txt("شاحن أصلي", "Chargeur d’origine"), txt("كابل USB-C", "Câble USB-C")],
      Laptop: [txt("الحاسوب المحمول", "Ordinateur portable"), txt("الشاحن", "Chargeur"), txt("كابل الطاقة", "Câble d’alimentation")],
      Smartphone: [txt("الهاتف", "Téléphone"), txt("كابل الشحن", "Câble de charge"), txt("أداة إخراج الشريحة", "Outil SIM")],
      Tablets: [txt("الجهاز اللوحي", "Tablette"), txt("كابل الشحن", "Câble de charge"), txt("الشاحن", "Chargeur")],
      "Apple Watch": [txt("الساعة", "Montre"), txt("السوار", "Bracelet"), txt("شاحن مغناطيسي", "Chargeur magnétique")],
      Playstation: [txt("الجهاز", "Console"), txt("يد التحكم", "Manette"), txt("كابلات التوصيل", "Câbles de connexion")],
      Accessories: [txt("الملحق", "Accessoire"), txt("دليل الاستخدام", "Guide d’utilisation")]
    };
    return map[p.type] || [txt("الجهاز", "Appareil"), txt("الكابل", "Câble")];
  }

  function specsFor(p, battery) {
    const title = p.title || "";
    const cpuOpt = p.options?.find((o) => /cpu/i.test(o.name));
    const ramOpt = p.options?.find((o) => /ram/i.test(o.name));
    const storageOpt = p.options?.find((o) => /storage/i.test(o.name));
    const isMac = p.type === "Macbook";
    const isLaptop = p.type === "Laptop" || isMac;
    const isPhone = p.type === "Smartphone";
    const cpuFromTitle = title.match(/(Core i[3579][^,/(-]*|M[1234](?: Pro| Max)?|Ryzen [3579][^,/(-]*)/i)?.[0];
    const cpu = cpuOpt?.values?.[0] || cpuFromTitle || (isMac ? "Apple Silicon" : isLaptop ? "Intel Core i5" : isPhone ? "SoC" : "—");
    const ram = ramOpt?.values?.[0] || (isLaptop ? (isMac ? "8 GB" : "8 GB") : isPhone ? "6 GB" : "—");
    const storage = storageOpt?.values?.[0] || (isPhone ? "128 GB" : isLaptop ? "256 GB SSD" : "—");
    const screen = isMac ? '13.3"' : isLaptop ? '14"' : isPhone ? '6.1"' : p.type === "Tablets" ? '10.2"' : p.type === "Apple Watch" ? "45 mm" : "—";
    const keyboard = isLaptop ? txt("فرنسي AZERTY", "Français AZERTY") : null;
    const condition = p.options?.find((o) => /condition|état/i.test(o.name))?.values?.[0] || "Excellent";
    return {
      cpu: { label: txt("المعالج", "Processeur"), value: cpu, choices: isLaptop ? [cpu, "Intel Core i7", "Intel Core i5", "Apple M1", "Apple M2"] : [] },
      ram: { label: txt("الذاكرة", "Mémoire RAM"), value: ram, choices: isLaptop ? [ram, "8 GB", "16 GB", "32 GB"] : [] },
      storage: { label: txt("التخزين", "Stockage"), value: storage, choices: [] },
      screen: { label: txt("حجم الشاشة", "Taille d’écran"), value: screen, choices: isLaptop ? [screen, '13.3"', '14"', '15.6"', '16"'] : isPhone ? ['5.8"', '6.1"', '6.7"'] : [] },
      keyboard: { label: txt("لوحة المفاتيح", "Clavier"), value: keyboard, choices: isLaptop ? ["Français AZERTY", "QWERTY (US)", "Arabe / Anglais"] : [] },
      condition: { label: txt("الحالة", "État"), value: condition, choices: [] },
      battery: { label: txt("صحة البطارية", "Santé de la batterie"), value: `${battery}%`, choices: [] }
    };
  }

  function priceProduct(p) {
    const price = roundMRU(p.price);
    const compare = roundMRU(p.compare);
    return {
      ...p,
      price,
      compare: compare > price ? compare : 0,
      discount: compare > price ? Math.round((1 - price / compare) * 100) : 0
    };
  }

  function buildProducts() {
    return RAW.products.map((raw, index) => {
      const seed = hashHandle(raw.handle);
      const p = priceProduct(raw);
      const stock = 2 + (seed % 17);
      const batteryBase = 84 + (seed % 16);
      const battery = p.type === "Smartphone" ? Math.min(100, batteryBase) : null;
      const condition = p.options?.find((o) => /condition|état/i.test(o.name))?.values?.[0] || (p.compare ? "Excellent" : "Good");
      const colorRemote = {};
      for (const v of raw.variants || []) {
        const alt = v.image?.alt;
        if (alt && v.image?.src) colorRemote[alt] = v.image.src;
      }
      const colors = p.colors || [];
      const colorImages = {};
      colors.forEach((c, i) => {
        colorImages[c.name] = p.images?.length
          ? p.images[Math.min(i, p.images.length - 1)]
          : p.image;
      });
      const variants = (raw.variants || []).map((v) => ({
        id: v.id,
        title: v.title,
        o1: v.o1,
        o2: v.o2,
        o3: v.o3,
        price: roundMRU(v.price ?? raw.price),
        compare: roundMRU(v.compare ?? raw.compare),
        available: v.available !== false,
        battery: battery ?? 0
      }));
      return {
        ...p,
        variants,
        price: roundMRU(raw.price),
        compare: roundMRU(raw.compare) > roundMRU(raw.price) ? roundMRU(raw.compare) : 0,
        discount: roundMRU(raw.compare) > roundMRU(raw.price) ? Math.round((1 - roundMRU(raw.price) / roundMRU(raw.compare)) * 100) : 0,
        stock,
        active: true,
        battery,
        condition,
        description: productDescriptions(p.type),
        includes: includesFor(p),
        specs: specsFor(p, battery || 92),
        colorImages,
        colorRemote,
        sku: `RS-${String(index + 1).padStart(4, "0")}`,
        warrantyMonths: 12,
        lowStock: stock <= 2
      };
    });
  }

  function buildState() {
    const products = buildProducts();
    products.forEach((p) => {
    });
    const collections = RAW.collections.map((c) => ({
      handle: c.handle,
      title: COLLECTION_TITLES[c.handle] || txt(c.title, c.title),
      visible: true
    }));
    const home = {
      anniversary: RAW.home.anniversary,
      iphones: RAW.home.iphones,
      samsung: RAW.home.samsung,
      laptops: RAW.home.laptops
    };
    return {
      version: 1,
      updatedAt: nowISO(),
      settings: {
        storeName: txt("ريستور", "Restore"),
        legalName: txt("ريستور موريتانيا", "Restore Mauritanie"),
        tagline: txt("إلكترونيات مجددة موثوقة في موريتانيا", "Électronique reconditionnée et fiable en Mauritanie"),
        logo: "assets/img/restore-logo.svg",
        logoWhite: "assets/img/restore-logo-white.svg",
        favicon: "assets/img/favicon.svg",
        colors: { primary: "#ff6400", ink: "#232323", purple: "#a72396", lavender: "#f1ecf9" },
        font: "Montserrat",
        radius: 10,
        country: {
          code: "MR",
          name: txt("موريتانيا", "Mauritanie"),
          flag: "assets/img/flag-mr.svg",
          dial: "+222",
          currencyCode: "MRU",
          currency: txt("أوقية", "MRU"),
          currencyName: txt("أوقية جديدة", "Nouvelle ouguiya"),
          currencyMode: "new"
        },
        city: txt("نواكشوط", "Nouakchott"),
        address: txt("نواكشوط، موريتانيا", "Nouakchott, Mauritanie"),
        timezone: "Africa/Nouakchott",
        phone: "+22246000000",
        phoneDisplay: "+222 46 00 00 00",
        whatsapp: "22246000000",
        email: "hello@restore.mr",
        hours: { open: "00:00", close: "23:59", days: [0, 1, 2, 3, 4, 5, 6], closed: false, maintenance: false },
        announcement: txt("توصيل مجاني داخل نواكشوط • خصم 10% عند الدفع عبر بنكيلي", "Livraison gratuite à Nouakchott • -10 % avec Bankily"),
        renewalText: txt("ما معنى مجدد من ريستور؟", "Que signifie reconditionné chez Restore ?"),
        categoriesTitle: txt("تسوق الإلكترونيات المجددة", "Électronique reconditionnée"),
        serviceTitle: txt("كل أجهزتنا أصلية ومفحوصة من طرف خبراء", "Tous nos appareils sont originaux et vérifiés par des experts"),
        serviceItems: [
          { icon: "smile", title: txt("بدون مخاطرة", "Sans risque"), text: txt("10 أيام لإرجاع الجهاز عند وجود أي مشكلة", "10 jours pour retourner l’appareil en cas de problème") },
          { icon: "badgeCheck", title: txt("فحص جهازًا بجهاز", "Vérifié un par un"), text: txt("50 نقطة فحص تشمل الشاشة، البطارية، السرعة والمتانة", "50 points de contrôle : écran, batterie, vitesse et durabilité") },
          { icon: "star", title: txt("أفضل الموردين فقط", "Seulement les meilleurs"), text: txt("نقبل موردًا واحدًا من كل أربعة بعد فحص صارم", "Nous acceptons un fournisseur sur quatre après un contrôle strict") },
          { icon: "chat", title: txt("دائمًا معك", "Toujours là pour vous"), text: txt("خدمة عملاء تجيب على أسئلتك وتتابع طلبك", "Un service client qui répond et suit votre commande") }
        ],
        trustTitle: txt("150,000+ عميل يثقون بنا", "150 000+ clients nous font confiance"),
        communityTitle: txt("انضم إلى مجتمع ريستور", "Rejoignez la communauté Restore"),
        reviewsTitle: txt("ماذا يقول عملاؤنا", "Ce que disent nos clients"),
        pressTitle: txt("ريستور في الأخبار", "Restore dans la presse"),
        trustBar: [
          { icon: "truck", label: txt("توصيل مجاني داخل نواكشوط", "Livraison gratuite à Nouakchott") },
          { icon: "shield", label: txt("ضمان 12 شهرًا", "Garantie 12 mois") },
          { icon: "return", label: txt("إرجاع خلال 10 أيام", "Retour sous 10 jours") },
          { icon: "badgeCheck", label: txt("فحص بواسطة خبراء", "Vérifié par des experts") }
        ],
        paymentOffer: txt("اشترِ عبر بنكيلي واحصل على خصم 10%", "Payez avec Bankily et obtenez 10 % de réduction"),
        paymentOfferCode: "BANKILY10",
        shippingNote: txt("رسوم الشحن تُحسب حسب المدينة عند إتمام الطلب.", "Les frais de livraison sont calculés selon la ville lors de la commande."),
        freeShippingOver: 20000,
        cities: DEFAULT_CITIES,
        payments: DEFAULT_PAYMENTS,
        navigation: DEFAULT_NAV,
        footerColumns: [
          { title: txt("من نحن", "À propos"), links: [
            { label: txt("من نحن", "À propos"), href: "page.html?slug=about-us" },
            { label: txt("تسوق الآن", "Boutique"), href: "collection.html?handle=all" },
            { label: txt("مدونتنا", "Notre blog"), href: "blog.html" },
            { label: txt("كن بائعًا", "Devenir vendeur"), href: "page.html?slug=become-a-seller" }
          ] },
          { title: txt("معلومات", "Informations"), links: [
            { label: txt("مركز المساعدة", "Centre d’aide"), href: "page.html?slug=help" },
            { label: txt("اتصل بنا", "Contact"), href: "page.html?slug=contact" },
            { label: txt("الشروط والأحكام", "Conditions générales"), href: "page.html?slug=terms" },
            { label: txt("سياسة الخصوصية", "Confidentialité"), href: "page.html?slug=privacy" }
          ] },
          { title: txt("حسابي", "Mon compte"), links: [
            { label: txt("حسابي", "Mon compte"), href: "account.html" },
            { label: txt("تتبع الطلب", "Suivre ma commande"), href: "page.html?slug=track-order" },
            { label: txt("طلب ضمان", "Demande de garantie"), href: "page.html?slug=raise-claim" },
            { label: txt("متابعة الضمان", "Suivi de garantie"), href: "page.html?slug=track-claim" }
          ] }
        ],
        social: [
          { id: "facebook", href: "https://www.facebook.com/", icon: "facebook" },
          { id: "instagram", href: "https://www.instagram.com/", icon: "instagram" },
          { id: "tiktok", href: "https://www.tiktok.com/", icon: "tiktok" }
        ],
        homeSections: [
          { id: "anniversary", visible: true, order: 1, title: txt("ريستور أنيفرساري", "Restore Anniversary"), collection: "restore-anniversary", handles: home.anniversary, layout: "plain", promo: "", flame: true },
          { id: "iphones", visible: true, order: 2, title: txt("آيفون مجدد معتمد", "iPhones reconditionnés certifiés"), collection: "refurbished-iphones", handles: home.iphones, layout: "left", promo: "assets/img/restore/promo-iphone.svg", flame: false },
          { id: "samsung", visible: true, order: 3, title: txt("سامسونج مجدد معتمد", "Samsung reconditionné certifié"), collection: "used-samsung", handles: home.samsung, layout: "right", promo: "assets/img/restore/promo-samsung.svg", flame: false },
          { id: "laptops", visible: true, order: 4, title: txt("حواسيب محمولة مجددة", "Ordinateurs portables reconditionnés"), collection: "laptops-used-refurbished", handles: home.laptops, layout: "left", promo: "assets/img/restore/promo-laptops.svg", flame: false }
        ],
        pageSections: [
          { id: "hero", visible: true, order: 1 },
          { id: "trust", visible: true, order: 2 },
          { id: "renewed", visible: true, order: 3 },
          { id: "categories", visible: true, order: 4 },
          { id: "offer", visible: true, order: 5 },
          { id: "products", visible: true, order: 6 },
          { id: "sustain", visible: true, order: 7 },
          { id: "service", visible: true, order: 8 },
          { id: "video", visible: true, order: 9 },
          { id: "reviews", visible: true, order: 10 },
          { id: "press", visible: true, order: 11 }
        ],
        heroSlides: [
          { id: "hero-1", visible: true, title: txt("تقنية مجددة، ثقة جديدة", "La tech reconditionnée, en toute confiance"), subtitle: txt("هواتف وحواسيب مفحوصة بضمان 12 شهرًا، وتوصيل لكل موريتانيا.", "Téléphones et ordinateurs contrôlés, garantis 12 mois et livrés partout en Mauritanie."), cta: txt("تسوق الآن", "Découvrir"), href: "collection.html?handle=all", image: "assets/img/hero-iphone.png", bg: "linear-gradient(135deg,#1f1f2e 0%,#39255b 55%,#ff6400 130%)" },
          { id: "hero-2", visible: true, title: txt("ماك بوك جاهز للعمل", "MacBook prêt à travailler"), subtitle: txt("macOS مثبت، بطارية مفحوصة، ولوحة مفاتيح بالعربية أو الفرنسية.", "macOS installé, batterie contrôlée et clavier arabe ou français."), cta: txt("اكتشف ماك بوك", "Voir les MacBook"), href: "collection.html?handle=refurbished-macbooks", image: "assets/img/hero-macbook.png", bg: "linear-gradient(135deg,#eef3ff 0%,#d9e5ff 45%,#f7c7ff 120%)", dark: false }
        ],
        offers: [
          { id: "bankily", active: true, title: txt("خصم 10% عند الدفع عبر بنكيلي", "10 % de réduction avec Bankily"), subtitle: txt("اختر بنكيلي عند إتمام الطلب وسيُطبّق الخصم تلقائيًا.", "Choisissez Bankily au paiement, la réduction s’applique automatiquement."), code: "BANKILY10", href: "collection.html?handle=all", startsAt: "", endsAt: new Date(Date.now() + 7 * 864e5).toISOString() }
        ],
        coupons: [
          { id: "c1", code: "RESTORE10", type: "percent", value: 10, active: true, minTotal: 0, expiresAt: "" },
          { id: "c2", code: "NOUAKCHOTT5", type: "percent", value: 5, active: true, minTotal: 10000, expiresAt: "" }
        ],
        seo: {
          title: txt("ريستور | إلكترونيات مجددة موثوقة في موريتانيا", "Restore | Électronique reconditionnée en Mauritanie"),
          description: txt("اشترِ هواتف وحواسيب مجددة مفحوصة في موريتانيا مع ضمان 12 شهرًا، توصيل سريع ودفع عبر بنكيلي ومصرفي وسداد.", "Achetez téléphones et ordinateurs reconditionnés en Mauritanie avec 12 mois de garantie, livraison rapide et paiement Bankily, Masrvi ou Sedad.")
        },
        pixels: { meta: "", tiktok: "", ga: "" },
        orderTemplate: DEFAULT_ORDER_TEMPLATE,
        whatsappTemplates: DEFAULT_WHATSAPP_TEMPLATES,
        otp: { enabled: false },
        blocklist: [],
        rateLimitSeconds: 60,
        lowStockThreshold: 2,
        autoHideOutOfStock: true,
        pwa: true,
        fakeData: true
      },
      products,
      collections,
      home,
      theme: { categories: DEFAULT_CATEGORIES },
      pages: DEFAULT_PAGES,
      faqs: DEFAULT_FAQS,
      homeReviews: DEFAULT_HOME_REVIEWS,
      press: DEFAULT_PRESS,
      blog: DEFAULT_BLOG,
      reviews: []
    };
  }

  function hydrate(saved) {
    const base = buildState();
    if (!saved) return base;
    const out = merge(base, saved);
    const baseProducts = new Map(base.products.map((p) => [p.handle, p]));
    out.products = (saved.products || base.products).map((p) => merge(baseProducts.get(p.handle) || {}, p));
    out.collections = (saved.collections || base.collections).map((c) => {
      const merged = merge(base.collections.find((x) => x.handle === c.handle) || {}, c);
      if (typeof merged.title === "string") merged.title = COLLECTION_TITLES[merged.handle] || txt(merged.title, merged.title);
      return merged;
    });
    out.pages = (saved.pages || base.pages).map((p) => merge(base.pages.find((x) => x.slug === p.slug) || {}, p));
    out.blog = (saved.blog || base.blog).map((b) => merge(base.blog.find((x) => x.slug === b.slug) || {}, b));
    out.settings.homeSections = (saved.settings?.homeSections || base.settings.homeSections).map((s) => merge(base.settings.homeSections.find((x) => x.id === s.id) || {}, s));
    out.settings.navigation = (saved.settings?.navigation || base.settings.navigation).map((n) => merge(base.settings.navigation.find((x) => x.id === n.id) || {}, n));
    out.settings.pageSections = (saved.settings?.pageSections || base.settings.pageSections).map((s) => merge(base.settings.pageSections.find((x) => x.id === s.id) || {}, s));
    out.products.forEach((p) => {
      if (!p.specs) p.specs = specsFor(p, p.battery || 92);
      if (!p.includes) p.includes = includesFor(p);
      if (!p.description) p.description = productDescriptions(p.type);
      if (!p.colorImages) p.colorImages = {};
      if (!p.colorRemote) p.colorRemote = {};
    });
    return out;
  }

  const savedState = readJSON(LS_STATE, null);
  let state = hydrate(savedState);
  let draft = readJSON(LS_DRAFT, null);
  const startedAt = Date.now();
  const channel = "BroadcastChannel" in window ? new BroadcastChannel(SYNC_CHANNEL) : null;

  /* ------------------------------------------------------------------------
     Managers, session and audit
     ------------------------------------------------------------------------ */
  const DEFAULT_MANAGERS = [
    { id: "m_owner", username: "owner", name: txt("مالك المتجر", "Propriétaire"), role: "owner", passwordHash: "913f69e9f2f3b662b7d6619843532fb692ccc1ba64ce95099460683bbd944afa", mustChange: true, whatsapp: "" },
    { id: "m_manager", username: "manager", name: txt("المدير الثاني", "Second manager"), role: "manager", passwordHash: "46aa31f635892938e7f9b3b3b282d12b0d1e5ebf3c4af8c5a1fe33b5cd08bd9d", mustChange: true, whatsapp: "" }
  ];
  let managers = readJSON(LS_MANAGERS, null) || clone(DEFAULT_MANAGERS);
  let session = readJSON(LS_SESSION, null);

  async function sha256(text) {
    if (!window.crypto?.subtle) {
      // Fallback only for old browsers; local demo mode is not a production secret store.
      let h = 0;
      for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) >>> 0;
      return `fallback-${h.toString(16)}`;
    }
    const data = new TextEncoder().encode(SALT + text);
    const digest = await crypto.subtle.digest("SHA-256", data);
    return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  const normalizeDigits = (s) => String(s || "").replace(/\D/g, "");

  /* ------------------------------------------------------------------------
     Language dictionary
     ------------------------------------------------------------------------ */
  const I18N = {
    ar: {
      home: "الرئيسية", shop: "تسوق", allProducts: "كل المنتجات", search: "بحث", account: "حسابي", wishlist: "المفضلة", cart: "السلة", checkout: "إتمام الطلب",
      searchPlaceholder: "ابحث عن iPhone، Galaxy، MacBook...", close: "إغلاق", menu: "القائمة", language: "اللغة", dark: "الوضع الليلي", light: "الوضع النهاري",
      freeDelivery: "توصيل مجاني", returns: "إرجاع سهل", warranty: "ضمان 12 شهرًا", macos: "macOS مثبت", checked: "مفحوص بواسطة خبراء",
      seeAll: "عرض الكل", shopNow: "تسوق الآن", discover: "اكتشف", addToCart: "أضف إلى السلة", buyNow: "اشترِ الآن", soldOut: "نفدت الكمية",
      continueShopping: "متابعة التسوق", quickView: "نظرة سريعة", addedToCart: "تمت الإضافة إلى السلة", removedWish: "تمت الإزالة من المفضلة", savedWish: "تمت الإضافة إلى المفضلة",
      popularNow: "الأكثر طلبًا الآن", resultsFor: "{count} نتيجة لـ «{q}»", noProducts: "لا توجد منتجات", tryFilter: "جرّب كلمة بحث أو تصنيفًا آخر.", browseAll: "تصفح كل المنتجات",
      sortBy: "ترتيب حسب", featured: "المميزة", priceLow: "السعر: من الأقل للأعلى", priceHigh: "السعر: من الأعلى للأقل", biggestDiscount: "أكبر خصم", nameAZ: "الاسم أ–ي",
      all: "الكل", onSale: "عروض", loadMore: "عرض المزيد", product: "منتج", products: "منتج", collection: "التصنيف", searchResults: "نتائج البحث",
      homeCrumb: "الرئيسية", reviews: "تقييمات", review: "تقييم", battery: "البطارية", condition: "الحالة", quantity: "الكمية", description: "الوصف",
      shippingDelivery: "الشحن والتوصيل", warrantyReturns: "الضمان والإرجاع", whatsIncluded: "ماذا يوجد مع الشحنة", faqs: "الأسئلة الشائعة", related: "منتجات مشابهة", youMayLike: "قد يعجبك أيضًا",
      freeDeliverySub: "توصيل مجاني داخل نواكشوط", warrantySub: "مغطى من طرف ريستور", returnsSub: "في حال وجود أي مشكلة", checkedSub: "50 نقطة فحص قبل البيع",
      paymentOffer: "اشترِ عبر بنكيلي واحصل على خصم 10%", paymentOfferShort: "خصم 10% مع بنكيلي", orderWhatsApp: "اطلب عبر واتساب",
      customize: "خصص طلبك", cpu: "المعالج", ram: "الذاكرة", storage: "التخزين", screen: "حجم الشاشة", keyboard: "لوحة المفاتيح",
      trustedBy: "150,000+ عميل يثقون بنا", excellent: "ممتاز", customers: "عميل", basedOn: "بناءً على تقييمات العملاء",
      contactUs: "اتصل بنا", aboutUs: "من نحن", information: "معلومات", myAccount: "حسابي", replyWithin: "نرد خلال يوم عمل", workingHours: "من الأحد إلى الخميس، 9:00 إلى 19:00",
      allRights: "© {year} {store}. جميع الحقوق محفوظة.", paymentMethods: "وسائل الدفع", followUs: "تابعنا",
      emptyCart: "سلتك فارغة", emptyCartText: "أضف جهازًا للمتابعة.", emptyWish: "قائمة المفضلة فارغة", emptyWishText: "اضغط على القلب في أي منتج لحفظه هنا.",
      contactInfo: "معلومات التواصل", fullName: "الاسم الكامل", email: "البريد الإلكتروني (اختياري)", phone: "رقم الهاتف", city: "المدينة", address: "العنوان الكامل", notes: "ملاحظات (اختياري)",
      payment: "طريقة الدفع", coupon: "كود الخصم", apply: "تطبيق", subtotal: "المجموع الفرعي", shipping: "الشحن", discount: "الخصم", total: "الإجمالي", free: "مجاني",
      placeOrder: "أكمل الطلب عبر واتساب", processing: "جاري تجهيز طلبك...", required: "يرجى إكمال الحقول المطلوبة", invalidPhone: "أدخل رقم هاتف موريتاني صحيح (8 أرقام)",
      storeClosed: "المتجر مغلق مؤقتًا. يمكنك تصفح المنتجات والعودة لاحقًا.", rateLimited: "تم إرسال طلب حديثًا من هذا الرقم. انتظر قليلًا قبل المحاولة مجددًا.", blockedPhone: "تعذر إتمام الطلب. تواصل معنا عبر واتساب.",
      orderReceived: "تم تسجيل طلبك", orderReceivedText: "سيتم تحويلك إلى واتساب لإرسال تفاصيل الطلب وتأكيده.", openWhatsApp: "فتح واتساب", redirecting: "جاري التحويل إلى واتساب...",
      country: "البلد", orderSummary: "ملخص الطلب", couponInvalid: "كود الخصم غير صالح أو منتهي", couponApplied: "تم تطبيق كود الخصم", whatsappTitle: "اطلب عبر واتساب", whatsappText: "أرسل لنا تفاصيل طلبك وسنؤكده معك.",
      aboutStore: "ريستور متجر موريتاني للإلكترونيات المجددة. نفحص كل جهاز ونقدم ضمانًا واضحًا وتوصيلًا لكل الولايات.",
      newsletter: "اشترك ليصلك كل جديد", newsletterPlaceholder: "بريدك الإلكتروني", subscribe: "اشتراك", subscribed: "تم الاشتراك",
      searchHint: "ابحث عن المنتج أو الماركة", noResults: "لا توجد نتائج", popular: "الأكثر بحثًا", clear: "مسح",
      pageNotFound: "الصفحة غير موجودة", productNotFound: "المنتج غير موجود", productNotFoundText: "قد يكون المنتج نفد أو الرابط غير صحيح.", goHome: "العودة للرئيسية",
      loginDemo: "تسجيل الدخول (عرض تجريبي)", signIn: "تسجيل الدخول", signOut: "خروج",
      addToWishlist: "أضف إلى المفضلة", orderId: "رقم الطلب", writeReview: "اكتب تقييمك", verifiedBuyer: "مشترٍ موثّق",
      login: "دخول", logout: "خروج", signedIn: "تم تسجيل الدخول", signedOut: "تم تسجيل الخروج",
      createAccount: "إنشاء حساب", accountCreated: "تم إنشاء حسابك", loginFailed: "تعذر تسجيل الدخول", registerFailed: "تعذر إنشاء الحساب",
      password: "كلمة المرور", trackOrder: "تتبع الطلب", trackOrderText: "أدخل رقم الطلب أو رقم الهاتف للاطلاع على حالة طلبك.",
      recentOrders: "طلباتي الأخيرة", orderNotFound: "لم نجد طلبًا مطابقًا.", myWishlist: "مفضلتي", viewWishlist: "عرض كل المفضلة", myReviews: "تقييماتي",
      reviewStatusPending: "بانتظار الموافقة", reviewStatusApproved: "منشور", reviewStatusRejected: "مرفوض",
      reviewPending: "تقييمك وصل إلى الإدارة وسيظهر بعد الموافقة عليه.", reviewIncomplete: "أكمل التقييم والعنوان والتعليق.",
      reviewSubmitted: "شكرًا! تم إرسال تقييمك للمراجعة.", loginRequired: "سجّل الدخول أولًا لتتمكن من التقييم.",
      loginToReview: "سجّل الدخول أو أنشئ حسابًا لتقييم هذا المنتج.", noReviews: "لا توجد تقييمات بعد. كن أول من يقيّم هذا المنتج.",
      rating: "التقييم", stars: "نجوم", title: "العنوان", comment: "التعليق",
      reviewTitlePlaceholder: "ملخص تجربتك", reviewBodyPlaceholder: "ما الذي أعجبك؟ وكيف كانت حالة الجهاز والخدمة؟", submitReview: "إرسال التقييم",
      closedTitle: "المتجر مغلق الآن", closedText: "نعود قريبًا. يمكنك مراسلتنا على واتساب.",
      timezone: "توقيت نواكشوط", viewAllReviews: "كل التقييمات", readMore: "اقرأ المزيد", blog: "المدونة", latestArticles: "أحدث المقالات",
      offerEnds: "ينتهي العرض خلال", days: "يوم", hours: "ساعة", minutes: "دقيقة", seconds: "ثانية",
      installment: "ادفع عبر بنكيلي واحصل على خصم {percent}%", shippingCalc: "تُحسب رسوم الشحن حسب المدينة عند إتمام الطلب.",
      macbookNote: "macOS مثبت وجاهز للاستخدام", originalDevice: "جهاز أصلي 100%", warrantyMonths: "ضمان {months} شهرًا",
      chooseSpecs: "اختر المواصفات", personalization: "تخصيص الطلب", emptyCheckout: "لا يمكن إتمام الطلب", backToShop: "العودة للمتجر"
    },
    fr: {
      home: "Accueil", shop: "Boutique", allProducts: "Tous les produits", search: "Rechercher", account: "Mon compte", wishlist: "Favoris", cart: "Panier", checkout: "Commander",
      searchPlaceholder: "Rechercher iPhone, Galaxy, MacBook...", close: "Fermer", menu: "Menu", language: "Langue", dark: "Mode sombre", light: "Mode clair",
      freeDelivery: "Livraison gratuite", returns: "Retour facile", warranty: "Garantie 12 mois", macos: "macOS installé", checked: "Vérifié par des experts",
      seeAll: "Voir tout", shopNow: "Découvrir", discover: "Découvrir", addToCart: "Ajouter au panier", buyNow: "Acheter maintenant", soldOut: "Épuisé",
      continueShopping: "Continuer mes achats", quickView: "Aperçu", addedToCart: "Ajouté au panier", removedWish: "Retiré des favoris", savedWish: "Ajouté aux favoris",
      popularNow: "Populaire en ce moment", resultsFor: "{count} résultat(s) pour « {q} »", noProducts: "Aucun produit", tryFilter: "Essayez un autre mot-clé ou filtre.", browseAll: "Voir tous les produits",
      sortBy: "Trier par", featured: "En vedette", priceLow: "Prix croissant", priceHigh: "Prix décroissant", biggestDiscount: "Meilleure réduction", nameAZ: "Nom A–Z",
      all: "Tout", onSale: "Promotions", loadMore: "Voir plus", product: "produit", products: "produits", collection: "Collection", searchResults: "Résultats de recherche",
      homeCrumb: "Accueil", reviews: "Avis", review: "avis", battery: "Batterie", condition: "État", quantity: "Quantité", description: "Description",
      shippingDelivery: "Livraison", warrantyReturns: "Garantie et retours", whatsIncluded: "Contenu du colis", faqs: "Questions fréquentes", related: "Produits similaires", youMayLike: "Vous aimerez aussi",
      freeDeliverySub: "Livraison offerte à Nouakchott", warrantySub: "Assurée par Restore", returnsSub: "En cas de problème", checkedSub: "50 points de contrôle avant la vente",
      paymentOffer: "Payez avec Bankily et obtenez 10 % de réduction", paymentOfferShort: "-10 % avec Bankily", orderWhatsApp: "Commander sur WhatsApp",
      customize: "Personnalisez votre commande", cpu: "Processeur", ram: "Mémoire RAM", storage: "Stockage", screen: "Taille d’écran", keyboard: "Clavier",
      trustedBy: "150 000+ clients nous font confiance", excellent: "Excellent", customers: "clients", basedOn: "Selon les avis clients",
      contactUs: "Contactez-nous", aboutUs: "À propos", information: "Informations", myAccount: "Mon compte", replyWithin: "Réponse sous un jour ouvré", workingHours: "Dimanche à jeudi, 9h00–19h00",
      allRights: "© {year} {store}. Tous droits réservés.", paymentMethods: "Moyens de paiement", followUs: "Suivez-nous",
      emptyCart: "Votre panier est vide", emptyCartText: "Ajoutez un appareil pour continuer.", emptyWish: "Votre liste de favoris est vide", emptyWishText: "Cliquez sur le cœur d’un produit pour l’enregistrer.",
      contactInfo: "Coordonnées", fullName: "Nom complet", email: "E-mail (facultatif)", phone: "Téléphone", city: "Ville", address: "Adresse complète", notes: "Notes (facultatif)",
      payment: "Paiement", coupon: "Code promo", apply: "Appliquer", subtotal: "Sous-total", shipping: "Livraison", discount: "Réduction", total: "Total", free: "Gratuite",
      placeOrder: "Finaliser sur WhatsApp", processing: "Préparation de votre commande...", required: "Veuillez remplir les champs obligatoires", invalidPhone: "Saisissez un numéro mauritanien valide (8 chiffres)",
      storeClosed: "La boutique est temporairement fermée. Revenez plus tard.", rateLimited: "Une commande récente a déjà été envoyée depuis ce numéro. Patientez un instant.", blockedPhone: "Impossible de finaliser. Contactez-nous sur WhatsApp.",
      orderReceived: "Commande enregistrée", orderReceivedText: "Vous allez être redirigé vers WhatsApp pour envoyer les détails et confirmer.", openWhatsApp: "Ouvrir WhatsApp", redirecting: "Redirection vers WhatsApp...",
      country: "Pays", orderSummary: "Récapitulatif", couponInvalid: "Code invalide ou expiré", couponApplied: "Code appliqué", whatsappTitle: "Commander sur WhatsApp", whatsappText: "Envoyez-nous les détails de votre commande, nous la confirmerons.",
      aboutStore: "Restore est une boutique mauritanienne d’électronique reconditionnée. Chaque appareil est contrôlé, garanti et livré dans toutes les wilayas.",
      newsletter: "Recevez nos nouveautés", newsletterPlaceholder: "Votre e-mail", subscribe: "S’abonner", subscribed: "Inscription confirmée",
      searchHint: "Recherchez un produit ou une marque", noResults: "Aucun résultat", popular: "Recherches populaires", clear: "Effacer",
      pageNotFound: "Page introuvable", productNotFound: "Produit introuvable", productNotFoundText: "Le produit est peut-être épuisé ou le lien est incorrect.", goHome: "Retour à l’accueil",
      loginDemo: "Connexion (démo)", signIn: "Se connecter", signOut: "Déconnexion",
      addToWishlist: "Ajouter aux favoris", orderId: "N° de commande", writeReview: "Laisser un avis", verifiedBuyer: "Achat vérifié",
      login: "Connexion", logout: "Déconnexion", signedIn: "Connexion réussie", signedOut: "Déconnexion réussie",
      createAccount: "Créer un compte", accountCreated: "Votre compte est créé", loginFailed: "Connexion impossible", registerFailed: "Création du compte impossible",
      password: "Mot de passe", trackOrder: "Suivre ma commande", trackOrderText: "Entrez le numéro de commande ou votre téléphone pour voir l’état.",
      recentOrders: "Mes dernières commandes", orderNotFound: "Aucune commande correspondante.", myWishlist: "Mes favoris", viewWishlist: "Voir tous les favoris", myReviews: "Mes avis",
      reviewStatusPending: "En attente", reviewStatusApproved: "Publié", reviewStatusRejected: "Refusé",
      reviewPending: "Votre avis est arrivé à la boutique et sera publié après validation.", reviewIncomplete: "Complétez la note, le titre et le commentaire.",
      reviewSubmitted: "Merci ! Votre avis a été envoyé pour validation.", loginRequired: "Connectez-vous pour laisser un avis.",
      loginToReview: "Connectez-vous ou créez un compte pour évaluer ce produit.", noReviews: "Aucun avis pour le moment. Soyez le premier à donner votre avis.",
      rating: "Note", stars: "étoiles", title: "Titre", comment: "Commentaire",
      reviewTitlePlaceholder: "Résumé de votre expérience", reviewBodyPlaceholder: "Qu’avez-vous aimé ? État de l’appareil et service ?", submitReview: "Envoyer l’avis",
      closedTitle: "Boutique fermée", closedText: "Nous revenons bientôt. Contactez-nous sur WhatsApp.",
      timezone: "Heure de Nouakchott", viewAllReviews: "Tous les avis", readMore: "Lire la suite", blog: "Blog", latestArticles: "Derniers articles",
      offerEnds: "L’offre se termine dans", days: "j", hours: "h", minutes: "min", seconds: "s",
      installment: "Payez avec Bankily et obtenez {percent} % de réduction", shippingCalc: "Les frais de livraison sont calculés selon la ville lors de la commande.",
      macbookNote: "macOS installé et prêt à l’emploi", originalDevice: "Appareil 100 % original", warrantyMonths: "Garantie {months} mois",
      chooseSpecs: "Choisir les options", personalization: "Personnalisation", emptyCheckout: "Commande impossible", backToShop: "Retour à la boutique"
    }
  };

  const LANG_KEY = "lang";
  let lang = localStorage.getItem(LS_LANG) === "fr" ? "fr" : "ar";
  let theme = localStorage.getItem(LS_THEME) === "dark" ? "dark" : "light";

  function t(key, vars = {}) {
    let value = I18N[lang]?.[key] ?? I18N.ar[key] ?? key;
    for (const [k, v] of Object.entries(vars)) value = value.replaceAll(`{${k}}`, v);
    return value;
  }
  function L(value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    if (typeof value === "object") return value[lang] ?? value.ar ?? value.fr ?? "";
    return String(value);
  }
  function money(n) {
    return formatCurrency(n);
  }
  function formatDate(value, opts = { year: "numeric", month: "short", day: "numeric" }) {
    try { return new Intl.DateTimeFormat(lang === "ar" ? "ar-MR" : "fr-MR", opts).format(new Date(value)); }
    catch { return String(value || ""); }
  }

  function setLang(next) {
    lang = next === "fr" ? "fr" : "ar";
    localStorage.setItem(LS_LANG, lang);
    applyDocument();
    window.dispatchEvent(new CustomEvent("restore:lang", { detail: lang }));
  }
  function setTheme(next) {
    theme = next === "dark" ? "dark" : "light";
    localStorage.setItem(LS_THEME, theme);
    applyDocument();
  }

  function applyDocument() {
    const html = document.documentElement;
    const dashboard = document.body?.dataset.page === "dashboard";
    if (!dashboard) {
      html.lang = lang;
      html.dir = lang === "ar" ? "rtl" : "ltr";
      html.dataset.lang = lang;
    }
    html.dataset.theme = theme;
    const colors = state.settings.colors || {};
    if (colors.primary) html.style.setProperty("--orange", colors.primary);
    if (colors.ink && theme !== "dark") html.style.setProperty("--ink", colors.ink);
    else html.style.removeProperty("--ink");
    if (colors.purple) html.style.setProperty("--purple", colors.purple);
    if (colors.lavender && theme !== "dark") html.style.setProperty("--lav", colors.lavender);
    else html.style.removeProperty("--lav");
    if (state.settings.radius != null) html.style.setProperty("--radius", `${state.settings.radius}px`);
    const font = state.settings.font;
    if (font) {
      html.style.setProperty("--font-main", font === "Montserrat" ? '"Montserrat", "Noto Sans Arabic", Tahoma, sans-serif' : `"${font}", "Noto Sans Arabic", Tahoma, sans-serif`);
    }
  }

    /* ------------------------------------------------------------------------
     Customer accounts, wishlist and product reviews (storefront)
     ------------------------------------------------------------------------ */
  // These functions delegate to the new implementations at the end of the file
  // for backward compatibility with storefront code

  // LS_CUSTOMER, LS_CUSTOMERS, LS_REVIEWS declared at top
  let currentCustomer = readJSON(LS_CUSTOMER, null);

  function notifyCustomer() {
    window.dispatchEvent(new CustomEvent("restore:customer", { detail: currentCustomer }));
    channel?.postMessage({ type: "customer" });
  }

  // Backward compatible signatures for storefront
  async function customerLogin(email, password) {
    return R.customerLogin({ email, password });
  }

  async function customerRegister(data) {
    return R.customerRegister(data);
  }

  function customerLogout() {
    return R.customerLogout();
  }

  function getCustomer() {
    if (!currentCustomer) currentCustomer = readJSON(LS_CUSTOMER, null);
    return currentCustomer;
  }

  async function customerSyncWishlist(handles = []) {
    return R.customerSyncWishlist(handles);
  }

  async function customerToggleWishlist(handle) {
    return R.customerToggleWishlist(handle);
  }

  function getProductReviews(handle) {
    // Sync version for backward compat - storefront expects sync
    const cust = getCustomer();
    const admin = (state.reviews || []).filter((review) => (review.handle === handle || review.productHandle === handle) && review.approved !== false);
    // Note: async reviews not available in sync context, return admin only
    return admin;
  }

  function getPendingReviews() {
    // Local only for sync backward compat
    const reviews = JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
    return reviews.filter((review) => review.status === "pending");
  }

  function getAllCustomerReviews() {
    return JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
  }

  function customerReviews() {
    const cust = getCustomer();
    return cust ? JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]').filter((review) => review.customerId === cust.id) : [];
  }

  // Async versions exposed via R object
  // submitReview, moderateReview, deleteCustomerReview are async and available via R

/* ------------------------------------------------------------------------
     Query helpers and order utilities
     ------------------------------------------------------------------------ */
  const AR_DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;
  function normalizeText(value) {
    return String(value || "")
      .toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(AR_DIACRITICS, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }
  const STOP_WORDS = new Set(["series", "série", "serie", "the", "and", "with", "من", "سلسلة", "ال", "في"]);
  function queryTokens(q) {
    return normalizeText(q).split(" ").filter((x) => x && !STOP_WORDS.has(x));
  }
  function productSearchText(p) {
    const options = (p.options || []).flatMap((o) => [o.name, ...(o.values || [])]);
    return normalizeText([p.title, p.vendor, p.type, p.handle, p.sku, ...(p.collections || []), ...options, p.condition].join(" "));
  }
  function matchesQuery(p, query) {
    const tokens = queryTokens(query);
    if (!tokens.length) return true;
    const haystack = productSearchText(p);
    return tokens.every((token) => haystack.includes(token));
  }
  function effectivePrice(p) {
    const variants = (p.variants || []).filter((v) => v.available);
    return Math.min(Number(p.price) || 0, ...variants.map((v) => Number(v.price) || Number(p.price) || 0));
  }
  function bestCardImage(p) { return p.image || p.images?.[0] || ""; }
  function isStoreOpen(date = new Date()) {
    const hours = state.settings.hours || {};
    if (hours.closed || hours.maintenance) return false;
    const parts = new Intl.DateTimeFormat("en-GB", { timeZone: state.settings.timezone || "Africa/Nouakchott", weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false }).formatToParts(date);
    const get = (type) => parts.find((p) => p.type === type)?.value;
    const map = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    const day = map[get("weekday")];
    if (!(hours.days || [0, 1, 2, 3, 4, 5, 6]).includes(day)) return false;
    const current = Number(get("hour")) * 60 + Number(get("minute"));
    const [openH, openM] = String(hours.open || "09:00").split(":").map(Number);
    const [closeH, closeM] = String(hours.close || "19:00").split(":").map(Number);
    const start = openH * 60 + openM;
    const end = closeH * 60 + closeM;
    return end < start ? current >= start || current < end : current >= start && current < end;
  }
  function orderId() {
    const d = new Date();
    return `RS-${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  }
  function decrementStock(items) {
    try {
      const next = clone(state);
      for (const item of items || []) {
        const p = next.products.find((x) => x.handle === item.handle);
        if (!p) continue;
        p.stock = Math.max(0, Number(p.stock || 0) - Number(item.qty || 1));
        p.lowStock = p.stock <= Number(next.settings.lowStockThreshold || 2);
      }
      next.updatedAt = nowISO();
      state = next;
      writeJSON(LS_STATE, state);
      channel?.postMessage({ type: "state", updatedAt: state.updatedAt });
    } catch (err) {
      console.warn("Restore: could not update local stock", err);
    }
  }
  function statusMeta(id) {
    const map = {
      new: { label: txt("جديد", "Nouveau"), color: "#ff6400" },
      confirmed: { label: txt("مؤكد", "Confirmé"), color: "#0b6fb8" },
      preparing: { label: txt("قيد التجهيز", "En préparation"), color: "#8e44ad" },
      shipped: { label: txt("تم الشحن", "Expédié"), color: "#00a651" },
      delivered: { label: txt("تم التسليم", "Livré"), color: "#2e7d32" },
      cancelled: { label: txt("ملغي", "Annulé"), color: "#c0392b" },
      returned: { label: txt("مرتجع", "Retourné"), color: "#7f8c8d" }
    };
    return map[id] || map.new;
  }

  /* ------------------------------------------------------------------------
     Local orders / abandoned / audit
     ------------------------------------------------------------------------ */
  function getOrders() { return readJSON(LS_ORDERS, []); }
  function saveOrders(orders) {
    writeJSON(LS_ORDERS, orders);
    channel?.postMessage({ type: "orders" });
    window.dispatchEvent(new CustomEvent("restore:orders"));
  }
  function addOrder(order) {
    const orders = getOrders();
    orders.unshift(order);
    saveOrders(orders);
    if (REMOTE) {
      supa("/rest/v1/" + CFG.ordersTable, {
        method: "POST",
        body: JSON.stringify({ id: order.id, data: order, status: order.status, created_at: order.createdAt }),
        headers: { Prefer: "resolution=merge-duplicates" }
      }).catch((err) => console.warn("Restore: remote order failed", err));
    }
    return order;
  }
  function updateOrder(id, patch) {
    const orders = getOrders().map((o) => (o.id === id ? { ...o, ...patch } : o));
    saveOrders(orders);
    if (REMOTE) {
      const order = orders.find((o) => o.id === id);
      if (order) supa(`/rest/v1/${CFG.ordersTable}?id=eq.${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify({ data: order, status: order.status }) }, true).catch(() => {});
    }
    return orders.find((o) => o.id === id);
  }
  function getAbandoned() { return readJSON(LS_ABANDONED, []); }
  function saveAbandoned(entry) {
    const rows = getAbandoned();
    const existing = rows.find((x) => normalizeDigits(x.phone) === normalizeDigits(entry.phone) && x.status === "open");
    if (existing) Object.assign(existing, entry, { updatedAt: nowISO() });
    else rows.unshift({ id: `ab_${Date.now()}`, createdAt: nowISO(), status: "open", ...entry });
    writeJSON(LS_ABANDONED, rows.slice(0, 100));
    channel?.postMessage({ type: "abandoned" });
    if (REMOTE && entry.phone) {
      const row = rows.find((x) => normalizeDigits(x.phone) === normalizeDigits(entry.phone) && x.status === "open");
      supa(`/rest/v1/${CFG.abandonedTable}`, { method: "POST", body: JSON.stringify({ id: row.id, data: row, created_at: row.createdAt }), headers: { Prefer: "resolution=merge-duplicates" } }).catch(() => {});
    }
  }
  function removeAbandoned(id) {
    writeJSON(LS_ABANDONED, getAbandoned().filter((x) => x.id !== id));
    channel?.postMessage({ type: "abandoned" });
  }
  function getAudit() { return readJSON(LS_AUDIT, []); }
  function addAudit(action, actor = session?.username || "owner") {
    const rows = getAudit();
    rows.unshift({ id: uid("log"), action, actor, at: nowISO() });
    writeJSON(LS_AUDIT, rows.slice(0, 500));
    if (REMOTE && session?.accessToken) {
      supa(`/rest/v1/${CFG.auditTable}`, { method: "POST", body: JSON.stringify({ id: rows[0].id, data: rows[0], created_at: rows[0].at }) }, true).catch(() => {});
    }
    channel?.postMessage({ type: "audit" });
  }

  /* ------------------------------------------------------------------------
     Supabase REST helpers
     ------------------------------------------------------------------------ */
  function remoteUrl(path) { return `${CFG.supabaseUrl.replace(/\/$/, "")}${path}`; }
  async function supa(path, options = {}, auth = false) {
    if (!REMOTE) throw new Error("Supabase is not configured");
    const headers = {
      apikey: CFG.supabaseAnonKey,
      "Content-Type": "application/json",
      ...(options.headers || {})
    };
    if (auth && session?.accessToken) headers.Authorization = `Bearer ${session.accessToken}`;
    const res = await fetch(remoteUrl(path), { ...options, headers });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Supabase ${res.status}: ${text.slice(0, 200)}`);
    }
    if (res.status === 204) return null;
    return res.json().catch(() => null);
  }
  async function uploadMedia(dataUrl, folder = "uploads") {
    if (!REMOTE) return null;
    if (!(await remoteSessionValid())) throw new Error("انتهت جلسة Supabase. أعد تسجيل الدخول.");
    const blob = await (await fetch(dataUrl)).blob();
    const extension = ({ "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif", "image/svg+xml": "svg" })[blob.type] || "webp";
    const stamp = new Date().toISOString().slice(0, 10);
    const id = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);
    const objectPath = `${folder}/${stamp}/${id}.${extension}`;
    const res = await fetch(remoteUrl(`/storage/v1/object/${encodeURIComponent(CFG.mediaBucket)}/${objectPath.split("/").map(encodeURIComponent).join("/")}`), {
      method: "POST",
      headers: {
        apikey: CFG.supabaseAnonKey,
        Authorization: `Bearer ${session.accessToken}`,
        "Content-Type": blob.type || "application/octet-stream",
        "x-upsert": "false"
      },
      body: blob
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Storage ${res.status}: ${text.slice(0, 160)}`);
    }
    return remoteUrl(`/storage/v1/object/public/${encodeURIComponent(CFG.mediaBucket)}/${objectPath.split("/").map(encodeURIComponent).join("/")}`);
  }

  async function remoteLogin(email, password) {
    const res = await fetch(remoteUrl("/auth/v1/token?grant_type=password"), {
      method: "POST",
      headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) throw new Error("بيانات الدخول غير صحيحة / Identifiants incorrects");
    const data = await res.json();
    session = {
      mode: "supabase",
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresAt: Date.now() + (data.expires_in || 3600) * 1000,
      email: data.user?.email,
      username: data.user?.email,
      role: "owner",
      name: data.user?.user_metadata?.full_name || data.user?.email,
      mustChange: Boolean(data.user?.user_metadata?.must_change_password)
    };
    writeJSON(LS_SESSION, session);
    return session;
  }
  async function remoteSessionValid() {
    if (!REMOTE || !session?.accessToken) return false;
    if (session.mode !== "supabase") return true;
    if (session.expiresAt && session.expiresAt > Date.now() + 30000) return true;
    if (!session.refreshToken) return false;
    try {
      const res = await fetch(remoteUrl("/auth/v1/token?grant_type=refresh_token"), {
        method: "POST",
        headers: { apikey: CFG.supabaseAnonKey, "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: session.refreshToken })
      });
      if (!res.ok) return false;
      const data = await res.json();
      session = { ...session, accessToken: data.access_token, refreshToken: data.refresh_token, expiresAt: Date.now() + (data.expires_in || 3600) * 1000 };
      writeJSON(LS_SESSION, session);
      return true;
    } catch { return false; }
  }

  async function loadRemoteState() {
    if (!REMOTE) return false;
    try {
      const rows = await supa(`/rest/v1/${CFG.stateTable}?id=eq.main&select=id,data,updated_at`);
      const remote = rows?.[0];
      if (!remote?.data) return false;
      const remoteStamp = Date.parse(remote.updated_at || remote.data.updatedAt || 0) || 0;
      const localStamp = Date.parse(state.updatedAt || 0) || 0;
      if (remoteStamp > localStamp) {
        state = hydrate(remote.data);
        writeJSON(LS_STATE, state);
        window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "remote" } }));
        return true;
      }
    } catch (err) {
      console.warn("Restore: state sync failed", err);
    }
    return false;
  }
  async function publish(next = state) {
    next.updatedAt = nowISO();
    next.version = Number(next.version || 0) + 1;
    state = hydrate(next);
    const stored = writeJSON(LS_STATE, state);
    localStorage.removeItem(LS_DRAFT);
    channel?.postMessage({ type: "state", updatedAt: state.updatedAt });
    window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "local" } }));
    if (!stored) throw new Error("تعذر حفظ البيانات محليًا. مساحة التخزين ممتلئة.");
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("انتهت جلسة Supabase. أعد تسجيل الدخول.");
      await supa(`/rest/v1/${CFG.stateTable}`, {
        method: "POST",
        body: JSON.stringify({ id: "main", data: state, updated_at: state.updatedAt }),
        headers: { Prefer: "resolution=merge-duplicates,return=minimal" }
      }, true);
    }
    return state;
  }
  function saveDraft(next = state) {
    next.updatedAt = nowISO();
    draft = hydrate(next);
    writeJSON(LS_DRAFT, draft);
    return draft;
  }
  function discardDraft() {
    localStorage.removeItem(LS_DRAFT);
    draft = null;
  }
  function useDraft() {
    if (!draft) return state;
    state = hydrate(draft);
    applyDocument();
    return state;
  }
  function resetLocalDemo() {
    [LS_STATE, LS_DRAFT, LS_MANAGERS, LS_ORDERS, LS_ABANDONED, LS_AUDIT, LS_SESSION, LS_CUSTOMERS, LS_REVIEWS, LS_CUSTOMER].forEach((k) => localStorage.removeItem(k));
    location.reload();
  }

  // Load remote state on boot. The UI renders local defaults first, then reloads
  // when a newer published state arrives.
  if (REMOTE) {
    loadRemoteState();
    setInterval(loadRemoteState, Math.max(2500, Number(CFG.pollMs) || 5000));
    setInterval(() => {
      if (document.body?.dataset.page === "dashboard") return;
      if (session?.mode !== "supabase") return;
      remoteSessionValid();
    }, 60000);
  }
  channel?.addEventListener("message", (event) => {
    if (event.data?.type === "state") window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "tab" } }));
    if (event.data?.type === "orders") window.dispatchEvent(new CustomEvent("restore:orders", { detail: { source: "tab" } }));
    if (event.data?.type === "reviews") notifyReviews();
    if (event.data?.type === "customer") notifyCustomer();
  });
  window.addEventListener("storage", (event) => {
    if (event.key === LS_STATE) window.dispatchEvent(new CustomEvent("restore:changed", { detail: { source: "storage" } }));
    if (event.key === LS_ORDERS) window.dispatchEvent(new CustomEvent("restore:orders", { detail: { source: "storage" } }));
    if (event.key === LS_REVIEWS) notifyReviews();
    if (event.key === LS_CUSTOMER || event.key === LS_CUSTOMERS) notifyCustomer();
  });

  /* ------------------------------------------------------------------------
     Auth / managers
     ------------------------------------------------------------------------ */
  async function login(identifier, password) {
    if (REMOTE) {
      session = null;
      const result = await remoteLogin(identifier.includes("@") ? identifier : `${identifier}@restore.mr`, password);
      return result;
    }
    const user = managers.find((m) => m.username.toLowerCase() === String(identifier).trim().toLowerCase());
    if (!user) throw new Error("اسم المستخدم غير موجود / Utilisateur introuvable");
    const hash = await sha256(password);
    if (hash !== user.passwordHash) throw new Error("كلمة المرور غير صحيحة / Mot de passe incorrect");
    session = { mode: "local", username: user.username, role: user.role, name: L(user.name), mustChange: Boolean(user.mustChange), loggedAt: Date.now() };
    writeJSON(LS_SESSION, session);
    return session;
  }
  async function changePassword(username, currentPassword, newPassword, whatsapp) {
    if (REMOTE) {
      if (!(await remoteSessionValid())) throw new Error("انتهت الجلسة");
      const res = await fetch(remoteUrl("/auth/v1/user"), {
        method: "PUT",
        headers: { apikey: CFG.supabaseAnonKey, Authorization: `Bearer ${session.accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify({ password: newPassword, data: { must_change_password: false, whatsapp } })
      });
      if (!res.ok) throw new Error("تعذر تحديث كلمة المرور في Supabase");
      session = { ...session, mustChange: false };
      writeJSON(LS_SESSION, session);
    } else {
      const idx = managers.findIndex((m) => m.username === username);
      if (idx < 0) throw new Error("المستخدم غير موجود");
      const hashCurrent = await sha256(currentPassword);
      if (hashCurrent !== managers[idx].passwordHash) throw new Error("كلمة المرور الحالية غير صحيحة");
      managers[idx].passwordHash = await sha256(newPassword);
      managers[idx].mustChange = false;
      managers[idx].whatsapp = normalizeDigits(whatsapp);
      writeJSON(LS_MANAGERS, managers);
      session = { ...session, mustChange: false };
      writeJSON(LS_SESSION, session);
    }
    if (whatsapp) {
      const next = clone(state);
      next.settings.whatsapp = normalizeDigits(whatsapp);
      next.settings.phone = String(whatsapp).startsWith("+") ? whatsapp : `+${normalizeDigits(whatsapp)}`;
      next.settings.phoneDisplay = formatPhone(next.settings.phone);
      state = next;
      writeJSON(LS_STATE, state);
    }
    return session;
  }
  function formatPhone(value) {
    const d = normalizeDigits(value);
    if (d.startsWith("222") && d.length >= 11) return `+222 ${d.slice(3, 5)} ${d.slice(5, 7)} ${d.slice(7, 9)} ${d.slice(9, 11)}`.trim();
    if (d.length === 8) return `+222 ${d.slice(0, 2)} ${d.slice(2, 4)} ${d.slice(4, 6)} ${d.slice(6, 8)}`;
    return value || "";
  }
  function currentSession() {
    if (!session) return null;
    if (session.mode === "local" && session.loggedAt && Date.now() - session.loggedAt > 12 * 3600 * 1000) {
      logout();
      return null;
    }
    return session;
  }
  function logout() {
    session = null;
    localStorage.removeItem(LS_SESSION);
    window.dispatchEvent(new CustomEvent("restore:logout"));
  }
  function addManager(data) {
    const username = String(data.username || "").trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,32}$/.test(username)) throw new Error("اسم المستخدم غير صالح");
    if (managers.some((m) => m.username === username)) throw new Error("اسم المستخدم مستخدم بالفعل");
    if (!data.password || data.password.length < 8) throw new Error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
    managers.push({ id: uid("m"), username, name: txt(data.nameAr || data.name || username, data.nameFr || data.name || username), role: data.role === "owner" ? "owner" : "manager", passwordHash: "", mustChange: true, whatsapp: normalizeDigits(data.whatsapp || "") });
    return sha256(data.password).then((hash) => {
      managers[managers.length - 1].passwordHash = hash;
      writeJSON(LS_MANAGERS, managers);
      addAudit(`أضاف مديرًا: ${username}`);
      return managers[managers.length - 1];
    });
  }
  function updateManager(id, patch) {
    managers = managers.map((m) => (m.id === id ? { ...m, ...patch } : m));
    writeJSON(LS_MANAGERS, managers);
  }
  function deleteManager(id) {
    const m = managers.find((x) => x.id === id);
    if (!m) return;
    if (m.role === "owner" && managers.filter((x) => x.role === "owner").length <= 1) throw new Error("لا يمكن حذف المالك الوحيد");
    managers = managers.filter((x) => x.id !== id);
    writeJSON(LS_MANAGERS, managers);
    addAudit(`حذف مديرًا: ${m.username}`);
  }
  function managerPublic() {
    return managers.map(({ passwordHash, ...m }) => m);
  }


  /* ------------------------------------------------------------------------
     Supabase Auth Integration
     ------------------------------------------------------------------------ */
  let authListenerAttached = false;
  function attachAuthListener() {
    if (authListenerAttached || !REMOTE || !window.supabase) return;
    authListenerAttached = true;
    const { data: { subscription } } = window.supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        await handleSupabaseSignIn(session);
      } else if (event === 'SIGNED_OUT') {
        handleSupabaseSignOut();
      } else if (event === 'TOKEN_REFRESHED' && session) {
        authSession = session;
      }
    });
  }

  let authSession = null;
  async function initSupabaseAuth() {
    if (!REMOTE || !window.supabase) return;
    const { data: { session } } = await window.supabase.auth.getSession();
    if (session) {
      authSession = session;
      await handleSupabaseSignIn(session);
    }
    attachAuthListener();
  }

  async function handleSupabaseSignIn(session) {
    authSession = session;
    // Get or create customer profile
    const { data: customer } = await supa(`/rest/v1/restore_customers?auth_id=eq.${session.user.id}&select=*`);
    if (customer && customer[0]) {
      currentCustomer = customer[0];
    } else {
      // Create customer profile
      const { data: newCustomer } = await supa(`/rest/v1/restore_customers`, {
        method: 'POST',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify({
          auth_id: session.user.id,
          name: session.user.user_metadata.full_name || session.user.email?.split('@')[0] || 'Customer',
          email: session.user.email,
          phone: session.user.user_metadata.phone || ''
        })
      });
      if (newCustomer && newCustomer[0]) currentCustomer = newCustomer[0];
    }
    // Sync wishlist from customer profile
    if (currentCustomer?.wishlist?.length) {
      localStorage.setItem('restore_wish_v1', JSON.stringify(currentCustomer.wishlist));
    }
    // Sync addresses
    if (currentCustomer?.addresses?.length) {
      state.settings.savedAddresses = currentCustomer.addresses;
      writeJSON(LS_STATE, state);
    }
    window.dispatchEvent(new CustomEvent('restore:customerLogin', { detail: currentCustomer }));
  }

  function handleSupabaseSignOut() {
    authSession = null;
    currentCustomer = null;
    localStorage.removeItem('restore_wish_v1');
    window.dispatchEvent(new CustomEvent('restore:customerLogout'));
  }

  /* ------------------------------------------------------------------------
     Customer Accounts (Local + Supabase)
     ------------------------------------------------------------------------ */
  // currentCustomer is declared in the backward-compat section above

  function loadLocalCustomer() {
    try {
      const data = localStorage.getItem(LS_CUSTOMER);
      if (data) currentCustomer = JSON.parse(data);
    } catch {}
  }
  loadLocalCustomer();

  function saveLocalCustomer() {
    if (currentCustomer) localStorage.setItem(LS_CUSTOMER, JSON.stringify(currentCustomer));
  }

  function hashPassword(pwd) {
    return sha256(pwd + 'restore-salt-2026');
  }

  async function customerRegister({ name, phone, email, password }) {
    const normalizedPhone = normalizeDigits(phone);
    // Check if exists locally
    const existing = JSON.parse(localStorage.getItem('restore_customers_v1') || '[]')
      .find(c => c.phone === normalizedPhone || c.email === email);
    if (existing) throw new Error('الحساب موجود بالفعل');

    const customer = {
      id: uid('cust'),
      name,
      phone: normalizedPhone,
      email,
      passwordHash: await hashPassword(password),
      addresses: [],
      wishlist: [],
      createdAt: nowISO()
    };
    const customers = JSON.parse(localStorage.getItem('restore_customers_v1') || '[]');
    customers.push(customer);
    localStorage.setItem('restore_customers_v1', JSON.stringify(customers));
    currentCustomer = customer;
    saveLocalCustomer();
    // Also create in Supabase if remote
    if (REMOTE) {
      try {
        await supa(`/rest/v1/restore_customers`, {
          method: 'POST',
          body: JSON.stringify({ ...customer, auth_id: null })
        });
      } catch {}
    }
    window.dispatchEvent(new CustomEvent('restore:customerLogin', { detail: currentCustomer }));
    return customer;
  }

  async function customerLogin({ phone, email, password }) {
    const normalizedPhone = phone ? normalizeDigits(phone) : null;
    // Try Supabase first if remote
    if (REMOTE && window.supabase) {
      const identifier = email || phone;
      const { data, error } = await window.supabase.auth.signInWithPassword({
        email: email || `${normalizedPhone}@restore.local`,
        password
      });
      if (!error && data.session) {
        await handleSupabaseSignIn(data.session);
        return currentCustomer;
      }
      // If Supabase auth fails, fall back to local
    }
    // Local auth
    const customers = JSON.parse(localStorage.getItem('restore_customers_v1') || '[]');
    const customer = customers.find(c => 
      (normalizedPhone && c.phone === normalizedPhone) || 
      (email && c.email === email)
    );
    if (!customer) throw new Error('الحساب غير موجود');
    if (customer.passwordHash !== await hashPassword(password)) {
      throw new Error('كلمة المرور غير صحيحة');
    }
    currentCustomer = customer;
    saveLocalCustomer();
    window.dispatchEvent(new CustomEvent('restore:customerLogin', { detail: currentCustomer }));
    return customer;
  }

  function customerLogout() {
    currentCustomer = null;
    localStorage.removeItem(LS_CUSTOMER);
    if (REMOTE && window.supabase) {
      window.supabase.auth.signOut();
    }
    window.dispatchEvent(new CustomEvent('restore:customerLogout'));
  }

  function getCustomer() {
    return currentCustomer;
  }

  function customerSyncWishlist() {
    if (!currentCustomer) return;
    const wish = readWish();
    if (REMOTE && currentCustomer.auth_id) {
      supa(`/rest/v1/restore_customers?auth_id=eq.${currentCustomer.auth_id}`, {
        method: 'PATCH',
        body: JSON.stringify({ wishlist: Array.from(wish) })
      });
    } else {
      currentCustomer.wishlist = Array.from(wish);
      saveLocalCustomer();
      const customers = JSON.parse(localStorage.getItem('restore_customers_v1') || '[]');
      const idx = customers.findIndex(c => c.id === currentCustomer.id);
      if (idx >= 0) {
        customers[idx] = currentCustomer;
        localStorage.setItem('restore_customers_v1', JSON.stringify(customers));
      }
    }
  }

  function customerToggleWishlist(handle) {
    const wish = readWish();
    if (wish.has(handle)) {
      wish.delete(handle);
    } else {
      wish.add(handle);
    }
    writeWish(wish);
    customerSyncWishlist();
    return wish.has(handle);
  }

  function customerAddAddress(address) {
    if (!currentCustomer) return;
    const addr = { ...address, id: uid('addr'), createdAt: nowISO() };
    currentCustomer.addresses = [...(currentCustomer.addresses || []), addr];
    saveLocalCustomer();
    if (REMOTE && currentCustomer.auth_id) {
      supa(`/rest/v1/restore_customers?auth_id=eq.${currentCustomer.auth_id}`, {
        method: 'PATCH',
        body: JSON.stringify({ addresses: currentCustomer.addresses })
      });
    }
    return addr;
  }

  function customerUpdateAddress(id, patch) {
    if (!currentCustomer) return;
    currentCustomer.addresses = (currentCustomer.addresses || []).map(a => a.id === id ? { ...a, ...patch } : a);
    saveLocalCustomer();
    if (REMOTE && currentCustomer.auth_id) {
      supa(`/rest/v1/restore_customers?auth_id=eq.${currentCustomer.auth_id}`, {
        method: 'PATCH',
        body: JSON.stringify({ addresses: currentCustomer.addresses })
      });
    }
  }

  function customerDeleteAddress(id) {
    if (!currentCustomer) return;
    currentCustomer.addresses = (currentCustomer.addresses || []).filter(a => a.id !== id);
    saveLocalCustomer();
    if (REMOTE && currentCustomer.auth_id) {
      supa(`/rest/v1/restore_customers?auth_id=eq.${currentCustomer.auth_id}`, {
        method: 'PATCH',
        body: JSON.stringify({ addresses: currentCustomer.addresses })
      });
    }
  }

  /* ------------------------------------------------------------------------
     Reviews/Comments System
     ------------------------------------------------------------------------ */
  async function submitReview({ productHandle, rating, title, body }) {
    if (!currentCustomer) throw new Error('يجب تسجيل الدخول لتترك تقييم');
    if (!rating || rating < 1 || rating > 5) throw new Error('التقييم يجب أن يكون بين 1 و 5');

    const review = {
      product_handle: productHandle,
      customer_id: currentCustomer.id,
      customer_name: currentCustomer.name,
      rating,
      title: title || '',
      body: body || '',
      status: 'pending',
      created_at: nowISO()
    };

    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_reviews`, {
        method: 'POST',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(review)
      });
      if (data && data[0]) return data[0];
    }
    // Local fallback
    const reviews = JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
    review.id = uid('rev');
    reviews.push(review);
    localStorage.setItem('restore_reviews_v1', JSON.stringify(reviews));
    return review;
  }

  async function getProductReviews(productHandle) {
    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_reviews?product_handle=eq.${productHandle}&status=eq.approved&order=created_at.desc`);
      return data || [];
    }
    const reviews = JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
    return reviews.filter(r => r.product_handle === productHandle && r.status === 'approved')
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }

  async function getPendingReviews() {
    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_reviews?status=eq.pending&order=created_at.desc`);
      return data || [];
    }
    const reviews = JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
    return reviews.filter(r => r.status === 'pending')
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }

  async function getAllCustomerReviews() {
    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_reviews?order=created_at.desc`);
      return data || [];
    }
    return JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
  }

  async function moderateReview(reviewId, action) { // action: 'approve' | 'reject'
    if (REMOTE) {
      const status = action === 'approve' ? 'approved' : 'rejected';
      await supa(`/rest/v1/restore_reviews?id=eq.${reviewId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      return true;
    }
    const reviews = JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
    const idx = reviews.findIndex(r => r.id === reviewId);
    if (idx >= 0) {
      reviews[idx].status = action === 'approve' ? 'approved' : 'rejected';
      localStorage.setItem('restore_reviews_v1', JSON.stringify(reviews));
      return true;
    }
    return false;
  }

  async function deleteCustomerReview(reviewId) {
    if (REMOTE) {
      await supa(`/rest/v1/restore_reviews?id=eq.${reviewId}`, { method: 'DELETE' });
      return true;
    }
    const reviews = JSON.parse(localStorage.getItem('restore_reviews_v1') || '[]');
    const filtered = reviews.filter(r => r.id !== reviewId);
    localStorage.setItem('restore_reviews_v1', JSON.stringify(filtered));
    return true;
  }

  /* ------------------------------------------------------------------------
     Currency Mode (Old vs New MRU)
     ------------------------------------------------------------------------ */
  const LS_CURRENCY_MODE = 'restore_currency_mode_v1';
  let currencyMode = localStorage.getItem(LS_CURRENCY_MODE) || 'new'; // 'old' or 'new'

  function getCurrencyMode() {
    return currencyMode;
  }

  function setCurrencyMode(mode) {
    if (mode !== 'old' && mode !== 'new') return;
    currencyMode = mode;
    localStorage.setItem(LS_CURRENCY_MODE, mode);
    window.dispatchEvent(new CustomEvent('restore:currencyMode', { detail: mode }));
    // Refresh price displays
    window.dispatchEvent(new CustomEvent('restore:changed', { detail: { source: 'currency' } }));
  }

  function formatCurrency(amount) {
    const num = Number(amount) || 0;
    const formatted = num.toLocaleString(lang === 'ar' ? 'en-US' : 'fr-FR', { maximumFractionDigits: 0 });
    const suffix = currencyMode === 'old' ? ' أوقية قديمة' : ` ${L(state.settings.country.currency)}`;
    return lang === 'ar' ? `${formatted}${suffix}` : `${formatted} ${L(state.settings.country.currency)}`;
  }

  /* ------------------------------------------------------------------------
     Payment Methods with Images
     ------------------------------------------------------------------------ */
  // Payment methods now support: { id, name, color, active, discount, note, image, logo }
  // image/logo can be uploaded to Supabase storage

  /* ------------------------------------------------------------------------
     Pages Management
     ------------------------------------------------------------------------ */
  async function getPages() {
    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_pages?order=created_at.desc`);
      return data || [];
    }
    return state.pages || [];
  }

  async function getPage(slug) {
    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_pages?slug=eq.${slug}&visible=eq.true&select=*`);
      return data?.[0] || null;
    }
    return (state.pages || []).find(p => p.slug === slug && p.visible !== false) || null;
  }

  async function savePage(pageData) { // { slug, title, body, seo_title, seo_description, visible }
    if (REMOTE) {
      const { data } = await supa(`/rest/v1/restore_pages`, {
        method: 'POST',
        headers: { Prefer: 'return=representation', 'On-Conflict': 'slug' },
        body: JSON.stringify({ ...pageData, updated_at: nowISO() })
      });
      return data?.[0];
    }
    // Local: merge into state.pages
    const pages = state.pages || [];
    const idx = pages.findIndex(p => p.slug === pageData.slug);
    const page = { ...pageData, id: pageData.id || uid('pg'), updatedAt: nowISO() };
    if (idx >= 0) pages[idx] = page;
    else pages.push(page);
    const next = clone(state);
    next.pages = pages;
    state = hydrate(next);
    writeJSON(LS_STATE, state);
    return page;
  }

  async function deletePage(slug) {
    if (REMOTE) {
      await supa(`/rest/v1/restore_pages?slug=eq.${slug}`, { method: 'DELETE' });
      return true;
    }
    const pages = (state.pages || []).filter(p => p.slug !== slug);
    const next = clone(state);
    next.pages = pages;
    state = hydrate(next);
    writeJSON(LS_STATE, state);
    return true;
  }

  /* ------------------------------------------------------------------------
     Owner Settings (Social, Phone, Password)
     ------------------------------------------------------------------------ */
  async function updateOwnerSettings(settings) { // { social, phone, email, address, etc }
    const next = clone(state);
    next.settings = { ...next.settings, ...settings };
    state = hydrate(next);
    writeJSON(LS_STATE, state);
    if (REMOTE) {
      await publish(state);
    }
    return state.settings;
  }

  async function changeOwnerPassword(currentPassword, newPassword) {
    // For local demo, just update the owner manager
    const owner = managers.find(m => m.role === 'owner');
    if (!owner) throw new Error('المالك غير موجود');
    if (owner.passwordHash !== await sha256(currentPassword)) {
      throw new Error('كلمة المرور الحالية غير صحيحة');
    }
    owner.passwordHash = await sha256(newPassword);
    owner.mustChange = false;
    writeJSON(LS_MANAGERS, managers);
    // If remote, also update Supabase auth
    if (REMOTE && window.supabase && authSession) {
      await window.supabase.auth.updateUser({ password: newPassword });
    }
    addAudit('تم تغيير كلمة مرور المالك');
    return true;
  }

  // Initialize customer on load
  if (typeof window !== 'undefined') {
    loadLocalCustomer();
    if (REMOTE) {
      // Wait for supabase to be ready
      if (window.supabase) initSupabaseAuth();
      else window.addEventListener('supabaseReady', initSupabaseAuth);
    }
  }

  /* ------------------------------------------------------------------------
     Public API
     ------------------------------------------------------------------------ */
  const R = {
    config: CFG,
    remote: REMOTE,
    get state() { return state; },
    set state(v) { state = v; },
    get store() { return state; },
    get draft() { return draft; },
    get lang() { return lang; },
    get theme() { return theme; },
    get managers() { return managerPublic(); },
    get orders() { return getOrders(); },
    get abandoned() { return getAbandoned(); },
    get audit() { return getAudit(); },
    t, L, money, formatDate, formatPhone, normalizeText, matchesQuery, queryTokens,
    setLang, setTheme, applyDocument, clone, uid, uploadMedia,
    effectivePrice, bestCardImage, isStoreOpen,
    customerLogin, customerRegister, customerLogout, getCustomer,
    customerSyncWishlist, customerToggleWishlist,
    submitReview, moderateReview, deleteCustomerReview,
    getProductReviews, getPendingReviews, getAllCustomerReviews, customerReviews,
    addReview: submitReview, getApprovedReviews: getProductReviews,
    currencyMode, formatCurrency, setCurrencyMode,
    orderId, statusMeta, decrementStock,
    login, logout, currentSession, changePassword, addManager, updateManager, deleteManager,
    getOrders, addOrder, updateOrder, getAbandoned, saveAbandoned, removeAbandoned,
    getPages, getPage, savePage, deletePage,
    updateOwnerSettings, changeOwnerPassword,
    getAudit, addAudit,
    publish, saveDraft, discardDraft, useDraft, resetLocalDemo, loadRemoteState,
    supa, remoteSessionValid,
    get statuses() { return ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled", "returned"]; }
  };
  window.RESTORE = R;
})();
