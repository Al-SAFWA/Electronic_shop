-- Restore store - Supabase schema, row level security and media bucket.
-- Run this once in the Supabase SQL editor (Project > SQL Editor > New query).
-- The dashboard uses the publishable/anon key. Never put the service_role key
-- in assets/js/config.js or anywhere in this static site.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table if not exists public.restore_state (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.restore_orders (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  status text not null default 'new',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_orders_created_idx on public.restore_orders (created_at desc);
create index if not exists restore_orders_status_idx on public.restore_orders (status);

create table if not exists public.restore_abandoned (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_abandoned_created_idx on public.restore_abandoned (created_at desc);

create table if not exists public.restore_audit (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists restore_audit_created_idx on public.restore_audit (created_at desc);

-- Customers (for wishlist, reviews, addresses)
create table if not exists public.restore_customers (
  id uuid primary key default gen_random_uuid(),
  auth_id uuid unique, -- links to auth.users
  name text,
  phone text,
  email text,
  password_hash text, -- for local auth fallback
  addresses jsonb default '[]'::jsonb,
  wishlist jsonb default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_customers_auth_idx on public.restore_customers (auth_id);
create index if not exists restore_customers_phone_idx on public.restore_customers (phone);

-- Reviews/Comments (with moderation)
create table if not exists public.restore_reviews (
  id uuid primary key default gen_random_uuid(),
  product_handle text not null,
  customer_id uuid references public.restore_customers(id) on delete set null,
  customer_name text,
  rating int not null check (rating >= 1 and rating <= 5),
  title text,
  body text,
  status text not null default 'pending', -- pending, approved, rejected
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_reviews_product_idx on public.restore_reviews (product_handle);
create index if not exists restore_reviews_status_idx on public.restore_reviews (status);
create index if not exists restore_reviews_customer_idx on public.restore_reviews (customer_id);

-- Custom Pages
create table if not exists public.restore_pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title jsonb not null, -- {ar: "", fr: ""}
  body jsonb not null,  -- {ar: "", fr: ""}
  seo_title jsonb,
  seo_description jsonb,
  visible boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restore_pages_slug_idx on public.restore_pages (slug);

create or replace function public.restore_set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists restore_orders_touch on public.restore_orders;
create trigger restore_orders_touch before update on public.restore_orders
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_abandoned_touch on public.restore_abandoned;
create trigger restore_abandoned_touch before update on public.restore_abandoned
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_state_touch on public.restore_state;
create trigger restore_state_touch before update on public.restore_state
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_customers_touch on public.restore_customers;
create trigger restore_customers_touch before update on public.restore_customers
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_reviews_touch on public.restore_reviews;
create trigger restore_reviews_touch before update on public.restore_reviews
for each row execute function public.restore_set_updated_at();

drop trigger if exists restore_pages_touch on public.restore_pages;
create trigger restore_pages_touch before update on public.restore_pages
for each row execute function public.restore_set_updated_at();

-- ---------------------------------------------------------------------------
-- Row level security
-- ---------------------------------------------------------------------------
alter table public.restore_state enable row level security;
alter table public.restore_orders enable row level security;
alter table public.restore_abandoned enable row level security;
alter table public.restore_audit enable row level security;
alter table public.restore_customers enable row level security;
alter table public.restore_reviews enable row level security;
alter table public.restore_pages enable row level security;

-- Storefront visitors can read the published state but cannot change it.
drop policy if exists restore_state_public_read on public.restore_state;
create policy restore_state_public_read on public.restore_state
  for select to anon, authenticated using (true);

drop policy if exists restore_state_staff_write on public.restore_state;
create policy restore_state_staff_write on public.restore_state
  for all to authenticated using (true) with check (true);

-- Orders
drop policy if exists restore_orders_public_insert on public.restore_orders;
create policy restore_orders_public_insert on public.restore_orders
  for insert to anon with check (true);

drop policy if exists restore_orders_staff_all on public.restore_orders;
create policy restore_orders_staff_all on public.restore_orders
  for all to authenticated using (true) with check (true);

-- Abandoned carts
drop policy if exists restore_abandoned_public_insert on public.restore_abandoned;
create policy restore_abandoned_public_insert on public.restore_abandoned
  for insert to anon with check (true);

drop policy if exists restore_abandoned_public_update on public.restore_abandoned;
create policy restore_abandoned_public_update on public.restore_abandoned
  for update to anon using (true) with check (true);

drop policy if exists restore_abandoned_staff_all on public.restore_abandoned;
create policy restore_abandoned_staff_all on public.restore_abandoned
  for all to authenticated using (true) with check (true);

-- Audit logs
drop policy if exists restore_audit_staff_all on public.restore_audit;
create policy restore_audit_staff_all on public.restore_audit
  for all to authenticated using (true) with check (true);

-- Customers - can read/write own data, staff can read all
drop policy if exists restore_customers_own_read on public.restore_customers;
create policy restore_customers_own_read on public.restore_customers
  for select to authenticated using (auth_id = auth.uid() or auth.role() = 'authenticated');

drop policy if exists restore_customers_own_write on public.restore_customers;
create policy restore_customers_own_write on public.restore_customers
  for insert to anon, authenticated with check (true); -- allow registration

drop policy if exists restore_customers_own_update on public.restore_customers;
create policy restore_customers_own_update on public.restore_customers
  for update to authenticated using (auth_id = auth.uid()) with check (auth_id = auth.uid());

drop policy if exists restore_customers_staff_all on public.restore_customers;
create policy restore_customers_staff_all on public.restore_customers
  for all to authenticated using (true) with check (true); -- staff can manage all

-- Reviews - public can read approved, customers can create own, staff moderate
drop policy if exists restore_reviews_public_read on public.restore_reviews;
create policy restore_reviews_public_read on public.restore_reviews
  for select to anon, authenticated using (status = 'approved');

drop policy if exists restore_reviews_customer_create on public.restore_reviews;
create policy restore_reviews_customer_create on public.restore_reviews
  for insert to authenticated with check (customer_id = (select id from restore_customers where auth_id = auth.uid()));

drop policy if exists restore_reviews_customer_read_own on public.restore_reviews;
create policy restore_reviews_customer_read_own on public.restore_reviews
  for select to authenticated using (customer_id = (select id from restore_customers where auth_id = auth.uid()));

drop policy if exists restore_reviews_staff_all on public.restore_reviews;
create policy restore_reviews_staff_all on public.restore_reviews
  for all to authenticated using (true) with check (true);

-- Pages - public read visible, staff manage all
drop policy if exists restore_pages_public_read on public.restore_pages;
create policy restore_pages_public_read on public.restore_pages
  for select to anon, authenticated using (visible = true);

drop policy if exists restore_pages_staff_all on public.restore_pages;
create policy restore_pages_staff_all on public.restore_pages
  for all to authenticated using (true) with check (true);

-- ---------------------------------------------------------------------------
-- Media bucket (public read, staff upload)
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'restore-media',
  'restore-media',
  true,
  5242880,
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists restore_media_public_read on storage.objects;
create policy restore_media_public_read on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'restore-media');

drop policy if exists restore_media_staff_insert on storage.objects;
create policy restore_media_staff_insert on storage.objects
  for insert to authenticated
  with check (bucket_id = 'restore-media');

drop policy if exists restore_media_staff_update on storage.objects;
create policy restore_media_staff_update on storage.objects
  for update to authenticated
  using (bucket_id = 'restore-media')
  with check (bucket_id = 'restore-media');

drop policy if exists restore_media_staff_delete on storage.objects;
create policy restore_media_staff_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'restore-media');

-- Explicit grants
grant usage on schema public to anon, authenticated;
grant select on public.restore_state to anon;
grant insert on public.restore_orders to anon;
grant insert, update on public.restore_abandoned to anon;
grant select on public.restore_reviews to anon;
grant select on public.restore_pages to anon;
grant all on public.restore_state, public.restore_orders, public.restore_abandoned, public.restore_audit, public.restore_customers, public.restore_reviews, public.restore_pages to authenticated;
