# Restore + Supabase setup

1. Create a Supabase project.
2. Open **SQL Editor**, paste `supabase/schema.sql`, and run it.
3. In **Authentication > Providers > Email**, enable email/password. Disable public sign-ups
   so only staff accounts you create can write to the store.
4. In **Authentication > Users**, create the owner account with email `owner@restore.mr`
   (or change the login username to match your email). Set a strong password and, if you
   want the forced first-login flow, add `must_change_password: true` to the user metadata.
5. Copy **Project URL** and the **anon/publishable key** into `assets/js/config.js`, or set
   `SUPABASE_URL` and `SUPABASE_ANON_KEY` in Vercel before building.
6. Open `dashboard.html`, sign in, and publish once. That creates the `main` row in
   `restore_state`, which storefront visitors then read anonymously.
7. Uploaded images go to the public `restore-media` bucket through the dashboard.

Notes:
- The anon key is public by design. RLS is what protects customer orders and staff writes.
- Public order insert is required for a static checkout. For high-traffic stores, add an Edge
  Function or Turnstile/reCAPTCHA to rate-limit fake order submissions.
- Do not put a `service_role` key in the site.
