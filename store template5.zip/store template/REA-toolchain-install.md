# REA toolchain installation — complete report

Date: 2026-10-17
Host: Fedora Linux 43 (Workstation), x86_64, no passwordless sudo → **everything installed user-space** under `~/.local/opt/rea`.
REA: `rea-agents@6.5.0` (official `morluto/rea`), MCP registered in OpenCode, skill `reverse-engineer-anything` v42.

---

## 1. What is registered

* **MCP server `rea`** added to `~/.config/opencode/opencode.jsonc` (backup: `opencode.jsonc.rea.backup`), **207 tools**.
* **Skill** installed at `~/.agents/skills/reverse-engineer-anything/` (official copy; my temporary `~/.config/opencode/skills/` copy was removed to avoid a duplicate ID).
* Runtime is pinned to **Node 24.22.0** (`~/.local/opt/rea/node24`) so the native SQLite limits API is available.
* All tool paths are injected via the MCP `environment` block, so the server finds them without touching your shell profile.

> **Status: live and ready.** `rea doctor --client opencode` → **healthy: True** (node 24.22.0 ✅, registration:opencode ✅). The MCP server connects on every launch with **207 tools** (verified after a full reboot: `started_at 2026-10-18T10:28:49Z`). Live over MCP: `inspect_sqlite_database` → `SQLite 3.53.4`, `extract_firmware` → `Unblob 26.6.4`, `inspect_apktool_client` → `Apktool 3.0.3`, `inspect_binary_layout` → `pwntools@4.15.0`, `inspect_signal_decoders` → `sigrok-cli@0.7.2`, `list_frida_devices` ✅.
>
> The MCP command stays the stock `npx -y rea-agents@6.5.0 mcp` (so REA's registration check stays green). Node 24 is selected via the `PATH` entry in the server's `environment`, which is why SQLite works without a non-standard command.

---

## 2. Installed components (all verified working)

| Capability | Component | Version | Path / how it is found | Verification (REA command) |
|---|---|---|---|---|
| Native decompilation | **Ghidra** | 12.1.4 | `GHIDRA_INSTALL_DIR=~/.local/opt/rea/ghidra_12.1.4_PUBLIC` | `analyze`, `function`, `decompile` → pseudo-C ✅ |
| Java for Ghidra/jadx | **Temurin JDK** | 21.0.12.1+1 | `JAVA_HOME=~/.local/opt/rea/jdk-21.0.12.1+1` | Ghidra headless runs ✅ |
| Android decompilation | **jadx-headless-mcp** | 0.7.1 | `REA_JADX_MCP_JAR=~/.local/opt/rea/jadx-headless-mcp-0.7.1-all.jar` | `doctor` → jadx OK ✅ |
| APK resources | **Apktool** | 3.0.3 | `REA_APKTOOL_COMMAND=~/.local/opt/rea/apktool` (wrapper) | `inspect-apktool-client` → 3.0.3 ✅ |
| JS deobfuscation | **Wakaru** | 1.14.0 | `REA_WAKARU_COMMAND=~/.local/opt/rea/wakaru/wakaru` | `recover-javascript-sources` → provider Wakaru ✅ |
| WebAssembly | **WABT** | 1.0.42 | `REA_WABT_BIN_DIRECTORY=~/.local/opt/rea/wabt-1.0.42/bin` | `inspect-wasm-artifact` ✅ |
| ELF/PE binary layout | **pwntools** (+ pyelftools 0.33, unicorn 2.1.2) | 4.15.0 | `REA_PWNTOOLS_PYTHON=~/.local/opt/rea/pwntools-venv/bin/python` | `inspect-binary-layout` (arch/segments/mitigations) ✅ |
| Firmware carving | **Binwalk** | 3.1.0 | `REA_BINWALK_COMMAND=~/.local/opt/rea/cargo-root/bin/binwalk` | `inspect-firmware-regions` ✅ |
| Firmware extraction | **Unblob** | 26.6.4 | `REA_UNBLOB_COMMAND=~/.local/bin/unblob` | `extract-firmware` → provider Unblob ✅ |
| Logic/signal analysis | **sigrok-cli** (+libsigrok/libsigrokdecode/libserialport) | 0.7.2 | `REA_SIGROK_COMMAND=~/.local/opt/rea/sigrok-cli` (wrapper, 112 decoders) | `inspect-signal-decoders` ✅ |
| Debugging / disasm | **Rizin** | 0.7.4 | `REA_RIZIN_COMMAND=~/.local/opt/rea/rizin-cli` (wrapper) | `execute-rizin-command`, `debug-with-rizin` ✅ |
| SQLite databases | **Node.js** native `node:sqlite` | 24.22.0 | MCP command runs under `~/.local/opt/rea/node24` | `inspect-sqlite-database` ✅ |
| Dynamic instrumentation | **Frida** (bundled optional dep of REA) | 17.23.2 | installed with `rea-agents` | `list-frida-devices` ✅ |
| EVM/Solidity bytecode | **evmole** (bundled dep of REA) | 0.9.3 | built into REA | `inspect-evm-interface` ✅ |
| Browser observation | **Google Chrome** + REA CDP provider | system `/usr/bin/google-chrome` | attach over CDP | `list-browser-targets`, `capture-web-screenshot`, `observe-web-session` ✅ |
| Packet capture | **tshark / capinfos** | 4.6.6 (pre-existing) | on `PATH` | `inspect-pcap-capture` available |

Verified available in `rea doctor --client opencode`: **ghidra ✅, jadx ✅**.

---

## 3. Deliberately NOT installed (unavailable / not user-installable)

| Item | Reason |
|---|---|
| **IDA Pro** provider | Commercial licence required. `doctor` reports `ida = NO`. |
| **Hopper** provider | Commercial, macOS-only; REA only offers to install it on macOS. |
| **JEB** provider | Commercial licence required. |
| **Kuna** provider | Commercial/remote service. |
| macOS-native utilities (`inspect_macho`, `inspect_plist`, `observe_native_calls`, `capture_native_ui_scenario`, …) | Require macOS/Xcode. Reported `unsupported_host` — expected on Linux. |
| HarmonyOS/Apple UI tooling (`inspect_asset_catalog`, native UI capture) | Require the vendor SDK / macOS. |
| unblob `sasquatch` / `sasquatch-v4be` (older/variant SquashFS) | The sasquatch fork must be built against zlib/lzma/lzo/lz4 **-devel** headers, which need root on Fedora. Standard SquashFS is still handled by other paths. |
| unblob `unar` (RAR and misc archives) | Needs the GNUstep base libraries (root to install). Rare inside firmware images. |
| REA registrations for other detected AI clients (claude_code, codex, gemini_cli, vscode, antigravity, hermes) | Not touched on purpose — they are separate apps. Additive and reversible with `rea setup --all-detected --yes` (writes `.rea.backup`). They affect only the host-level `environment_healthy` flag, not the OpenCode scope. |

Everything else is installed. The only `unsupported_host` capability groups are the macOS-only ones listed above (10 operations).

---

## 4. Environment variables

Stored in two places:

1. **MCP server** (`~/.config/opencode/opencode.jsonc` → `mcp.rea.environment`) — used by the OpenCode MCP process.
2. **`~/.local/opt/rea/rea-env.sh`** — for command-line use. Source it:

```sh
source ~/.local/opt/rea/rea-env.sh
rea doctor --client opencode
```

Variables set: `PATH`, `JAVA_HOME`, `GHIDRA_INSTALL_DIR`, `REA_JADX_MCP_JAR`, `REA_APKTOOL_COMMAND`, `REA_WAKARU_COMMAND`, `REA_WABT_BIN_DIRECTORY`, `REA_PWNTOOLS_PYTHON`, `REA_SIGROK_COMMAND`, `REA_BINWALK_COMMAND`, `REA_UNBLOB_COMMAND`, `REA_RIZIN_COMMAND`, `REA_OBJDUMP_COMMAND`, `REA_GDB_COMMAND`.

`JAVA_HOME` is intentionally **not** written to `~/.bashrc` (it would change the default Java for all your tools); it is scoped to the REA MCP process and the `rea-env.sh` helper.

---

## 5. Provenance (official sources only)

| Component | Source |
|---|---|
| REA | npm `rea-agents@6.5.0`, GitHub `morluto/rea` |
| Ghidra | `github.com/NationalSecurityAgency/ghidra` tag `Ghidra_12.1.4_build` |
| Temurin JDK 21 | Adoptium `jdk-21.0.12.1+1` |
| Node.js 24 | `nodejs.org/dist/latest-v24.x` (v24.22.0) |
| Wakaru | `github.com/pionxzh/wakaru` v1.14.0 |
| WABT | `github.com/WebAssembly/wabt` 1.0.42 |
| jadx-headless-mcp | `github.com/1013503897/jadx-headless-mcp` v0.7.1 |
| Apktool | `github.com/iBotPeaches/Apktool` v3.0.3 |
| Binwalk | crates.io `binwalk` 3.1.0 (ReFirmLabs) |
| Unblob / pwntools | PyPI `unblob` 26.6.4 / `pwntools` 4.15.0 |
| sigrok / rizin | Fedora 43 RPMs (extracted to user space), sigrok-cli 0.7.2, rizin 0.7.4 |

### SHA-256 (downloaded artifacts)

```
dbf930b076c6b9be08d57c449cacefc3bdd6b71ebd59b3066fc0e1f5b14f9423  apktool_3.0.3.jar
6e5eacf500b64292bfb73c49797c1958f6ee44646e43e868039ae7feb573ff75  jadx-headless-mcp-0.7.1-all.jar
664fa06782a61eda7ed15885134b52525fd565dd77607e642062ceb6cd927c38  wakaru/wakaru
06d447a1cb9a1233a78e7cbd52a75ed079b3e34658ef65475cb93f778c1f54f4  cargo-root/bin/binwalk
807a24dfbd1b0fc328841bead7aaaaba9df7b9c743d138e4941ff794ee4f26e5c  rizin/usr/bin/rizin
03df71b7a57591a59c318ee2429b77fea8b2de30ae02959523789018b9b8feb0  sigrok/usr/bin/sigrok-cli
ce79869e1307ed8ee1e2baa86a412b1eb5b75d10a01006d788a6f968bcfaee94  jdk21.tar.gz
cc2f601cee82d9a5a233302fe307abc600727035fd7d2c3a3571755989e95008  node24.tar.xz
```

Ghidra zip (`ghidra_12.1.4_PUBLIC_20260921.zip`, 543 MB) was verified against the publisher digest: **OK**.

---

## 6. Notes / limitations

* Total footprint of `~/.local/opt/rea` is about **2.7 GB** (Ghidra dominates).
* `sigrok-cli` and `rizin` were taken from Fedora RPMs and extracted to user space because `dnf install` needs root; wrappers set `LD_LIBRARY_PATH` and `SIGROKDECODE_DIR`. Hardware drivers need root udev rules — file-based decoding works.
* `debug-with-rizin` needs an inferior TTY; it is verified with an allocated pseudo-terminal (`/dev/pts/*`).
* Browser tools attach over CDP to an already-running Chrome (`--remote-debugging-port`); they do not launch the browser themselves unless a scenario contract supplies the executable.

---

## 7. Extended tooling added on Fedora (beyond REA's own checklist)

* **QEMU user-mode (static)** — run/analyze foreign-architecture binaries with no root and no binfmt registration. Present: `qemu-aarch64[a_be]`, `qemu-arm[eb]`, `qemu-mips*`, `qemu-riscv32/64`, `qemu-ppc*` (v10.1.5) under `~/.local/opt/rea/extra/bin`.
* **unblob external extractors raised from 8/15 → 13/15**:
  * `lz4`, `lziprecover`, `partclone.restore`, `fsck.erofs` (+ Intel `libqpl`), `jefferson` (JFFS2), `ubireader_extract_files`/`ubireader_extract_images` (UBI images).
  * Fedora RPMs (lz4, lziprecover, erofs-utils, partclone, intel-qpl) extracted to `~/.local/opt/rea/extra/usr`; `jefferson` + `ubi_reader` installed via `uv tool` into `~/.local/bin`.
  * A single shim dir `~/.local/opt/rea/extra/bin` puts them on `PATH`; `fsck.erofs` is a wrapper that injects `LD_LIBRARY_PATH` for `libqpl`.
* The system already provided `liblz4`, `libuuid`, `libbz2`, `liblzo2`, `libicuuc`, `libwavpack`, so most extracted binaries run with no extra library paths.
* **PATH** (both the MCP `environment.PATH` and `rea-env.sh`) is now: `node24/bin : extra/bin : rea/ : ~/.local/bin : /usr/local/bin : /usr/bin : /bin`.

Verification: `unblob --show-external-dependencies` → 13 ✓ / 2 ✗ (only `sasquatch`, `unar` — see §3), and `extract-firmware` runs through the MCP.
