export function createClient(config) {
  const base = String(config?.supabaseUrl || "").replace(/\/$/, "");
  const key = String(config?.supabaseAnonKey || "");
  async function request(path, { method = "GET", body, token, headers = {} } = {}) {
    const res = await fetch(base + path, {
      method,
      headers: { apikey: key, "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
      body: body == null ? undefined : JSON.stringify(body),
    });
    if (!res.ok) throw new Error(await res.text().catch(() => res.statusText));
    if (res.status === 204) return null;
    return res.json().catch(() => null);
  }
  return { request, base, key };
}
