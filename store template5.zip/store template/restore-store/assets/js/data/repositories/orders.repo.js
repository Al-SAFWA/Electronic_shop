export function createOrdersRepo(client, table = "restore_orders") {
  return {
    async list({ token, limit = 500 } = {}) {
      return client.request(`/rest/v1/${table}?select=*&order=created_at.desc&limit=${limit}`, { token });
    },
    async updateStatus(id, status, token) {
      return client.request(`/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, {
        method: "PATCH", token, headers: { Prefer: "return=minimal" }, body: { status, updated_at: new Date().toISOString() }
      });
    }
  };
}
