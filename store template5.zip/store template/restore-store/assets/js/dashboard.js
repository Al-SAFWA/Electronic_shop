/* ==========================================================================
   Restore dashboard application
   ========================================================================== */
import { esc, sanitizeRichHTML } from "./core/dom.js";

const _initDashboard = () => {
  "use strict";

  const R = window.RESTORE;
  if (!R) return;
  const app = document.getElementById("dash-app");
  const modalRoot = document.getElementById("dash-modal-root");
  const LS_DASH_LANG = "restore_dash_lang_v1";

  const clone = (value) => R.clone(value);
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const digits = (value) => String(value ?? "").replace(/\D/g, "");
  const money = (value) => R.money(value);
  const fmtDate = (value) => R.formatDate(value);
  const fmtDateTime = (value) => R.formatDate(value, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  const nowIso = () => new Date().toISOString();

  let dashLang = localStorage.getItem(LS_DASH_LANG) === "fr" ? "fr" : "ar";
  const dt = (ar, fr) => (dashLang === "ar" ? ar : fr);
  const lng = (value) => {
    if (value == null) return "";
    if (typeof value === "string") return value;
    if (typeof value === "object") return value[dashLang] ?? value.ar ?? value.fr ?? "";
    return String(value);
  };

  let model = clone(R.draft || R.state);
  let dirty = Boolean(R.draft);
  let session = R.currentSession();
  let route = (location.hash || "#overview").slice(1);
  let currentTab = "";
  let searchTerm = "";
  let saveTimer;
  let orderBadgeSeen = Number(localStorage.getItem("restore_orders_seen_v1") || 0);
  const openEditors = {};

  const ICONS = {
    overview: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="4" rx="1.5"/><rect x="14" y="11" width="7" height="10" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
    orders: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z"/><path d="M9 8h6M9 12h6"/>',
    cart: '<circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M3 4h2l2.4 11h11L21 7H6"/>',
    products: '<path d="M4 7l8-4 8 4-8 4-8-4z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/>',
    categories: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    content: '<path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    palette: '<circle cx="12" cy="12" r="9"/><circle cx="8.5" cy="9" r="1"/><circle cx="15.5" cy="9" r="1"/><circle cx="9" cy="15" r="1"/><path d="M12 21c-1.2-2.3 1-4 3-4 2 0 3.5 1.5 3.5 3.5 0 .5-2.5.5-6.5.5z"/>',
    marketing: '<path d="M4 9v6h4l8 4V5L8 9H4z"/><path d="M20 9a4 4 0 0 1 0 6"/>',
    payment: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M7 15h4"/>',
    team: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="18" cy="9" r="2"/><path d="M17 14c2.5 0 4 1.5 4 4"/>',
    reports: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.9l.06.06-2.12 2.12-.06-.06a1.7 1.7 0 0 0-1.9-.34 1.7 1.7 0 0 0-1 1.55V21h-3v-.09a1.7 1.7 0 0 0-1-1.55 1.7 1.7 0 0 0-1.9.34l-.06.06L4.2 17.6l.06-.06a1.7 1.7 0 0 0 .34-1.9A1.7 1.7 0 0 0 3.1 14H3v-3h.1a1.7 1.7 0 0 0 1.55-1 1.7 1.7 0 0 0-.34-1.9L4.2 8l2.12-2.12.06.06a1.7 1.7 0 0 0 1.9.34A1.7 1.7 0 0 0 9.3 4.7V4.6h3v.1a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.9-.34l.06-.06L17.4 8l-.06.06a1.7 1.7 0 0 0-.34 1.9 1.7 1.7 0 0 0 1.55 1h.09v3h-.09a1.7 1.7 0 0 0-1.55 1z"/>',
    audit: '<path d="M6 3h12v18H6z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    abandoned: '<path d="M4 4h16v12H9l-5 4V4z"/><path d="M8 9h8M8 12h5"/>',
    reviews: '<path d="M12 3l2.7 5.5 6 .9-4.35 4.25 1.03 6L12 16.9l-5.38 2.8 1.03-6L3.3 9.4l6-.9L12 3z"/>',
    blog: '<path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/><path d="M16 16h.01"/>',
    pages: '<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/>',
    preview: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    publish: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    logout: '<path d="M10 4H5v16h5M14 8l4 4-4 4M8 12h10"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    moon: '<path d="M20 15.5A8.5 8.5 0 0 1 8.5 4a8.5 8.5 0 1 0 11.5 11.5z"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    whatsapp: '<path d="M20.5 11.7a8.5 8.5 0 0 1-12.6 7.5L3.5 20.5l1.3-4.3a8.5 8.5 0 1 1 15.7-4.5z"/><path d="M8.4 7.8c.2-.4.4-.4.7-.4h.5c.2 0 .4 0 .5.4l.8 1.9c.1.2 0 .4-.1.6l-.6.7c-.2.2-.1.3 0 .5.7 1.2 1.7 2.2 2.9 2.9.2.1.4.2.5 0l.7-.8c.2-.2.4-.2.6-.1l1.9.9c.3.1.4.3.4.5 0 1-.5 1.8-1.4 2.1-.6.2-1.4.3-2.3.1-3.6-.8-6.4-3.6-7.2-7.2-.2-1-.1-1.8.1-2.4z"/>',
    external: '<path d="M14 3h7v7M10 14L21 3"/><path d="M21 14v7H3V3h7"/>',
    edit: '<path d="M4 20h4L20 8l-4-4L4 16v4z"/><path d="M14 6l4 4"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    down: '<path d="M18 9l-6 6-6-6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    arrows: '<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
    print: '<path d="M6 9V3h12v6M6 18H4v-7h16v7h-2"/><path d="M6 14h12v7H6z"/>',
    refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 9a7 7 0 0 1 11.4-2L20 9M4 15l2.5 2a7 7 0 0 0 11.4-2"/>',
    chevron: '<path d="M9 5l7 7-7 7"/>',
  };
  const icon = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.overview}</svg>`;

  function toast(message, type = "") {
    const node = document.getElementById("dash-toast");
    if (!node) return;
    node.textContent = message;
    node.className = `toast show ${type}`;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { node.className = "toast"; }, 3200);
  }

  function getPath(object, path) {
    return String(path).split(".").reduce((value, key) => value?.[key], object);
  }
  function setPath(object, path, value) {
    const parts = String(path).split(".");
    let cursor = object;
    parts.forEach((key, index) => {
      if (index === parts.length - 1) {
        cursor[key] = value;
        return;
      }
      if (cursor[key] == null || typeof cursor[key] !== "object") cursor[key] = /^\d+$/.test(parts[index + 1]) ? [] : {};
      cursor = cursor[key];
    });
  }

  function orderList() {
    return R.getOrders().slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  function productList() {
    return model.products || [];
  }
  function newOrdersCount() {
    return orderList().filter((order) => order.status === "new").length;
  }
  function orderStatusCount(status) {
    return orderList().filter((order) => order.status === status).length;
  }
  function revenueOfOrders(orders) {
    return orders.filter((order) => order.status !== "cancelled" && order.status !== "returned").reduce((sum, order) => sum + (Number(order.total) || 0), 0);
  }
  function lowStockProducts() {
    return productList().filter((product) => product.active !== false && Number(product.stock) <= Number(model.settings.lowStockThreshold || 2));
  }

  function saveDraftSoon() {
    dirty = true;
    model.updatedAt = nowIso();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      R.saveDraft(model);
      updateDraftState();
    }, 500);
    updateDraftState();
  }
  function saveDraftNow() {
    clearTimeout(saveTimer);
    model.updatedAt = nowIso();
    R.saveDraft(model);
    dirty = true;
    updateDraftState();
  }
  function updateDraftState() {
    const node = $(".dash-save-state");
    if (!node) return;
    node.className = `dash-save-state ${dirty ? "dirty" : "published"}`;
    node.innerHTML = `<i></i>${dirty ? dt("تغييرات غير منشورة", "Modifications non publiées") : dt("متجر محدث", "Boutique à jour")}`;
  }

  function updateCounts() {
    const count = newOrdersCount();
    $$("[data-nav-count='orders']").forEach((node) => {
      node.textContent = count || "";
      node.hidden = !count;
    });
    const badge = $("[data-order-alert]");
    if (badge) {
      const unseen = Math.max(0, count - orderBadgeSeen);
      badge.textContent = unseen || "";
      badge.hidden = !unseen;
    }
  }

  /* --------------------------------------------------------------------------
     Authentication screens
     -------------------------------------------------------------------------- */
  function renderLogin() {
    session = null;
    app.innerHTML = `
      <div class="dash-login">
        <section class="login-brand">
          <div>
            <a class="logo" href="index.html"><img src="${esc(model.settings.logoWhite || "assets/img/restore-logo-white.svg")}" alt="Restore"></a>
            <h1>${dt("أدر متجرك من مكان واحد.", "Gérez votre boutique depuis un seul endroit.")}</h1>
            <p>${dt("الطلبات، المنتجات، المحتوى، الألوان، العروض والتقارير — كل شيء متصل بالمتجر مباشرة.", "Commandes, produits, contenu, couleurs, offres et rapports — tout est connecté à la boutique en direct.")}</p>
            <div class="login-features">
              <span>${dt("نشر فوري", "Publication instantanée")}</span>
              <span>${dt("عربي / فرنسي", "Arabe / Français")}</span>
              <span>${dt("Supabase", "Supabase")}</span>
              <span>PWA</span>
            </div>
          </div>
          <footer>${dt("ريستور موريتانيا", "Restore Mauritanie")} · ${new Date().getFullYear()}</footer>
        </section>
        <section class="login-panel">
          <div class="login-card">
            <div class="login-lang">
              <button type="button" data-dash-lang="ar" class="${dashLang === "ar" ? "active" : ""}">العربية</button>
              <button type="button" data-dash-lang="fr" class="${dashLang === "fr" ? "active" : ""}">Français</button>
            </div>
            <h2>${dt("تسجيل الدخول", "Connexion")}</h2>
            <p>${dt("ادخل إلى لوحة تحكم ريستور.", "Accédez au tableau de bord Restore.")}</p>
            <form id="login-form">
              <div class="field"><label>${dt("البريد الإلكتروني أو اسم المستخدم", "E-mail ou identifiant")}</label><input name="username" type="text" autocomplete="username" required autofocus placeholder="owner@restore.mr"></div>
              <div class="field"><label>${dt("كلمة المرور", "Mot de passe")}</label><input name="password" type="password" autocomplete="current-password" required></div>
              <div class="login-error" id="login-error"></div>
              <button class="btn btn-primary" type="submit">${dt("دخول", "Se connecter")}</button>
            </form>

          </div>
        </section>
      </div>`;
    $("#login-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const error = $("#login-error");
      error.textContent = "";
      try {
        await R.login(data.get("username"), data.get("password"));
        session = R.currentSession();
        R.addAudit(dt("تسجيل دخول إلى لوحة التحكم", "Connexion au tableau de bord"), session?.username);
        if (session?.mustChange) renderPasswordChange();
        else renderShell();
      } catch (err) {
        error.textContent = err.message || String(err);
      }
    });
  }

  function renderPasswordChange() {
    app.innerHTML = `
      <div class="dash-login">
        <section class="login-brand">
          <div>
            <a class="logo" href="index.html"><img src="${esc(model.settings.logoWhite || "assets/img/restore-logo-white.svg")}" alt="Restore"></a>
            <h1>${dt("أمّن متجرك أولًا.", "Sécurisez votre boutique.")}</h1>
            <p>${dt("يجب تغيير كلمة المرور الافتراضية وربط رقم واتساب قبل استعمال لوحة التحكم.", "Changez le mot de passe par défaut et associez un numéro WhatsApp avant d’utiliser le tableau de bord.")}</p>
          </div>
          <footer>${dt("خطوة إلزامية", "Étape obligatoire")}</footer>
        </section>
        <section class="login-panel">
          <div class="login-card">
            <span class="badge-soft orange">${dt("أول تسجيل دخول", "Première connexion")}</span>
            <h2 style="margin-top:10px">${dt("تغيير كلمة المرور", "Changer le mot de passe")}</h2>
            <p>${dt("الحساب", "Compte")}: <strong>${esc(session?.username || "")}</strong></p>
            <form id="password-form">
              <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input name="current" type="password" required></div>
              <div class="field"><label>${dt("كلمة المرور الجديدة", "Nouveau mot de passe")}</label><input name="next" type="password" minlength="8" required></div>
              <div class="field"><label>${dt("تأكيد كلمة المرور", "Confirmer le mot de passe")}</label><input name="confirm" type="password" minlength="8" required></div>
              <div class="field"><label>${dt("رقم واتساب المتجر / المدير", "WhatsApp de la boutique / du gérant")}</label><input name="whatsapp" inputmode="tel" placeholder="22246000000" dir="ltr" required value="${esc(model.settings.whatsapp || "")}"></div>
              <div class="field"><label>${dt("طرق الدفع المطلوبة", "Méthodes de paiement obligatoires")}</label>
                <div class="setup-form" style="margin-top:8px">
                  ${(model.settings.payments || []).map((p, i) => `
                    <label class="toggle-card ${p.active !== false ? "active" : ""}" data-payment="${i}">
                      <input type="checkbox" ${p.active !== false ? "checked" : ""}>
                      <div><strong>${esc(lng(p.name))}</strong><small>${p.discount ? dt("خصم ", "Réduction ") + p.discount + "%" : ""}</small></div>
                    </label>
                  `).join("")}
                </div>
                <p class="form-note">${dt("اختر على الأقل طريقة دفع واحدة", "Sélectionnez au moins un moyen de paiement")}</p>
              </div>
              <div class="login-error" id="password-error"></div>
              <button class="btn btn-primary" type="submit">${dt("حفظ ومتابعة", "Enregistrer et continuer")}</button>
            </form>
          </div>
        </section>
      </div>`;
    $("#logout-must")?.addEventListener("click", () => { R.logout(); renderLogin(); });
    $("#password-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const error = $("#password-error");
      error.textContent = "";
      if (data.get("next") !== data.get("confirm")) { error.textContent = dt("كلمتا المرور غير متطابقتين", "Les mots de passe ne correspondent pas"); return; }
      if (String(data.get("next")).length < 8) { error.textContent = dt("8 أحرف على الأقل", "8 caractères minimum"); return; }
      try {
        await R.changePassword(session.username, data.get("current"), data.get("next"), data.get("whatsapp"));
        session = R.currentSession();
        model = clone(R.state);
        R.addAudit(dt("غيّر كلمة المرور", "Mot de passe modifié"), session?.username);
        toast(dt("تم تحديث كلمة المرور", "Mot de passe mis à jour"), "good");
        renderShell();
      } catch (err) {
        error.textContent = err.message || String(err);
      }
    });
  }

  /* --------------------------------------------------------------------------
     Application shell
     -------------------------------------------------------------------------- */
  const NAV_GROUPS = [
    {
      label: { ar: "نظرة عامة", fr: "Vue d’ensemble" },
      items: [
        { id: "overview", icon: "overview", ar: "نظرة عامة", fr: "Vue d’ensemble" },
        { id: "orders", icon: "orders", ar: "الطلبات", fr: "Commandes", count: true },
        { id: "abandoned", icon: "abandoned", ar: "السلال المتروكة", fr: "Paniers abandonnés" }
      ]
    },
    {
      label: { ar: "المتجر", fr: "Boutique" },
      items: [
        { id: "products", icon: "products", ar: "المنتجات", fr: "Produits" },
        { id: "categories", icon: "categories", ar: "الفئات", fr: "Catégories" },
        { id: "reviews", icon: "reviews", ar: "التقييمات", fr: "Avis" }
      ]
    },
    {
      label: { ar: "المحتوى", fr: "Contenu" },
      items: [
        { id: "content", icon: "content", ar: "نصوص المتجر", fr: "Textes & contenu" },
        { id: "homepage", icon: "home", ar: "الصفحة الرئيسية", fr: "Page d’accueil" },
        { id: "appearance", icon: "palette", ar: "الهوية والألوان", fr: "Identité & couleurs" },
        { id: "marketing", icon: "marketing", ar: "العروض والتسويق", fr: "Offres & marketing" },
        { id: "blog", icon: "blog", ar: "المدونة", fr: "Blog" },
        { id: "pages", icon: "pages", ar: "الصفحات", fr: "Pages" }
      ]
    },
    {
      label: { ar: "العمليات", fr: "Opérations" },
      items: [
        { id: "payments", icon: "payment", ar: "الدفع والتوصيل", fr: "Paiement & livraison" },
        { id: "team", icon: "team", ar: "الفريق", fr: "Équipe" },
        { id: "reports", icon: "reports", ar: "التقارير", fr: "Rapports" },
        { id: "settings", icon: "settings", ar: "الإعدادات", fr: "Réglages" },
        { id: "audit", icon: "audit", ar: "سجل النشاط", fr: "Journal d’activité" }
      ]
    },
    {
      label: { ar: "الحساب", fr: "Compte" },
      items: [
        { id: "profile", icon: "team", ar: "ملفي الشخصي", fr: "Mon profil" }
      ]
    }
  ];
  const OWNER_ONLY_ROUTES = new Set(["team", "settings", "audit"]);
  const ROUTE_TITLES = {
    overview: { ar: "نظرة عامة", fr: "Vue d’ensemble", sub: { ar: "ملخص مباشر لمتجر ريستور", fr: "Résumé en direct de Restore" } },
    orders: { ar: "الطلبات", fr: "Commandes", sub: { ar: "إدارة الطلبات والواتساب والفواتير", fr: "Commandes, WhatsApp et factures" } },
    abandoned: { ar: "السلال المتروكة", fr: "Paniers abandonnés", sub: { ar: "استرجع العملاء الذين لم يكملوا الطلب", fr: "Récupérez les clients qui n’ont pas finalisé" } },
    products: { ar: "المنتجات", fr: "Produits", sub: { ar: "المخزون والأسعار والصور", fr: "Stock, prix et images" } },
    categories: { ar: "الفئات", fr: "Catégories", sub: { ar: "تنظيم مجموعات المتجر", fr: "Organisez les collections" } },
    reviews: { ar: "التقييمات", fr: "Avis clients", sub: { ar: "راجع واعتمد تقييمات العملاء", fr: "Modérez les avis clients" } },
    content: { ar: "نصوص المتجر", fr: "Textes & contenu", sub: { ar: "المحتوى بالعربية والفرنسية", fr: "Contenu en arabe et français" } },
    homepage: { ar: "الصفحة الرئيسية", fr: "Page d’accueil", sub: { ar: "الأقسام، السلايدر والترتيب", fr: "Sections, slider et ordre" } },
    appearance: { ar: "الهوية والألوان", fr: "Identité & couleurs", sub: { ar: "الشعار، الألوان والخطوط", fr: "Logo, couleurs et polices" } },
    marketing: { ar: "العروض والتسويق", fr: "Offres & marketing", sub: { ar: "بنكيلي، الكوبونات والبانرات", fr: "Bankily, coupons et bannières" } },
    blog: { ar: "المدونة", fr: "Blog", sub: { ar: "المقالات والصور المنشورة", fr: "Articles et images publiés" } },
    pages: { ar: "الصفحات", fr: "Pages", sub: { ar: "الصفحات الثابتة والسياسات", fr: "Pages statiques et politiques" } },
    payments: { ar: "الدفع والتوصيل", fr: "Paiement & livraison", sub: { ar: "بنكيلي، مصرفي، سداد، كليك والمدن", fr: "Bankily, Masrvi, Sedad, Click et villes" } },
    team: { ar: "الفريق", fr: "Équipe", sub: { ar: "المديرون وصلاحيات الدخول", fr: "Gérants et accès" } },
    reports: { ar: "التقارير", fr: "Rapports", sub: { ar: "المبيعات، الطلبات والمخزون", fr: "Ventes, commandes et stock" } },
    settings: { ar: "الإعدادات", fr: "Réglages", sub: { ar: "SEO، واتساب، البكسل والحماية", fr: "SEO, WhatsApp, pixels et sécurité" } },
    audit: { ar: "سجل النشاط", fr: "Journal d’activité", sub: { ar: "كل التغييرات المسجلة", fr: "Toutes les modifications" } }
  };

  function renderShell() {
    const displayName = session?.role === "owner" ? dt("مالك المتجر", "Propriétaire") : dt("مدير المتجر", "Gérant");
    const initials = String(displayName || "R").slice(0, 2).toUpperCase();
    const mgr = R.managers.find((item) => item.id === session?.id) || R.managers.find((item) => item.username === session?.username);
    const mgrAvatar = mgr?.avatar && mgr.avatar.trim() ? mgr.avatar : "";
    const remoteLabel = R.remote ? "Supabase" : "";
    app.innerHTML = `
      <div class="dash-shell">
        <aside class="dash-sidebar" id="dash-sidebar">
          <a class="brand" href="index.html"><img src="${esc(model.settings.logoWhite || "assets/img/restore-logo-white.svg")}" alt="Restore"></a>
          <div class="dash-workspace"><span class="dot"></span><div><strong>${esc(lng(model.settings.storeName))}</strong><small>MRU</small></div></div>
          <nav class="dash-nav">
            ${NAV_GROUPS.map((group) => `
              <div class="dash-nav-label">${esc(group.label[dashLang] || group.label.ar)}</div>
              ${group.items.filter((item) => session?.role === "owner" || !OWNER_ONLY_ROUTES.has(item.id)).map((item) => `<a href="#${item.id}" data-route="${item.id}" class="${route === item.id ? "active" : ""}">${icon(item.icon)}<span>${esc(item[dashLang] || item.ar)}</span>${item.count ? `<span class="count" data-nav-count="orders" ${newOrdersCount() ? "" : "hidden"}>${newOrdersCount() || ""}</span>` : ""}</a>`).join("")}
            `).join("")}
          </nav>
          <div class="dash-user">
            <span class="dash-avatar" data-route="profile" title="${dt("ملفي الشخصي", "Mon profil")}">${mgrAvatar ? `<img src="${esc(mgrAvatar)}" alt="">` : esc(initials)}</span>
            <div><strong>${esc(displayName)}</strong><small>${session?.role === "owner" ? dt("المالك", "Propriétaire") : dt("مدير", "Gérant")}</small></div>
            <button type="button" data-action="logout" title="${dt("خروج", "Déconnexion")}">${icon("logout")}</button>
          </div>
        </aside>
        <main class="dash-main">
          <header class="dash-topbar">
            <button class="dash-menu-btn" type="button" data-action="toggle-sidebar">${icon("menu")}</button>
            <div class="dash-title"><h1 id="dash-title">${esc(ROUTE_TITLES[route]?.[dashLang] || ROUTE_TITLES[route]?.ar || "")}</h1><small id="dash-subtitle">${esc(ROUTE_TITLES[route]?.sub?.[dashLang] || "")}</small></div>
            <label class="dash-search">${icon("search")}<input id="dash-search" placeholder="${dt("بحث في الطلبات والمنتجات...", "Rechercher commandes, produits...")}" value="${esc(searchTerm)}"></label>
            <div class="dash-top-actions">
              <span class="dash-save-state ${dirty ? "dirty" : "published"}"><i></i>${dirty ? dt("تغييرات غير منشورة", "Modifications non publiées") : dt("متجر محدث", "Boutique à jour")}</span>
              <button class="dash-lang" type="button" data-dash-lang="${dashLang === "ar" ? "fr" : "ar"}">${dashLang === "ar" ? "FR" : "AR"}</button>
              <button class="dash-icon-btn" type="button" data-action="theme" title="${dt("الوضع الليلي", "Mode sombre")}">${icon(R.theme === "dark" ? "sun" : "moon")}</button>
              <a class="dash-icon-btn" href="index.html" target="_blank" rel="noopener" title="${dt("عرض المتجر", "Voir la boutique")}">${icon("external")}</a>
              <button class="dash-icon-btn" type="button" data-action="orders-alert" title="${dt("طلبات جديدة", "Nouvelles commandes")}">${icon("bell")}<span class="alert-dot" data-order-alert ${Math.max(0, newOrdersCount() - orderBadgeSeen) ? "" : "hidden"}>${Math.max(0, newOrdersCount() - orderBadgeSeen) || ""}</span></button>
              <div class="dash-publish">
                <button class="btn btn-soft" type="button" data-action="preview" title="${dt("معاينة", "Aperçu")}">${icon("preview")}<span>${dt("معاينة", "Aperçu")}</span></button>
                <button class="btn btn-primary" type="button" data-action="publish" title="${dt("نشر", "Publier")}">${icon("publish")}<span>${dt("نشر", "Publier")}</span></button>
              </div>
            </div>
          </header>
          <div class="dash-view" id="dash-view"></div>
        </main>
      </div>`;
    renderRoute();
    updateCounts();
  }

  function renderRoute() {
    if (!session) { renderLogin(); return; }
    if (session.mustChange) { renderPasswordChange(); return; }
    if (!ROUTE_TITLES[route]) route = "overview";
    if (OWNER_ONLY_ROUTES.has(route) && session.role !== "owner") {
      route = "overview";
      toast(dt("هذه الصفحة متاحة للمالك فقط", "Cette page est réservée au propriétaire"), "error");
    }
    const view = $("#dash-view");
    if (!view) { renderShell(); return; }
    const views = {
      overview: viewOverview,
      orders: viewOrders,
      abandoned: viewAbandoned,
      products: viewProducts,
      categories: viewCategories,
      reviews: viewReviews,
      content: viewContent,
      homepage: viewHomepage,
      appearance: viewAppearance,
      marketing: viewMarketing,
      blog: viewBlog,
      pages: viewPages,
      payments: viewPayments,
      team: viewTeam,
      reports: viewReports,
      settings: viewSettings,
      audit: viewAudit,
      profile: viewProfile
    };
    view.innerHTML = (views[route] || viewOverview)();
    $$(".dash-nav a").forEach((link) => link.classList.toggle("active", link.dataset.route === route));
    const title = $("#dash-title");
    const subtitle = $("#dash-subtitle");
    if (title) title.textContent = ROUTE_TITLES[route]?.[dashLang] || ROUTE_TITLES[route]?.ar || "";
    if (subtitle) subtitle.textContent = ROUTE_TITLES[route]?.sub?.[dashLang] || "";
    const search = $("#dash-search");
    if (search && search.value !== searchTerm) search.value = searchTerm;
    updateDraftState();
    updateCounts();
    if (route === "orders" || route === "reports") setTimeout(() => localStorage.setItem("restore_orders_seen_v1", String(newOrdersCount())), 800);
  }

  /* --------------------------------------------------------------------------
     Overview
     -------------------------------------------------------------------------- */
  function statCard(label, value, note, accent, iconName, trend = "") {
    return `<article class="dash-card stat-card" style="--accent:${accent}">
      <div class="stat-top"><span class="stat-label">${esc(label)}</span><span class="stat-icon">${icon(iconName)}</span></div>
      <strong>${value}</strong><small>${trend ? `<span class="trend">${esc(trend)}</span> · ` : ""}${esc(note)}</small>
    </article>`;
  }

  function viewOverview() {
    const orders = orderList();
    const totalRevenue = revenueOfOrders(orders);
    const delivered = orders.filter((order) => order.status === "delivered").length;
    const newCount = orders.filter((order) => order.status === "new").length;
    const cancelled = orders.filter((order) => order.status === "cancelled" || order.status === "returned").length;
    const low = lowStockProducts();
    const abandoned = R.getAbandoned().filter((item) => item.status === "open");
    const recent = orders.slice(0, 6);
    const days = [...Array(7)].map((_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const key = date.toISOString().slice(0, 10);
      const total = orders.filter((order) => String(order.createdAt).slice(0, 10) === key).reduce((sum, order) => sum + Number(order.total || 0), 0);
      return { label: date.toLocaleDateString(dashLang === "ar" ? "ar-MR" : "fr-FR", { weekday: "short" }), total };
    });
    const maxDay = Math.max(1, ...days.map((day) => day.total));
    const statusRows = ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled"].map((status) => {
      const meta = R.statusMeta(status);
      return { status, label: lng(meta.label), color: meta.color, count: orderStatusCount(status) };
    });
    const displayName = session?.role === "owner" ? dt("مالك المتجر", "Propriétaire") : dt("مدير المتجر", "Gérant");
    return `
      <div class="dash-view-head">
        <div><h2>${dt("مرحبًا", "Bonjour")} ${esc(displayName)} 👋</h2><p>${dt("هذا ملخص مباشر لأداء متجرك.", "Voici un résumé en direct de votre boutique.")}</p></div>
        <div class="dash-view-actions">
          <a class="btn btn-primary" href="#products" data-route="products">${icon("plus")} ${dt("إضافة منتج", "Ajouter un produit")}</a>
          <a class="btn btn-soft" href="#reports" data-route="reports">${dt("عرض التقارير", "Voir les rapports")}</a>
        </div>
      </div>
      <div class="dash-grid cols-4" style="margin-bottom:14px">
        ${statCard(dt("إجمالي الطلبات", "Commandes totales"), orders.length, dt("كل الطلبات المسجلة", "Toutes les commandes"), "#ff6400", "orders", newCount ? `+${newCount} ${dt("جديد", "nouveau")}` : "")}
        ${statCard(dt("الإيرادات", "Chiffre d’affaires"), money(totalRevenue), dt("دون الملغاة والمرتجعة", "Hors annulées et retours"), "#128c53", "reports")}
        ${statCard(dt("طلبات جديدة", "Nouvelles commandes"), newCount, dt("تحتاج إلى تأكيد", "À confirmer"), "#a72396", "bell")}
        ${statCard(dt("مخزون منخفض", "Stock faible"), low.length, dt("منتجات تحتاج متابعة", "Produits à suivre"), "#e67e22", "products")}
      </div>
      <div class="dash-grid cols-3" style="margin-bottom:14px">
        <article class="dash-card" style="grid-column:span 2">
          <div class="dash-card-head"><h3>${dt("آخر الطلبات", "Dernières commandes")}</h3><a href="#orders" data-route="orders">${dt("عرض الكل", "Tout voir")}</a></div>
          <div class="dash-card-body" style="padding-top:10px">
            ${recent.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الطلب", "Commande")}</th><th>${dt("العميل", "Client")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("المجموع", "Total")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead><tbody>
              ${recent.map((order) => {
                const status = R.statusMeta(order.status);
                return `<tr>
                  <td><strong>${esc(order.id)}</strong><br><small>${esc(fmtDate(order.createdAt))}</small></td>
                  <td>${esc(order.customer?.name || "")}<br><small dir="ltr">${esc(order.customer?.phone || "")}</small></td>
                  <td>${esc(order.customer?.city || "")}</td>
                  <td class="price">${money(order.total)}</td>
                  <td><span class="status-pill" style="--status:${status.color}">${esc(lng(status.label))}</span></td>
                  <td><button class="btn btn-sm btn-soft" type="button" data-action="view-order" data-id="${esc(order.id)}">${dt("تفاصيل", "Détails")}</button></td>
                </tr>`;
              }).join("")}</tbody></table></div>` : `<div class="empty-dash">${icon("orders")}<p>${dt("لا توجد طلبات بعد. ستظهر الطلبات القادمة من المتجر هنا مباشرة.", "Aucune commande. Les commandes de la boutique apparaîtront ici.")}</p></div>`}
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("حالة المتجر", "État de la boutique")}</h3><a href="#settings" data-route="settings">${dt("إعدادات", "Réglages")}</a></div>
          <div class="dash-card-body">
            <div style="display:flex;align-items:center;gap:9px;padding:9px 0;border-bottom:1px solid var(--border)"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${R.isStoreOpen() ? "#25a55f" : "#c0392b"}"></span><div><strong style="font-size:10px">${R.isStoreOpen() ? dt("المتجر مفتوح", "Boutique ouverte") : dt("المتجر مغلق", "Boutique fermée")}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${model.settings.hours.open} — ${model.settings.hours.close} · ${esc(model.settings.timezone)}</small></div></div>

            <div style="display:flex;align-items:center;gap:9px;padding:9px 0"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${dirty ? "#e67e22" : "#25a55f"}"></span><div><strong style="font-size:10px">${dirty ? dt("مسودة غير منشورة", "Brouillon non publié") : dt("كل التغييرات منشورة", "Tout est publié")}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${dt("آخر تحديث", "Dernière mise à jour")}: ${esc(fmtDateTime(model.updatedAt))}</small></div></div>
            <button class="btn btn-primary btn-block btn-sm" type="button" data-action="preview" style="margin-top:8px">${icon("preview")} ${dt("معاينة المتجر", "Prévisualiser")}</button>
          </div>
        </article>
      </div>
      <div class="dash-grid cols-3">
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("الطلبات في آخر 7 أيام", "Commandes des 7 jours")}</h3></div>
          <div class="dash-card-body">
            <div class="report-bars">${days.map((day) => `<div class="bar" style="height:${Math.max(5, Math.round(day.total / maxDay * 100))}%" title="${money(day.total)}"><span>${esc(day.label)}</span></div>`).join("")}</div>
            <div class="report-legend"><span><i></i>${money(days.reduce((sum, day) => sum + day.total, 0))} ${dt("هذا الأسبوع", "cette semaine")}</span></div>
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("توزيع حالات الطلبات", "Répartition des statuts")}</h3></div>
          <div class="dash-card-body">
            ${statusRows.map((row) => `<div style="display:grid;grid-template-columns:65px 1fr 22px;align-items:center;gap:7px;margin-bottom:8px"><small style="font-size:8px;color:var(--muted)">${esc(row.label)}</small><div class="mini-bar" style="--bar:${row.color}"><i style="width:${orders.length ? Math.max(3, row.count / orders.length * 100) : 0}%"></i></div><strong style="font-size:9px">${row.count}</strong></div>`).join("")}
          </div>
        </article>
        <article class="dash-card">
          <div class="dash-card-head"><h3>${dt("تحتاج انتباهك", "À surveiller")}</h3></div>
          <div class="dash-card-body">
            <div class="list-editor">
              <div class="list-row"><div class="grow"><strong>${low.length} ${dt("منتجات بمخزون منخفض", "produits en stock faible")}</strong><small>${dt("حد التنبيه", "Seuil")}: ${model.settings.lowStockThreshold}</small></div><a class="btn btn-sm btn-soft" href="#products" data-route="products">${dt("إدارة", "Gérer")}</a></div>
              <div class="list-row"><div class="grow"><strong>${abandoned.length} ${dt("سلة متروكة", "paniers abandonnés")}</strong><small>${dt("فرص استرجاع", "Opportunités")}</small></div><a class="btn btn-sm btn-soft" href="#abandoned" data-route="abandoned">${dt("عرض", "Voir")}</a></div>
              <div class="list-row"><div class="grow"><strong>${cancelled} ${dt("طلبات ملغاة/مرتجعة", "annulées/retournées")}</strong><small>${dt("راجع الأسباب", "Vérifiez les causes")}</small></div><a class="btn btn-sm btn-soft" href="#orders" data-route="orders">${dt("الطلبات", "Commandes")}</a></div>
            </div>
          </div>
        </article>
      </div>`;
  }
  /* --------------------------------------------------------------------------
     Shared modal / field helpers
     -------------------------------------------------------------------------- */
  let editBuffer = null;
  let orderFilter = "all";
  let productSearch = "";
  let productCategory = "all";
  let productStock = "all";
  let abandonedFilter = "open";

  function openModal(title, body, { wide = false, footer = "", onMount = null } = {}) {
    modalRoot.innerHTML = `
      <div class="dash-modal-backdrop" data-action="modal-backdrop">
        <section class="dash-modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
          <div class="dash-modal-head"><h3>${esc(title)}</h3><button type="button" data-action="close-modal" aria-label="${dt("إغلاق", "Fermer")}">${icon("close")}</button></div>
          <div class="dash-modal-body">${body}</div>
          ${footer ? `<div class="dash-modal-foot">${footer}</div>` : ""}
        </section>
      </div>`;
    document.body.classList.add("no-scroll");
    if (onMount) onMount(modalRoot);
  }
  function closeModal() {
    modalRoot.innerHTML = "";
    document.body.classList.remove("no-scroll");
    editBuffer = null;
  }

  function field(label, path, { type = "text", value, placeholder = "", hint = "", rows = 3, options = null, disabled = false } = {}) {
    let actual = value !== undefined ? value : getPath(model, path);
    if (type === "datetime-local") actual = isoLocal(actual);
    if (options) {
      return `<div class="field"><label>${esc(label)}</label><select data-path="${esc(path)}" ${disabled ? "disabled" : ""}>${options.map((option) => {
        const optionValue = typeof option === "object" ? option.value : option;
        const optionLabel = typeof option === "object" ? option.label : option;
        return `<option value="${esc(optionValue)}" ${String(optionValue) === String(actual) ? "selected" : ""}>${esc(optionLabel)}</option>`;
      }).join("")}</select>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
    }
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><textarea data-path="${esc(path)}" rows="${rows}" placeholder="${esc(placeholder)}" ${disabled ? "disabled" : ""}>${esc(actual ?? "")}</textarea>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
    return `<div class="field"><label>${esc(label)}</label><input type="${type}" data-path="${esc(path)}" value="${esc(actual ?? "")}" placeholder="${esc(placeholder)}" ${disabled ? "disabled" : ""}>${hint ? `<p class="form-note">${esc(hint)}</p>` : ""}</div>`;
  }

  function biField(label, path, { type = "text", rows = 3 } = {}) {
    const value = getPath(model, path) || {};
    if (type === "textarea") {
      return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><textarea data-path="${esc(path)}.ar" rows="${rows}" dir="rtl" placeholder="العربية">${esc(value.ar ?? "")}</textarea><textarea data-path="${esc(path)}.fr" rows="${rows}" dir="ltr" placeholder="Français">${esc(value.fr ?? "")}</textarea></div></div>`;
    }
    return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><input data-path="${esc(path)}.ar" value="${esc(value.ar ?? "")}" dir="rtl" placeholder="العربية"><input data-path="${esc(path)}.fr" value="${esc(value.fr ?? "")}" dir="ltr" placeholder="Français"></div></div>`;
  }

  function editInput(label, path, { type = "text", value = "", placeholder = "", rows = 3, help = "" } = {}) {
    const suffix = `data-edit-path="${esc(path)}"`;
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><textarea ${suffix} rows="${rows}" placeholder="${esc(placeholder)}">${esc(value ?? "")}</textarea>${help ? `<p class="form-note">${esc(help)}</p>` : ""}</div>`;
    return `<div class="field"><label>${esc(label)}</label><input type="${type}" ${suffix} value="${esc(value ?? "")}" placeholder="${esc(placeholder)}">${help ? `<p class="form-note">${esc(help)}</p>` : ""}</div>`;
  }
  function editBi(label, path, value = {}, { type = "text", rows = 3 } = {}) {
    if (type === "textarea") return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><textarea data-edit-path="${esc(path)}.ar" rows="${rows}" dir="rtl">${esc(value?.ar ?? "")}</textarea><textarea data-edit-path="${esc(path)}.fr" rows="${rows}" dir="ltr">${esc(value?.fr ?? "")}</textarea></div></div>`;
    return `<div class="field"><label>${esc(label)}</label><div class="bi-grid"><input data-edit-path="${esc(path)}.ar" value="${esc(value?.ar ?? "")}" dir="rtl"><input data-edit-path="${esc(path)}.fr" value="${esc(value?.fr ?? "")}" dir="ltr"></div></div>`;
  }
  function editToggle(label, path, checked) {
    return `<div class="check-row"><label class="toggle"><input type="checkbox" data-edit-path="${esc(path)}" ${checked ? "checked" : ""}><span></span></label><span>${esc(label)}</span></div>`;
  }
  function directToggle(label, path, checked) {
    return `<div class="check-row"><label class="toggle"><input type="checkbox" data-path="${esc(path)}" data-type="bool" ${checked ? "checked" : ""}><span></span></label><span>${esc(label)}</span></div>`;
  }
  function imageEditor(label, path, value = "") {
    return `<div class="field"><label>${esc(label)}</label><div class="image-field">
      <span class="image-preview"><img src="${esc(value || "assets/img/favicon.svg")}" alt=""></span>
      <div class="grow">
        <input data-edit-path="${esc(path)}" value="${esc(value)}" placeholder="assets/img/...">
        <label class="upload-btn">${icon("upload")} ${dt("رفع صورة", "Téléverser")}<input type="file" accept="image/*" data-upload-path="${esc(path)}"></label>
      </div>
    </div></div>`;
  }
  function editorFooter(canDelete = false, deleteAction = "") {
    return `${canDelete ? `<button class="btn btn-danger btn-sm" type="button" data-action="${esc(deleteAction)}">${icon("trash")} ${dt("حذف", "Supprimer")}</button>` : ""}<span style="flex:1"></span><button class="btn btn-soft btn-sm" type="button" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" type="button" data-action="save-editor">${icon("check")} ${dt("حفظ", "Enregistrer")}</button>`;
  }

  function statusOptions(selected) {
    return R.statuses.map((status) => {
      const meta = R.statusMeta(status);
      return `<option value="${status}" ${status === selected ? "selected" : ""}>${esc(lng(meta.label))}</option>`;
    }).join("");
  }

  /* --------------------------------------------------------------------------
     Orders
     -------------------------------------------------------------------------- */
  function filteredOrders() {
    const needle = R.normalizeText(searchTerm);
    return orderList().filter((order) => {
      if (orderFilter !== "all" && order.status !== orderFilter) return false;
      if (!needle) return true;
      const haystack = R.normalizeText([order.id, order.customer?.name, order.customer?.phone, order.customer?.city, order.customer?.address, ...(order.items || []).map((item) => item.title)].join(" "));
      return haystack.includes(needle);
    });
  }

  function ordersTable(orders) {
    if (!orders.length) return `<div class="table-empty">${icon("orders")}<p>${dt("لا توجد طلبات مطابقة.", "Aucune commande correspondante.")}</p></div>`;
    return `<div class="dash-table-wrap"><table class="dash-table">
      <thead><tr><th>${dt("الطلب", "Commande")}</th><th>${dt("العميل", "Client")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("المنتجات", "Articles")}</th><th>${dt("الدفع", "Paiement")}</th><th>${dt("المجموع", "Total")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead>
      <tbody>${orders.map((order) => {
        const status = R.statusMeta(order.status);
        return `<tr>
          <td><strong style="font-size:9px">${esc(order.id)}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${esc(fmtDateTime(order.createdAt))}</small></td>
          <td><strong style="font-size:10px">${esc(order.customer?.name || "")}</strong><br><small dir="ltr" style="font-size:8px;color:var(--soft-muted)">${esc(order.customer?.phone || "")}</small></td>
          <td>${esc(order.customer?.city || "")}</td>
          <td>${(order.items || []).reduce((sum, item) => sum + Number(item.qty || 1), 0)}</td>
          <td>${esc(order.payment?.name || "")}</td>
          <td class="price">${money(order.total)}</td>
          <td><select class="dash-field" data-order-status="${esc(order.id)}" style="min-width:95px;height:28px;padding:2px 6px;font-size:9px;border-color:${status.color}">${statusOptions(order.status)}</select></td>
          <td><div class="cell-actions">
            <button class="btn btn-sm btn-soft" type="button" data-action="view-order" data-id="${esc(order.id)}">${dt("عرض", "Voir")}</button>
            <a class="btn btn-sm btn-soft" href="https://wa.me/${digits(order.customer?.phone)}" target="_blank" rel="noopener" title="WhatsApp">${icon("whatsapp")}</a>
          </div></td>
        </tr>`;
      }).join("")}</tbody>
    </table></div>`;
  }

  function viewOrders() {
    const orders = filteredOrders();
    const tabs = [{ id: "all", label: dt("الكل", "Toutes"), count: orderList().length }, ...R.statuses.map((status) => ({ id: status, label: lng(R.statusMeta(status).label), count: orderStatusCount(status) }))];
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الطلبات", "Commandes")}</h2><p>${dt("كل طلب يصل من المتجر يظهر هنا فورًا.", "Chaque commande de la boutique apparaît ici en direct.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" type="button" data-action="export-orders">${icon("download")} ${dt("تصدير CSV", "Exporter CSV")}</button></div>
      </div>
      <div class="dash-toolbar">
        <div class="segmented" style="flex-wrap:wrap">${tabs.map((tab) => `<button type="button" data-order-filter="${tab.id}" class="${orderFilter === tab.id ? "active" : ""}">${esc(tab.label)} ${tab.count ? `(${tab.count})` : ""}</button>`).join("")}</div>
        <div class="spacer"></div>
        <label class="field" style="min-width:210px"><input id="order-search" placeholder="${dt("بحث بالرقم، الاسم أو الهاتف", "N°, nom ou téléphone")}" value="${esc(searchTerm)}"></label>
      </div>
      <div class="dash-card">${ordersTable(orders)}</div>`;
  }

  function orderMessage(order, type = "confirm") {
    const template = model.settings.whatsappTemplates?.[type];
    if (!template) return "";
    let text = lng(template)
      .replaceAll("{name}", order.customer?.name || "")
      .replaceAll("{order_id}", order.id)
      .replaceAll("{store}", lng(model.settings.storeName));
    return text;
  }

  function printOrder(order, mode) {
    const invoice = mode === "invoice";
    const win = window.open("", "_blank", "width=820,height=980");
    if (!win) { toast(dt("اسمح بالنوافذ المنبثقة للطباعة", "Autorisez les pop-ups pour imprimer"), "error"); return; }
    const itemRows = (order.items || []).map((item) => `<tr><td>${esc(item.title)}<br><small>${esc(item.variantTitle || "")} ${esc(item.specsText || "")}</small></td><td>${item.qty}</td><td>${money(item.price)}</td><td>${money(item.line)}</td></tr>`).join("");
    win.document.write(`<!doctype html><html lang="${dashLang}" dir="${dashLang === "ar" ? "rtl" : "ltr"}"><head><meta charset="utf-8"><title>${invoice ? dt("فاتورة", "Facture") : dt("ملصق شحن", "Étiquette")} ${esc(order.id)}</title><style>
      @page{size:A4;margin:16mm}*{box-sizing:border-box}body{font-family:Tahoma,Arial,sans-serif;color:#111;font-size:12px;line-height:1.6}header{display:flex;justify-content:space-between;border-bottom:2px solid #ff6400;padding-bottom:12px;margin-bottom:18px}h1{font-size:22px;margin:0}img{width:120px}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:start;font-size:11px}th{background:#f5f5f5}small{color:#666;font-size:9px}.total{font-size:16px;font-weight:bold;text-align:end;margin-top:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.box{border:1px solid #ddd;padding:10px;border-radius:6px}.label{border:2px solid #111;padding:22px;margin-top:20px}.label h2{font-size:26px;margin:0 0 10px}.label .addr{font-size:17px;line-height:1.8}.barcode{margin-top:16px;font-family:monospace;font-size:13px;letter-spacing:2px}</style></head><body>
      <header><div><img src="${location.origin}${location.pathname.replace(/[^/]*$/, "")}${esc(model.settings.logo || "assets/img/restore-logo.svg")}" alt="Restore"><h1>${invoice ? dt("فاتورة", "Facture") : dt("ملصق شحن", "Étiquette d’expédition")}</h1></div><div style="text-align:end"><strong>${esc(model.settings.mapPhone || model.settings.phoneDisplay || "")}</strong><br>${esc(lng(model.settings.address))}<br>${esc(model.settings.email || "")}</div></header>
      ${invoice ? `<div class="grid"><div class="box"><strong>${dt("فاتورة", "Facture")}: ${esc(order.id)}</strong><br>${esc(fmtDate(order.createdAt))}<br>${dt("الحالة", "Statut")}: ${esc(lng(R.statusMeta(order.status).label))}</div><div class="box"><strong>${dt("العميل", "Client")}</strong><br>${esc(order.customer?.name || "")}<br>${esc(order.customer?.phone || "")}<br>${esc(order.customer?.city || "")} — ${esc(order.customer?.address || "")}</div></div>
      <table><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("الكمية", "Qté")}</th><th>${dt("السعر", "Prix")}</th><th>${dt("المجموع", "Total")}</th></tr></thead><tbody>${itemRows}</tbody></table>
      <div class="total">${dt("المجموع الكلي", "Total")}: ${money(order.total)}</div>` : `<div class="label"><h2>${esc(model.settings.storeName?.[dashLang] || "Restore")}</h2><div class="addr"><strong>${esc(order.customer?.name || "")}</strong><br>${esc(order.customer?.phone || "")}<br>${esc(order.customer?.address || "")}<br>${esc(order.customer?.city || "")} — ${dt("موريتانيا", "Mauritanie")}</div><div class="barcode">${esc(order.id)} · ${esc(digits(order.customer?.phone).slice(-8))}</div></div>`}
      <p style="margin-top:24px;font-size:9px;color:#888">${dt("تم إنشاء هذا المستند من لوحة تحكم ريستور.", "Document généré depuis le tableau de bord Restore.")}</p>
      </body></html>`);
    win.document.close();
    setTimeout(() => { win.focus(); win.print(); }, 350);
  }

  function viewOrderModal(id) {
    const order = R.getOrders().find((item) => item.id === id);
    if (!order) return;
    const status = R.statusMeta(order.status);
    const wa = `https://wa.me/${digits(order.customer?.phone)}?text=${encodeURIComponent(orderMessage(order, "confirm"))}`;
    openModal(`${dt("الطلب", "Commande")} ${order.id}`, `
      <div class="order-detail">
        <div>
          <div class="order-detail-section">
            <h4>${dt("المنتجات", "Articles")}</h4>
            ${(order.items || []).map((item) => `<div class="order-item-row"><img src="${esc(item.image || "assets/img/favicon.svg")}" alt=""><div class="grow"><strong>${esc(item.title)}</strong><small>${esc(item.variantTitle || "")} ${item.specsText ? `· ${esc(item.specsText)}` : ""}</small></div><span>×${item.qty}</span><strong>${money(item.line)}</strong></div>`).join("")}
            <div class="order-totals">
              <div><span>${dt("المجموع الفرعي", "Sous-total")}</span><span>${money(order.subtotal)}</span></div>
              <div><span>${dt("الشحن", "Livraison")}</span><span>${money(order.shipping)}</span></div>
              <div><span>${dt("الخصم", "Réduction")}</span><span>${money(order.discount)}</span></div>
              <div class="total"><span>${dt("المجموع", "Total")}</span><span>${money(order.total)}</span></div>
            </div>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("ملاحظات العميل", "Notes du client")}</h4>
            <p>${esc(order.customer?.notes || dt("لا توجد ملاحظات", "Aucune note"))}</p>
          </div>
        </div>
        <div>
          <div class="order-detail-section">
            <h4>${dt("العميل", "Client")}</h4>
            <p><strong>${esc(order.customer?.name || "")}</strong><br><span dir="ltr">${esc(order.customer?.phone || "")}</span><br>${esc(order.customer?.city || "")}<br>${esc(order.customer?.address || "")}<br>${esc(order.customer?.email || "")}</p>
            <div style="display:flex;gap:5px;margin-top:9px;flex-wrap:wrap"><a class="btn btn-sm btn-whatsapp" href="${wa}" target="_blank" rel="noopener">${icon("whatsapp")} ${dt("واتساب", "WhatsApp")}</a><a class="btn btn-sm btn-soft" href="tel:${esc(order.customer?.phone)}">${dt("اتصال", "Appeler")}</a></div>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("إدارة الطلب", "Gestion")}</h4>
            <div class="field"><label>${dt("الحالة", "Statut")}</label><select data-order-status="${esc(order.id)}">${statusOptions(order.status)}</select></div>
            <div class="field" style="margin-top:8px"><label>${dt("ملاحظة داخلية", "Note interne")}</label><textarea rows="3" data-order-note="${esc(order.id)}">${esc(order.internalNote || "")}</textarea></div>
            <p class="form-note" style="margin-top:8px">${dt("الدفع", "Paiement")}: <strong>${esc(order.payment?.name || "")}</strong> · ${dt("المصدر", "Source")}: ${esc(order.source || "whatsapp")}</p>
          </div>
          <div class="order-detail-section" style="margin-top:10px">
            <h4>${dt("المستندات", "Documents")}</h4>
            <div style="display:flex;gap:5px;flex-wrap:wrap"><button class="btn btn-sm btn-soft" data-action="print-invoice" data-id="${esc(order.id)}">${icon("print")} ${dt("فاتورة", "Facture")}</button><button class="btn btn-sm btn-soft" data-action="print-label" data-id="${esc(order.id)}">${dt("ملصق شحن", "Étiquette")}</button></div>
            <div style="margin-top:12px"><span class="status-pill" style="--status:${status.color}">${esc(lng(status.label))}</span></div>
          </div>
        </div>
      </div>`, {
      wide: true,
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إغلاق", "Fermer")}</button><button class="btn btn-primary btn-sm" data-action="save-order" data-id="${esc(order.id)}">${icon("check")} ${dt("حفظ التغييرات", "Enregistrer")}</button>`
    });
  }

  function exportOrdersCsv() {
    const orders = orderList();
    const rows = [
      ["order_id", "date", "status", "name", "phone", "city", "address", "payment", "items", "subtotal", "shipping", "discount", "total", "currency", "coupon", "notes"],
      ...orders.map((order) => [
        order.id, order.createdAt, order.status, order.customer?.name, order.customer?.phone, order.customer?.city, order.customer?.address,
        order.payment?.name, (order.items || []).map((item) => `${item.title} x${item.qty}`).join(" | "),
        order.subtotal, order.shipping, order.discount, order.total, order.currency || "MRU", order.coupon || "", order.customer?.notes || ""
      ])
    ];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `restore-orders-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
    toast(dt("تم تصدير الطلبات", "Commandes exportées"), "good");
  }

  /* --------------------------------------------------------------------------
     Abandoned checkout
     -------------------------------------------------------------------------- */
  function viewAbandoned() {
    const all = R.getAbandoned();
    const list = all.filter((item) => abandonedFilter === "all" || item.status === abandonedFilter);
    return `
      <div class="dash-view-head">
        <div><h2>${dt("السلال المتروكة", "Paniers abandonnés")}</h2><p>${dt("بيانات تُحفظ أثناء ملء العميل لصفحة الدفع.", "Données enregistrées pendant la saisie au checkout.")}</p></div>
      </div>
      <div class="dash-toolbar"><div class="segmented">${[["open", dt("مفتوحة", "Ouverts")], ["contacted", dt("تم التواصل", "Contactés")], ["closed", dt("مغلقة", "Fermés")], ["all", dt("الكل", "Tous")]].map(([id, label]) => `<button data-abandoned-filter="${id}" class="${abandonedFilter === id ? "active" : ""}">${label}</button>`).join("")}</div><div class="spacer"></div><span class="badge-soft orange">${all.filter((item) => item.status === "open").length} ${dt("مفتوحة", "ouverts")}</span></div>
      <div class="dash-card">${list.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("العميل", "Client")}</th><th>${dt("الهاتف", "Téléphone")}</th><th>${dt("المدينة", "Ville")}</th><th>${dt("السلة", "Panier")}</th><th>${dt("القيمة", "Valeur")}</th><th>${dt("التاريخ", "Date")}</th><th>${dt("الحالة", "Statut")}</th><th></th></tr></thead><tbody>
        ${list.map((item) => `<tr>
          <td><strong>${esc(item.name || dt("زائر", "Visiteur"))}</strong></td>
          <td dir="ltr">${esc(item.phone || "—")}</td>
          <td>${esc(item.city || "—")}</td>
          <td>${(item.items || []).map((product) => `${esc(product.title)} ×${product.qty}`).join("<br>") || "—"}</td>
          <td class="price">${money(item.subtotal || 0)}</td>
          <td>${esc(fmtDateTime(item.updatedAt || item.createdAt))}</td>
          <td><span class="badge-soft">${esc(item.status || "open")}</span></td>
          <td><div class="cell-actions">
            ${item.phone ? `<a class="btn btn-sm btn-soft" href="https://wa.me/${digits(item.phone)}?text=${encodeURIComponent(dt("مرحباً، رأينا أنك لم تكمل طلبك من ريستور. هل نساعدك؟", "Bonjour, nous avons vu que vous n’avez pas finalisé votre commande Restore. Pouvons-nous vous aider ?"))}" target="_blank" rel="noopener">${icon("whatsapp")}</a>` : ""}
            <button class="btn btn-sm btn-soft" data-action="abandoned-status" data-id="${esc(item.id)}" data-status="contacted">${dt("تم التواصل", "Contacté")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-abandoned" data-id="${esc(item.id)}">${icon("trash")}</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>` : `<div class="table-empty">${icon("abandoned")}<p>${dt("لا توجد سلال متروكة.", "Aucun panier abandonné.")}</p></div>`}</div>`;
  }

  /* --------------------------------------------------------------------------
     Products
     -------------------------------------------------------------------------- */
  function filteredProducts() {
    const needle = R.normalizeText(productSearch);
    return productList().filter((product) => {
      if (productCategory !== "all" && !(product.collections || []).includes(productCategory)) return false;
      if (productStock === "low" && Number(product.stock) > Number(model.settings.lowStockThreshold || 2)) return false;
      if (productStock === "out" && Number(product.stock) > 0) return false;
      if (!needle) return true;
      return R.normalizeText([product.title, product.handle, product.vendor, product.type, product.sku].join(" ")).includes(needle);
    });
  }

  function viewProducts() {
    const list = filteredProducts();
    const shown = list.slice(0, 80);
    return `
      <div class="dash-view-head">
        <div><h2>${dt("المنتجات", "Produits")}</h2><p>${list.length} ${dt("منتج في المخزون", "produits en stock")} · ${lowStockProducts().length} ${dt("بحاجة لتعبئة", "à réapprovisionner")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" data-action="bulk-price">${icon("edit")} ${dt("تعديل أسعار جماعي", "Prix groupés")}</button><button class="btn btn-primary" data-action="add-product">${icon("plus")} ${dt("منتج جديد", "Nouveau produit")}</button></div>
      </div>
      <div class="dash-toolbar">
        <label class="field" style="min-width:210px"><input id="product-search" placeholder="${dt("بحث عن منتج...", "Rechercher un produit...")}" value="${esc(productSearch)}"></label>
        <label class="field"><select data-product-filter="category"><option value="all">${dt("كل الفئات", "Toutes catégories")}</option>${model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${productCategory === collection.handle ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("")}</select></label>
        <label class="field"><select data-product-filter="stock"><option value="all">${dt("كل المخزون", "Tout le stock")}</option><option value="low" ${productStock === "low" ? "selected" : ""}>${dt("مخزون منخفض", "Stock faible")}</option><option value="out" ${productStock === "out" ? "selected" : ""}>${dt("نفد المخزون", "Épuisé")}</option></select></label>
        <div class="spacer"></div>
        <span class="badge-soft">${shown.length}/${list.length}</span>
        ${directToggle(dt("إخفاء المنتجات المنتهية من المتجر", "Masquer les produits épuisés"), "settings.autoHideOutOfStock", model.settings.autoHideOutOfStock)}
      </div>
      <div class="dash-card">
        ${shown.length ? `<div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("SKU", "SKU")}</th><th>${dt("الفئة", "Catégorie")}</th><th>${dt("السعر", "Prix")}</th><th>${dt("المخزون", "Stock")}</th><th>${dt("الحالة", "Statut")}</th><th>${dt("المتجر", "Boutique")}</th><th></th></tr></thead><tbody>
          ${shown.map((product) => {
            const productIndex = model.products.indexOf(product);
            const category = model.collections.find((collection) => (product.collections || []).includes(collection.handle));
            const isLow = Number(product.stock) <= Number(model.settings.lowStockThreshold || 2);
            return `<tr>
              <td><div class="cell-main"><img src="${esc(product.image)}" alt=""><div><strong>${esc(product.title)}</strong><small>${esc(product.type || "")} · ${esc(product.condition || "")}</small></div></div></td>
              <td style="direction:ltr">${esc(product.sku || product.handle)}</td>
              <td>${esc(category ? lng(category.title) : (product.collections?.[0] || "—"))}</td>
              <td class="price">${money(product.price)}${product.compare > product.price ? `<br><small style="text-decoration:line-through;color:var(--soft-muted)">${money(product.compare)}</small>` : ""}</td>
              <td><div style="display:flex;flex-direction:column;gap:3px"><strong style="font-size:9px;color:${Number(product.stock) <= 0 ? "var(--danger)" : isLow ? "#e67e22" : "inherit"}">${product.stock}</strong><div class="mini-bar" style="--bar:${isLow ? "#e67e22" : "#25a55f"};min-width:50px"><i style="width:${Math.min(100, Math.max(3, Number(product.stock) / 20 * 100))}%"></i></div></div></td>
              <td><span class="badge-soft ${product.active !== false ? "green" : ""}">${product.active !== false ? dt("نشط", "Actif") : dt("مخفي", "Masqué")}</span></td>
              <td><label class="toggle"><input type="checkbox" data-product-active="${productIndex}" ${product.active !== false ? "checked" : ""}><span></span></label></td>
              <td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-product" data-index="${productIndex}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-product" data-index="${productIndex}">${icon("trash")}</button></div></td>
            </tr>`;
          }).join("")}</tbody></table></div>` : `<div class="table-empty">${icon("products")}<p>${dt("لا توجد منتجات مطابقة.", "Aucun produit correspondant.")}</p></div>`}
      </div>`;
  }

  function productEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? {
      handle: `restore-${Date.now().toString(36)}`, title: { ar: "منتج جديد", fr: "Nouveau produit" }, vendor: "Restore",
      type: "Smartphone", condition: "Good", price: 0, compare: 0, stock: 1, battery: 90, active: true,
      image: "assets/products/iphone-13-pro-max-1.png", images: ["assets/products/iphone-13-pro-max-1.png"],
      description: { ar: "", fr: "" }, includes: [], specs: {}, colors: [], colorImages: {}, variants: [],
      collections: [], sku: "", warrantyMonths: 12
    } : clone(model.products[index]);
    editBuffer = buffer;
    const categoryOptions = model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${buffer.collections?.includes(collection.handle) ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("");
    openModal(isNew ? dt("منتج جديد", "Nouveau produit") : buffer.title?.ar || buffer.title, `
      <div class="dash-tabs"><button class="active" type="button">${dt("المعلومات", "Informations")}</button><button type="button" data-product-tab="media">${dt("الصور والألوان", "Images & couleurs")}</button><button type="button" data-product-tab="specs">${dt("المواصفات", "Spécifications")}</button></div>
      <div class="dash-panel active" data-product-panel="main">
        <div class="form-grid">
          ${editBi(dt("اسم المنتج", "Nom du produit"), "title", buffer.title)}
          <div class="field"><label>${dt("المعرف", "Identifiant")}</label><input data-edit-path="handle" value="${esc(buffer.handle)}" dir="ltr" ${isNew ? "" : "readonly"}></div>
          <div class="field"><label>${dt("الفئة", "Catégorie")}</label><select data-edit-path="collections.0"><option value="">—</option>${categoryOptions}</select></div>
          <div class="field"><label>Vendor</label><input data-edit-path="vendor" value="${esc(buffer.vendor)}"></div>
          <div class="field"><label>${dt("النوع", "Type")}</label><select data-edit-path="type">${["Smartphone", "Macbook", "Laptop", "Tablets", "Apple Watch", "Playstation", "Accessories"].map((type) => `<option ${buffer.type === type ? "selected" : ""}>${type}</option>`).join("")}</select></div>
          <div class="field"><label>${dt("الحالة", "État")}</label><select data-edit-path="condition">${["Like New", "Excellent", "Very Good", "Good", "Fair", "New"].map((condition) => `<option ${buffer.condition === condition ? "selected" : ""}>${condition}</option>`).join("")}</select></div>
          <div class="field"><label>${dt("السعر (MRU)", "Prix (MRU)")}</label><input type="number" data-edit-path="price" value="${esc(buffer.price)}"></div>
          <div class="field"><label>${dt("السعر قبل الخصم", "Prix barré")}</label><input type="number" data-edit-path="compare" value="${esc(buffer.compare)}"></div>
          <div class="field"><label>${dt("المخزون", "Stock")}</label><input type="number" data-edit-path="stock" value="${esc(buffer.stock)}"></div>
          <div class="field"><label>${dt("صحة البطارية %", "Santé batterie %")}</label><input type="number" data-edit-path="battery" value="${esc(buffer.battery)}"></div>
          <div class="field"><label>${dt("الضمان (أشهر)", "Garantie (mois)")}</label><input type="number" data-edit-path="warrantyMonths" value="${esc(buffer.warrantyMonths || 12)}"></div>
          <div class="field"><label>SKU</label><input data-edit-path="sku" value="${esc(buffer.sku || "")}"></div>
          ${editBi(dt("الوصف", "Description"), "description", buffer.description, { type: "textarea", rows: 4 })}
          <div class="span-2">${editToggle(dt("إظهار المنتج في المتجر", "Afficher dans la boutique"), "active", buffer.active !== false)}</div>
        </div>
      </div>
      <div class="dash-panel" data-product-panel="media">
        <div class="form-grid">
          ${imageEditor(dt("الصورة الرئيسية", "Image principale"), "image", buffer.image)}
          <div class="field span-2"><label>${dt("صور إضافية (رابط في كل سطر)", "Images supplémentaires (une URL par ligne)")}</label><textarea data-edit-path="images" rows="4" data-json="array">${esc((buffer.images || []).join("\n"))}</textarea></div>
          <div class="field"><label>${dt("ألوان (اسم:لون:#hex)", "Couleurs (nom:couleur:#hex)")}</label><textarea data-edit-path="colors" rows="4" data-colors>${esc((buffer.colors || []).map((color) => `${color.name}:${color.hex}`).join("\n"))}</textarea></div>
          <div class="field"><label>${dt("صور الألوان (اسم:رابط)", "Images couleurs (nom:URL)")}</label><textarea data-edit-path="colorImages" rows="4" data-colormap>${esc(Object.entries(buffer.colorImages || {}).map(([key, value]) => `${key}:${value}`).join("\n"))}</textarea></div>
          <div class="field span-2"><label>${dt("المتغيرات (JSON متقدم)", "Variantes (JSON avancé)")}</label><textarea data-edit-path="variants" rows="5" data-json="raw">${esc(JSON.stringify(buffer.variants || [], null, 2))}</textarea></div>
        </div>
      </div>
      <div class="dash-panel" data-product-panel="specs">
        <div class="form-grid">
          <div class="field span-2"><label>${dt("المواصفات (JSON)", "Spécifications (JSON)")}</label><textarea data-edit-path="specs" rows="14" data-json="raw">${esc(JSON.stringify(buffer.specs || {}, null, 2))}</textarea><p class="form-note">${dt("أمثلة: cpu, ram, storage, screen, condition, keyboard, battery. كل قيمة تحتوي label و value و choices.", "Exemples : cpu, ram, storage, screen, condition, keyboard, battery. Chaque valeur contient label, value et choices.")}</p></div>
          <div class="field span-2"><label>${dt("ماذا يوجد في العلبة (JSON)", "Contenu de la boîte (JSON)")}</label><textarea data-edit-path="includes" rows="7" data-json="raw">${esc(JSON.stringify(buffer.includes || [], null, 2))}</textarea></div>
        </div>
      </div>`, {
      wide: true,
      footer: editorFooter(!isNew, "delete-product-buffer"),
      onMount: (root) => {
        root.querySelectorAll("[data-product-tab]").forEach((tab) => tab.addEventListener("click", () => {
          root.querySelectorAll("[data-product-tab]").forEach((item) => item.classList.toggle("active", item === tab));
          root.querySelectorAll("[data-product-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.productPanel === tab.dataset.productTab));
        }));
      }
    });
    // Attach save specifically through the shared action, while preserving the newly created index.
    pendingProductIndex = isNew ? null : index;
  }
  let pendingProductIndex = null;

  function saveProductEditor() {
    const item = editBuffer;
    if (!item) return;
    // Parse the structured fields that use helper textareas.
    const editingModal = $(".dash-modal");
    editingModal?.querySelectorAll("[data-colors]").forEach((node) => {
      item.colors = node.value.split("\n").map((line) => {
        const parts = line.split(":").map((part) => part.trim());
        return parts[0] ? { name: parts[0], hex: parts[1]?.startsWith("#") ? parts[1] : `#${parts[1] || "999999"}` } : null;
      }).filter(Boolean);
    });
    editingModal?.querySelectorAll("[data-colormap]").forEach((node) => {
      item.colorImages = Object.fromEntries(node.value.split("\n").map((line) => line.split(":")).filter((parts) => parts.length >= 2).map((parts) => [parts[0].trim(), parts.slice(1).join(":").trim()]));
    });
    editingModal?.querySelectorAll("[data-json]").forEach((node) => {
      const path = node.dataset.editPath;
      if (path === "images") {
        item.images = node.value.split("\n").map((line) => line.trim()).filter(Boolean);
        if (item.images[0]) item.image = item.images[0];
        return;
      }
      try {
        if (!node.value.trim()) { setPath(item, path, node.dataset.json === "array" ? [] : null); return; }
        const parsed = JSON.parse(node.value);
        setPath(item, path, parsed);
      } catch {
        toast(`${dt("JSON غير صالح في", "JSON invalide dans")} ${path}`, "error");
      }
    });
    item.price = Number(item.price) || 0;
    item.compare = Number(item.compare) || 0;
    item.stock = Number(item.stock) || 0;
    item.battery = Number(item.battery) || 0;
    item.warrantyMonths = Number(item.warrantyMonths) || 12;
    if (item.active == null) item.active = true;
    if (pendingProductIndex == null) {
      if (model.products.some((product) => product.handle === item.handle)) { toast(dt("المعرف مستخدم مسبقًا", "Identifiant déjà utilisé"), "error"); return; }
      model.products.unshift(item);
    } else {
      model.products[pendingProductIndex] = item;
    }
    saveDraftNow();
    closeModal();
    R.addAudit(`${dt("حفظ منتج", "Produit enregistré")}: ${item.title?.ar || item.handle}`);
    toast(dt("تم حفظ المنتج في المسودة", "Produit enregistré dans le brouillon"), "good");
    renderRoute();
  }

  function bulkPriceModal() {
    openModal(dt("تعديل الأسعار الجماعي", "Modification groupée des prix"), `
      <div class="field"><label>${dt("الفئة", "Catégorie")}</label><select id="bulk-category"><option value="all">${dt("كل الفئات", "Toutes")}</option>${model.collections.map((collection) => `<option value="${esc(collection.handle)}">${esc(lng(collection.title))}</option>`).join("")}</select></div>
      <div class="form-grid" style="margin-top:10px"><div class="field"><label>${dt("نسبة التغيير %", "Pourcentage")}</label><input id="bulk-percent" type="number" value="5" placeholder="5"></div><div class="field"><label>${dt("الاتجاه", "Sens")}</label><select id="bulk-direction"><option value="up">${dt("زيادة", "Augmenter")}</option><option value="down">${dt("تخفيض", "Diminuer")}</option></select></div></div>
      <p class="form-note" style="margin-top:10px">${dt("سيتم تحديث السعر الأخير مع الحفاظ على السعر المشطوب كما هو. يمكنك التراجع بعدم النشر.", "Le prix sera ajusté. Le prix barré reste inchangé. Vous pouvez annuler avant publication.")}</p>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="apply-bulk-price">${dt("تطبيق", "Appliquer")}</button>`
    });
  }

  function applyBulkPrice() {
    const category = $("#bulk-category")?.value || "all";
    const percent = Number($("#bulk-percent")?.value) || 0;
    const direction = $("#bulk-direction")?.value || "up";
    let count = 0;
    model.products.forEach((product) => {
      if (product.active === false) return;
      if (category !== "all" && !(product.collections || []).includes(category)) return;
      const factor = direction === "up" ? 1 + percent / 100 : 1 - percent / 100;
      product.price = Math.max(0, Math.round(Number(product.price) * factor / 5) * 5);
      count += 1;
    });
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(`${count} ${dt("منتجًا تم تحديث سعره", "produits mis à jour")}`, "good");
  }

  function deleteProduct(index, fromBuffer = false) {
    const product = fromBuffer ? editBuffer : model.products[index];
    if (!product) return;
    if (!confirm(`${dt("حذف", "Supprimer")} ${product.title?.ar || product.handle}?`)) return;
    if (fromBuffer) model.products = model.products.filter((item) => item.handle !== product.handle);
    else model.products.splice(index, 1);
    saveDraftNow();
    closeModal();
    R.addAudit(`${dt("حذف منتج", "Produit supprimé")}: ${product.handle}`);
    renderRoute();
    toast(dt("تم حذف المنتج من المسودة", "Produit supprimé du brouillon"), "good");
  }

  /* --------------------------------------------------------------------------
     Categories
     -------------------------------------------------------------------------- */
  function viewCategories() {
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الفئات", "Catégories")}</h2><p>${dt("تظهر الفئات في القائمة والصفحة الرئيسية.", "Les catégories apparaissent dans le menu et l’accueil.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-primary" data-action="add-category">${icon("plus")} ${dt("فئة جديدة", "Nouvelle catégorie")}</button></div>
      </div>
      <div class="dash-grid cols-2">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("فئات المتجر", "Catégories boutique")}</h3><span class="badge-soft">${model.theme.categories.length}</span></div><div class="dash-card-body">
          <div class="list-editor">${model.theme.categories.map((category, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(category.label))}</strong><small class="handle">${esc(category.handle)}</small></div><button class="btn btn-sm btn-soft" data-action="edit-category" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-category" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
        </div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("المجموعات", "Collections")}</h3><span class="badge-soft">${model.collections.length}</span></div><div class="dash-card-body">
          <div class="list-editor">${model.collections.map((collection, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(collection.title))}</strong><small class="handle">${esc(collection.handle)}</small></div>${directToggle("", `collections.${index}.visible`, collection.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-collection" data-index="${index}">${icon("edit")}</button></div>`).join("")}</div>
        </div></article>
      </div>`;
  }

  function categoryEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { label: { ar: "فئة جديدة", fr: "Nouvelle catégorie" }, handle: `category-${Date.now().toString(36)}`, image: "assets/img/category-iphone.png" } : clone(model.theme.categories[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("فئة جديدة", "Nouvelle catégorie") : lng(buffer.label), `
      <div class="form-grid">
        ${editBi(dt("اسم الفئة", "Nom"), "label", buffer.label)}
        <div class="field"><label>${dt("المعرف", "Identifiant")}</label><input data-edit-path="handle" value="${esc(buffer.handle)}" dir="ltr"></div>
        <div class="span-2">${imageEditor(dt("صورة الفئة", "Image"), "image", buffer.image)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-category-buffer"),
      onMount: () => { pendingCategoryIndex = isNew ? null : index; }
    });
  }
  let pendingCategoryIndex = null;

  function saveCategoryEditor() {
    const item = editBuffer;
    if (!item) return;
    if (pendingCategoryIndex == null) model.theme.categories.push(item);
    else model.theme.categories[pendingCategoryIndex] = item;
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(dt("تم حفظ الفئة", "Catégorie enregistrée"), "good");
  }

  function collectionEditor(index) {
    const buffer = clone(model.collections[index]);
    editBuffer = buffer;
    openModal(lng(buffer.title), `
      <div class="form-grid">${editBi(dt("اسم المجموعة", "Nom de la collection"), "title", buffer.title)}<div class="field"><label>${dt("المعرف", "Identifiant")}</label><input value="${esc(buffer.handle)}" readonly dir="ltr"></div></div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-collection" data-index="${index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }
  /* --------------------------------------------------------------------------
     Storefront content and navigation
     -------------------------------------------------------------------------- */
  function isoLocal(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const pad = (number) => String(number).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function directImageEditor(label, path, value = "") {
    return `<div class="field"><label>${esc(label)}</label><div class="image-field">
      <span class="image-preview"><img data-preview-for="${esc(path)}" src="${esc(value || "assets/img/favicon.svg")}" alt=""></span>
      <div class="grow">
        <input data-path="${esc(path)}" value="${esc(value)}" placeholder="assets/img/...">
        <label class="upload-btn">${icon("upload")} ${dt("رفع صورة", "Téléverser")}<input type="file" accept="image/*" data-upload-path="${esc(path)}" data-upload-target="direct"></label>
      </div>
    </div></div>`;
  }

  function viewContent() {
    const settings = model.settings;
    return `
      <div class="dash-view-head">
        <div><h2>${dt("نصوص المتجر", "Textes & contenu")}</h2><p>${dt("كل نص يظهر في المتجر قابل للتعديل هنا بالعربية والفرنسية.", "Chaque texte visible sur la boutique est modifiable ici en arabe et en français.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-primary" data-action="save-draft">${icon("check")} ${dt("حفظ المسودة", "Enregistrer")}</button></div>
      </div>
      <div class="dash-tabs">
        <button class="active" type="button" data-dash-tab="content-main">${dt("الهوية والنصوص", "Identité & textes")}</button>
        <button type="button" data-dash-tab="content-contact">${dt("التواصل والمواعيد", "Contact & horaires")}</button>
        <button type="button" data-dash-tab="content-trust">${dt("شريط الثقة", "Barre de confiance")}</button>
        <button type="button" data-dash-tab="content-nav">${dt("القائمة", "Navigation")}</button>
        <button type="button" data-dash-tab="content-footer">${dt("التذييل", "Pied de page")}</button>
      </div>
      <div class="dash-panel active" data-dash-panel="content-main">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("النصوص الأساسية", "Textes principaux")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("اسم المتجر", "Nom de la boutique"), "settings.storeName")}
            ${biField(dt("الشعار النصي", "Slogan"), "settings.tagline")}
            ${biField(dt("شريط الإعلان", "Bandeau d’annonce"), "settings.announcement", { type: "textarea", rows: 2 })}
            ${biField(dt("عنوان الفئات", "Titre catégories"), "settings.categoriesTitle")}
            ${biField(dt("عنوان خدمة العملاء", "Titre service"), "settings.serviceTitle", { type: "textarea", rows: 2 })}
            ${biField(dt("عنوان آراء العملاء", "Titre avis"), "settings.reviewsTitle")}
            ${biField(dt("عنوان الصحافة", "Titre presse"), "settings.pressTitle")}
            ${biField(dt("نص المجدد", "Texte reconditionné"), "settings.renewalText")}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام مخصصة", "Sections personnalisées")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("عنوان الثقة", "Titre confiance"), "settings.trustTitle")}
            ${biField(dt("عنوان المجتمع", "Titre communauté"), "settings.communityTitle")}
            ${biField(dt("ملاحظة الشحن", "Note livraison"), "settings.shippingNote", { type: "textarea", rows: 2 })}
            ${field(dt("الحد الأدنى للشحن المجاني (MRU)", "Seuil livraison gratuite (MRU)"), "settings.freeShippingOver", { type: "number" })}
            ${field(dt("رقم الهاتف للعرض", "Téléphone affiché"), "settings.phoneDisplay")}
            ${field("WhatsApp", "settings.whatsapp", { hint: dt("أرقام فقط مع رمز الدولة، مثال 22246000000", "Chiffres uniquement avec indicatif, ex. 22246000000") })}
            ${field(dt("البريد الإلكتروني", "E-mail"), "settings.email", { type: "email" })}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="content-contact">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات التواصل", "Coordonnées")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("العنوان", "Adresse"), "settings.address", { type: "textarea", rows: 2 })}
            ${field(dt("الهاتف", "Téléphone"), "settings.phone")}
            ${field(dt("واتساب", "WhatsApp"), "settings.whatsapp")}
            ${field(dt("بريد الدعم", "E-mail support"), "settings.email", { type: "email" })}
            ${field(dt("المنطقة الزمنية", "Fuseau horaire"), "settings.timezone")}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("ساعات العمل والحالة", "Horaires et état")}</h3></div><div class="dash-card-body dash-form">
            <div class="form-grid">${field(dt("الفتح", "Ouverture"), "settings.hours.open", { type: "time" })}${field(dt("الإغلاق", "Fermeture"), "settings.hours.close", { type: "time" })}</div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.hours.closed" data-type="bool" ${settings.hours.closed ? "checked" : ""}><span></span></label><span>${dt("إغلاق المتجر مؤقتًا", "Fermer temporairement")}</span></div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.hours.maintenance" data-type="bool" ${settings.hours.maintenance ? "checked" : ""}><span></span></label><span>${dt("وضع الصيانة", "Mode maintenance")}</span></div>
            ${biField(dt("رسالة الإغلاق", "Message de fermeture"), "settings.closedMessage", { type: "textarea", rows: 2 })}
            <p class="form-note">${dt("تظهر حالة المتجر تلقائيًا للزوار حسب ساعات العمل. الأوقات بتوقيت نواكشوط.", "L’état est calculé selon les horaires. Heure de Nouakchott.")}</p>
            <p class="form-note">${dt("ساعات اليوم", "Aujourd’hui")}: <strong>${R.isStoreOpen() ? dt("مفتوح", "Ouvert") : dt("مغلق", "Fermé")}</strong></p>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="content-trust">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("شريط الثقة", "Barre de confiance")}</h3><button data-action="add-trust">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="dash-form">${(settings.trustBar || []).map((item, index) => `<div class="form-section"><div class="form-grid"><div class="field"><label>${dt("الأيقونة", "Icône")}</label><input data-path="settings.trustBar.${index}.icon" value="${esc(item.icon)}"></div><div class="field"><label>${dt("العربي", "Arabe")}</label><input data-path="settings.trustBar.${index}.label.ar" value="${esc(item.label?.ar || "")}" dir="rtl"></div><div class="field"><label>Français</label><input data-path="settings.trustBar.${index}.label.fr" value="${esc(item.label?.fr || "")}" dir="ltr"></div><div style="display:flex;align-items:flex-end"><button class="btn btn-sm btn-danger" data-action="remove-trust" data-index="${index}">${icon("trash")}</button></div></div></div>`).join("")}</div>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="content-nav">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("قائمة التنقل", "Navigation")}</h3><button data-action="add-nav">${icon("plus")} ${dt("إضافة عنصر", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="list-editor">${(settings.navigation || []).map((item, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(item.label))}</strong><small class="handle">${esc(item.href)}</small></div>${directToggle("", `settings.navigation.${index}.visible`, item.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-nav" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-nav" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
          <p class="form-note" style="margin-top:10px">${dt("كل عنصر يمكن أن يحتوي على قائمة فرعية. استخدم محرر العنصر لإضافة روابط مثل S24 Series أو iPhone 16.", "Chaque entrée peut contenir un sous-menu. Utilisez l’éditeur pour ajouter des liens comme Galaxy S24.")}</p>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="content-footer">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أعمدة التذييل", "Colonnes du pied de page")}</h3></div><div class="dash-card-body dash-form">
          ${(settings.footerColumns || []).map((column, index) => `<div class="form-section"><h4>${dt("عمود", "Colonne")} ${index + 1}</h4><div class="form-grid">${["ar", "fr"].map((language) => `<div class="field"><label>${language.toUpperCase()}</label><input data-path="settings.footerColumns.${index}.title.${language}" value="${esc(column.title?.[language] || "")}" dir="${language === "ar" ? "rtl" : "ltr"}"></div>`).join("")}</div><div class="field" style="margin-top:8px"><label>${dt("روابط (اسم|رابط في كل سطر)", "Liens (nom|URL par ligne)")}</label><textarea rows="4" data-lines-path="settings.footerColumns.${index}.links">${esc((column.links || []).map((link) => `${link.label?.ar || ""}|${link.label?.fr || ""}|${link.href}`).join("\n"))}</textarea></div></div>`).join("")}
          <button class="btn btn-soft" data-action="add-footer-column">${icon("plus")} ${dt("إضافة عمود", "Ajouter une colonne")}</button>
        </div></article>
      </div>`;
  }

  function navEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `nav-${Date.now().toString(36)}`, label: { ar: "عنصر جديد", fr: "Nouvel élément" }, href: "collection.html?handle=all", visible: true, sub: [] } : clone(model.settings.navigation[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("عنصر قائمة", "Élément de navigation") : lng(buffer.label), `
      <div class="form-grid">
        ${editBi(dt("الاسم", "Nom"), "label", buffer.label)}
        ${editInput(dt("الرابط", "Lien"), "href", { value: buffer.href })}
        <div class="field span-2"><label>${dt("قائمة فرعية (اسم عربي|اسم فرنسي|رابط في كل سطر)", "Sous-menu (nom AR|nom FR|URL par ligne)")}</label><textarea rows="6" data-subnav>${esc((buffer.sub || []).map((item) => `${item.label?.ar || ""}|${item.label?.fr || ""}|${item.href}`).join("\n"))}</textarea></div>
        ${editToggle(dt("ظاهر", "Visible"), "visible", buffer.visible !== false)}
      </div>`, {
      footer: editorFooter(!isNew, "delete-nav-buffer"),
      onMount: () => { pendingNavIndex = isNew ? null : index; }
    });
  }
  let pendingNavIndex = null;

  function saveNavEditor() {
    const item = editBuffer;
    if (!item) return;
    const subNode = $("[data-subnav]");
    item.sub = (subNode?.value || "").split("\n").map((line) => {
      const [ar, fr, href] = line.split("|").map((part) => part.trim());
      return ar && href ? { label: { ar, fr: fr || ar }, href } : null;
    }).filter(Boolean);
    if (pendingNavIndex == null) model.settings.navigation.push(item);
    else model.settings.navigation[pendingNavIndex] = item;
    saveDraftNow();
    closeModal();
    renderRoute();
    toast(dt("تم حفظ عنصر القائمة", "Navigation enregistrée"), "good");
  }

  /* --------------------------------------------------------------------------
     Homepage
     -------------------------------------------------------------------------- */
  const PAGE_SECTION_LABELS = {
    hero: { ar: "السلايدر الرئيسي", fr: "Hero / Slider" },
    trust: { ar: "شريط الثقة", fr: "Barre de confiance" },
    renewed: { ar: "ما معنى مجدد", fr: "Reconditionné" },
    categories: { ar: "الفئات", fr: "Catégories" },
    offer: { ar: "عرض بنكيلي", fr: "Offre Bankily" },
    products: { ar: "أقسام المنتجات", fr: "Sections produits" },
    sustain: { ar: "الاستدامة", fr: "Durabilité" },
    service: { ar: "الخدمات", fr: "Services" },
    video: { ar: "المجتمع والفيديو", fr: "Communauté & vidéo" },
    reviews: { ar: "آراء العملاء", fr: "Avis clients" },
    press: { ar: "الصحافة", fr: "Presse" }
  };

  function viewHomepage() {
    const sections = [...(model.settings.pageSections || [])].sort((a, b) => Number(a.order) - Number(b.order));
    const productSections = [...(model.settings.homeSections || [])].sort((a, b) => Number(a.order) - Number(b.order));
    return `
      <div class="dash-view-head">
        <div><h2>${dt("الصفحة الرئيسية", "Page d’accueil")}</h2><p>${dt("أعد ترتيب الأقسام، أخفِ أي قسم، وعدّل السلايدر والعروض.", "Réorganisez les sections, masquez-en et modifiez le slider.")}</p></div>
        <div class="dash-view-actions"><button class="btn btn-soft" data-action="preview">${icon("preview")} ${dt("معاينة", "Aperçu")}</button></div>
      </div>
      <div class="dash-tabs"><button class="active" data-dash-tab="home-sections">${dt("ترتيب الأقسام", "Ordre des sections")}</button><button data-dash-tab="home-hero">${dt("السلايدر", "Slider")}</button><button data-dash-tab="home-products">${dt("أقسام المنتجات", "Sections produits")}</button></div>
      <div class="dash-panel active" data-dash-panel="home-sections">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام الصفحة", "Sections de la page")}</h3><span class="badge-soft">${sections.filter((section) => section.visible !== false).length}/${sections.length}</span></div><div class="dash-card-body"><div class="list-editor">
            ${sections.map((section, index) => `<div class="list-row"><span class="drag">${icon("arrows")}</span><div class="grow"><strong>${esc(PAGE_SECTION_LABELS[section.id]?.[dashLang] || section.id)}</strong><small>${section.id}</small></div><div class="row-actions"><button class="btn btn-sm btn-soft" data-action="page-section-up" data-id="${section.id}" ${index === 0 ? "disabled" : ""}>${icon("up")}</button><button class="btn btn-sm btn-soft" data-action="page-section-down" data-id="${section.id}" ${index === sections.length - 1 ? "disabled" : ""}>${icon("down")}</button><label class="toggle"><input type="checkbox" data-page-section-visible="${section.id}" ${section.visible !== false ? "checked" : ""}><span></span></label></div></div>`).join("")}
          </div><p class="form-note" style="margin-top:10px">${dt("التغييرات تظهر في المعاينة فورًا وتُنشر عند الضغط على نشر.", "Les changements apparaissent dans l’aperçu et sont publiés via Publier.")}</p></div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معاينة الترتيب", "Aperçu de l’ordre")}</h3></div><div class="dash-card-body">
            <div style="border:1px solid var(--border);border-radius:10px;padding:10px;display:grid;gap:5px;background:var(--surface-2)">
              ${sections.filter((section) => section.visible !== false).map((section, index) => `<div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:7px 9px;font-size:9px;display:flex;justify-content:space-between"><span>${index + 1}. ${esc(PAGE_SECTION_LABELS[section.id]?.[dashLang] || section.id)}</span><span style="color:var(--soft-muted)">${section.id}</span></div>`).join("")}
            </div>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="home-hero">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("شرائح السلايدر", "Diapositives")}</h3><button data-action="add-hero">${icon("plus")} ${dt("إضافة شريحة", "Ajouter")}</button></div><div class="dash-card-body">
          <div class="list-editor">${(model.settings.heroSlides || []).map((slide, index) => `<div class="list-row"><span class="image-preview" style="width:44px;height:44px;flex-basis:44px"><img src="${esc(slide.image)}" alt=""></span><div class="grow"><strong>${esc(lng(slide.title))}</strong><small>${esc(slide.href)}</small></div>${directToggle("", `settings.heroSlides.${index}.visible`, slide.visible !== false)}<button class="btn btn-sm btn-soft" data-action="edit-hero" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-hero" data-index="${index}">${icon("trash")}</button></div>`).join("")}</div>
          <p class="form-note" style="margin-top:10px">${dt("ضع صورة بخلفية شفافة للحصول على أفضل نتيجة. يمكن استخدام رابط أو رفع صورة.", "Utilisez une image à fond transparent. URL ou téléversement.")}</p>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="home-products">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أقسام المنتجات على الرئيسية", "Sections produits")}</h3></div><div class="dash-card-body">
          <div class="list-editor">${productSections.map((section, index) => `<div class="list-row"><span class="drag">${icon("arrows")}</span><div class="grow"><strong>${esc(lng(section.title))}</strong><small class="handle">${esc(section.collection || "")} · ${esc(section.layout)}</small></div><div class="row-actions"><button class="btn btn-sm btn-soft" data-action="home-section-up" data-id="${section.id}" ${index === 0 ? "disabled" : ""}>${icon("up")}</button><button class="btn btn-sm btn-soft" data-action="home-section-down" data-id="${section.id}" ${index === productSections.length - 1 ? "disabled" : ""}>${icon("down")}</button><label class="toggle"><input type="checkbox" data-home-section-visible="${section.id}" ${section.visible !== false ? "checked" : ""}><span></span></label><button class="btn btn-sm btn-soft" data-action="edit-home-section" data-id="${section.id}">${icon("edit")}</button></div></div>`).join("")}</div>
          <button class="btn btn-soft" style="margin-top:10px" data-action="add-home-section">${icon("plus")} ${dt("إضافة قسم منتجات", "Ajouter une section")}</button>
        </div></article>
      </div>`;
  }

  let pendingHeroIndex = null;
  function heroEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `hero-${Date.now().toString(36)}`, visible: true, title: { ar: "", fr: "" }, subtitle: { ar: "", fr: "" }, cta: { ar: "تسوق الآن", fr: "Découvrir" }, href: "collection.html?handle=all", image: "assets/img/hero-iphone.png", bg: "linear-gradient(135deg,#1f1f2e 0%,#39255b 55%,#ff6400 130%)", dark: true } : clone(model.settings.heroSlides[index]);
    editBuffer = buffer;
    pendingHeroIndex = isNew ? null : index;
    openModal(isNew ? dt("شريحة جديدة", "Nouvelle diapositive") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        ${editBi(dt("العنوان الفرعي", "Sous-titre"), "subtitle", buffer.subtitle, { type: "textarea", rows: 3 })}
        ${editBi(dt("زر الدعوة", "Bouton"), "cta", buffer.cta)}
        ${editInput(dt("رابط الزر", "Lien du bouton"), "href", { value: buffer.href })}
        <div class="field span-2"><label>CSS background</label><input data-edit-path="bg" value="${esc(buffer.bg)}" dir="ltr"></div>
        <div class="field span-2">${imageEditor(dt("صورة الجهاز", "Image appareil"), "image", buffer.image)}</div>
        <div class="span-2">${editToggle(dt("نص داكن على خلفية فاتحة", "Texte foncé sur fond clair"), "dark", buffer.dark === false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-hero-buffer")
    });
  }
  function saveHeroEditor() {
    if (!editBuffer) return;
    if (pendingHeroIndex == null) model.settings.heroSlides.push(editBuffer);
    else model.settings.heroSlides[pendingHeroIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ السلايدر", "Slider enregistré"), "good");
  }

  function homeSectionEditor(id) {
    const index = model.settings.homeSections.findIndex((section) => section.id === id);
    if (index < 0) return;
    const buffer = clone(model.settings.homeSections[index]);
    editBuffer = buffer;
    openModal(lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("المجموعة", "Collection")}</label><select data-edit-path="collection">${model.collections.map((collection) => `<option value="${esc(collection.handle)}" ${collection.handle === buffer.collection ? "selected" : ""}>${esc(lng(collection.title))}</option>`).join("")}</select></div>
        <div class="field"><label>${dt("التخطيط", "Disposition")}</label><select data-edit-path="layout">${["plain", "left", "right"].map((layout) => `<option ${buffer.layout === layout ? "selected" : ""}>${layout}</option>`).join("")}</select></div>
        <div class="field span-2">${imageEditor(dt("صورة البانر الجانبي", "Image promo"), "promo", buffer.promo || "")}</div>
        <div class="span-2">${editToggle(dt("إظهار شعلة", "Afficher la flamme"), "flame", Boolean(buffer.flame))}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-home-section" data-id="${id}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function moveInArray(array, index, direction) {
    const target = index + direction;
    if (target < 0 || target >= array.length) return;
    [array[index], array[target]] = [array[target], array[index]];
    array.forEach((item, position) => { item.order = position + 1; });
  }

  /* --------------------------------------------------------------------------
     Appearance
     -------------------------------------------------------------------------- */
  function viewAppearance() {
    const colors = model.settings.colors || {};
    const fonts = ["Montserrat", "Tajawal", "Cairo", "Inter", "Poppins", "DM Sans"];
    return `
      <div class="dash-view-head"><div><h2>${dt("الهوية والألوان", "Identité & couleurs")}</h2><p>${dt("غيّر الشعار والألوان والخط. تظهر التغييرات في المتجر بعد النشر.", "Changez logo, couleurs et police. Les changements sont publiés sur la boutique.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="preview">${icon("preview")} ${dt("معاينة مباشرة", "Aperçu")}</button></div></div>
      <div class="dash-grid cols-2">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الشعار والأيقونات", "Logo & icônes")}</h3></div><div class="dash-card-body dash-form">
          ${directImageEditor(dt("الشعار الأساسي", "Logo principal"), "settings.logo", model.settings.logo)}
          ${directImageEditor(dt("الشعار الأبيض", "Logo blanc"), "settings.logoWhite", model.settings.logoWhite)}
          ${directImageEditor(dt("أيقونة الموقع", "Favicon"), "settings.favicon", model.settings.favicon)}
          <div class="form-grid">${field(dt("الانحناء (px)", "Arrondi (px)"), "settings.radius", { type: "number" })}<div class="field"><label>${dt("خط الواجهة", "Police")}</label><select data-path="settings.font">${fonts.map((font) => `<option value="${font}" ${model.settings.font === font ? "selected" : ""}>${font}</option>`).join("")}</select></div></div>
        </div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("ألوان العلامة", "Couleurs de marque")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">
            ${field(dt("اللون الأساسي", "Couleur principale"), "settings.colors.primary", { type: "color" })}
            ${field(dt("اللون الثانوي", "Couleur secondaire"), "settings.colors.purple", { type: "color" })}
            ${field(dt("لون النص", "Couleur texte"), "settings.colors.ink", { type: "color" })}
            ${field(dt("الخلفية الفاتحة", "Fond clair"), "settings.colors.lavender", { type: "color" })}
          </div>
          <div style="border-radius:12px;padding:18px;background:var(--surface-2);border:1px solid var(--border);margin-top:4px">
            <span class="eyebrow">${dt("معاينة", "Aperçu")}</span>
            <h3 style="font-size:22px;margin:8px 0 6px">${esc(lng(model.settings.storeName))}</h3>
            <p style="font-size:11px;color:var(--muted);margin-bottom:12px">${esc(lng(model.settings.tagline))}</p>
            <button class="btn btn-primary btn-sm" type="button">${dt("تسوق الآن", "Découvrir")}</button>
            <button class="btn btn-soft btn-sm" type="button" style="margin-inline-start:5px">${dt("معرفة المزيد", "En savoir plus")}</button>
          </div>
          <p class="form-note">${dt("يوفر المتجر الوضع الفاتح والداكن تلقائيًا. الألوان تُطبّق على الأزرار، الشريط العلوي والعروض.", "Le mode clair/sombre est automatique. Les couleurs s’appliquent aux boutons, au header et aux offres.")}</p>
        </div></article>
      </div>
      <article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("الوضع الليلي والحركات", "Mode sombre et animations")}</h3></div><div class="dash-card-body"><div class="form-grid">${directToggle(dt("تفعيل الوضع الليلي للزوار", "Activer le mode sombre"), "settings.darkMode", model.settings.darkMode !== false)}${directToggle(dt("تفعيل الحركات", "Activer les animations"), "settings.animations", model.settings.animations !== false)}${directToggle(dt("تفعيل PWA", "Activer la PWA"), "settings.pwa", model.settings.pwa !== false)}</div></div></article>`;
  }

  /* --------------------------------------------------------------------------
     Marketing / coupons
     -------------------------------------------------------------------------- */
  function viewMarketing() {
    const offer = (model.settings.offers || []).find((item) => item.id === "bankily") || (model.settings.offers || [])[0] || {};
    return `
      <div class="dash-view-head"><div><h2>${dt("العروض والتسويق", "Offres & marketing")}</h2><p>${dt("كوبونات، عرض بنكيلي والبانر الترويجي.", "Coupons, offre Bankily et bannière promo.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="marketing-offer">${dt("عرض بنكيلي", "Offre Bankily")}</button><button data-dash-tab="marketing-coupons">${dt("الكوبونات", "Coupons")}</button><button data-dash-tab="marketing-banner">${dt("بانر وإعلان", "Bannière & annonce")}</button></div>
      <div class="dash-panel active" data-dash-panel="marketing-offer">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("عرض الدفع عبر بنكيلي", "Offre Bankily")}</h3><span class="badge-soft orange">-10%</span></div><div class="dash-card-body dash-form">
            <div class="form-grid">${biField(dt("العنوان", "Titre"), "settings.offers.0.title")}${biField(dt("الوصف", "Sous-titre"), "settings.offers.0.subtitle", { type: "textarea", rows: 2 })}</div>
            <div class="form-grid">${field(dt("كود الخصم", "Code promo"), "settings.offers.0.code")}${field(dt("نهاية العرض", "Fin de l’offre"), "settings.offers.0.endsAt", { type: "datetime-local" })}</div>
            <div class="check-row"><label class="toggle"><input type="checkbox" data-path="settings.offers.0.active" data-type="bool" ${offer.active !== false ? "checked" : ""}><span></span></label><span>${dt("العرض نشط", "Offre active")}</span></div>
            ${biField(dt("نص عرض الدفع في المنتج", "Texte offre au produit"), "settings.paymentOffer", { type: "textarea", rows: 2 })}
            ${field(dt("كود بانكيلي", "Code Bankily"), "settings.paymentOfferCode")}
            <p class="form-note">${dt("يُعرض العد التنازلي تلقائيًا حتى تاريخ النهاية. الكود يُطبق عند اختيار الدفع عبر بنكيلي.", "Le compte à rebours s’affiche jusqu’à la date de fin. Le code s’applique avec Bankily.")}</p>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معاينة العرض", "Aperçu de l’offre")}</h3></div><div class="dash-card-body">
            <div style="border-radius:14px;padding:24px;background:linear-gradient(135deg,#15151d,#3b2235);color:#fff">
              <span style="font-size:9px;letter-spacing:.1em;color:#ffb38b">BANKILY · -10%</span>
              <h3 style="font-size:21px;margin:9px 0 7px;line-height:1.2">${esc(lng(offer.title))}</h3>
              <p style="font-size:10px;color:rgba(255,255,255,.65);line-height:1.6">${esc(lng(offer.subtitle))}</p>
              <span style="display:inline-block;margin-top:13px;border:1px dashed rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;letter-spacing:.12em">${esc(offer.code || "BANKILY10")}</span>
            </div>
            <p class="form-note" style="margin-top:10px">${dt("ينتهي", "Se termine")}: ${esc(offer.endsAt ? fmtDateTime(offer.endsAt) : "—")}</p>
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="marketing-coupons">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("كوبونات الخصم", "Coupons")}</h3><button data-action="add-coupon">${icon("plus")} ${dt("كوبون جديد", "Nouveau coupon")}</button></div><div class="dash-card-body">
          <div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("الكود", "Code")}</th><th>${dt("النوع", "Type")}</th><th>${dt("القيمة", "Valeur")}</th><th>${dt("الحد الأدنى", "Minimum")}</th><th>${dt("الانتهاء", "Expiration")}</th><th>${dt("نشط", "Actif")}</th><th></th></tr></thead><tbody>
            ${(model.settings.coupons || []).map((coupon, index) => `<tr><td><strong style="direction:ltr">${esc(coupon.code)}</strong></td><td>${coupon.type === "percent" ? dt("نسبة", "Pourcentage") : dt("ثابت", "Fixe")}</td><td>${coupon.type === "percent" ? `${coupon.value}%` : money(coupon.value)}</td><td>${money(coupon.minTotal || 0)}</td><td>${coupon.expiresAt ? esc(fmtDate(coupon.expiresAt)) : "—"}</td><td><label class="toggle"><input type="checkbox" data-coupon-active="${index}" ${coupon.active !== false ? "checked" : ""}><span></span></label></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-coupon" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-coupon" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
          </tbody></table></div>
        </div></article>
      </div>
      <div class="dash-panel" data-dash-panel="marketing-banner">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("البانر والرسائل", "Bannière & messages")}</h3></div><div class="dash-card-body dash-form">
          ${biField(dt("شريط الإعلان العلوي", "Bandeau haut"), "settings.announcement", { type: "textarea", rows: 2 })}
          <div class="form-grid">${biField(dt("رسالة المتجر المغلق", "Message boutique fermée"), "settings.closedMessage", { type: "textarea", rows: 2 })}${biField(dt("عنوان عرض الرئيسية", "Titre offre accueil"), "settings.paymentOffer", { type: "textarea", rows: 2 })}</div>
          ${biField(dt("عنوان قسم الاستدامة", "Titre durabilité"), "settings.sustainabilityTitle")}
          <p class="form-note">${dt("البانر يعرض تلقائيًا في أعلى كل صفحات المتجر. يمكن إخفاؤه من إعدادات الواجهة.", "La bannière s’affiche en haut du site. Masquable depuis l’apparence.")}</p>
        </div></article>
      </div>`;
  }

  function couponEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `coupon-${Date.now().toString(36)}`, code: "RESTORE10", type: "percent", value: 10, active: true, minTotal: 0, expiresAt: "" } : clone(model.settings.coupons[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("كوبون جديد", "Nouveau coupon") : buffer.code, `
      <div class="form-grid">
        ${editInput(dt("الكود", "Code"), "code", { value: buffer.code })}
        <div class="field"><label>${dt("النوع", "Type")}</label><select data-edit-path="type"><option value="percent" ${buffer.type === "percent" ? "selected" : ""}>${dt("نسبة مئوية", "Pourcentage")}</option><option value="fixed" ${buffer.type === "fixed" ? "selected" : ""}>${dt("مبلغ ثابت", "Montant fixe")}</option></select></div>
        ${editInput(dt("القيمة", "Valeur"), "value", { type: "number", value: buffer.value })}
        ${editInput(dt("الحد الأدنى للطلب", "Minimum de commande"), "minTotal", { type: "number", value: buffer.minTotal || 0 })}
        ${editInput(dt("تاريخ الانتهاء", "Date d’expiration"), "expiresAt", { type: "date", value: buffer.expiresAt ? String(buffer.expiresAt).slice(0, 10) : "" })}
        <div class="span-2">${editToggle(dt("نشط", "Actif"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-coupon" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  /* --------------------------------------------------------------------------
     Blog and pages
     -------------------------------------------------------------------------- */
  function viewBlog() {
    return `
      <div class="dash-view-head"><div><h2>${dt("المدونة", "Blog")}</h2><p>${dt("مقالات تساعد العملاء وتقوي SEO.", "Des articles utiles et bons pour le SEO.")}</p></div><div class="dash-view-actions"><button class="btn btn-primary" data-action="add-post">${icon("plus")} ${dt("مقال جديد", "Nouvel article")}</button></div></div>
      <div class="dash-card"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المقال", "Article")}</th><th>${dt("الرابط", "Slug")}</th><th>${dt("التاريخ", "Date")}</th><th>${dt("منشور", "Publié")}</th><th></th></tr></thead><tbody>
        ${(model.blog || []).map((post, index) => `<tr><td><div class="cell-main"><img src="${esc(post.image)}" alt=""><div><strong>${esc(lng(post.title))}</strong><small>${esc(lng(post.excerpt))}</small></div></div></td><td class="handle" style="direction:ltr">${esc(post.slug)}</td><td>${esc(post.date)}</td><td><span class="badge-soft ${post.published !== false ? "green" : ""}">${post.published !== false ? dt("منشور", "Publié") : dt("مسودة", "Brouillon")}</span></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-post" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-post" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
      </tbody></table></div></div>`;
  }

  let pendingPostIndex = null;
  function postEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `post-${Date.now().toString(36)}`, slug: `post-${Date.now().toString(36)}`, title: { ar: "", fr: "" }, excerpt: { ar: "", fr: "" }, body: { ar: "", fr: "" }, image: "assets/img/category-iphone.png", date: new Date().toISOString().slice(0, 10), published: true } : clone(model.blog[index]);
    editBuffer = buffer;
    pendingPostIndex = isNew ? null : index;
    openModal(isNew ? dt("مقال جديد", "Nouvel article") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("الرابط", "Slug")}</label><input data-edit-path="slug" value="${esc(buffer.slug)}" dir="ltr"></div>
        <div class="field"><label>${dt("التاريخ", "Date")}</label><input type="date" data-edit-path="date" value="${esc(buffer.date)}"></div>
        ${editBi(dt("المقتطف", "Extrait"), "excerpt", buffer.excerpt, { type: "textarea", rows: 2 })}
        <div class="span-2">${imageEditor(dt("الصورة", "Image"), "image", buffer.image)}</div>
        ${editBi(dt("المحتوى", "Contenu"), "body", buffer.body, { type: "textarea", rows: 10 })}
        <div class="span-2">${editToggle(dt("نشر المقال", "Publier"), "published", buffer.published !== false)}</div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-post" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function viewPages() {
    return `
      <div class="dash-view-head"><div><h2>${dt("الصفحات", "Pages")}</h2><p>${dt("الصفحات الثابتة والأسئلة الشائعة.", "Pages statiques et FAQ.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="pages-static">${dt("الصفحات", "Pages")}</button><button data-dash-tab="pages-faq">${dt("الأسئلة الشائعة", "FAQ")}</button></div>
      <div class="dash-panel active" data-dash-panel="pages-static">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الصفحات الثابتة", "Pages statiques")}</h3><button data-action="add-page">${icon("plus")} ${dt("صفحة جديدة", "Nouvelle page")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.pages || []).map((page, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(page.title))}</strong><small class="handle">${esc(page.slug)}</small></div>${directToggle("", `pages.${index}.visible`, page.visible !== false)}<a class="btn btn-sm btn-soft" href="page.html?slug=${encodeURIComponent(page.slug)}" target="_blank" rel="noopener" title="${dt("معاينة", "Aperçu")}">${icon("external")}</a><button class="btn btn-sm btn-soft" data-action="edit-page" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-page" data-index="${index}">${icon("trash")}</button></div>`).join("")}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pages-faq">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("الأسئلة الشائعة", "FAQ")}</h3><button data-action="add-faq">${icon("plus")} ${dt("سؤال جديد", "Nouvelle question")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.faqs || []).map((faq, index) => `<div class="list-row"><div class="grow"><strong>${esc(lng(faq.q))}</strong><small>${esc(lng(faq.a)).slice(0, 90)}</small></div><button class="btn btn-sm btn-soft" data-action="edit-faq" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-faq" data-index="${index}">${icon("trash")}</button></div>`).join("")}
        </div></div></article>
      </div>`;
  }

  let pendingPageIndex = null;
  function pageEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { slug: `page-${Date.now().toString(36)}`, title: { ar: "", fr: "" }, body: { ar: "", fr: "" }, visible: true, seoTitle: { ar: "", fr: "" }, seoDescription: { ar: "", fr: "" } } : clone(model.pages[index]);
    editBuffer = buffer;
    pendingPageIndex = isNew ? null : index;
    openModal(isNew ? dt("صفحة جديدة", "Nouvelle page") : lng(buffer.title), `
      <div class="form-grid">
        ${editBi(dt("العنوان", "Titre"), "title", buffer.title)}
        <div class="field"><label>${dt("الرابط", "Slug")}</label><input data-edit-path="slug" value="${esc(buffer.slug)}" dir="ltr"></div>
        ${editBi(dt("محتوى الصفحة", "Contenu"), "body", buffer.body, { type: "textarea", rows: 12 })}
        ${editBi(dt("عنوان SEO", "Titre SEO"), "seoTitle", buffer.seoTitle)}
        ${editBi(dt("وصف SEO", "Description SEO"), "seoDescription", buffer.seoDescription, { type: "textarea", rows: 2 })}
        <p class="form-note span-2">${dt("الرابط يستخدم حروفًا إنجليزية صغيرة وأرقامًا وشرطات فقط. يظهر المحتوى في المتجر مباشرة بعد النشر.", "Le slug utilise des minuscules, chiffres et tirets. Le contenu apparaît après publication.")}</p>
        ${editToggle(dt("ظاهرة", "Visible"), "visible", buffer.visible !== false)}
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-page" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  function savePageEditor() {
    if (!editBuffer) return;
    const slug = String(editBuffer.slug || "").trim().toLowerCase();
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 80) {
      return toast(dt("الرابط: حروف إنجليزية صغيرة وأرقام وشرطات فقط", "Slug : minuscules, chiffres et tirets uniquement"), "error");
    }
    const duplicate = (model.pages || []).some((page, index) => page.slug === slug && index !== pendingPageIndex);
    if (duplicate) return toast(dt("هذا الرابط مستخدم لصفحة أخرى", "Ce slug est déjà utilisé"), "error");
    if (!String(editBuffer.title?.ar || editBuffer.title?.fr || "").trim()) return toast(dt("عنوان الصفحة مطلوب", "Le titre est requis"), "error");
    editBuffer.slug = slug;
    editBuffer.seoTitle = editBuffer.seoTitle || editBuffer.title;
    if (pendingPageIndex == null) model.pages.push(editBuffer);
    else model.pages[pendingPageIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ الصفحة في المسودة. انشر لتظهر للزوار.", "Page enregistrée en brouillon. Publiez pour la rendre visible."), "good");
  }

  function faqEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `faq-${Date.now().toString(36)}`, q: { ar: "", fr: "" }, a: { ar: "", fr: "" } } : clone(model.faqs[index]);
    editBuffer = buffer;
    openModal(isNew ? dt("سؤال جديد", "Nouvelle question") : lng(buffer.q), `
      <div class="dash-form">${editBi(dt("السؤال", "Question"), "q", buffer.q)}${editBi(dt("الجواب", "Réponse"), "a", buffer.a, { type: "textarea", rows: 4 })}</div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-faq" data-index="${isNew ? "" : index}">${dt("حفظ", "Enregistrer")}</button>`
    });
  }
  /* --------------------------------------------------------------------------
     Reviews
     -------------------------------------------------------------------------- */
    function viewReviews() {
    if (!Array.isArray(model.reviews)) model.reviews = [];
    const home = model.homeReviews || [];
    const allCustomer = R.getAllCustomerReviews();
    const pending = allCustomer.filter((review) => review.status === "pending");
    const approved = allCustomer.filter((review) => review.status === "approved");
    const rejected = allCustomer.filter((review) => review.status === "rejected");
    if (!viewReviews.refreshed) {
      viewReviews.refreshed = true;
      R.refreshReviews().catch(() => {});
    }
    const customerRow = (review, actions) => `<div class="list-row review-pending-row">
      <div class="grow">
        <strong>${esc(review.customerName)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong>
        <small>${esc(review.productHandle)} — ${esc(L(review.title))}</small>
        <p class="review-body-preview">${esc(String(L(review.body)).slice(0, 160))}${String(L(review.body)).length > 160 ? "…" : ""}</p>
        <small class="review-date">${esc(R.formatDate(review.createdAt))}${review.email ? ` · ${esc(review.email)}` : ""}</small>
      </div>
      <div class="cell-actions">${actions}</div>
    </div>`;
    return `
      <div class="dash-view-head"><div><h2>${dt("التقييمات", "Avis clients")}</h2><p>${dt("إدارة تقييمات الصفحة الرئيسية، المنتجات، وتقييمات العملاء.", "Gestion des avis accueil, produits et avis clients.")}</p></div></div>
      <div class="dash-tabs">
        <button class="active" data-dash-tab="reviews-home">${dt("الرئيسية", "Accueil")} <span class="badge-soft">${home.length}</span></button>
        <button data-dash-tab="reviews-products">${dt("المنتجات", "Produits")} <span class="badge-soft">${(model.reviews || []).length}</span></button>
        <button data-dash-tab="reviews-customers">${dt("العملاء", "Clients")} <span class="badge-soft ${pending.length ? "orange" : ""}">${pending.length}</span></button>
      </div>
      <div class="dash-panel active" data-dash-panel="reviews-home">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("آراء الصفحة الرئيسية", "Avis page d’accueil")}</h3><button class="btn btn-primary btn-sm" data-action="add-home-review">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${home.map((review, index) => `<div class="list-row"><div class="grow"><strong>${esc(review.name)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong><small>${esc(L(review.title))} — ${esc(L(review.city))}</small></div><button class="btn btn-sm btn-soft" data-action="edit-home-review" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-home-review" data-index="${index}">${icon("trash")}</button></div>`).join("") || `<div class="empty-dash">${dt("لا توجد تقييمات.", "Aucun avis.")}</div>`}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="reviews-products">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تقييمات المنتجات", "Avis produits")}</h3><button class="btn btn-soft" data-action="add-product-review">${icon("plus")} ${dt("إضافة", "Ajouter")}</button></div><div class="dash-card-body"><div class="list-editor">
          ${(model.reviews || []).map((review, index) => `<div class="list-row"><div class="grow"><strong>${esc(review.name)} <span style="color:#f5a623">${"★".repeat(Number(review.rating) || 5)}</span></strong><small>${esc(review.handle)} — ${esc(L(review.title))}</small></div><label class="toggle"><input type="checkbox" data-review-approved="${index}" ${review.approved !== false ? "checked" : ""}><span></span></label><button class="btn btn-sm btn-soft" data-action="edit-product-review" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-product-review" data-index="${index}">${icon("trash")}</button></div>`).join("") || `<div class="empty-dash">${dt("لا توجد تقييمات منتجات مخصصة.", "Aucun avis produit dédié.")}</div>`}
        </div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="reviews-customers">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تقييمات العملاء المعلقة", "Avis clients en attente")}</h3><span class="badge-soft orange">${pending.length}</span></div><div class="dash-card-body">
          ${pending.length ? `<div class="list-editor">
            ${pending.map((review) => customerRow(review, `
              <button class="btn btn-sm btn-success" data-action="approve-customer-review" data-id="${esc(review.id)}">${icon("check")} ${dt("اعتماد", "Approuver")}</button>
              <button class="btn btn-sm btn-danger" data-action="reject-customer-review" data-id="${esc(review.id)}">${icon("trash")} ${dt("رفض", "Refuser")}</button>`)).join("")}
          </div>` : `<div class="empty-dash">${dt("لا توجد تقييمات معلقة.", "Aucun avis en attente.")}</div>`}
        </div></article>
        ${approved.length ? `<article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("المعتمدة", "Approuvés")}</h3><span class="badge-soft green">${approved.length}</span></div><div class="dash-card-body"><div class="list-editor">
          ${approved.map((review) => customerRow(review, `
            <a class="btn btn-sm btn-soft" href="product.html?handle=${encodeURIComponent(review.productHandle)}" target="_blank" rel="noopener">${icon("external")}</a>
            <button class="btn btn-sm btn-soft" data-action="reject-customer-review" data-id="${esc(review.id)}">${icon("close")} ${dt("إلغاء الاعتماد", "Retirer")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-customer-review" data-id="${esc(review.id)}">${icon("trash")}</button>`)).join("")}
        </div></div></article>` : ""}
        ${rejected.length ? `<article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("المرفوضة", "Rejetés")}</h3><span class="badge-soft">${rejected.length}</span></div><div class="dash-card-body"><div class="list-editor">
          ${rejected.map((review) => customerRow(review, `
            <button class="btn btn-sm btn-success" data-action="approve-customer-review" data-id="${esc(review.id)}">${icon("check")} ${dt("اعتماد", "Approuver")}</button>
            <button class="btn btn-sm btn-soft" data-action="delete-customer-review" data-id="${esc(review.id)}">${icon("trash")}</button>`)).join("")}
        </div></div></article>` : ""}
      </div>`;
  }
  let pendingReviewKind = "home";
  let pendingReviewIndex = null;
  function reviewEditor(kind, index) {
    const isNew = index == null;
    const source = kind === "home" ? (model.homeReviews || []) : (model.reviews || []);
    const buffer = isNew ? {
      id: `review-${Date.now().toString(36)}`, name: "", city: { ar: "نواكشوط", fr: "Nouakchott" }, rating: 5,
      title: { ar: "", fr: "" }, body: { ar: "", fr: "" }, color: "#2e7d6f", handle: "", verified: true, approved: true
    } : clone(source[index]);
    editBuffer = buffer;
    pendingReviewKind = kind;
    pendingReviewIndex = isNew ? null : index;
    openModal(isNew ? dt("تقييم جديد", "Nouvel avis") : dt("تعديل التقييم", "Modifier l’avis"), `
      <div class="form-grid">
        <div class="field"><label>${dt("اسم العميل", "Nom")}</label><input data-edit-path="name" value="${esc(buffer.name)}"></div>
        <div class="field"><label>${dt("التقييم", "Note")}</label><select data-edit-path="rating">${[5, 4, 3, 2, 1].map((value) => `<option value="${value}" ${Number(buffer.rating) === value ? "selected" : ""}>${"★".repeat(value)}</option>`).join("")}</select></div>
        ${editBi(dt("المدينة", "Ville"), "city", buffer.city)}
        ${kind === "product" ? `<div class="field"><label>${dt("المنتج", "Produit")}</label><select data-edit-path="handle">${model.products.map((product) => `<option value="${esc(product.handle)}" ${product.handle === buffer.handle ? "selected" : ""}>${esc(product.title)}</option>`).join("")}</select></div>` : `<div class="field"><label>${dt("لون الصورة الرمزية", "Couleur avatar")}</label><input type="color" data-edit-path="color" value="${esc(buffer.color || "#2e7d6f")}"></div>`}
        ${editBi(dt("عنوان التقييم", "Titre"), "title", buffer.title)}
        <div class="span-2">${editBi(dt("نص التقييم", "Contenu"), "body", buffer.body, { type: "textarea", rows: 4 })}</div>
        ${kind === "product" ? `<div class="span-2">${editToggle(dt("شراء موثق", "Achat vérifié"), "verified", buffer.verified !== false)}${editToggle(dt("معتمد للنشر", "Approuvé"), "approved", buffer.approved !== false)}</div>` : ""}
      </div>`, {
      footer: editorFooter(!isNew, "delete-review-buffer")
    });
  }

  function saveReviewEditor() {
    if (!editBuffer) return;
    const list = pendingReviewKind === "home" ? model.homeReviews : (model.reviews || (model.reviews = []));
    if (pendingReviewIndex == null) list.push(editBuffer);
    else list[pendingReviewIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ التقييم", "Avis enregistré"), "good");
  }

  /* --------------------------------------------------------------------------
     Payments and shipping cities
     -------------------------------------------------------------------------- */
  function viewPayments() {
    return `
      <div class="dash-view-head"><div><h2>${dt("الدفع والتوصيل", "Paiement & livraison")}</h2><p>${dt("فعّل طرق الدفع المحلية وحدد رسوم المدن. يمكنك رفع شعار لكل طريقة دفع.", "Activez les paiements locaux et les frais par ville. Vous pouvez télécharger un logo pour chaque moyen de paiement.")}</p></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="pay-methods">${dt("طرق الدفع", "Moyens de paiement")}</button><button data-dash-tab="pay-cities">${dt("مدن التوصيل", "Villes de livraison")}</button><button data-dash-tab="pay-shipping">${dt("إعدادات الشحن", "Réglages livraison")}</button></div>
      <div class="dash-panel active" data-dash-panel="pay-methods">
        <div class="dash-view-actions" style="justify-content:flex-end;margin-bottom:9px"><button class="btn btn-primary btn-sm" data-action="add-payment">${icon("plus")} ${dt("طريقة دفع", "Moyen de paiement")}</button></div>
        <div class="dash-grid cols-2">
          ${(model.settings.payments || []).map((payment, index) => `<article class="dash-card"><div class="dash-card-body">
            <div style="display:flex;align-items:center;gap:9px;margin-bottom:10px">
              ${(payment.image || payment.logo) ? `<img src="${esc(payment.image || payment.logo)}" alt="" style="width:36px;height:36px;border-radius:9px;object-fit:contain">` : `<span style="width:36px;height:36px;border-radius:9px;background:${esc(payment.color)};color:#fff;display:grid;place-items:center;font-size:10px;font-weight:800">${esc(String(lng(payment.name)).slice(0, 2))}</span>`}
              <div style="flex:1"><strong style="font-size:12px">${esc(lng(payment.name))}</strong><br><small style="font-size:8px;color:var(--soft-muted)">${esc(lng(payment.note))}</small></div>
              <label class="toggle"><input type="checkbox" data-payment-active="${index}" ${payment.active !== false ? "checked" : ""}><span></span></label>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
              <span class="badge-soft ${payment.discount ? "orange" : ""}">${payment.discount ? `-${payment.discount}%` : dt("بدون خصم", "Sans remise")}</span>
              <div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-payment" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-payment" data-index="${index}">${icon("trash")}</button></div>
            </div>
            ${(payment.image || payment.logo) ? `<div class="image-preview" style="margin-top:8px"><img src="${esc(payment.image || payment.logo)}" alt="" style="max-width:100%;max-height:40px;border-radius:6px"></div>` : ""}
          </div></article>`).join("")}
        </div>
        <article class="dash-card" style="margin-top:14px"><div class="dash-card-body">${biField(dt("نص عرض الدفع", "Texte offre paiement"), "settings.paymentOffer", { type: "textarea", rows: 2 })}<p class="form-note" style="margin-top:8px">${dt("يظهر هذا النص في صفحة المنتج وصفحة الدفع. البنكيلي يطبق الخصم المحدد أعلاه تلقائيًا.", "Ce texte apparaît sur la fiche produit et au checkout. Bankily applique automatiquement la remise.")}</p></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pay-cities">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("مدن التوصيل", "Villes de livraison")}</h3><button data-action="add-city">${icon("plus")} ${dt("إضافة مدينة", "Ajouter une ville")}</button></div><div class="dash-card-body"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المدينة", "Ville")}</th><th>${dt("الرسوم", "Frais")}</th><th>${dt("المدة", "Délai")}</th><th>${dt("نشطة", "Active")}</th><th></th></tr></thead><tbody>
          ${(model.settings.cities || []).map((city, index) => `<tr><td><strong>${esc(lng(city.name))}</strong></td><td>${money(city.fee)}</td><td>${esc(lng(city.days))}</td><td><label class="toggle"><input type="checkbox" data-city-active="${index}" ${city.active !== false ? "checked" : ""}><span></span></label></td><td><div class="cell-actions"><button class="btn btn-sm btn-soft" data-action="edit-city" data-index="${index}">${icon("edit")}</button><button class="btn btn-sm btn-soft" data-action="delete-city" data-index="${index}">${icon("trash")}</button></div></td></tr>`).join("")}
        </tbody></table></div></div></article>
      </div>
      <div class="dash-panel" data-dash-panel="pay-shipping">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("إعدادات الشحن", "Réglages livraison")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">${field(dt("الشحن المجاني بعد (MRU)", "Livraison gratuite dès (MRU)"), "settings.freeShippingOver", { type: "number" })}${field(dt("حد المخزون المنخفض", "Seuil stock faible"), "settings.lowStockThreshold", { type: "number" })}</div>
          ${biField(dt("ملاحظة الشحن", "Note livraison"), "settings.shippingNote", { type: "textarea", rows: 2 })}
          ${directToggle(dt("إخفاء المنتجات المنتهية من المتجر", "Masquer les produits épuisés"), "settings.autoHideOutOfStock", model.settings.autoHideOutOfStock)}
          <p class="form-note">${dt("تظهر رسوم كل مدينة في صفحة الدفع ويُضاف الشحن المجاني إذا تجاوز المجموع الحد المحدد.", "Les frais de chaque ville s’affichent au checkout ; la livraison est offerte au-delà du seuil.")}</p>
        </div></article>
      </div>`;
  }

  let pendingPaymentIndex = null;
  function paymentEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `payment-${Date.now().toString(36)}`, name: { ar: "", fr: "" }, image: "", color: "#0b6fb8", active: true, discount: 0, note: { ar: "", fr: "" } } : clone(model.settings.payments[index]);
    editBuffer = buffer;
    pendingPaymentIndex = isNew ? null : index;
    openModal(isNew ? dt("طريقة دفع جديدة", "Nouveau moyen") : lng(buffer.name), `
      <div class="form-grid">
        ${editBi(dt("الاسم", "Nom"), "name", buffer.name)}
        <div class="field"><label>${dt("اللون", "Couleur")}</label><input type="color" data-edit-path="color" value="${esc(buffer.color)}"></div>
        <div class="field"><label>${dt("الخصم %", "Remise %")}</label><input type="number" data-edit-path="discount" value="${esc(buffer.discount || 0)}"></div>
        <div class="field"><label>${dt("ملاحظة", "Note")}</label><input data-edit-path="note.ar" value="${esc(buffer.note?.ar || "")}" dir="rtl"></div>
        <div class="field"><label>Note FR</label><input data-edit-path="note.fr" value="${esc(buffer.note?.fr || "")}" dir="ltr"></div>
        <div class="span-2">${imageEditor(dt("صورة التطبيق", "Image de l’application"), "image", buffer.image || buffer.logo || "")}</div>
        <div class="span-2">${editToggle(dt("مفعلة", "Active"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-payment-buffer")
    });
  }

  function viewPaymentSave() {
    if (!editBuffer) return;
    if (pendingPaymentIndex == null) model.settings.payments.push(editBuffer);
    else model.settings.payments[pendingPaymentIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ طريقة الدفع", "Paiement enregistré"), "good");
  }

  let pendingCityIndex = null;
  function cityEditor(index) {
    const isNew = index == null;
    const buffer = isNew ? { id: `city-${Date.now().toString(36)}`, name: { ar: "", fr: "" }, fee: 0, days: { ar: "2–4 أيام", fr: "2–4 jours" }, active: true } : clone(model.settings.cities[index]);
    editBuffer = buffer;
    pendingCityIndex = isNew ? null : index;
    openModal(isNew ? dt("مدينة جديدة", "Nouvelle ville") : lng(buffer.name), `
      <div class="form-grid">
        ${editBi(dt("المدينة", "Ville"), "name", buffer.name)}
        <div class="field"><label>${dt("رسوم الشحن", "Frais")}</label><input type="number" data-edit-path="fee" value="${esc(buffer.fee)}"></div>
        ${editBi(dt("المدة", "Délai"), "days", buffer.days)}
        <div class="span-2">${editToggle(dt("نشطة", "Active"), "active", buffer.active !== false)}</div>
      </div>`, {
      footer: editorFooter(!isNew, "delete-city-buffer")
    });
  }

  function viewCitySave() {
    if (!editBuffer) return;
    if (pendingCityIndex == null) model.settings.cities.push(editBuffer);
    else model.settings.cities[pendingCityIndex] = editBuffer;
    saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المدينة", "Ville enregistrée"), "good");
  }

  /* --------------------------------------------------------------------------
     Team
     -------------------------------------------------------------------------- */
  function viewProfile() {
    const mgr = R.managers.find((item) => item.id === session?.id) || R.managers.find((item) => item.username === session?.username);
    const currentUser = mgr || { username: session?.username, name: { ar: session?.name, fr: session?.name }, whatsapp: "", email: "" };
    const hasAvatar = currentUser.avatar && currentUser.avatar.trim();
    const avatarSrc = hasAvatar ? currentUser.avatar : "";
    const initials = String(lng(currentUser.name) || session?.username || "U").slice(0, 2).toUpperCase();

    return `
      <div class="dash-view-head"><div><h2>${dt("ملفي الشخصي", "Mon profil")}</h2><p>${dt("إدارة معلومات الحساب والتواصل والدفع", "Gérer les informations du compte, contact et paiement")}</p></div></div>
      <div class="dash-tabs">
        <button class="active" data-dash-tab="profile-info">${dt("معلومات الحساب", "Infos du compte")}</button>
        ${session?.role === "owner" ? `<button data-dash-tab="profile-contact">${dt("التواصل", "Contact")}</button>
        <button data-dash-tab="profile-social">${dt("السوشيال", "Social")}</button>` : ""}
        <button data-dash-tab="profile-security">${dt("الأمان", "Sécurité")}</button>
        <button data-dash-tab="profile-payment">${dt("طرق الدفع", "Moyens de paiement")}</button>
      </div>

      <div class="dash-panel active" data-dash-panel="profile-info">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات الحساب", "Informations du compte")}</h3></div><div class="dash-card-body dash-form">
            <div class="form-grid">
              <div class="field"><label>${dt(R.remote ? "البريد الإلكتروني" : "اسم المستخدم", R.remote ? "E-mail" : "Nom d'utilisateur")}</label><input id="profile-username" value="${esc(session?.username || "")}" ${R.remote || session?.role !== "owner" ? "readonly" : ""} dir="ltr" autocomplete="username"></div>
              <div class="field"><label>${dt("الدور", "Rôle")}</label><input value="${session?.role === 'owner' ? dt('المالك', 'Propriétaire') : dt('مدير', 'Gérant')}" readonly></div>
              <div class="field"><label>${dt("الاسم بالعربية", "Nom en arabe")}</label><input id="profile-name-ar" value="${esc(currentUser.name?.ar || "")}" dir="rtl"></div>
              <div class="field"><label>Nom en français</label><input id="profile-name-fr" value="${esc(currentUser.name?.fr || "")}" dir="ltr"></div>
              <div class="field"><label>${dt("البريد الإلكتروني للتواصل", "E-mail de contact")}</label><input id="profile-email" type="email" value="${esc(currentUser.email || "")}" ${R.remote ? "readonly" : ""} dir="ltr" autocomplete="email"></div>
              <div class="field"><label>${dt("واتساب", "WhatsApp")}</label><input id="profile-whatsapp" value="${esc(currentUser.whatsapp || "")}" dir="ltr" placeholder="222..." inputmode="tel"></div>
            </div>
            ${R.remote ? `<p class="form-note">${dt("لتغيير بريد الدخول، استخدم لوحة Supabase > Authentication.", "Pour changer l’e-mail de connexion, utilisez Supabase > Authentication.")}</p>` : ""}
            <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-profile-info">${icon("check")} ${dt("حفظ المعلومات", "Enregistrer")}</button></div>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("الصورة الرمزية", "Avatar")}</h3></div><div class="dash-card-body" style="display:flex;align-items:center;gap:15px">
            <div class="image-field" style="width:100px;height:100px;border-radius:50%;overflow:hidden;background:linear-gradient(135deg,#ff6400,#a72396);color:#fff;display:grid;place-items:center;font-size:28px;font-weight:700">
              ${avatarSrc ? `<img src="${esc(avatarSrc)}" alt="" style="width:100%;height:100%;object-fit:cover">` : esc(initials)}
            </div>
            <div>
              <label class="upload-btn">${icon("upload")} ${dt("تغيير الصورة", "Changer l'image")}<input type="file" accept="image/*" id="profile-avatar-upload"></label>
              <p class="form-note">${dt("سيتم تحديث الصورة في جميع أنحاء لوحة التحكم والمتجر", "L'image sera mise à jour dans tout le tableau de bord et la boutique")}</p>
            </div>
          </div></div></article>
        </div>
      </div>

      ${session?.role === "owner" ? `<div class="dash-panel" data-dash-panel="profile-contact">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("معلومات التواصل للمتجر", "Infos de contact de la boutique")}</h3></div><div class="dash-card-body dash-form">
          ${biField(dt("اسم المتجر", "Nom de la boutique"), "settings.storeName")}
          ${biField(dt("الشعار", "Slogan"), "settings.tagline")}
          <div class="form-grid">${field(dt("واتساب المتجر", "WhatsApp de la boutique"), "settings.whatsapp", { placeholder: "22246000000" })}${field(dt("البريد الإلكتروني", "E-mail"), "settings.email", { placeholder: "contact@restore.mr" })}</div>
          ${biField(dt("العنوان", "Adresse"), "settings.address", { type: "textarea", rows: 2 })}
          ${biField(dt("المدينة", "Ville"), "settings.city")}
          <div class="form-grid">${field(dt("الرقم الظاهر", "Numéro affiché"), "settings.phoneDisplay", { placeholder: "+222 46 00 00 00" })}${field(dt("رقم الهاتف (دولي)", "Téléphone (international)"), "settings.phone", { placeholder: "+22246000000" })}</div>
          <p class="form-note">${dt("هذه المعلومات تظهر في الفوتر وصفحة التواصل وفي رسالة الواتساب للطلب", "Ces infos apparaissent dans le footer, la page contact et le message WhatsApp de commande")}</p>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-owner-contact">${icon("check")} ${dt("حفظ معلومات المتجر", "Enregistrer les infos boutique")}</button></div>
        </div></article>
      </div>` : ""}

      ${session?.role === "owner" ? `<div class="dash-panel" data-dash-panel="profile-social">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("روابط التواصل الاجتماعي", "Liens réseaux sociaux")}</h3></div><div class="dash-card-body dash-form">
          <p class="form-note">${dt("أضف روابط حساباتك على المنصات الاجتماعية. ستظهر في الفوتر وصفحة التواصل.", "Ajoutez les liens de vos comptes sociaux. Ils apparaîtront dans le footer et la page contact.")}</p>
          <div id="social-links-editor">
            ${(model.settings.social || []).map((s, i) => {
              const platform = String(s.platform || s.id || "");
              const options = ["facebook", "instagram", "tiktok", "youtube", "x", "twitter", "snapchat", "whatsapp", "linkedin", "telegram"];
              return `
              <div class="social-row" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;flex-wrap:wrap">
                <select data-social-platform="${i}" style="flex:1;min-width:130px;max-width:170px">
                  <option value="">${dt("اختر المنصة", "Choisir la plateforme")}</option>
                  ${options.map((id) => `<option value="${id}" ${platform === id ? "selected" : ""}>${id}</option>`).join("")}
                </select>
                <input type="url" data-social-url="${i}" value="${esc(s.href || "")}" placeholder="https://..." style="flex:2;min-width:200px" dir="ltr">
                <button type="button" class="btn btn-sm btn-soft" data-action="remove-social" data-index="${i}" style="padding:6px" aria-label="${dt("حذف", "Supprimer")}">${icon("trash")}</button>
              </div>`;
            }).join("")}
          </div>
          <button type="button" class="btn btn-secondary btn-sm" id="add-social-link">${icon("plus")} ${dt("إضافة رابط", "Ajouter un lien")}</button>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="save-owner-social">${icon("check")} ${dt("حفظ الروابط", "Enregistrer les liens")}</button></div>
        </div></article>
      </div>` : ""}

      <div class="dash-panel" data-dash-panel="profile-security">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("تغيير كلمة المرور", "Changer le mot de passe")}</h3></div><div class="dash-card-body dash-form">
          <div class="form-grid">
            <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input id="sec-current" type="password" autocomplete="current-password"></div>
            <div class="field"><label>${dt("الجديدة", "Nouveau")}</label><input id="sec-next" type="password" minlength="8" autocomplete="new-password"></div>
            <div class="field"><label>${dt("التأكيد", "Confirmer")}</label><input id="sec-confirm" type="password" autocomplete="new-password"></div>
          </div>
          <div class="btn-group" style="margin-top:10px"><button class="btn btn-primary" id="change-own-pwd">${icon("check")} ${dt("تغيير كلمة المرور", "Changer le mot de passe")}</button></div>
        </div></article>
        <article class="dash-card" style="margin-top:14px"><div class="dash-card-head"><h3>${dt("الجلسات النشطة", "Sessions actives")}</h3></div><div class="dash-card-body">
          <p class="form-note">${dt("سيتم عرض الجلسات قريباً مع إمكانية إلغاء الجلسات البعيدة", "Les sessions s'afficheront bientôt avec possibilité de révoquer les sessions distantes")}</p>
        </div></article>
      </div>

      <div class="dash-panel" data-dash-panel="profile-payment">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("طرق الدفع المفعلة", "Moyens de paiement actifs")}</h3></div><div class="dash-card-body">
          ${(model.settings.payments || []).filter(p => p.active !== false).map((payment) => `<div class="list-row"><div style="display:flex;align-items:center;gap:10px"><span style="width:32px;height:32px;border-radius:8px;background:${esc(payment.color)};color:#fff;display:grid;place-items:center;font-size:9px;font-weight:800">${esc(String(lng(payment.name)).slice(0, 2))}</span><div><strong>${esc(lng(payment.name))}</strong><br><small>${esc(lng(payment.note))}</small></div></div></div>`).join("")}
        </div></article>
      </div>`;
  }
  function viewTeam() {
    return `
      <div class="dash-view-head"><div><h2>${dt("الفريق", "Équipe")}</h2><p>${dt("صلاحيات المالك والمديرين.", "Accès propriétaire et gérants.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="change-own-password">${dt("كلمة مروري", "Mon mot de passe")}</button><button class="btn btn-primary" data-action="add-manager">${icon("plus")} ${dt("مدير جديد", "Nouveau gérant")}</button></div></div>
      <div class="dash-grid cols-2">
        ${R.managers.map((manager) => `<article class="dash-card"><div class="dash-card-body"><div style="display:flex;align-items:center;gap:10px"><span class="dash-avatar" style="background:${manager.role === "owner" ? "linear-gradient(135deg,#ff6400,#a72396)" : "#375e97"}">${esc(String(lng(manager.name) || manager.username).slice(0, 2).toUpperCase())}</span><div style="flex:1"><strong style="font-size:12px">${esc(lng(manager.name) || manager.username)}</strong><br><small style="font-size:8px;color:var(--soft-muted)">@${esc(manager.username)} · ${manager.role === "owner" ? dt("مالك", "Propriétaire") : dt("مدير", "Gérant")}</small></div><span class="badge-soft ${manager.mustChange ? "orange" : "green"}">${manager.mustChange ? dt("تغيير كلمة المرور", "Changer MDP") : dt("نشط", "Actif")}</span></div><div style="margin-top:11px;padding-top:10px;border-top:1px solid var(--border);display:flex;align-items:center;gap:5px"><span style="font-size:8px;color:var(--soft-muted);direction:ltr">${esc(manager.whatsapp || "—")}</span><span style="flex:1"></span>${manager.username !== session?.username ? `<button class="btn btn-sm btn-soft" data-action="force-password" data-id="${manager.id}">${dt("إلزام التغيير", "Forcer MDP")}</button>` : ""}<button class="btn btn-sm btn-soft" data-action="edit-manager" data-id="${manager.id}">${icon("edit")}</button>${manager.role !== "owner" || R.managers.filter((item) => item.role === "owner").length > 1 ? `<button class="btn btn-sm btn-soft" data-action="delete-manager" data-id="${manager.id}">${icon("trash")}</button>` : ""}</div></div></article>`).join("")}
      </div>
      <article class="dash-card" style="margin-top:14px"><div class="dash-card-body"><h3 style="font-size:12px;margin-bottom:7px">${dt("نصائح الأمان", "Conseils de sécurité")}</h3><ul style="list-style:disc;padding-inline-start:17px;font-size:10px;color:var(--muted);line-height:1.9"><li>${dt("يُطلب من كل مدير تغيير كلمة المرور عند أول دخول.", "Chaque gérant doit changer son mot de passe à la première connexion.")}</li><li>${dt("استخدم Supabase Auth في الإنتاج بدل الحسابات المحلية.", "Utilisez Supabase Auth en production au lieu des comptes locaux.")}</li><li>${dt("راجع سجل النشاط بانتظام.", "Consultez régulièrement le journal d’activité.")}</li></ul></div></article>`;
  }

  let pendingManagerId = null;
  function managerEditor(id) {
    const manager = id ? R.managers.find((item) => item.id === id) : null;
    pendingManagerId = id || null;
    const remote = Boolean(R.remote);
    const usernameField = remote
      ? `<div class="field"><label>${dt("البريد الإلكتروني", "E-mail")}</label><input id="manager-email" type="email" value="${esc(manager?.email || "")}" ${manager ? "readonly" : ""} dir="ltr" placeholder="manager@restore.mr" autocomplete="off"></div>`
      : `<div class="field"><label>${dt("اسم المستخدم", "Nom d’utilisateur")}</label><input id="manager-username" value="${esc(manager?.username || "")}" ${manager ? "readonly" : ""} dir="ltr" placeholder="manager2" autocomplete="off"></div>
         <div class="field"><label>${dt("البريد الإلكتروني (اختياري)", "E-mail (optionnel)")}</label><input id="manager-email" type="email" value="${esc(manager?.email || "")}" dir="ltr" placeholder="manager@restore.mr" autocomplete="off"></div>`;
    openModal(manager ? lng(manager.name) : dt("مدير جديد", "Nouveau gérant"), `
      <div class="form-grid">
        ${usernameField}
        <div class="field"><label>${dt("الدور", "Rôle")}</label><select id="manager-role"><option value="manager" ${manager?.role !== "owner" ? "selected" : ""}>${dt("مدير", "Gérant")}</option><option value="owner" ${manager?.role === "owner" ? "selected" : ""}>${dt("مالك", "Propriétaire")}</option></select></div>
        <div class="field"><label>${dt("الاسم بالعربية", "Nom en arabe")}</label><input id="manager-name-ar" value="${esc(manager?.name?.ar || "")}" dir="rtl"></div>
        <div class="field"><label>Nom en français</label><input id="manager-name-fr" value="${esc(manager?.name?.fr || "")}" dir="ltr"></div>
        <div class="field"><label>WhatsApp</label><input id="manager-whatsapp" value="${esc(manager?.whatsapp || "")}" dir="ltr" placeholder="222..." inputmode="tel"></div>
        ${!manager ? `<div class="field"><label>${dt("كلمة مرور مؤقتة (8 أحرف على الأقل)", "Mot de passe temporaire (8 caractères min.)")}</label><input id="manager-password" type="password" minlength="8" placeholder="********" autocomplete="new-password"></div>` : ""}
      </div>
      <p class="form-note" style="margin-top:10px">${remote
        ? dt("يُنشأ الحساب في Supabase عبر دالة المالك الآمنة. سيُطلب من المدير تغيير كلمة المرور عند أول دخول. لا يمكن تغيير البريد بعد الإنشاء من هنا.", "Le compte est créé dans Supabase via la fonction sécurisée du propriétaire. Le gérant devra changer son mot de passe à la première connexion. L’e-mail ne peut plus être modifié ici.")
        : dt("سيُطلب من المدير الجديد تغيير كلمة المرور عند أول دخول.", "Le nouveau gérant devra changer son mot de passe à la première connexion.")}</p>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-manager">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  async function saveManager() {
    const username = $("#manager-username")?.value.trim() || "";
    const email = $("#manager-email")?.value.trim().toLowerCase() || "";
    const role = $("#manager-role")?.value === "owner" ? "owner" : "manager";
    const nameAr = $("#manager-name-ar")?.value.trim();
    const nameFr = $("#manager-name-fr")?.value.trim();
    const whatsapp = $("#manager-whatsapp")?.value.trim();
    try {
      if (!pendingManagerId) {
        const password = $("#manager-password")?.value || "";
        if (password.length < 8) throw new Error(dt("كلمة المرور 8 أحرف على الأقل", "Mot de passe : 8 caractères minimum"));
        if (R.remote && !email) throw new Error(dt("البريد الإلكتروني مطلوب لإنشاء حساب Supabase", "L’e-mail est requis pour un compte Supabase"));
        if (!R.remote && !username) throw new Error(dt("اسم المستخدم مطلوب", "Le nom d’utilisateur est requis"));
        const created = await R.addManager({ username: username || email, email, password, nameAr, nameFr, role, whatsapp });
        if (!R.remote) model = clone(R.state);
        R.addAudit(`${dt("إضافة مدير", "Gérant ajouté")}: ${created?.email || created?.username || email || username}`);
      } else {
        const current = R.managers.find((item) => item.id === pendingManagerId);
        if (current?.role === "owner" && role !== "owner" && R.managers.filter((item) => item.role === "owner").length <= 1) throw new Error(dt("لا يمكن إزالة صلاحية المالك الوحيد", "Impossible de retirer le dernier propriétaire"));
        R.updateManager(pendingManagerId, {
          name: { ar: nameAr || nameFr || current?.username || "", fr: nameFr || nameAr || current?.username || "" },
          role,
          whatsapp,
          ...(!R.remote && email ? { email } : {})
        });
        R.addAudit(`${dt("تعديل مدير", "Gérant modifié")}: ${current?.username || ""}`);
      }
      if (R.remote) await R.refreshStaff().catch(() => {});
      closeModal(); renderRoute(); toast(dt("تم حفظ الفريق", "Équipe enregistrée"), "good");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  function changeOwnPasswordModal() {
    openModal(dt("تغيير كلمة المرور", "Changer le mot de passe"), `
      <div class="dash-form">
        <div class="field"><label>${dt("كلمة المرور الحالية", "Mot de passe actuel")}</label><input id="own-current" type="password"></div>
        <div class="form-grid"><div class="field"><label>${dt("الجديدة", "Nouveau")}</label><input id="own-next" type="password" minlength="8"></div><div class="field"><label>${dt("التأكيد", "Confirmer")}</label><input id="own-confirm" type="password"></div></div>
        <div class="field"><label>WhatsApp</label><input id="own-whatsapp" value="${esc(R.managers.find((item) => item.username === session?.username)?.whatsapp || "")}" dir="ltr"></div>
      </div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-primary btn-sm" data-action="save-own-password">${dt("حفظ", "Enregistrer")}</button>`
    });
  }

  async function saveOwnPassword() {
    const next = $("#own-next")?.value || "";
    if (next !== ($("#own-confirm")?.value || "")) return toast(dt("كلمتا المرور غير متطابقتين", "Les mots de passe diffèrent"), "error");
    try {
      await R.changePassword(session.username, $("#own-current")?.value || "", next, $("#own-whatsapp")?.value || "");
      session = R.currentSession();
      closeModal(); toast(dt("تم تحديث كلمة المرور", "Mot de passe mis à jour"), "good");
    } catch (error) { toast(error.message, "error"); }
  }

  /* --------------------------------------------------------------------------
     Reports
     -------------------------------------------------------------------------- */
  let reportRange = "30";
  function reportOrders() {
    const orders = orderList().filter((order) => order.status !== "cancelled" && order.status !== "returned");
    if (reportRange === "all") return orders;
    const days = Number(reportRange) || 30;
    const cutoff = Date.now() - days * 864e5;
    return orders.filter((order) => Date.parse(order.createdAt) >= cutoff);
  }

  function viewReports() {
    const orders = reportOrders();
    const revenue = revenueOfOrders(orders);
    const items = orders.flatMap((order) => order.items || []);
    const itemCount = items.reduce((sum, item) => sum + Number(item.qty || 1), 0);
    const avg = orders.length ? revenue / orders.length : 0;
    const cityMap = {};
    orders.forEach((order) => {
      const city = order.customer?.city || "—";
      cityMap[city] = cityMap[city] || { count: 0, revenue: 0 };
      cityMap[city].count += 1;
      cityMap[city].revenue += Number(order.total) || 0;
    });
    const productMap = {};
    items.forEach((item) => {
      const key = item.handle || item.title;
      productMap[key] = productMap[key] || { title: item.title, image: item.image, qty: 0, revenue: 0 };
      productMap[key].qty += Number(item.qty || 1);
      productMap[key].revenue += Number(item.line || 0);
    });
    const topProducts = Object.values(productMap).sort((a, b) => b.revenue - a.revenue).slice(0, 8);
    const topCities = Object.entries(cityMap).sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 8);
    const maxCity = Math.max(1, ...topCities.map(([, data]) => data.revenue));
    const abandoned = R.getAbandoned().length;
    const conversion = orders.length + abandoned ? Math.round(orders.length / (orders.length + abandoned) * 100) : 0;
    const days = [...Array(7)].map((_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const key = date.toISOString().slice(0, 10);
      const total = orders.filter((order) => String(order.createdAt).slice(0, 10) === key).reduce((sum, order) => sum + Number(order.total || 0), 0);
      return { label: date.toLocaleDateString(dashLang === "ar" ? "ar-MR" : "fr-FR", { weekday: "short" }), total };
    });
    const maxDay = Math.max(1, ...days.map((day) => day.total));
    const low = lowStockProducts().slice(0, 8);
    return `
      <div class="dash-view-head"><div><h2>${dt("التقارير", "Rapports")}</h2><p>${dt("المبيعات والمخزون والأداء.", "Ventes, stock et performance.")}</p></div><div class="dash-view-actions"><div class="segmented">${[["7", "7j"], ["30", "30j"], ["90", "90j"], ["all", dt("الكل", "Tout")]].map(([id, label]) => `<button data-report-range="${id}" class="${reportRange === id ? "active" : ""}">${label}</button>`).join("")}</div><button class="btn btn-soft" data-action="export-orders">${icon("download")} CSV</button></div></div>
      <div class="dash-grid cols-4" style="margin-bottom:14px">
        ${statCard(dt("الإيرادات", "Chiffre d’affaires"), money(revenue), `${orders.length} ${dt("طلب", "commandes")}`, "#128c53", "reports")}
        ${statCard(dt("متوسط الطلب", "Panier moyen"), money(avg), dt("لكل طلب", "par commande"), "#ff6400", "cart")}
        ${statCard(dt("القطع المباعة", "Articles vendus"), itemCount, dt("إجمالي القطع", "total unités"), "#a72396", "products")}
        ${statCard(dt("نسبة التحويل", "Conversion"), `${conversion}%`, `${abandoned} ${dt("سلة متروكة", "paniers")}`, "#0b6fb8", "marketing")}
      </div>
      <div class="dash-grid cols-3">
        <article class="dash-card" style="grid-column:span 2"><div class="dash-card-head"><h3>${dt("الإيرادات آخر 7 أيام", "Revenus 7 jours")}</h3></div><div class="dash-card-body"><div class="report-bars">${days.map((day) => `<div class="bar" style="height:${Math.max(5, Math.round(day.total / maxDay * 100))}%" title="${money(day.total)}"><span>${esc(day.label)}</span></div>`).join("")}</div><div class="report-legend"><span><i></i>${money(days.reduce((sum, day) => sum + day.total, 0))}</span></div></div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("أفضل المدن", "Meilleures villes")}</h3></div><div class="dash-card-body">${topCities.length ? topCities.map(([city, data]) => `<div style="margin-bottom:9px"><div style="display:flex;justify-content:space-between;font-size:9px;margin-bottom:4px"><span>${esc(city)}</span><strong>${money(data.revenue)}</strong></div><div class="mini-bar"><i style="width:${Math.round(data.revenue / maxCity * 100)}%"></i></div><small style="font-size:8px;color:var(--soft-muted)">${data.count} ${dt("طلب", "commandes")}</small></div>`).join("") : `<div class="empty-dash">${dt("لا توجد بيانات.", "Aucune donnée.")}</div>`}</div></article>
      </div>
      <div class="dash-grid cols-2" style="margin-top:14px">
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("المنتجات الأكثر مبيعًا", "Meilleures ventes")}</h3></div><div class="dash-card-body"><div class="dash-table-wrap"><table class="dash-table"><thead><tr><th>${dt("المنتج", "Produit")}</th><th>${dt("القطع", "Unités")}</th><th>${dt("الإيراد", "Revenu")}</th></tr></thead><tbody>${topProducts.map((product) => `<tr><td><div class="cell-main"><img src="${esc(product.image)}" alt=""><strong>${esc(product.title)}</strong></div></td><td>${product.qty}</td><td class="price">${money(product.revenue)}</td></tr>`).join("") || `<tr><td colspan="3" class="table-empty">${dt("لا توجد مبيعات.", "Aucune vente.")}</td></tr>`}</tbody></table></div></div></article>
        <article class="dash-card"><div class="dash-card-head"><h3>${dt("مخزون منخفض", "Stock faible")}</h3><a href="#products" data-route="products">${dt("إدارة", "Gérer")}</a></div><div class="dash-card-body"><div class="list-editor">${low.map((product) => `<div class="list-row"><span class="image-preview" style="width:32px;height:32px;flex-basis:32px"><img src="${esc(product.image)}" alt=""></span><div class="grow"><strong>${esc(product.title)}</strong><small>${dt("متبقي", "Reste")}: ${product.stock}</small></div><span class="badge-soft ${product.stock <= 0 ? "" : "orange"}">${product.stock <= 0 ? dt("نفد", "Épuisé") : dt("منخفض", "Faible")}</span></div>`).join("") || `<div class="empty-dash">${dt("المخزون جيد.", "Stock correct.")}</div>`}</div></div></article>
      </div>`;
  }
  /* --------------------------------------------------------------------------
     Settings
     -------------------------------------------------------------------------- */
  function viewSettings() {
    const settings = model.settings;
    return `
      <div class="dash-view-head"><div><h2>${dt("الإعدادات", "Réglages")}</h2><p>${dt("SEO، واتساب، الحماية والتكامل.", "SEO, WhatsApp, sécurité et intégration.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="discard-draft">${dt("إلغاء المسودة", "Annuler le brouillon")}</button><button class="btn btn-primary" data-action="save-draft">${icon("check")} ${dt("حفظ", "Enregistrer")}</button></div></div>
      <div class="dash-tabs"><button class="active" data-dash-tab="settings-seo">SEO</button><button data-dash-tab="settings-whatsapp">WhatsApp</button><button data-dash-tab="settings-security">${dt("الحماية", "Sécurité")}</button><button data-dash-tab="settings-advanced">${dt("متقدم", "Avancé")}</button></div>
      <div class="dash-panel active" data-dash-panel="settings-seo">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("محركات البحث", "Référencement")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("عنوان SEO", "Titre SEO"), "settings.seo.title")}
            ${biField(dt("وصف SEO", "Description SEO"), "settings.seo.description", { type: "textarea", rows: 3 })}
            <div class="form-grid">${field(dt("الرابط الأساسي", "URL de base"), "settings.baseUrl", { placeholder: "https://restore.mr" })}${field(dt("صورة المشاركة", "Image de partage"), "settings.seo.image", { placeholder: "assets/img/..." })}</div>
            <p class="form-note">${dt("يُستخدم عنوان ووصف SEO في كل صفحة، وتُضاف بيانات المنتج المنظمة تلقائيًا.", "Titres et descriptions sont appliqués par page ; les données produit structurées sont ajoutées automatiquement.")}</p>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("بكسلات التحليلات", "Pixels analytiques")}</h3></div><div class="dash-card-body dash-form">
            ${field("Meta Pixel ID", "settings.pixels.meta", { placeholder: "1234567890" })}
            ${field("TikTok Pixel ID", "settings.pixels.tiktok", { placeholder: "C..." })}
            ${field("Google Analytics ID", "settings.pixels.ga", { placeholder: "G-XXXXXXX" })}
            <p class="form-note">${dt("تُحمّل الأكواد تلقائيًا في المتجر بعد النشر. لا تضع أكوادًا كاملة، فقط المعرف.", "Les scripts sont chargés automatiquement. Indiquez uniquement l’identifiant.")}</p>
            ${directToggle(dt("تفعيل PWA للجوال", "Activer la PWA mobile"), "settings.pwa", settings.pwa !== false)}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-whatsapp">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("رسالة الطلب", "Message de commande")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("القالب الكامل", "Modèle complet"), "settings.orderTemplate", { type: "textarea", rows: 13 })}
            <p class="form-note">${dt("المتغيرات: {store} {order_id} {name} {phone} {city} {address} {payment} {items} {subtotal} {shipping} {discount} {total} {notes}", "Variables : {store} {order_id} {name} {phone} {city} {address} {payment} {items} {subtotal} {shipping} {discount} {total} {notes}")}</p>
            ${field("WhatsApp", "settings.whatsapp", { hint: dt("الرقم الذي تستقبل عليه الطلبات", "Numéro qui reçoit les commandes") })}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("رسائل المتابعة", "Messages de suivi")}</h3></div><div class="dash-card-body dash-form">
            ${biField(dt("تأكيد الطلب", "Confirmation"), "settings.whatsappTemplates.confirm", { type: "textarea", rows: 3 })}
            ${biField(dt("تم الشحن", "Expédition"), "settings.whatsappTemplates.shipped", { type: "textarea", rows: 3 })}
            ${biField(dt("تم التسليم", "Livraison"), "settings.whatsappTemplates.delivered", { type: "textarea", rows: 3 })}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-security">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("الحماية من الطلبات المزعجة", "Protection anti-spam")}</h3></div><div class="dash-card-body dash-form">
            ${field(dt("الفاصل الزمني بين الطلبات (ثانية)", "Délai entre commandes (secondes)"), "settings.rateLimitSeconds", { type: "number" })}
            <div class="field"><label>${dt("قائمة الحظر (رقم في كل سطر)", "Liste de blocage (un numéro par ligne)")}</label><textarea data-blocklist rows="7" dir="ltr">${esc((settings.blocklist || []).join("\n"))}</textarea></div>
            <p class="form-note">${dt("تُطبق القائمة على أرقام الهواتف بصيغة 222XXXXXXXX.", "La liste s’applique aux numéros au format 222XXXXXXXX.")}</p>
            ${directToggle(dt("طلب رمز تحقق OTP (قريبًا)", "Vérification OTP (bientôt)"), "settings.otp.enabled", settings.otp?.enabled)}
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("المخزون والمنتجات", "Stock & produits")}</h3></div><div class="dash-card-body dash-form">
            ${field(dt("حد المخزون المنخفض", "Seuil de stock faible"), "settings.lowStockThreshold", { type: "number" })}
            ${directToggle(dt("إخفاء المنتجات المنتهية تلقائيًا", "Masquer automatiquement les produits épuisés"), "settings.autoHideOutOfStock", settings.autoHideOutOfStock !== false)}
            ${directToggle(dt("إظهار بيانات تجريبية حتى إدخال بياناتك", "Afficher les données de démo jusqu’à vos données"), "settings.fakeData", settings.fakeData !== false)}
            ${directToggle(dt("الوضع الليلي", "Mode sombre"), "settings.darkMode", settings.darkMode !== false)}
          </div></article>
        </div>
      </div>
      <div class="dash-panel" data-dash-panel="settings-advanced">
        <div class="dash-grid cols-2">
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("التكامل والاستضافة", "Intégration & hébergement")}</h3></div><div class="dash-card-body">
            <div class="publish-modal-list">
              <div><span>${dt("وضع البيانات", "Mode données")}</span><strong>${R.remote ? "Supabase" : dt("محلي تجريبي", "Local démo")}</strong></div>
              <div><span>Supabase URL</span><strong dir="ltr" style="font-size:8px">${esc(R.config.supabaseUrl || dt("غير مهيأ", "Non configuré"))}</strong></div>
              <div><span>${dt("المشروع", "Projet")}</span><strong>${dt("ريستور موريتانيا", "Restore Mauritanie")}</strong></div>
              <div><span>${dt("نطاق البيع", "Périmètre")}</span><strong>MRU · Mauritanie</strong></div>
            </div>
            <div class="field" style="margin-top:12px"><label>${dt("العملة المعروضة افتراضيًا", "Affichage de la devise par défaut")}</label><select data-currency-mode>
              <option value="new" ${R.getCurrencyMode() === "new" ? "selected" : ""}>${dt("أوقية جديدة (MRU)", "Nouvelle ouguiya (MRU)")}</option>
              <option value="old" ${R.getCurrencyMode() === "old" ? "selected" : ""}>${dt("أوقية قديمة (MRO) = القيمة × 10", "Ancienne ouguiya (MRO) = valeur × 10")}</option>
            </select><p class="form-note">${dt("يمكن للزائر تبديلها من رأس المتجر. الأسعار محفوظة بالأوقية الجديدة.", "Le visiteur peut la changer dans l’en-tête. Les prix restent en nouvelle ouguiya.")}</p></div>
            <p class="form-note" style="margin-top:11px">${dt("لربط Supabase: ضع URL و anon key في config.js ثم نفّذ ملف supabase/schema.sql. ستتزامن الطلبات والحالة تلقائيًا.", "Pour Supabase : renseignez URL et anon key dans config.js puis exécutez supabase/schema.sql.")}</p>
            <a class="btn btn-soft btn-sm" href="supabase/schema.sql" target="_blank">${dt("عرض ملف SQL", "Voir le fichier SQL")}</a>
          </div></article>
          <article class="dash-card"><div class="dash-card-head"><h3>${dt("منطقة الخطر", "Zone sensible")}</h3></div><div class="dash-card-body">
            <p style="font-size:10px;color:var(--muted);line-height:1.8;margin-bottom:12px">${dt("إعادة تعيين البيانات التجريبية ستحذف الطلبات والمسودات والحسابات المحلية. لا يمكن التراجع.", "Réinitialiser la démo supprime commandes, brouillons et comptes locaux. Action irréversible.")}</p>
            <div style="display:flex;gap:7px;flex-wrap:wrap"><button class="btn btn-soft btn-sm" data-action="publish">${icon("publish")} ${dt("نشر الآن", "Publier")}</button><button class="btn btn-danger btn-sm" data-action="reset-demo">${icon("trash")} ${dt("إعادة تعيين التجربة", "Réinitialiser la démo")}</button></div>
          </div></article>
        </div>
      </div>`;
  }

  /* --------------------------------------------------------------------------
     Audit log
     -------------------------------------------------------------------------- */
  function viewAudit() {
    const logs = R.getAudit();
    return `
      <div class="dash-view-head"><div><h2>${dt("سجل النشاط", "Journal d’activité")}</h2><p>${dt("آخر 500 عملية في لوحة التحكم.", "Les 500 dernières actions du tableau de bord.")}</p></div><div class="dash-view-actions"><button class="btn btn-soft" data-action="clear-audit">${icon("trash")} ${dt("مسح السجل", "Effacer")}</button></div></div>
      <article class="dash-card"><div class="dash-card-body">${logs.length ? `<div class="list-editor">${logs.map((log) => `<div class="audit-row"><span class="audit-dot"></span><div><strong>${esc(log.action)}</strong><small>${esc(fmtDateTime(log.at))} · ${esc(log.actor || "system")}</small></div></div>`).join("")}</div>` : `<div class="empty-dash">${icon("audit")}<p>${dt("لا توجد عمليات مسجلة بعد.", "Aucune action enregistrée.")}</p></div>`}</div></article>`;
  }

  /* --------------------------------------------------------------------------
     Publish, preview and draft lifecycle
     -------------------------------------------------------------------------- */
  /* ==========================================================================
     First-time Setup Modal
     ========================================================================== */
  function openPublishModal() {
    saveDraftNow();
    const products = model.products.length;
    const draftHours = model.updatedAt ? Math.max(0, Math.round((Date.now() - Date.parse(model.updatedAt)) / 3600000)) : 0;
    openModal(dt("نشر التغييرات", "Publier les changements"), `
      <div class="publish-modal-list">
        <div><span>${dt("المنتجات", "Produits")}</span><strong>${products}</strong></div>
        <div><span>${dt("الأقسام", "Sections")}</span><strong>${(model.settings.pageSections || []).filter((section) => section.visible !== false).length}</strong></div>
        <div><span>${dt("الطلبات", "Commandes")}</span><strong>${R.getOrders().length}</strong></div>
        <div><span>${dt("آخر تعديل", "Dernière modification")}</span><strong>${esc(fmtDateTime(model.updatedAt))}</strong></div>
        <div><span>${dt("مساحة المتجر", "Boutique")}</span><strong>${R.remote ? "Supabase" : dt("محلي", "Local")} · MRU</strong></div>
      </div>
      <div style="display:flex;align-items:flex-start;gap:8px;background:var(--surface-2);border-radius:8px;padding:11px;margin-top:13px;font-size:10px;color:var(--muted);line-height:1.6">${icon("info")}<span>${dt("سيظهر المحتوى والألوان والمنتجات للزوار خلال ثوانٍ. يمكنك فتح المعاينة أولًا للتأكد.", "Le contenu, les couleurs et les produits seront visibles en quelques secondes. Ouvrez l’aperçu pour vérifier.")}</span></div>`, {
      footer: `<button class="btn btn-soft btn-sm" data-action="close-modal">${dt("إلغاء", "Annuler")}</button><button class="btn btn-soft btn-sm" data-action="preview">${icon("preview")} ${dt("معاينة", "Aperçu")}</button><button class="btn btn-primary btn-sm" data-action="confirm-publish">${icon("publish")} ${dt("نشر", "Publier")}</button>`
    });
  }

  async function publishNow() {
    const button = $("[data-action='confirm-publish']");
    if (button) { button.disabled = true; button.textContent = dt("جارٍ النشر...", "Publication..."); }
    try {
      const published = await R.publish(model);
      model = clone(published);
      dirty = false;
      closeModal();
      renderRoute();
      updateDraftState();
      R.addAudit(dt("نشر تحديث المتجر", "Publication de la boutique"));
      toast(dt("تم نشر التغييرات في المتجر", "Changements publiés sur la boutique"), "good");
    } catch (error) {
      toast(error.message || String(error), "error");
      if (button) { button.disabled = false; button.textContent = dt("نشر", "Publier"); }
    }
  }

  /* --------------------------------------------------------------------------
     Event delegation
     -------------------------------------------------------------------------- */
  let editorKind = null;
  let lastOrderCount = newOrdersCount();
  let searchTimer;

  function applyLiveColor(path) {
    const html = document.documentElement;
    const map = { "settings.colors.primary": "--orange", "settings.colors.purple": "--purple", "settings.colors.ink": "--ink", "settings.colors.lavender": "--lav" };
    if (map[path]) html.style.setProperty(map[path], getPath(model, path));
    if (path === "settings.font") {
      const font = getPath(model, path);
      html.style.setProperty("--font-main", `"${font}", "Noto Sans Arabic", Tahoma, sans-serif`);
    }
  }

  function handleField(node) {
    const editPath = node.dataset.editPath;
    const path = node.dataset.path;
    if (!editPath && !path) return;
    let value = node.type === "checkbox" ? node.checked : node.value;
    if (node.dataset.type === "bool") value = node.checked;
    if (node.type === "number" || node.dataset.type === "number") value = value === "" ? 0 : Number(value);
    if (node.type === "datetime-local" && value) value = new Date(value).toISOString();
    const target = editPath ? editBuffer : model;
    if (!target) return;
    setPath(target, editPath || path, value);
    if (!editPath) {
      applyLiveColor(path);
      saveDraftSoon();
      if (path.startsWith("settings.") || path.startsWith("pages.") || path.startsWith("collections.")) {
        // no DOM re-render while typing; the draft is saved in the background
      }
    }
  }

  function handleDirectToggle(node) {
    if (node.dataset.pageSectionVisible) {
      const section = model.settings.pageSections.find((item) => item.id === node.dataset.pageSectionVisible);
      if (section) { section.visible = node.checked; saveDraftSoon(); }
    }
    if (node.dataset.homeSectionVisible) {
      const section = model.settings.homeSections.find((item) => item.id === node.dataset.homeSectionVisible);
      if (section) { section.visible = node.checked; saveDraftSoon(); }
    }
    if (node.dataset.productActive != null) {
      const product = model.products[Number(node.dataset.productActive)];
      if (product) { product.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.couponActive != null) {
      const coupon = model.settings.coupons[Number(node.dataset.couponActive)];
      if (coupon) { coupon.active = node.checked; saveDraftNow(); }
    }
    if (node.dataset.paymentActive != null) {
      const payment = model.settings.payments[Number(node.dataset.paymentActive)];
      if (payment) { payment.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.cityActive != null) {
      const city = model.settings.cities[Number(node.dataset.cityActive)];
      if (city) { city.active = node.checked; saveDraftNow(); renderRoute(); }
    }
    if (node.dataset.reviewApproved != null) {
      const review = model.reviews[Number(node.dataset.reviewApproved)];
      if (review) { review.approved = node.checked; saveDraftNow(); }
    }
    if (node.dataset.orderStatus) {
      const order = R.getOrders().find((item) => item.id === node.dataset.orderStatus);
      if (order) {
        R.updateOrder(order.id, { status: node.value });
        R.addAudit(`${dt("تحديث حالة طلب", "Statut commande")} ${order.id}: ${node.value}`);
        toast(dt("تم تحديث حالة الطلب", "Statut mis à jour"), "good");
        if (route === "overview" || route === "orders") renderRoute();
      }
    }
  }

  function handleLines(node) {
    const path = node.dataset.linesPath;
    if (!path) return;
    const rows = node.value.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
      const parts = line.split("|").map((part) => part.trim());
      if (parts.length >= 3) return { label: { ar: parts[0], fr: parts[1] }, href: parts.slice(2).join("|") };
      return { label: { ar: parts[0], fr: parts[0] }, href: parts[1] || "#" };
    });
    setPath(model, path, rows);
    saveDraftSoon();
  }

  function resizeImage(file) {
    return new Promise((resolve, reject) => {
      if (file.size > 4 * 1024 * 1024) { reject(new Error(dt("الصورة أكبر من 4MB", "Image supérieure à 4 Mo"))); return; }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(dt("تعذر قراءة الصورة", "Impossible de lire l’image")));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error(dt("صورة غير صالحة", "Image invalide")));
        image.onload = () => {
          const max = 900;
          const scale = Math.min(1, max / Math.max(image.width, image.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.width * scale));
          canvas.height = Math.max(1, Math.round(image.height * scale));
          const context = canvas.getContext("2d");
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL("image/webp", 0.82));
        };
        image.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  async function handleUpload(input) {
    const file = input.files?.[0];
    if (!file) return;
    const path = input.dataset.uploadPath;
    const direct = input.dataset.uploadTarget === "direct";
    try {
      let data = await resizeImage(file);
      const target = direct ? model : editBuffer;
      if (!target) return;
      if (R.remote) {
        try {
          const publicUrl = await R.uploadMedia(data);
          if (publicUrl) data = publicUrl;
        } catch (uploadError) {
          toast(`${dt("تعذر رفع الصورة إلى Supabase", "Échec du téléversement Supabase")}: ${uploadError.message}`, "error");
          return;
        }
      }
      setPath(target, path, data);
      const field = input.closest(".image-field");
      const inputNode = field?.querySelector("input[data-edit-path], input[data-path]");
      if (inputNode) inputNode.value = data;
      const preview = field?.querySelector("img");
      if (preview) preview.src = data;
      if (direct) saveDraftSoon();
      toast(dt("تم رفع الصورة", "Image importée"), "good");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  document.addEventListener("click", (event) => {
    const link = event.target.closest("[data-route]");
    if (link) {
      event.preventDefault();
      route = link.dataset.route;
      if (location.hash !== `#${route}`) history.replaceState(null, "", `#${route}`);
      $("#dash-sidebar")?.classList.remove("open");
      renderRoute();
      return;
    }
    const langButton = event.target.closest("[data-dash-lang]");
    if (langButton) {
      dashLang = langButton.dataset.dashLang === "fr" ? "fr" : "ar";
      localStorage.setItem(LS_DASH_LANG, dashLang);
      document.documentElement.lang = dashLang;
      document.documentElement.dir = dashLang === "ar" ? "rtl" : "ltr";
      if (session?.mustChange) renderPasswordChange();
      else if (session) renderShell();
      else renderLogin();
      return;
    }
    const tab = event.target.closest("[data-dash-tab]");
    if (tab) {
      const tabs = tab.parentElement;
      tabs.querySelectorAll("[data-dash-tab]").forEach((item) => item.classList.toggle("active", item === tab));
      const container = tabs.parentElement;
      container.querySelectorAll("[data-dash-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.dashPanel === tab.dataset.dashTab));
      return;
    }
    const filterButton = event.target.closest("[data-order-filter]");
    if (filterButton) { orderFilter = filterButton.dataset.orderFilter; renderRoute(); return; }
    const abandonedButton = event.target.closest("[data-abandoned-filter]");
    if (abandonedButton) { abandonedFilter = abandonedButton.dataset.abandonedFilter; renderRoute(); return; }
    const reportButton = event.target.closest("[data-report-range]");
    if (reportButton) { reportRange = reportButton.dataset.reportRange; renderRoute(); return; }
    const productFilter = event.target.closest("[data-product-filter]");
    if (productFilter) { /* handled in change */ }


    const actionNode = event.target.closest("[data-action]");
    if (!actionNode) return;
    const action = actionNode.dataset.action;
    const index = actionNode.dataset.index != null ? Number(actionNode.dataset.index) : null;
    const id = actionNode.dataset.id || "";

    switch (action) {
      case "logout":
        R.addAudit(dt("تسجيل خروج", "Déconnexion"), session?.username);
        R.logout();
        renderLogin();
        break;
      case "profile":
        route = "profile"; history.replaceState(null, "", "#profile"); renderRoute();
        break;
      case "toggle-sidebar":
        $("#dash-sidebar")?.classList.toggle("open");
        break;
      case "theme": {
        const next = R.theme === "dark" ? "light" : "dark";
        R.setTheme(next);
        actionNode.innerHTML = icon(next === "dark" ? "sun" : "moon");
        break;
      }
      case "orders-alert":
        route = "orders"; history.replaceState(null, "", "#orders");
        orderBadgeSeen = newOrdersCount();
        localStorage.setItem("restore_orders_seen_v1", String(orderBadgeSeen));
        updateCounts(); renderRoute();
        break;
      case "save-draft":
        saveDraftNow(); toast(dt("تم حفظ المسودة", "Brouillon enregistré"), "good");
        break;
      case "preview":
        if (dirty) saveDraftNow();
        window.open("index.html?preview=1", "_blank", "noopener");
        break;
      case "publish":
        openPublishModal();
        break;
      case "confirm-publish":
        publishNow();
        break;
      case "discard-draft":
        if (confirm(dt("إلغاء كل التغييرات غير المنشورة؟", "Annuler toutes les modifications non publiées ?"))) {
          R.discardDraft(); model = clone(R.state); dirty = false; closeModal(); renderRoute(); toast(dt("تم إلغاء المسودة", "Brouillon annulé"));
        }
        break;
      case "reset-demo":
        if (session?.role !== "owner") { toast(dt("للمالك فقط", "Propriétaire uniquement"), "error"); break; }
        if (confirm(dt("إعادة تعيين البيانات التجريبية وحذف كل الطلبات؟", "Réinitialiser la démo et supprimer toutes les commandes ?"))) {
          if (confirm(dt("تأكيد أخير: لا يمكن التراجع.", "Dernière confirmation : irréversible."))) R.resetLocalDemo();
        }
        break;
      case "close-modal":
        closeModal();
        break;
      case "modal-backdrop":
        if (event.target === actionNode) closeModal();
        break;
      case "view-order":
        viewOrderModal(id);
        break;
      case "save-order": {
        const order = R.getOrders().find((item) => item.id === id);
        if (order) {
          const status = $(`.dash-modal [data-order-status="${CSS.escape(id)}"]`)?.value || order.status;
          const note = $(`.dash-modal [data-order-note="${CSS.escape(id)}"]`)?.value || "";
          R.updateOrder(id, { status, internalNote: note });
          R.addAudit(`${dt("تحديث الطلب", "Commande modifiée")} ${id}: ${status}`);
          toast(dt("تم حفظ الطلب", "Commande enregistrée"), "good");
        }
        closeModal(); renderRoute();
        break;
      }
      case "print-invoice":
        printOrder(R.getOrders().find((order) => order.id === id), "invoice");
        break;
      case "print-label":
        printOrder(R.getOrders().find((order) => order.id === id), "label");
        break;
      case "export-orders":
        exportOrdersCsv();
        break;
      case "abandoned-status": {
        const rows = R.getAbandoned().map((item) => item.id === id ? { ...item, status: actionNode.dataset.status || "contacted", contactedAt: nowIso() } : item);
        localStorage.setItem("restore_abandoned_v1", JSON.stringify(rows));
        window.dispatchEvent(new CustomEvent("restore:orders"));
        renderRoute(); toast(dt("تم تحديث السلة", "Panier mis à jour"), "good");
        break;
      }
      case "delete-abandoned":
        if (confirm(dt("حذف السلة المتروكة؟", "Supprimer ce panier ?"))) { R.removeAbandoned(id); renderRoute(); }
        break;
      case "add-product":
        editorKind = "product"; productEditor(null);
        break;
      case "edit-product":
        editorKind = "product"; productEditor(index);
        break;
      case "delete-product":
        deleteProduct(index);
        break;
      case "delete-product-buffer":
        deleteProduct(null, true);
        break;
      case "bulk-price":
        bulkPriceModal();
        break;
      case "apply-bulk-price":
        applyBulkPrice();
        break;
      case "save-editor":
        if (editorKind === "product") saveProductEditor();
        else if (editorKind === "category") saveCategoryEditor();
        else if (editorKind === "nav") saveNavEditor();
        else if (editorKind === "hero") saveHeroEditor();
        else if (editorKind === "review") saveReviewEditor();
        else if (editorKind === "payment") viewPaymentSave();
        else if (editorKind === "city") viewCitySave();
        break;
      case "add-category":
        editorKind = "category"; categoryEditor(null);
        break;
      case "edit-category":
        editorKind = "category"; categoryEditor(index);
        break;
      case "delete-category":
        if (confirm(dt("حذف الفئة؟", "Supprimer la catégorie ?"))) { model.theme.categories.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "delete-category-buffer":
        if (confirm(dt("حذف الفئة؟", "Supprimer la catégorie ?"))) { model.theme.categories = model.theme.categories.filter((item) => item.handle !== editBuffer.handle); saveDraftNow(); closeModal(); renderRoute(); }
        break;
      case "edit-collection":
        collectionEditor(index);
        break;
      case "save-collection":
        if (editBuffer) { model.collections[index] = editBuffer; saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المجموعة", "Collection enregistrée"), "good"); }
        break;
      case "add-trust":
        model.settings.trustBar.push({ icon: "truck", label: { ar: "", fr: "" } }); saveDraftNow(); renderRoute();
        break;
      case "remove-trust":
        model.settings.trustBar.splice(index, 1); saveDraftNow(); renderRoute();
        break;
      case "add-nav":
        editorKind = "nav"; navEditor(null);
        break;
      case "edit-nav":
        editorKind = "nav"; navEditor(index);
        break;
      case "delete-nav":
        if (confirm(dt("حذف عنصر القائمة؟", "Supprimer cet élément ?"))) { model.settings.navigation.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "delete-nav-buffer":
        model.settings.navigation = model.settings.navigation.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute();
        break;
      case "add-footer-column":
        model.settings.footerColumns.push({ title: { ar: "روابط", fr: "Liens" }, links: [] }); saveDraftNow(); renderRoute();
        break;
      case "add-hero":
        editorKind = "hero"; heroEditor(null);
        break;
      case "edit-hero":
        editorKind = "hero"; heroEditor(index);
        break;
      case "delete-hero":
        if (confirm(dt("حذف الشريحة؟", "Supprimer la diapositive ?"))) { model.settings.heroSlides.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "delete-hero-buffer":
        model.settings.heroSlides = model.settings.heroSlides.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute();
        break;
      case "page-section-up": {
        const sections = [...model.settings.pageSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index > 0) { [sections[index - 1], sections[index]] = [sections[index], sections[index - 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "page-section-down": {
        const sections = [...model.settings.pageSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index >= 0 && index < sections.length - 1) { [sections[index + 1], sections[index]] = [sections[index], sections[index + 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "home-section-up": {
        const sections = [...model.settings.homeSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index > 0) { [sections[index - 1], sections[index]] = [sections[index], sections[index - 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "home-section-down": {
        const sections = [...model.settings.homeSections].sort((a, b) => a.order - b.order);
        const index = sections.findIndex((item) => item.id === id);
        if (index >= 0 && index < sections.length - 1) { [sections[index + 1], sections[index]] = [sections[index], sections[index + 1]]; sections.forEach((section, position) => { section.order = position + 1; }); saveDraftNow(); renderRoute(); }
        break;
      }
      case "edit-home-section":
        homeSectionEditor(id);
        break;
      case "save-home-section": {
        if (!editBuffer) return;
        const index = model.settings.homeSections.findIndex((section) => section.id === id);
        if (index >= 0) model.settings.homeSections[index] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ قسم المنتجات", "Section enregistrée"), "good");
        break;
      }
      case "add-home-section": {
        const collection = model.collections[0]?.handle || "all";
        model.settings.homeSections.push({ id: `section-${Date.now().toString(36)}`, visible: true, order: model.settings.homeSections.length + 1, title: { ar: "منتجات مختارة", fr: "Produits sélectionnés" }, collection, layout: "left", promo: "", flame: false });
        saveDraftNow(); renderRoute(); break;
      }
      case "add-coupon":
        couponEditor(null);
        break;
      case "edit-coupon":
        couponEditor(index);
        break;
      case "delete-coupon":
        model.settings.coupons.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "save-coupon":
        if (!editBuffer) return;
        if (actionNode.dataset.index === "") model.settings.coupons.push(editBuffer);
        else model.settings.coupons[Number(actionNode.dataset.index)] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ الكوبون", "Coupon enregistré"), "good"); break;
      case "add-payment":
        editorKind = "payment"; paymentEditor(null); break;
      case "edit-payment":
        editorKind = "payment"; paymentEditor(index); break;
      case "delete-payment":
        if (model.settings.payments.length <= 1) { toast(dt("يجب ترك طريقة دفع واحدة على الأقل", "Gardez au moins un moyen de paiement"), "error"); break; }
        model.settings.payments.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "delete-payment-buffer":
        model.settings.payments = model.settings.payments.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute(); break;
      case "add-city":
        editorKind = "city"; cityEditor(null); break;
      case "edit-city":
        editorKind = "city"; cityEditor(index); break;
      case "delete-city":
        model.settings.cities.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "delete-city-buffer":
        model.settings.cities = model.settings.cities.filter((item) => item.id !== editBuffer.id); saveDraftNow(); closeModal(); renderRoute(); break;
      case "add-manager":
        managerEditor(null); break;
      case "edit-manager":
        managerEditor(id); break;
      case "delete-manager":
        if (confirm(dt("حذف حساب المدير؟", "Supprimer ce gérant ?"))) {
          try { R.deleteManager(id); renderRoute(); toast(dt("تم حذف المدير", "Gérant supprimé"), "good"); } catch (error) { toast(error.message, "error"); }
        }
        break;
      case "force-password":
        R.updateManager(id, { mustChange: true }); renderRoute(); toast(dt("سيُطلب تغيير كلمة المرور", "Changement de mot de passe requis"), "good"); break;
      case "save-manager":
        saveManager(); break;
      case "change-own-password":
        changeOwnPasswordModal(); break;
      case "save-own-password":
        saveOwnPassword(); break;
      case "add-post":
        postEditor(null); break;
      case "edit-post":
        postEditor(index); break;
      case "delete-post":
        if (confirm(dt("حذف المقال؟", "Supprimer l’article ?"))) { model.blog.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "save-post":
        if (!editBuffer) return;
        if (pendingPostIndex == null) model.blog.push(editBuffer); else model.blog[pendingPostIndex] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ المقال", "Article enregistré"), "good"); break;
      case "add-page":
        pageEditor(null); break;
      case "edit-page":
        pageEditor(index); break;
      case "delete-page":
        if (confirm(dt("حذف الصفحة؟", "Supprimer la page ?"))) { model.pages.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "save-page":
        savePageEditor(); break;
      case "add-faq":
        faqEditor(null); break;
      case "edit-faq":
        faqEditor(index); break;
      case "delete-faq":
        if (confirm(dt("حذف السؤال؟", "Supprimer la question ?"))) { model.faqs.splice(index, 1); saveDraftNow(); renderRoute(); }
        break;
      case "save-faq":
        if (!editBuffer) return;
        if (actionNode.dataset.index === "") model.faqs.push(editBuffer); else model.faqs[Number(actionNode.dataset.index)] = editBuffer;
        saveDraftNow(); closeModal(); renderRoute(); toast(dt("تم حفظ السؤال", "Question enregistrée"), "good"); break;
      case "add-home-review":
        editorKind = "review"; reviewEditor("home", null); break;
      case "edit-home-review":
        editorKind = "review"; reviewEditor("home", index); break;
      case "delete-home-review":
        model.homeReviews.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "add-product-review":
        editorKind = "review"; reviewEditor("product", null); break;
      case "edit-product-review":
        editorKind = "review"; reviewEditor("product", index); break;
      case "delete-product-review":
        model.reviews.splice(index, 1); saveDraftNow(); renderRoute(); break;
      case "delete-review-buffer":
        if (pendingReviewKind === "home") model.homeReviews = model.homeReviews.filter((item) => item.id !== editBuffer.id);
        else model.reviews = model.reviews.filter((item) => item.id !== editBuffer.id);
        saveDraftNow(); closeModal(); renderRoute(); break;
      case "approve-customer-review": {
        R.moderateReview(id, "approve").then(() => {
          R.addAudit(`${dt("اعتماد تقييم عميل", "Avis client approuvé")}: ${id}`);
          renderRoute();
          toast(dt("تم اعتماد التقييم", "Avis approuvé"), "good");
        }).catch((error) => toast(error.message, "error"));
        break;
      }
      case "reject-customer-review": {
        R.moderateReview(id, "reject").then(() => {
          R.addAudit(`${dt("رفض تقييم عميل", "Avis client refusé")}: ${id}`);
          renderRoute();
          toast(dt("تم رفض التقييم", "Avis refusé"), "good");
        }).catch((error) => toast(error.message, "error"));
        break;
      }
      case "delete-customer-review": {
        if (confirm(dt("حذف التقييم نهائيًا؟", "Supprimer définitivement cet avis ?"))) {
          R.deleteCustomerReview(id).then(() => {
            R.addAudit(`${dt("حذف تقييم عميل", "Avis client supprimé")}: ${id}`);
            renderRoute();
            toast(dt("تم حذف التقييم", "Avis supprimé"), "good");
          }).catch((error) => toast(error.message, "error"));
        }
        break;
      }
      case "clear-audit":
        if (confirm(dt("مسح كل سجل النشاط؟", "Effacer tout le journal ?"))) { localStorage.removeItem("restore_audit_v1"); renderRoute(); }
        break;
      case "save-profile-info": {
        const username = $("#profile-username")?.value.trim();
        const nameAr = $("#profile-name-ar")?.value.trim();
        const nameFr = $("#profile-name-fr")?.value.trim();
        const email = $("#profile-email")?.value.trim();
        const whatsapp = $("#profile-whatsapp")?.value.trim();
        (async () => {
          try {
            if (!session?.id) throw new Error(dt("الجلسة منتهية. أعد تسجيل الدخول.", "Session expirée. Reconnectez-vous."));
            if (!R.remote && username && username !== session.username) {
              if (!/^[a-z0-9._@-]{3,64}$/.test(username)) throw new Error(dt("اسم مستخدم غير صالح", "Identifiant invalide"));
              if (R.managers.some((m) => m.username === username && m.id !== session.id)) throw new Error(dt("اسم المستخدم مستخدم", "Identifiant déjà utilisé"));
              R.updateManager(session.id, { username });
              session = { ...session, username };
              localStorage.setItem("restore_session_v1", JSON.stringify(session));
            }
            if (nameAr || nameFr) R.updateManager(session.id, { name: { ar: nameAr || nameFr, fr: nameFr || nameAr } });
            if (email && !R.remote) R.updateManager(session.id, { email });
            if (whatsapp) {
              const digitsOnly = whatsapp.replace(/\D/g, "");
              if (digitsOnly && digitsOnly.length !== 8 && digitsOnly.length !== 11) throw new Error(dt("رقم واتساب غير صالح", "Numéro WhatsApp invalide"));
              R.updateManager(session.id, { whatsapp: digitsOnly });
            }
            if (R.remote) await R.refreshStaff().catch(() => {});
            R.addAudit(`${dt("تحديث الملف الشخصي", "Profil mis à jour")}: ${session?.username}`);
            toast(dt("تم حفظ المعلومات", "Informations enregistrées"), "good");
            renderRoute();
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      case "save-owner-contact": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const allowed = new Set(["storeName", "legalName", "tagline", "email", "whatsapp", "phone", "phoneDisplay", "address", "city", "hours"]);
        const patch = {};
        document.querySelectorAll("[data-dash-panel='profile-contact'] [data-edit-path]").forEach((inp) => {
          const raw = String(inp.dataset.editPath || "");
          if (!raw.startsWith("settings.")) return;
          const key = raw.slice("settings.".length);
          if (!allowed.has(key.split(".")[0])) return;
          const val = inp.type === "checkbox" ? inp.checked : inp.value;
          setPath(patch, key, typeof val === "string" ? val.trim() : val);
        });
        (async () => {
          try {
            const saved = await R.updateOwnerSettings(patch);
            const next = clone(model);
            Object.entries(patch).forEach(([key, value]) => setPath(next, `settings.${key}`, value));
            model = next;
            saveDraftNow();
            R.addAudit(`${dt("تحديث تواصل المتجر", "Contact boutique mis à jour")}`);
            toast(dt("تم حفظ معلومات المتجر ونشرها", "Infos boutique enregistrées et publiées"), "good");
            renderRoute();
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      case "save-owner-social": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const allowed = new Set(["facebook", "instagram", "tiktok", "youtube", "x", "twitter", "snapchat", "whatsapp", "linkedin", "telegram"]);
        const socials = [];
        const rows = document.querySelectorAll("[data-dash-panel='profile-social'] .social-row");
        for (const row of rows) {
          const platform = String(row.querySelector("[data-social-platform]")?.value || "").trim().toLowerCase();
          let href = String(row.querySelector("[data-social-url]")?.value || "").trim();
          if (!platform && !href) continue;
          if (!allowed.has(platform)) return toast(dt("اختر منصة صالحة لكل رابط", "Choisissez une plateforme valide pour chaque lien"), "error");
          if (href && !/^https?:\/\//i.test(href)) href = `https://${href}`;
          if (!/^https:\/\//i.test(href)) return toast(dt("روابط السوشيال يجب أن تبدأ بـ https://", "Les liens doivent commencer par https://"), "error");
          socials.push({ platform, href });
        }
        (async () => {
          try {
            const saved = await R.updateOwnerSettings({ social: socials });
            const next = clone(model);
            next.settings.social = Array.isArray(saved.social) ? saved.social : socials.map((item) => ({ ...item, id: item.platform, icon: item.platform }));
            model = next;
            saveDraftNow();
            R.addAudit(`${dt("تحديث روابط السوشيال", "Liens sociaux mis à jour")}`);
            toast(dt("حُفظت الروابط ونُشرت", "Liens enregistrés et publiés"), "good");
            renderRoute();
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      case "remove-social": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const idx = Number(actionNode.dataset.index);
        const next = clone(model);
        if (next.settings.social) next.settings.social.splice(idx, 1);
        model = next;
        saveDraftSoon();
        renderRoute();
        break;
      }
      case "add-social-link": {
        if (session?.role !== "owner") return toast(dt("للمالك فقط", "Propriétaire uniquement"), "error");
        const next = clone(model);
        next.settings.social = next.settings.social || [];
        next.settings.social.push({ platform: "", href: "" });
        model = next;
        saveDraftSoon();
        renderRoute();
        break;
      }
      case "change-own-pwd": {
        const current = $("#sec-current")?.value || "";
        const nextPwd = $("#sec-next")?.value || "";
        const confirm = $("#sec-confirm")?.value || "";
        if (!current || !nextPwd || nextPwd !== confirm) return toast(dt("تحقق من كلمات المرور", "Vérifiez les mots de passe"), "error");
        if (nextPwd.length < 8) return toast(dt("كلمة المرور 8 أحرف على الأقل", "Mot de passe : 8 caractères minimum"), "error");
        (async () => {
          try {
            await R.changePassword(session.username, current, nextPwd, "");
            session = R.currentSession();
            toast(dt("تم تغيير كلمة المرور", "Mot de passe changé"), "good");
            $("#sec-current").value = "";
            $("#sec-next").value = "";
            $("#sec-confirm").value = "";
          } catch (error) { toast(error.message, "error"); }
        })();
        break;
      }
      default:
        break;
    }
  });

  document.addEventListener("input", (event) => {
    const node = event.target;
    if (node.id === "order-search") {
      searchTerm = node.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { renderRoute(); const next = $("#order-search"); if (next) { next.focus(); next.setSelectionRange(next.value.length, next.value.length); } }, 320);
      return;
    }
    if (node.id === "product-search") {
      productSearch = node.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { renderRoute(); const next = $("#product-search"); if (next) { next.focus(); next.setSelectionRange(next.value.length, next.value.length); } }, 320);
      return;
    }
    if (node.id === "dash-search") {
      searchTerm = node.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        if (route === "orders" || route === "products") renderRoute();
      }, 380);
      return;
    }
    if (node.matches("[data-edit-path]")) {
      handleField(node);
      const preview = node.closest(".image-field")?.querySelector("img");
      if (preview && node.type !== "file") preview.src = node.value || "assets/img/favicon.svg";
    } else if (node.matches("[data-path]")) {
      handleField(node);
      const preview = node.closest(".image-field")?.querySelector("img");
      if (preview && node.type !== "file") preview.src = node.value || "assets/img/favicon.svg";
    }
  });

  document.addEventListener("change", (event) => {
    const node = event.target;
    if (node.matches("[data-upload-path]")) { handleUpload(node); return; }
    if (node.id === "profile-avatar-upload" && node.files?.[0]) {
      const file = node.files[0];
      (async () => {
        try {
          const dataUrl = await R.resizeImage(file, 256, 0.85);
          const publicUrl = await R.uploadMedia(dataUrl);
          const url = publicUrl || dataUrl;
          R.updateManager(session.id, { avatar: url });
          model = clone(R.state);
          session = R.currentSession();
          localStorage.setItem("restore_session_v1", JSON.stringify(session));
          R.addAudit(`${dt("تحديث الصورة الرمزية", "Avatar mis à jour")}`);
          toast(dt("تم تحديث الصورة", "Image mise à jour"), "good");
          renderRoute();
        } catch (error) { toast(error.message, "error"); }
      })();
      return;
    }
    if (node.matches("[data-lines-path]")) { handleLines(node); return; }
    if (node.matches("[data-currency-mode]")) {
      R.setCurrencyMode(node.value);
      setPath(model, "settings.country.currencyMode", node.value);
      saveDraftSoon();
      toast(dt("تم تغيير العملة المعروضة", "Devise d’affichage modifiée"), "good");
      return;
    }
    if (node.dataset.blocklist != null) {
      model.settings.blocklist = node.value.split("\n").map((line) => digits(line)).filter(Boolean);
      saveDraftSoon();
      return;
    }
    if (node.matches("[data-page-section-visible], [data-home-section-visible], [data-product-active], [data-coupon-active], [data-payment-active], [data-city-active], [data-review-approved]")) {
      handleDirectToggle(node);
      return;
    }
    if (node.matches("[data-order-status]")) {
      handleDirectToggle(node);
      return;
    }
    if (node.matches("[data-product-filter]")) {
      if (node.dataset.productFilter === "category") productCategory = node.value;
      if (node.dataset.productFilter === "stock") productStock = node.value;
      saveDraftNow();
      renderRoute();
      return;
    }
    if (node.matches("[data-edit-path]")) {
      handleField(node);
      return;
    }
    if (node.matches("[data-path]")) {
      handleField(node);
      saveDraftNow();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modalRoot.innerHTML) closeModal();
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveDraftNow();
      toast(dt("تم حفظ المسودة", "Brouillon enregistré"), "good");
    }
  });

  window.addEventListener("hashchange", () => {
    const next = (location.hash || "#overview").slice(1);
    if (ROUTE_TITLES[next] && next !== route) {
      route = next;
      if (session) renderRoute();
    }
  });

  window.addEventListener("restore:orders", () => {
    const count = newOrdersCount();
    updateCounts();
    if (count > lastOrderCount) {
      toast(dt("طلب جديد وصل من المتجر", "Nouvelle commande reçue"), "good");
      try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
          const context = new AudioContext();
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          oscillator.connect(gain); gain.connect(context.destination);
          oscillator.frequency.value = 880; gain.gain.value = 0.03;
          oscillator.start(); oscillator.stop(context.currentTime + 0.16);
        }
      } catch {}
      if (route === "orders" || route === "overview") renderRoute();
    }
    lastOrderCount = count;
  });

  window.addEventListener("restore:changed", () => {
    if (!dirty) {
      model = clone(R.state);
      if (session) renderRoute();
    }
  });

  window.addEventListener("restore:reviews", () => {
    if (session && route === "reviews") renderRoute();
  });

  window.addEventListener("restore:orders", () => {
    if (session && (route === "orders" || route === "overview" || route === "reports")) updateCounts();
  });

  window.addEventListener("beforeunload", () => {
    if (dirty) {
      try { R.saveDraft(model); } catch {}
    }
  });

  /* --------------------------------------------------------------------------
     Boot
     -------------------------------------------------------------------------- */
  function boot() {
    if (!session) { renderLogin(); return; }
    if (session.mustChange) { renderPasswordChange(); return; }
    renderShell();
    if (R.remote) {
      R.loadRemoteState().then((updated) => {
        if (updated && !dirty) { model = clone(R.state); renderRoute(); }
      }).catch(() => {});
    }
  }
  boot();

};
_initDashboard();
