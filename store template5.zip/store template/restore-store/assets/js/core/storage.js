export const readJSON = (store, key, fallback) => {
  try { const raw = store.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
};
export const writeJSON = (store, key, value) => {
  try { store.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
};
export const readLocal = (key, fallback) => readJSON(localStorage, key, fallback);
export const writeLocal = (key, value) => writeJSON(localStorage, key, value);
export const readSession = (key, fallback) => readJSON(sessionStorage, key, fallback);
export const writeSession = (key, value) => writeJSON(sessionStorage, key, value);
