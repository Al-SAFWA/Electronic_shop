const bus = new EventTarget();
export const on = (type, fn) => { bus.addEventListener(type, fn); return () => bus.removeEventListener(type, fn); };
export const emit = (type, detail) => bus.dispatchEvent(new CustomEvent(type, { detail }));
export default { on, emit };
