import { num } from "../core/utils.js";

export function effectiveUnitPrice(product, variant = null) {
  if (variant && variant.price != null) return Math.max(0, Math.round(num(variant.price, 0)));
  return Math.max(0, Math.round(num(product?.price, 0)));
}
export function lineTotal(product, variant, qty) {
  return effectiveUnitPrice(product, variant) * Math.max(1, Math.floor(num(qty, 1)));
}
export function shippingFee(subtotal, city, freeOver = 0) {
  if (num(subtotal) >= num(freeOver)) return 0;
  return Math.max(0, Math.round(num(city?.fee, 0)));
}
export function paymentDiscount(subtotal, payment) {
  return Math.round(num(subtotal) * Math.max(0, num(payment?.discount, 0)) / 100);
}
export function couponDiscount(subtotal, coupon, now = Date.now()) {
  if (!coupon || coupon.active === false) return { amount: 0, code: "" };
  if (coupon.expiresAt && Date.parse(coupon.expiresAt) < now) return { amount: 0, code: "" };
  if (num(subtotal) < num(coupon.minTotal, 0)) return { amount: 0, code: "" };
  const code = String(coupon.code || "").toUpperCase();
  const amount = coupon.type === "percent"
    ? Math.round(num(subtotal) * Math.max(0, num(coupon.value, 0)) / 100)
    : Math.max(0, Math.round(num(coupon.value, 0)));
  return { amount, code };
}
export function computeTotals({ subtotal, city, freeOver = 0, payment = null, coupon = null, now = Date.now() }) {
  const sub = Math.max(0, Math.round(num(subtotal)));
  const ship = shippingFee(sub, city, freeOver);
  const payDisc = paymentDiscount(sub, payment);
  const coup = couponDiscount(sub, coupon, now);
  const discount = Math.min(sub, payDisc + coup.amount);
  return {
    subtotal: sub,
    shipping: ship,
    paymentDiscount: payDisc,
    couponDiscount: coup.amount,
    coupon: coup.code,
    discount,
    total: Math.max(0, sub + ship - discount),
  };
}
