import { effectiveUnitPrice, lineTotal } from "./pricing.js";
import { num } from "../core/utils.js";

export function normalizeCartItem(item) {
  const qty = Math.max(1, Math.min(99, Math.floor(num(item?.qty, 1))));
  return { handle: String(item?.handle || ""), variantId: item?.variantId || null, qty, specs: item?.specs || {} };
}
export function addToCart(items, product, variant, qty = 1) {
  const next = (items || []).map(normalizeCartItem);
  const vid = variant?.id || null;
  const found = next.find((i) => i.handle === product.handle && i.variantId === vid);
  if (found) found.qty = Math.min(99, found.qty + Math.max(1, Math.floor(num(qty, 1))));
  else next.push(normalizeCartItem({ handle: product.handle, variantId: vid, qty }));
  return next;
}
export function setQty(items, handle, variantId, qty) {
  return (items || []).map(normalizeCartItem).map((i) => (i.handle === handle && i.variantId === (variantId || null) ? { ...i, qty: Math.max(1, Math.min(99, Math.floor(num(qty, 1)))) } : i));
}
export function removeFromCart(items, handle, variantId) {
  return (items || []).map(normalizeCartItem).filter((i) => !(i.handle === handle && i.variantId === (variantId || null)));
}
export function cartSubtotal(items, catalogByHandle) {
  return (items || []).reduce((sum, item) => {
    const p = catalogByHandle.get(item.handle);
    if (!p) return sum;
    const v = (p.variants || []).find((x) => x.id === item.variantId) || null;
    return sum + lineTotal(p, v, item.qty);
  }, 0);
}
