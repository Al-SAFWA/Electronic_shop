import { num, safeText, uid } from "../core/utils.js";
import { computeTotals } from "./pricing.js";

export function buildOrderDraft({ cartItems, catalogByHandle, customer, city, payment, coupon, settings, lang = "ar" }) {
  let subtotal = 0;
  const items = (cartItems || []).map((it) => {
    const p = catalogByHandle.get(it.handle);
    if (!p) throw new Error(`Unknown product: ${it.handle}`);
    const v = (p.variants || []).find((x) => x.id === it.variantId) || null;
    const price = Math.max(0, Math.round(num(v?.price ?? p.price)));
    const qty = Math.max(1, Math.min(20, Math.floor(num(it.qty, 1))));
    const line = price * qty;
    subtotal += line;
    return { handle: p.handle, title: p.title, image: p.image, variantId: v?.id || null, variantTitle: [v?.label, v?.color, v?.storage].filter(Boolean).join(" / "), qty, price, line };
  });
  const totals = computeTotals({ subtotal, city, freeOver: settings?.freeShippingOver || 0, payment, coupon });
  return {
    id: `RS-${Date.now().toString(36).toUpperCase()}${uid("").slice(0,4).toUpperCase()}`,
    status: "new", source: "whatsapp", lang,
    customer: {
      name: safeText(customer?.name, 120), phone: safeText(customer?.phone, 40),
      email: safeText(customer?.email, 120), city: customer?.city || "", cityId: city?.id || null,
      address: safeText(customer?.address, 300), notes: safeText(customer?.notes, 500),
    },
    items, ...totals,
    payment: payment ? { id: payment.id, name: payment.name, discount: num(payment.discount) } : null,
    currency: "MRU",
  };
}
