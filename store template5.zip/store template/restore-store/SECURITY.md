# Security Policy

## Supported versions
This repository is a project template. Security fixes are applied to the current working tree/release branch in use.

## Reporting a vulnerability
- **Do not** open a public issue for suspected security vulnerabilities.
- Report privately to the store/project owner with: affected file/URL, impact, reproduction steps, and any proof-of-concept.
- For a live store deployment, replace this section with a real security contact (email/PGP/form) and response SLA.

## Threat model (summary)
- **Assets:** staff credentials/sessions, customer PII in orders/abandoned carts, published catalog/state, media uploads, order totals/stock integrity.
- **Trust boundaries:** browser (untrusted for prices/totals/stock/roles), Supabase anon key (public), Supabase Auth JWT claims (`app_metadata.role`), Edge Functions with `service_role` (trusted server boundary), staff-only dashboard operations.
- **Key controls:** RLS with `is_staff()/is_owner()`, no public abandoned-cart/order writes by default, server-side atomic order validation (`restore_create_order`/`create-order`), shared rate limiting, optional Turnstile (fail-closed in production when misconfigured), CSP tightened (`script-src` without `unsafe-inline/eval`), local vendored DOMPurify sanitization, demo mode disabled by default.
- **Known residual risks:** static client architecture; `style-src 'unsafe-inline'`; sessions are memory/sessionStorage-limited (no HttpOnly backend cookies); distributed rate limiting requires deployed RPC/table; third-party analytics pixels increase surface; legacy God-object files remain during phased modularization.
- **Secrets:** never commit `service_role`, `.env.local`, `.vercel/project.json`, or JWTs. Rotate immediately if exposed and purge git history.
