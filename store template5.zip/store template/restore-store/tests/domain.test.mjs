import test from 'node:test';
import assert from 'node:assert/strict';
import { computeTotals, shippingFee, couponDiscount } from '../assets/js/domain/pricing.js';
import { addToCart, cartSubtotal, removeFromCart } from '../assets/js/domain/cart.js';
import { buildOrderDraft } from '../assets/js/domain/order.js';

test('shippingFee respects free threshold', () => {
  assert.equal(shippingFee(5000, { fee: 300 }, 4000), 0);
  assert.equal(shippingFee(3000, { fee: 300 }, 4000), 300);
});

test('couponDiscount percent and minTotal', () => {
  assert.deepEqual(couponDiscount(10000, { active: true, type: 'percent', value: 10, code: 'X' }), { amount: 1000, code: 'X' });
  assert.deepEqual(couponDiscount(100, { active: true, type: 'fixed', value: 50, code: 'Y', minTotal: 500 }), { amount: 0, code: '' });
});

test('computeTotals combines shipping/payment/coupon', () => {
  const t = computeTotals({ subtotal: 10000, city: { fee: 200 }, freeOver: 20000, payment: { discount: 10 }, coupon: { active: true, type: 'fixed', value: 500, code: 'C' } });
  assert.equal(t.subtotal, 10000);
  assert.equal(t.shipping, 200);
  assert.equal(t.paymentDiscount, 1000);
  assert.equal(t.couponDiscount, 500);
  assert.equal(t.total, 8700);
});

test('cart add/remove/subtotal', () => {
  const catalog = new Map([['p1', { handle:'p1', price:1000, variants:[{id:'v1',price:1200}] }]]);
  let items = addToCart([], { handle:'p1' }, { id:'v1' }, 2);
  assert.equal(cartSubtotal(items, catalog), 2400);
  items = removeFromCart(items, 'p1', 'v1');
  assert.equal(items.length, 0);
});

test('buildOrderDraft computes totals from catalog', () => {
  const catalog = new Map([['p1', { handle:'p1', title:{ar:'x',fr:'x'}, image:'', price:1000, variants:[] }]]);
  const draft = buildOrderDraft({ cartItems:[{handle:'p1',qty:2}], catalogByHandle:catalog, customer:{name:'A',phone:'+22246000000',address:'NKT'}, city:{id:'nkc',fee:200}, payment:{id:'cod',name:{ar:'COD'},discount:0}, coupon:null, settings:{freeShippingOver:99999}, lang:'ar' });
  assert.equal(draft.subtotal, 2000);
  assert.equal(draft.shipping, 200);
  assert.equal(draft.total, 2200);
  assert.equal(draft.items[0].line, 2000);
});
