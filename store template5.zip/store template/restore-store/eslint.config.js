// ESLint flat config (install eslint to enforce). Keeps module boundaries explicit.
export default [
  {
    files: ["assets/js/**/*.js"],
    rules: {
      "no-restricted-imports": ["warn", {
        patterns: [
          { group: ["**/ui/**"], message: "domain/data/core must not import from ui (ui → domain → data → core)." }
        ]
      }]
    }
  },
  {
    files: ["assets/js/domain/**/*.js", "assets/js/data/**/*.js", "assets/js/core/**/*.js"],
    rules: { "no-restricted-globals": ["warn", "document", "window"] }
  }
];
