#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
function walk(d, out=[]){ for(const f of fs.readdirSync(d,{withFileTypes:true})){ const p=path.join(d,f.name); if(f.isDirectory()) walk(p,out); else if(/\.m?js$/.test(f.name)) out.push(p);} return out; }
const files = fs.existsSync('assets/js') ? walk('assets/js') : [];
let fail = 0;
for (const file of files) {
  const rel = file.replace(/\\/g,'/');
  const src = fs.readFileSync(file,'utf8');
  const imports = [...src.matchAll(/from\s+['"]([^'"]+)['"]/g)].map(m=>m[1]);
  for (const imp of imports) {
    const resolved = path.posix.normalize(path.posix.join(path.posix.dirname(rel), imp));
    if ((/\/domain\/|\/data\/|\/core\//.test(rel)) && /\/ui\//.test(resolved)) {
      console.error(`BOUNDARY: ${rel} imports ui -> ${imp}`); fail=1;
    }
  }
}
if (fail) process.exit(1);
console.log('module boundaries ok');
