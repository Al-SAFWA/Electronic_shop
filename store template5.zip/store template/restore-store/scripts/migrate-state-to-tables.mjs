#!/usr/bin/env node
/**
 * One-time migration: read restore_state.data from Supabase and backfill relational tables.
 * DRY RUN by default. Set APPLY=1 to write. Requires SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in env.
 */
const APPLY = process.env.APPLY === '1';
const URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
if (!URL || !KEY) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY. Dry-run example: APPLY=0 SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/migrate-state-to-tables.mjs');
  process.exit(1);
}
const h = { apikey: KEY, Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=minimal' };
const get = async (p) => (await fetch(URL+p,{headers:h})).json();
const post = async (p, body) => APPLY ? fetch(URL+p,{method:'POST',headers:h,body:JSON.stringify(body)}) : { ok:true, dryRun:true };
const txt = (v) => (v && typeof v==='object') ? v : { ar: String(v||''), fr: String(v||'') };

const rows = await get('/rest/v1/restore_state?id=eq.main&select=data');
const data = rows?.[0]?.data || {};
const products = Array.isArray(data.products) ? data.products : [];
const collections = Array.isArray(data.collections) ? data.collections : [];
const cats = new Map();
for (const p of products) if (p.category) cats.set(p.category, { id: String(p.category), slug: String(p.category), title: txt(p.categoryTitle || p.category), active: true });

console.log(JSON.stringify({ apply: APPLY, counts: { products: products.length, collections: collections.length, categories: cats.size } }, null, 2));
for (const c of cats.values()) { console.log('[category]', c.id); await post('/rest/v1/restore_categories', c); }
for (const p of products) {
  const row = { id: String(p.id || p.handle), handle: String(p.handle), title: txt(p.title), brand: p.brand || null, category_id: p.category || null, price: Math.max(0, Math.round(Number(p.price||0))), compare_at: p.compareAt ? Math.round(Number(p.compareAt)) : null, stock: Math.max(0, Math.floor(Number(p.stock||0))), condition: p.condition || null, specs: p.specs || {}, images: p.images || (p.image ? [p.image] : []), active: p.active !== false };
  console.log('[product]', row.handle); await post('/rest/v1/restore_products', row);
  for (const v of (p.variants||[])) {
    const vr = { id: String(v.id || `${row.id}_${v.sku||Math.random()}`), product_id: row.id, sku: v.sku || null, color: v.color || v.label || null, storage: v.storage || null, price_delta: Math.round(Number(v.price||row.price) - row.price), stock: Math.max(0, Math.floor(Number(v.stock ?? row.stock ?? 0))) };
    console.log('  [variant]', vr.id); await post('/rest/v1/restore_product_variants', vr);
  }
}
for (const c of collections) {
  const row = { id: String(c.id || c.handle), handle: String(c.handle), title: txt(c.title), description: txt(c.description || ''), active: c.active !== false };
  console.log('[collection]', row.handle); await post('/rest/v1/restore_collections', row);
  for (const [i, handle] of (c.products||[]).entries()) {
    const p = products.find(x=>x.handle===handle); if (!p) continue;
    await post('/rest/v1/restore_collection_products', { collection_id: row.id, product_id: String(p.id||p.handle), sort_order: i });
  }
}
console.log(APPLY ? 'Applied.' : 'Dry run complete. Re-run with APPLY=1 to write.');
