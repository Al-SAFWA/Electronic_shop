# REA skill — install + live use report

## What was installed

| Field | Value |
| --- | --- |
| Skill ID | `reverse-engineer-anything` |
| Source (GitHub) | `morluto/rea` → `.agents/skills/reverse-engineer-anything/` (official project; awesome list warns trojanized forks exist) |
| Skill metadata version | `42` |
| License | MIT |
| Installed to | `~/.config/opencode/skills/reverse-engineer-anything/` |
| Files | `SKILL.md` + 6 files in `references/` |
| `SKILL.md` sha256 | `976e400f028618926c0b658ee50df79996f5f32402d33b49a23bfdbc232b45e6` |
| Discovery path | Global OpenCode skills dir — auto-advertised and loadable via the `skill` tool (verified this session) |

The skill ships instructions only. The REA engine is the official npm package
`rea-agents` (v6.5.0); this session used its documented CLI fallback, which needs
no MCP registration and no native disassembler.

## Live demonstration

**Target A — a "store" JavaScript bundle with the original per-module source removed.**

- Target hash (sha256): `9012f81bf9541a11ea846594bea4979d7d16a6fe1468e705d6115c868b6b60ca`
- Command: `rea analyze-javascript-application /tmp/opencode/re-demo/store-app --format json`
- Evidence ID: `ev_513c2c744c6ae7668262c30c3ddc44110fb83e22e55bba63d50a15c632e377ff`

Recovered (observed facts from the semantic relation graph):

- **Functions by name:** `subtotal`, `computeTotal`, `applyPromo`, `applyTax`, `__webpack_require__` (+6 anonymous factory/arrow functions)
- **Symbol tables:**
  - `TIER_DISCOUNT` → `none`, `silver`, `gold`, `platinum`
  - `PROMOS` → `SAVE10`, `FLAT5` (each with `type`/`value`)
  - `RATES` → `US-CA`, `US-OR`, `EU-DE`
- **Constants:** `0.05`, `0.10`, `0.15`, `10`, `"percent"`, `500`, `"flat"`, `0.0725`, `0`, `0.19`
- **Call graph:** `computeTotal → subtotal / applyPromo / applyTax`, etc.

**Recovered rule (inference from the above, cross-checked against the binary's output):**
`total = round(round(round(subtotal × (1 − tierRate)) × promoFactor) × (1 + taxRate))`

Verification: the shipped bundle prints `4170`; the rule REA reconstructed from the
static artifact also yields `4170` for the same inputs. ✅

REA's own stated limitations for this run (kept verbatim): the JS was parsed as
inert text and never executed; import/endpoint/storage relationships do not prove
runtime behavior; dynamic or obfuscated paths may stay unresolved. 87 nodes remain
explicitly **unknown**.

**Target B — a stripped native binary (Go), to show native metadata recovery.**

- Built with `-trimpath -ldflags "-s -w"`, no symbols.
- Command: `rea inspect-go-binary /tmp/opencode/re-demo/store-go/store`
- Evidence ID: `ev_abea7c0f07428508a124b280985133bd946a3f24d3881f8ec4a3828058e66431`
- Recovered: Go toolchain `go1.26.7-X:nodwarf5`, module/file identity, build settings
  (`-buildmode=exe`, `-trimpath=true`, `CGO_ENABLED=1`, `GOOS/GOARCH/GOAMD64`), with
  exact file byte offsets for the embedded build-info blob.
- Stated limitation: only Go build information is read — function names and
  decompiled code are **not** recovered by this operation.

## To enable the full MCP toolset (not applied)

The skill's 207 MCP tools (Ghidra/IDA/JADX-backed decompilation, firmware, APK, etc.)
need registration. A read-only plan was generated with
`rea setup --client opencode --dry-run --json`. It would, **with your approval**:

1. Add the REA MCP server to `~/.config/opencode/opencode.jsonc` (backup:
   `opencode.jsonc.rea.backup`) — command `npx -y rea-agents@6.5.0 mcp`.
2. Install/refresh the skill at `~/.agents/skills/reverse-engineer-anything`.

`doctor` currently reports `node 22.22.2` healthy and no analysis engines
(Ghidra / IDA / JADX / Hopper) installed; static JavaScript and the target-free
inspectors worked without them.

## Demo artifacts

- `/tmp/opencode/re-demo/store-app/` — JS target (bundle + package.json)
- `/tmp/opencode/re-demo/store-go/` — Go target (source + stripped binary)
- `/tmp/opencode/re-demo/ground-truth/pricing.js` — original source, used only to verify
- `/tmp/opencode/re-demo/analysis.json` — full REA Evidence record
