/* ==========================================================================
   RimTech Storefront Application — Mauritania Edition
   Bilingual (AR 🇲🇷 / FR 🇫🇷), Dark Mode, WhatsApp Direct Checkout,
   Real-Time Sync with Admin Dashboard & Supabase
   ========================================================================== */
(() => {
  "use strict";

  const S = window.STORE;
  if (!S) return;

  // Real-time custom settings override from Admin Dashboard / Supabase / localStorage
  function getCustomSettings() {
    try {
      const saved = localStorage.getItem("rimtech_settings");
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {};
  }
  const SETTINGS = Object.assign({
    brand: S.brand || "RimTech",
    currency: S.currency || "MRU",
    currency_ar: S.currency_ar || "أ.ج",
    phone: S.phone || "+22236001234",
    whatsapp: S.whatsapp || "+22236001234",
    shipping_rates: S.shipping_rates || [],
    payment_methods: S.payment_methods || [],
    sections: S.sections || {}
  }, getCustomSettings());

  // Products & Collections
  function getLiveProducts() {
    try {
      const saved = localStorage.getItem("rimtech_products");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return S.products;
  }

  let PRODUCTS = getLiveProducts();
  let BY_HANDLE = new Map(PRODUCTS.map((p) => [p.handle, p]));

  function refreshProductsMap() {
    PRODUCTS = getLiveProducts();
    BY_HANDLE = new Map(PRODUCTS.map((p) => [p.handle, p]));
  }

  const CART_KEY = "rimtech_cart_v1";
  const WISH_KEY = "rimtech_wish_v1";
  const LANG_KEY = "rimtech_lang";
  const THEME_KEY = "rimtech_theme";
  const ORDERS_KEY = "rimtech_orders";
  const ABANDONED_KEY = "rimtech_abandoned_carts";
  const MAX_QTY = 10;

  // --------------------------------------------------------------------------
  // Language & Internationalization (Bilingual Arabic 🇲🇷 / French 🇫🇷)
  // --------------------------------------------------------------------------
  let currentLang = localStorage.getItem(LANG_KEY) || "ar";

  const I18N = {
    ar: {
      site_title: "RimTech | الأجهزة المجددة المعتمدة في موريتانيا",
      announcement: "⚡ اشترِ الآن عبر بنكيلي واحصل على خصم فوري 10% على جميع الأجهزة!",
      search_placeholder: "ابحث عن هاتف، لابتوب، ماك بوك، مواصفات...",
      cart_title: "سلة المشتريات",
      cart_empty: "سلة مشترياتك فارغة حالياً",
      cart_subtotal: "المجموع الفرعي:",
      cart_shipping_calc: "الشحن يُحسب عند إتمام الطلب",
      cart_checkout_btn: "متابعة الطلب والشراء",
      cart_continue_btn: "تصفح الأجهزة المتاحة",
      wishlist_title: "قائمة الرغبات",
      wishlist_empty: "لم تقم بحفظ أي جهاز بعد",
      added_cart: "تمت إضافة الجهاز إلى السلة",
      removed_cart: "تم حذف الجهاز من السلة",
      saved_wish: "تم الحفظ في المفضلة",
      removed_wish: "تمت الإزالة من المفضلة",
      free_delivery: "توصيل مجاني في نواكشوط",
      return_window: "10 أيام حق الإرجاع",
      warranty_badge: "ضمان شامل 12 شهراً",
      renewed_info: "ما هو الجهاز المجدد المعتمد من RimTech؟",
      shop_certified: "تسوق الأجهزة المجددة المعتمدة",
      all_products: "كافة المنتجات المتاحة",
      sold_out: "نفد من المخزون",
      add_to_cart: "أضف إلى السلة",
      buy_now: "شراء فوري عبر واتساب",
      order_via_whatsapp: "إتمام الشراء عبر واتساب",
      battery_health: "نسبة البطارية",
      condition: "الحالة العامة",
      whats_included: "ماذا يوجد في العلبة؟",
      specs: "المواصفات الفنية",
      reviews: "آراء وتقييمات العملاء",
      faqs: "الأسئلة الشائعة",
      related_products: "أجهزة مشابهة قد تعجبك",
      flash_deals: "عروض الصفقات الخاطفة في موريتانيا",
      ends_in: "ينتهي العرض خلال:",
      hours: "ساعات",
      minutes: "دقائق",
      seconds: "ثوانٍ",
      contact_us: "اتصل بنا",
      delivery_cities: "التوصيل لكافة المدن الموريتانية",
      filter_all: "الكل",
      sort_by: "ترتيب حسب",
      price_low_high: "السعر: من الأقل إلى الأعلى",
      price_high_low: "السعر: من الأعلى إلى الأقل",
      sort_featured: "المميز والموصى به",
      search_results_for: "نتائج البحث عن",
      no_products_found: "لم يتم العثور على أجهزة مطابقة",
      checkout_title: "إتمام الطلب والدفع",
      checkout_customer_info: "بيانات الزبون والتوصيل",
      fullname: "الاسم الكامل",
      phone_whatsapp: "رقم الهاتف / الواتساب في موريتانيا",
      city: "المدينة / الولاية",
      address: "الحي وتفاصيل العنوان (مثل: تفرغ زينة، لكصر، عرفات...)",
      payment_method: "طريقة الدفع في موريتانيا",
      order_notes: "ملاحظات إضافية على الطلب (اختياري)",
      order_summary: "ملخص الطلب",
      subtotal: "المجموع الفرعي",
      shipping_fee: "رسوم الشحن والتوصيل",
      bankily_discount: "خصم بنكيلي (10%)",
      total_amount: "المبلغ الإجمالي النهائي",
      order_confirmed: "تم تسجيل طلبك بنجاح! جاري تحويلك إلى واتساب...",
      trust_expert: "مفحوص ومختبر من قبل خبراء تقنيين",
      trust_os: "نظام التشغيل أصلي ومنصب وجاهز",
      trust_customers: "150,000+ عميل راضٍ | تقييم ممتاز ★★★★★",
      qty: "الكمية"
    },
    fr: {
      site_title: "RimTech | Appareils Reconditionnés Certifiés en Mauritanie",
      announcement: "⚡ Payez avec Bankily et profitez de -10% de réduction immédiate !",
      search_placeholder: "Rechercher un smartphone, MacBook, PC portable...",
      cart_title: "Panier d'achats",
      cart_empty: "Votre panier est vide",
      cart_subtotal: "Sous-total :",
      cart_shipping_calc: "Frais de livraison calculés à la commande",
      cart_checkout_btn: "Commander via WhatsApp",
      cart_continue_btn: "Explorer les appareils",
      wishlist_title: "Mes Favoris",
      wishlist_empty: "Aucun appareil enregistré",
      added_cart: "Ajouté au panier",
      removed_cart: "Retiré du panier",
      saved_wish: "Ajouté aux favoris",
      removed_wish: "Retiré des favoris",
      free_delivery: "Livraison gratuite à Nouakchott",
      return_window: "10 jours pour changer d'avis",
      warranty_badge: "Garantie officielle 12 mois",
      renewed_info: "Qu'est-ce que le reconditionné certifié RimTech ?",
      shop_certified: "Appareils Reconditionnés Certifiés",
      all_products: "Tous les produits",
      sold_out: "Épuisé",
      add_to_cart: "Ajouter au panier",
      buy_now: "Acheter via WhatsApp",
      order_via_whatsapp: "Finaliser la commande via WhatsApp",
      battery_health: "État de la batterie",
      condition: "État esthétique",
      whats_included: "Qu'est-ce qui est inclus dans la boîte ?",
      specs: "Caractéristiques techniques",
      reviews: "Avis des clients vérifiés",
      faqs: "Foire Aux Questions (FAQ)",
      related_products: "Produits similaires",
      flash_deals: "Ventes Flash Exclusives en Mauritanie",
      ends_in: "Offre se termine dans :",
      hours: "heures",
      minutes: "min",
      seconds: "sec",
      contact_us: "Contactez-nous",
      delivery_cities: "Livraison partout en Mauritanie",
      filter_all: "Tous",
      sort_by: "Trier par",
      price_low_high: "Prix : Croissant",
      price_high_low: "Prix : Décroissant",
      sort_featured: "Recommandés",
      search_results_for: "Résultats de recherche pour",
      no_products_found: "Aucun appareil trouvé",
      checkout_title: "Validation de la commande",
      checkout_customer_info: "Coordonnées et Livraison",
      fullname: "Nom et Prénom",
      phone_whatsapp: "Numéro de téléphone / WhatsApp en Mauritanie",
      city: "Ville de livraison",
      address: "Quartier et adresse (ex: Tevragh-Zeina, Ksar, Arafat...)",
      payment_method: "Mode de paiement en Mauritanie",
      order_notes: "Notes ou instructions supplémentaires (optionnel)",
      order_summary: "Récapitulatif de commande",
      subtotal: "Sous-total",
      shipping_fee: "Frais de livraison",
      bankily_discount: "Remise Bankily (-10%)",
      total_amount: "Montant Total à Payer",
      order_confirmed: "Commande enregistrée ! Redirection vers WhatsApp...",
      trust_expert: "Vérifié sur 50 points par nos experts",
      trust_os: "Système préinstallé et configuré",
      trust_customers: "150 000+ clients satisfaits | Excellent ★★★★★",
      qty: "Quantité"
    }
  };

  const t = (key) => I18N[currentLang]?.[key] || I18N.ar[key] || key;

  function setLanguage(lang) {
    currentLang = lang === "fr" ? "fr" : "ar";
    localStorage.setItem(LANG_KEY, currentLang);
    document.documentElement.lang = currentLang;
    document.documentElement.dir = currentLang === "ar" ? "rtl" : "ltr";
    document.body.classList.toggle("rtl", currentLang === "ar");
    boot();
  }

  // --------------------------------------------------------------------------
  // Theme Management (Light / Dark)
  // --------------------------------------------------------------------------
  let currentTheme = localStorage.getItem(THEME_KEY) || "light";

  function applyTheme(theme) {
    currentTheme = theme === "dark" ? "dark" : "light";
    localStorage.setItem(THEME_KEY, currentTheme);
    document.documentElement.setAttribute("data-theme", currentTheme);
    document.body.classList.toggle("dark-theme", currentTheme === "dark");
  }
  applyTheme(currentTheme);

  function toggleTheme() {
    applyTheme(currentTheme === "dark" ? "light" : "dark");
    const btn = document.getElementById("theme-toggle");
    if (btn) btn.innerHTML = currentTheme === "dark" ? ICON.sun : ICON.moon;
  }

  // --------------------------------------------------------------------------
  // Formatting Utilities (Mauritanian Ouguiya - MRU)
  // --------------------------------------------------------------------------
  const esc = (s) =>
    String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const money = (n) => {
    n = Number(n) || 0;
    const formatted = Math.round(n).toLocaleString(currentLang === "ar" ? "ar-MR" : "fr-FR");
    const curr = currentLang === "ar" ? (SETTINGS.currency_ar || "أ.ج") : (SETTINGS.currency || "MRU");
    return `${formatted} ${curr}`;
  };

  const discountFor = (price, compare) =>
    compare && compare > price ? Math.round((1 - price / compare) * 100) : 0;

  const svg = (body, filled = false) =>
    `<svg viewBox="0 0 24 24" ${filled ? 'fill="currentColor" stroke="none"' : 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"'}>${body}</svg>`;

  const ICON = {
    search: svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>'),
    user: svg('<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20.5c.6-3.6 3.6-5.5 7.5-5.5s6.9 1.9 7.5 5.5"/>'),
    heart: svg('<path d="M12 20.3S4.8 15.9 4.8 10.9A4.1 4.1 0 0 1 12 8a4.1 4.1 0 0 1 7.2 2.9c0 5-7.2 9.4-7.2 9.4z"/>'),
    bag: svg('<path d="M6.2 8.2h11.6l1 11.6H5.2l1-11.6z"/><path d="M9 8.2V6.4a3 3 0 0 1 6 0v1.8"/>'),
    chevronDown: svg('<path d="M6 9l6 6 6-6"/>'),
    chevronRight: svg('<path d="M9 5.5l6.5 6.5L9 18.5"/>'),
    chevronLeft: svg('<path d="M15 5.5L8.5 12 15 18.5"/>'),
    close: svg('<path d="M6 6l12 12M18 6L6 18"/>'),
    menu: svg('<path d="M3.5 6.5h17M3.5 12h17M3.5 17.5h17"/>'),
    flame: svg('<path d="M12.4 2.2c.5 3.6-3.2 5.1-3.2 8.8a2.8 2.8 0 0 0 5.6 0c0-1.1-.4-2-1-2.7 2 1.2 3.2 3 3.2 5.2a5.9 5.9 0 1 1-11.8 0c0-4.4 3.6-6.6 6.2-11.3z"/>', true),
    trash: svg('<path d="M4 7h16M9 7V5h6v2M7 7l1 13h8l1-13M10 11v6M14 11v6"/>'),
    play: svg('<path d="M8 5.5v13l10-6.5z"/>', true),
    star: svg('<path d="M12 3.2l2.7 5.5 6 .9-4.35 4.25 1.03 6L12 16.9l-5.38 2.8 1.03-6L3.3 9.6l6-.9L12 3.2z"/>', true),
    truck: svg('<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17.5" cy="18" r="1.6"/>'),
    shield: svg('<path d="M12 3l7 2.6v5.6c0 4.4-3 7.6-7 9.8-4-2.2-7-5.4-7-9.8V5.6L12 3z"/><path d="M9 12l2 2 4-4"/>'),
    return: svg('<path d="M4 9h10a5 5 0 0 1 0 10H8"/><path d="M8 5L4 9l4 4"/>'),
    info: svg('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
    check: svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
    smile: svg('<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5c1 1.3 2.2 2 3.5 2s2.5-.7 3.5-2"/><path d="M9 9.5h.01M15 9.5h.01" stroke-width="2.2"/>'),
    badgeCheck: svg('<path d="M12 2.5l2.1 1.6 2.6-.4 1.1 2.4 2.4 1.1-.4 2.6L21.5 12l-1.6 2.1.4 2.6-2.4 1.1-1.1 2.4-2.6-.4L12 21.5l-2.1-1.6-2.6.4-1.1-2.4-2.4-1.1.4-2.6L2.5 12l1.6-2.1-.4-2.6 2.4-1.1 1.1-2.4 2.6.4L12 2.5z"/><path d="M8.3 12.2l2.4 2.4 5-5" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>', true),
    chat: svg('<path d="M4 4h16v11H9.5L4 19.5V4z"/><path d="M8 9.5h8M8 12.5h5" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>', true),
    sun: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>'),
    moon: svg('<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>'),
    whatsapp: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.301-.15-1.78-.878-2.056-.978-.276-.1-.477-.15-.678.15-.2.301-.778.978-.954 1.179-.175.2-.351.226-.652.075-.301-.15-1.27-.468-2.42-1.494-.895-.798-1.5-1.784-1.675-2.085-.175-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.151-.175.201-.301.301-.501.101-.2.05-.376-.025-.526-.075-.15-.678-1.634-.929-2.238-.244-.589-.493-.509-.678-.518-.176-.009-.377-.009-.578-.009-.201 0-.527.075-.803.376-.276.301-1.054 1.03-1.054 2.512s1.079 2.913 1.23 3.114c.15.201 2.122 3.24 5.141 4.544.718.31 1.279.496 1.716.634.721.229 1.377.197 1.896.119.579-.087 1.78-.728 2.031-1.431.251-.703.251-1.305.176-1.431-.076-.126-.277-.201-.578-.351zM12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22l4.98-1.305A9.957 9.957 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/></svg>`
  };

  function hydrateIcons(root = document) {
    root.querySelectorAll("[data-icon]").forEach((el) => {
      const name = el.dataset.icon;
      if (ICON[name]) el.innerHTML = ICON[name];
    });
  }

  let toastTimer;
  function toast(msg) {
    let t = document.getElementById("toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "toast";
      t.className = "toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 2400);
  }

  // --------------------------------------------------------------------------
  // Cart & Local Storage
  // --------------------------------------------------------------------------
  function readCart() {
    try {
      const v = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
      return Array.isArray(v) ? v : [];
    } catch {
      return [];
    }
  }

  function writeCart(items) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    syncBadges();
    renderCart();
  }

  function cartDetails() {
    return readCart()
      .map((it) => {
        const product = BY_HANDLE.get(it.handle);
        if (!product) return null;
        const variant = product.variants?.find((v) => String(v.id) === String(it.variantId)) || product.variants?.[0];
        return { ...it, product, variant, line: (Number(variant?.price ?? product.price) || 0) * it.qty };
      })
      .filter(Boolean);
  }

  const cartCount = () => readCart().reduce((n, it) => n + (Number(it.qty) || 0), 0);
  const cartSubtotal = () => cartDetails().reduce((n, it) => n + it.line, 0);

  function addToCart(handle, variantId, qty = 1) {
    const product = BY_HANDLE.get(handle);
    if (!product) return;
    const items = readCart();
    const found = items.find((it) => it.handle === handle && String(it.variantId) === String(variantId));
    if (found) found.qty = Math.min(MAX_QTY, found.qty + qty);
    else items.push({ handle, variantId, qty: Math.min(MAX_QTY, qty) });
    writeCart(items);
    toast(t("added_cart"));
  }

  function setQty(variantId, handle, qty) {
    const items = readCart();
    const it = items.find((x) => x.handle === handle && String(x.variantId) === String(variantId));
    if (!it) return;
    it.qty = Math.max(0, Math.min(MAX_QTY, qty));
    writeCart(items.filter((x) => x.qty > 0));
  }

  function removeLine(handle, variantId) {
    writeCart(readCart().filter((x) => !(x.handle === handle && String(x.variantId) === String(variantId))));
    toast(t("removed_cart"));
  }

  // --------------------------------------------------------------------------
  // Wishlist
  // --------------------------------------------------------------------------
  function readWish() {
    try {
      const v = JSON.parse(localStorage.getItem(WISH_KEY) || "[]");
      return new Set(Array.isArray(v) ? v : []);
    } catch {
      return new Set();
    }
  }

  function toggleWish(handle) {
    const set = readWish();
    if (set.has(handle)) {
      set.delete(handle);
      toast(t("removed_wish"));
    } else {
      set.add(handle);
      toast(t("saved_wish"));
    }
    localStorage.setItem(WISH_KEY, JSON.stringify([...set]));
    syncBadges();
    document.querySelectorAll("[data-wish]").forEach((b) => b.classList.toggle("active", set.has(b.dataset.wish)));
    if (document.body.dataset.page === "wishlist") renderWishlist();
  }

  function syncBadges() {
    const n = cartCount();
    document.querySelectorAll(".cart-count-n").forEach((el) => {
      el.textContent = n;
      el.hidden = n === 0;
    });
    const w = readWish().size;
    document.querySelectorAll(".wish-count").forEach((el) => {
      el.textContent = w;
      el.hidden = w === 0;
    });
  }

  // --------------------------------------------------------------------------
  // Top Navigation & Menu (FIXED: S24, iPhone 16, MacBooks, etc.)
  // --------------------------------------------------------------------------
  const NAV = [
    {
      label_ar: "عروض الصفقات",
      label_fr: "Ventes Flash",
      href: "collection.html?handle=revibe-anniversary",
      flame: true
    },
    {
      label_ar: "هواتف آيفون",
      label_fr: "iPhones",
      href: "collection.html?handle=refurbished-iphones",
      sub: [
        { label: "iPhone 16 Series", q: "iPhone 16" },
        { label: "iPhone 15 Series", q: "iPhone 15" },
        { label: "iPhone 14 Series", q: "iPhone 14" },
        { label: "iPhone 13 Series", q: "iPhone 13" },
        { label: "iPhone 12 Series", q: "iPhone 12" },
        { label: "iPhone 11 Series", q: "iPhone 11" }
      ]
    },
    {
      label_ar: "سامسونج جالكسي",
      label_fr: "Samsung Galaxy",
      href: "collection.html?handle=used-samsung",
      sub: [
        { label: "Galaxy S24 Series", q: "S24" },
        { label: "Galaxy S23 Series", q: "S23" },
        { label: "Galaxy S22 Series", q: "S22" },
        { label: "Galaxy S21 Series", q: "S21" },
        { label: "Galaxy S20 Series", q: "S20" },
        { label: "Galaxy Z Fold / Flip", q: "Fold|Flip" },
        { label: "Galaxy Note", q: "Note" }
      ]
    },
    {
      label_ar: "ماك بوك وأبل",
      label_fr: "MacBooks",
      href: "collection.html?handle=refurbished-macbooks",
      sub: [
        { label: "MacBook Pro", q: "Pro" },
        { label: "MacBook Air", q: "Air" },
        { label: "Tous les MacBooks", q: "" }
      ]
    },
    {
      label_ar: "أجهزة لابتوب",
      label_fr: "PC Portables",
      href: "collection.html?handle=laptops-used-refurbished",
      sub: [
        { label: "Dell", q: "Dell" },
        { label: "Lenovo ThinkPad", q: "Lenovo" },
        { label: "HP ProBook", q: "HP" },
        { label: "Acer", q: "Acer" }
      ]
    },
    {
      label_ar: "أجهزة آيباد",
      label_fr: "iPads & Tablettes",
      href: "collection.html?handle=ipads"
    },
    {
      label_ar: "ساعات أبل",
      label_fr: "Apple Watch",
      href: "collection.html?handle=apple-watches"
    },
    {
      label_ar: "سماعات وصوتيات",
      label_fr: "Audio & Écouteurs",
      href: "collection.html?handle=audio"
    },
    {
      label_ar: "لوحة التحكم",
      label_fr: "Dashboard Admin",
      href: "admin.html",
      highlight: true
    }
  ];

  // --------------------------------------------------------------------------
  // Header Rendering
  // --------------------------------------------------------------------------
  function renderHeader() {
    const el = document.getElementById("site-header");
    if (!el) return;
    el.className = "site-header animate-fade-in";

    const isAr = currentLang === "ar";
    const flagSrc = isAr ? "assets/img/flag-mr.svg" : "assets/img/flag-fr.svg";
    const flagAlt = isAr ? "موريتانيا" : "France";
    const nextLang = isAr ? "fr" : "ar";
    const nextLangLabel = isAr ? "Français 🇫🇷" : "العربية 🇲🇷";

    el.innerHTML = `
      <div class="announcement">
        <span>${t("announcement")}</span>
      </div>
      <div class="container header-top">
        <button class="menu-btn" type="button" data-open-menu aria-label="Open menu">${ICON.menu}</button>
        <a class="logo" href="index.html" aria-label="Home">
          <img src="assets/img/logo-black.svg" alt="${esc(SETTINGS.brand)}">
        </a>
        <form class="search" id="header-search" role="search" autocomplete="off">
          <input type="search" placeholder="${esc(t("search_placeholder"))}" aria-label="Search">
          <button class="search-btn" type="submit" aria-label="Search">${ICON.search}</button>
        </form>
        <div class="header-actions">
          <button class="lang-switcher-btn" type="button" id="lang-switcher" aria-label="Switch Language">
            <img class="lang-flag-img" src="${flagSrc}" alt="${flagAlt}">
            <span>${isAr ? "العربية" : "Français"}</span>
          </button>
          <button class="theme-toggle-btn" type="button" id="theme-toggle" aria-label="Toggle Theme">
            ${currentTheme === "dark" ? ICON.sun : ICON.moon}
          </button>
          <a class="icon-btn" href="admin.html" title="لوحة التحكم / Admin Dashboard" aria-label="Dashboard">${ICON.user}</a>
          <a class="icon-btn" href="wishlist.html" aria-label="Wishlist">
            ${ICON.heart}
            <span class="cart-count wish-count" hidden>0</span>
          </a>
          <button class="icon-btn" type="button" data-open-cart aria-label="Open cart">
            ${ICON.bag}
            <span class="cart-count cart-count-n" hidden>0</span>
          </button>
        </div>
      </div>
      <nav class="main-nav" aria-label="Main">
        <div class="container nav-inner">
          ${NAV.map((n) => {
            const label = isAr ? n.label_ar : n.label_fr;
            const subs = n.sub ? n.sub.map((s) => {
              const qParam = s.q ? `&q=${encodeURIComponent(s.q)}` : "";
              return `<a href="${n.href}${qParam}">${s.label}</a>`;
            }).join("") : "";

            return `
              <div class="nav-item">
                <a href="${n.href}" style="${n.highlight ? 'color:#10b981;font-weight:800;' : ''}">
                  ${label}
                  ${n.flame ? '<span class="flame" data-icon="flame" aria-hidden="true"></span>' : ""}
                </a>
                ${subs ? `<div class="nav-drop">${subs}</div>` : ""}
              </div>
            `;
          }).join("")}
        </div>
        <button class="nav-scroll" type="button" aria-label="Scroll categories"><span data-icon="chevronRight" aria-hidden="true"></span></button>
      </nav>
    `;

    // Event listeners
    const form = el.querySelector("#header-search");
    const input = form.querySelector("input");
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (input.value.trim()) {
        location.href = `collection.html?q=${encodeURIComponent(input.value.trim())}`;
      }
    });

    el.querySelector("#lang-switcher")?.addEventListener("click", () => {
      setLanguage(nextLang);
    });

    el.querySelector("#theme-toggle")?.addEventListener("click", () => {
      toggleTheme();
    });

    el.querySelectorAll("[data-open-cart]").forEach((b) => b.addEventListener("click", openCart));
    el.querySelector("[data-open-menu]")?.addEventListener("click", openMenu);
    el.querySelector(".nav-scroll")?.addEventListener("click", () => {
      el.querySelector(".nav-inner")?.scrollBy({ left: 260, behavior: "smooth" });
    });

    hydrateIcons(el);
  }

  // --------------------------------------------------------------------------
  // Trust Bar & Footer Rendering
  // --------------------------------------------------------------------------
  function renderFooter() {
    const el = document.getElementById("site-footer");
    if (!el) return;

    const isAr = currentLang === "ar";
    const trustBar = `
      <div class="trust-bar">
        <div class="container trust-inner">
          <ul class="trust-list">
            <li><img src="assets/img/trust-delivery.svg" alt=""> ${t("free_delivery")}</li>
            <li><img src="assets/img/trust-return.svg" alt=""> ${t("return_window")}</li>
            <li><img src="assets/img/trust-warranty.svg" alt=""> ${t("warranty_badge")}</li>
          </ul>
          <div class="bnpl" style="gap:10px;">
            <span style="font-weight:800;color:#10b981;">${isAr ? "وسائل الدفع المعتمدة في موريتانيا:" : "Moyens de paiement :"}</span>
            <img src="assets/img/pay-bankily.svg" alt="Bankily" style="height:26px;">
            <img src="assets/img/pay-masrvi.svg" alt="Masrvi" style="height:26px;">
            <img src="assets/img/pay-sedad.svg" alt="Sedad" style="height:26px;">
            <img src="assets/img/pay-click.svg" alt="Click" style="height:26px;">
          </div>
        </div>
      </div>
    `;

    el.innerHTML = trustBar + `
      <footer class="footer">
        <div class="container footer-main">
          <div>
            <a class="logo" href="index.html" aria-label="Home">
              <img src="assets/img/logo-white.svg" alt="${esc(SETTINGS.brand)}">
            </a>
            <div class="footer-contact">
              <h4>${t("contact_us")}</h4>
              <div class="row">
                <span><a href="tel:${SETTINGS.phone}">${SETTINGS.phone}</a></span>
                <span>(نواكشوط، موريتانيا / Nouakchott, Mauritanie)</span>
              </div>
              <div class="row">
                <span><a href="mailto:${SETTINGS.email}">${SETTINGS.email}</a></span>
                <span>خدمة الزبائن متوفرة 7/7 أيام</span>
              </div>
            </div>
            <div style="margin-top:16px;">
              <a href="https://wa.me/${SETTINGS.whatsapp.replace(/\+/g, '')}" class="btn-whatsapp" target="_blank" rel="noopener">
                ${ICON.whatsapp}
                <span>${isAr ? "تواصل معنا مباشرة عبر واتساب" : "Contactez-nous sur WhatsApp"}</span>
              </a>
            </div>
          </div>
          <div>
            <h4>${isAr ? "الأجهزة الأكثر طلباً" : "Nos Catégories"}</h4>
            <ul>
              <li><a href="collection.html?handle=refurbished-iphones">هواتف آيفون (iPhones)</a></li>
              <li><a href="collection.html?handle=used-samsung">سامسونج جالكسي (Samsung)</a></li>
              <li><a href="collection.html?handle=refurbished-macbooks">أجهزة ماك بوك (MacBooks)</a></li>
              <li><a href="collection.html?handle=laptops-used-refurbished">أجهزة لابتوب (Laptops)</a></li>
              <li><a href="collection.html?handle=ipads">أجهزة آيباد (iPads)</a></li>
            </ul>
          </div>
          <div>
            <h4>${isAr ? "معلومات هامة" : "Informations"}</h4>
            <ul>
              <li><a href="page.html?slug=renewed">${isAr ? "ما هو التجديد المعتمد؟" : "Guide du Reconditionné"}</a></li>
              <li><a href="page.html?slug=shipping">${isAr ? "الشحن والتوصيل في موريتانيا" : "Livraison en Mauritanie"}</a></li>
              <li><a href="page.html?slug=returns">${isAr ? "سياسة الضمان والاسترجاع" : "Garantie et Retours"}</a></li>
              <li><a href="page.html?slug=terms">${isAr ? "الشروط والأحكام" : "Conditions Générales"}</a></li>
              <li><a href="admin.html" style="color:#10b981;font-weight:700;">${isAr ? "دخول المالك والمدير (Dashboard)" : "Accès Admin"}</a></li>
            </ul>
          </div>
        </div>
        <div class="container footer-bottom">
          <p>© ${new Date().getFullYear()} ${esc(SETTINGS.brand)} Mauritanie. ${isAr ? "جميع الحقوق محفوظة." : "Tous droits réservés."}</p>
        </div>
      </footer>

      <!-- Floating WhatsApp Quick Button -->
      <a href="https://wa.me/${SETTINGS.whatsapp.replace(/\+/g, '')}" class="whatsapp-floating" target="_blank" rel="noopener" aria-label="WhatsApp Chat">
        ${ICON.whatsapp}
        <span>WhatsApp</span>
      </a>
    `;

    hydrateIcons(el);
  }

  // --------------------------------------------------------------------------
  // Product Card HTML
  // --------------------------------------------------------------------------
  function cardHTML(p) {
    const minPrice = p.price;
    const compare = p.compare;
    const disc = discountFor(minPrice, compare);
    const wishActive = readWish().has(p.handle);
    const battery = p.battery_health ? `<span class="battery-badge-card">🔋 ${p.battery_health}</span>` : "";

    return `
      <article class="card animate-fade-in" data-handle="${esc(p.handle)}">
        <div class="card-media">
          ${battery}
          <a href="product.html?handle=${esc(p.handle)}">
            <img src="${p.image}" alt="${esc(p.title)}" loading="lazy">
          </a>
          <button class="wish ${wishActive ? "active" : ""}" type="button" data-wish="${esc(p.handle)}" aria-label="Save to wishlist">
            ${ICON.heart}
          </button>
          ${disc > 0 ? `<span class="badge">-${disc}%</span>` : ""}
        </div>
        <div class="card-body">
          <div class="card-vendor">${esc(p.vendor || SETTINGS.brand)}</div>
          <h3 class="card-title"><a href="product.html?handle=${esc(p.handle)}">${esc(p.title)}</a></h3>
          <div class="card-rating">
            <span class="stars">${ICON.star.repeat(5)}</span>
            <span class="reviews-count">(5.0)</span>
          </div>
          <div class="card-price-row">
            <span class="card-price">${money(minPrice)}</span>
            ${compare && compare > minPrice ? `<span class="card-compare">${money(compare)}</span>` : ""}
          </div>
          <div style="margin-top:10px;">
            <a href="product.html?handle=${esc(p.handle)}" class="btn btn-primary" style="width:100%;text-align:center;padding:8px 12px;font-size:12px;display:block;">
              ${t("buy_now")}
            </a>
          </div>
        </div>
      </article>
    `;
  }

  // --------------------------------------------------------------------------
  // Homepage Rendering
  // --------------------------------------------------------------------------
  function renderHome() {
    // 1. Hero
    const hero = document.getElementById("hero");
    if (hero) {
      hero.innerHTML = `
        <div class="hero-slide active">
          <picture>
            <source media="(max-width: 640px)" srcset="assets/img/hero-1-mobile.png">
            <img src="assets/img/hero-1.png" alt="${t("site_title")}">
          </picture>
          <div class="hero-overlay">
            <div class="container hero-content">
              <span class="hero-tag" style="background:#006233;color:#fff;padding:6px 14px;border-radius:20px;font-weight:800;">
                🇲🇷 نواكشوط - موريتانيا
              </span>
              <h1 style="font-size:36px;font-weight:900;color:#fff;margin:12px 0;">
                ${currentLang === "ar" ? "أجهزة أصلية مجددة ومفحوصة بضمان 12 شهراً" : "Appareils Reconditionnés Certifiés avec Garantie 12 Mois"}
              </h1>
              <p style="color:#e2e8f0;font-size:16px;max-width:550px;margin-bottom:20px;">
                ${currentLang === "ar" ? "وفر حتى 60% على هواتف آيفون، سامسونج، وأجهزة ماك بوك ولابتوب الأصلية مع شحن سريع في نواكشوط والمدن الداخلية." : "Économisez jusqu'à 60% sur vos smartphones et ordinateurs certifiés avec livraison rapide."}
              </p>
              <div style="display:flex;gap:12px;flex-wrap:wrap;">
                <a class="btn btn-primary" href="collection.html?handle=all" style="padding:14px 28px;font-size:15px;font-weight:800;">
                  ${t("shop_certified")}
                </a>
                <a class="btn-whatsapp" href="https://wa.me/${SETTINGS.whatsapp.replace(/\+/g, '')}" target="_blank" rel="noopener">
                  ${ICON.whatsapp}
                  <span>${t("buy_now")}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      `;
    }

    // 2. Categories
    const catTrack = document.getElementById("cat-track");
    if (catTrack) {
      const cats = S.theme?.categories || [];
      catTrack.innerHTML = cats.map((c) => `
        <a class="cat-card" href="collection.html?handle=${c.handle}">
          <div class="cat-img"><img src="${c.image}" alt="${esc(c.label)}" loading="lazy"></div>
          <span class="cat-label">${esc(c.label)}</span>
        </a>
      `).join("");
    }

    // 3. Merchandised Homepage Sections
    const homeSections = document.getElementById("home-sections");
    if (homeSections) {
      // Flash deal countdown widget
      const flashSection = `
        <section class="flash-deals-strip">
          <div class="container flash-inner">
            <div class="flash-title">
              <span class="flame" data-icon="flame"></span>
              <span>${t("flash_deals")}</span>
              <span class="badge" style="background:#ea580c;color:#fff;font-size:12px;padding:4px 10px;">${S.flash_deal?.discount_badge || "خصم 40%"}</span>
            </div>
            <div class="flash-timer">
              <span>${t("ends_in")}</span>
              <div class="timer-unit"><span id="timer-h">08</span><small>${t("hours")}</small></div>
              <span>:</span>
              <div class="timer-unit"><span id="timer-m">42</span><small>${t("minutes")}</small></div>
              <span>:</span>
              <div class="timer-unit"><span id="timer-s">19</span><small>${t("seconds")}</small></div>
            </div>
          </div>
        </section>
      `;

      // 4 Merchandised Sections
      const sectionsConfig = [
        { handle: "revibe-anniversary", title: currentLang === "ar" ? "أقوى عروض التجديد" : "Offres Spéciales", promo: "assets/img/promo-iphone.webp", layout: "left", keys: S.home?.anniversary },
        { handle: "refurbished-iphones", title: currentLang === "ar" ? "هواتف آيفون المجددة المعتمدة" : "iPhones Reconditionnés Certifiés", promo: "assets/img/promo-iphone.webp", layout: "right", keys: S.home?.iphones },
        { handle: "used-samsung", title: currentLang === "ar" ? "سامسونج جالكسي المعتمد" : "Samsung Galaxy Certifié", promo: "assets/img/promo-samsung.webp", layout: "left", keys: S.home?.samsung },
        { handle: "laptops-used-refurbished", title: currentLang === "ar" ? "أجهزة لابتوب وماك بوك للأعمال" : "Laptops & MacBooks Reconditionnés", promo: "assets/img/promo-laptops.webp", layout: "right", keys: S.home?.laptops }
      ];

      const html = sectionsConfig.map((d) => {
        const pool = (d.keys || []).map((h) => BY_HANDLE.get(h)).filter(Boolean);
        const list = pool.length ? pool : PRODUCTS.filter((p) => p.collections.includes(d.handle)).slice(0, 8);
        const cards = list.map(cardHTML).join("");

        const head = `
          <div class="section-head">
            <h2>${esc(d.title)}</h2>
            <a class="view-all" href="collection.html?handle=${d.handle}">${currentLang === "ar" ? "عرض كل الأجهزة" : "Tout voir"} <span data-icon="chevronRight"></span></a>
          </div>
        `;
        const promo = `<a class="promo" href="collection.html?handle=${d.handle}"><img src="${d.promo}" alt="${esc(d.title)}" loading="lazy"></a>`;
        const panel = `
          <div class="carousel-wrap">
            <div class="carousel-panel"><div class="track">${cards}</div></div>
            <button class="carousel-arrow next" type="button" data-scroll="next" aria-label="Next">${ICON.chevronRight}</button>
          </div>
        `;

        return `
          <section class="product-section">
            <div class="container">
              ${head}
              <div class="blocks with-${d.layout}">${d.layout === "left" ? promo + panel : panel + promo}</div>
            </div>
          </section>
        `;
      }).join("");

      // Customer Reviews Section
      const reviewsData = S.reviews || [];
      const reviewsHTML = `
        <section class="reviews" aria-labelledby="reviews-heading">
          <div class="container">
            <div class="reviews-head">
              <h2 id="reviews-heading">${t("reviews")}</h2>
              <div class="reviews-meta">
                <span>150,000+ ${currentLang === "ar" ? "عميل راضٍ" : "Clients satisfaits"}</span>
                <span class="sep">|</span>
                <span>${currentLang === "ar" ? "تقييم ممتاز" : "Excellent"}</span>
                <span class="tp-stars" aria-label="5 stars">
                  ${ICON.star.repeat(5)}
                </span>
                <span class="tp-logo"><span class="mark" data-icon="star"></span>Trustpilot</span>
              </div>
            </div>
            <div class="reviews-track">
              ${reviewsData.map((r) => `
                <article class="review-card">
                  <span class="review-avatar" style="background:${r.color}">${r.avatar}</span>
                  <div class="review-name">${esc(r.name)}</div>
                  <div style="font-size:11px;color:#10b981;font-weight:700;margin-bottom:6px;">✓ ${esc(r.location)} · مشترٍ موثق</div>
                  <div class="review-stars">${ICON.star.repeat(r.rating || 5)}</div>
                  <div class="review-title">${esc(r.title)}</div>
                  <p class="review-body">${esc(r.body)}</p>
                </article>
              `).join("")}
            </div>
          </div>
        </section>
      `;

      // FAQs Section
      const faqsData = S.faqs || [];
      const faqsHTML = `
        <section class="container" style="margin:40px auto 60px;">
          <h2 style="font-size:26px;font-weight:900;text-align:center;margin-bottom:24px;">
            ${t("faqs")}
          </h2>
          <div class="accordion" style="max-width:850px;margin:0 auto;">
            ${faqsData.map((f, i) => `
              <details ${i === 0 ? "open" : ""}>
                <summary style="font-weight:800;font-size:15px;padding:16px;">
                  ${esc(currentLang === "ar" ? f.q_ar : f.q_fr)}
                </summary>
                <div class="acc-body" style="padding:16px;line-height:1.7;color:var(--ink);">
                  <p>${esc(currentLang === "ar" ? f.a_ar : f.a_fr)}</p>
                </div>
              </details>
            `).join("")}
          </div>
        </section>
      `;

      homeSections.innerHTML = flashSection + html + reviewsHTML + faqsHTML;
    }

    // Start Live Countdown Timer
    startCountdown();
    hydrateIcons();
  }

  function startCountdown() {
    let secondsLeft = 8 * 3600 + 42 * 60 + 19;
    const hEl = document.getElementById("timer-h");
    const mEl = document.getElementById("timer-m");
    const sEl = document.getElementById("timer-s");
    if (!hEl || !mEl || !sEl) return;

    setInterval(() => {
      if (secondsLeft > 0) secondsLeft--;
      const h = Math.floor(secondsLeft / 3600);
      const m = Math.floor((secondsLeft % 3600) / 60);
      const s = secondsLeft % 60;
      hEl.textContent = String(h).padStart(2, "0");
      mEl.textContent = String(m).padStart(2, "0");
      sEl.textContent = String(s).padStart(2, "0");
    }, 1000);
  }

  // --------------------------------------------------------------------------
  // Collection & Search Results (FIXED: Sub-links filter bug)
  // --------------------------------------------------------------------------
  const COL = { handle: "all", q: "", brand: "all", sale: false, sort: "featured", shown: 12, items: [] };

  function renderCollection() {
    const params = new URLSearchParams(location.search);
    COL.handle = params.get("handle") || "all";
    let rawQ = (params.get("q") || "").trim();

    // Clean noise words from query (e.g., 'Series', 'سلسلة')
    const cleanQ = rawQ.replace(/\b(series|سلسلة)\b/gi, "").trim();
    COL.q = cleanQ;

    const col = S.collections?.find((c) => c.handle === COL.handle);
    let list = COL.handle === "all" ? PRODUCTS.slice() : PRODUCTS.filter((p) => p.collections?.includes(COL.handle));

    // Smart Tokenized Matching
    if (COL.q) {
      const tokens = COL.q.toLowerCase().split(/\s+/).filter(Boolean);
      list = list.filter((p) => {
        const hay = `${p.title} ${p.vendor} ${p.type} ${p.handle} ${(p.options||[]).map(o=>o.values.join(' ')).join(' ')}`.toLowerCase();
        // Support pipe matching (e.g. Fold|Flip)
        if (COL.q.includes("|")) {
          const parts = COL.q.toLowerCase().split("|");
          return parts.some((part) => hay.includes(part.trim()));
        }
        return tokens.every((token) => hay.includes(token));
      });

      // Fallback: If 0 items matched within category, search across ALL products
      if (list.length === 0 && COL.handle !== "all") {
        const tokens = COL.q.toLowerCase().split(/\s+/).filter(Boolean);
        list = PRODUCTS.filter((p) => {
          const hay = `${p.title} ${p.vendor} ${p.type} ${p.handle}`.toLowerCase();
          return tokens.every((token) => hay.includes(token));
        });
      }
    }

    COL.items = list;

    const pageTitle = rawQ ? `${t("search_results_for")} “${rawQ}”` : col ? col.title : t("all_products");
    document.title = `${pageTitle} | ${SETTINGS.brand}`;

    const titleEl = document.getElementById("col-title");
    if (titleEl) titleEl.textContent = pageTitle;

    const countEl = document.getElementById("col-count");
    if (countEl) countEl.textContent = `${COL.items.length} ${currentLang === "ar" ? "جهاز متاح" : "appareils trouvés"}`;

    const crumb = document.getElementById("col-crumb");
    if (crumb) crumb.innerHTML = `<a href="index.html">${currentLang === "ar" ? "الرئيسية" : "Accueil"}</a><span>/</span><span>${esc(pageTitle)}</span>`;

    bindCollectionOnce();
    drawCollectionGrid();
    hydrateIcons();
  }

  function drawCollectionGrid() {
    let items = COL.items.slice();
    if (COL.brand !== "all") items = items.filter((p) => (p.vendor || "").toLowerCase() === COL.brand.toLowerCase());
    if (COL.sale) items = items.filter((p) => p.compare && p.compare > p.price);

    if (COL.sort === "price-asc") items.sort((a, b) => a.price - b.price);
    else if (COL.sort === "price-desc") items.sort((a, b) => b.price - a.price);

    const grid = document.getElementById("col-grid");
    if (!grid) return;

    if (!items.length) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column:1/-1;padding:50px 20px;text-align:center;">
          <h2 style="font-size:22px;margin-bottom:12px;">${t("no_products_found")}</h2>
          <p style="color:var(--soft-muted);margin-bottom:20px;">${currentLang === "ar" ? "يرجى تجربة البحث باسم هاتف آخر أو تصفح كافة الأجهزة المتاحة." : "Essayez avec d'autres termes de recherche."}</p>
          <a class="btn btn-primary" href="collection.html?handle=all">${t("all_products")}</a>
        </div>
      `;
    } else {
      grid.innerHTML = items.slice(0, COL.shown).map(cardHTML).join("");
    }

    const more = document.getElementById("load-more");
    if (more) more.style.display = items.length > COL.shown ? "" : "none";
  }

  let collectionBound = false;
  function bindCollectionOnce() {
    if (collectionBound) return;
    collectionBound = true;
    document.getElementById("col-sort")?.addEventListener("change", (e) => {
      COL.sort = e.target.value;
      COL.shown = 12;
      drawCollectionGrid();
    });
    document.getElementById("load-more")?.addEventListener("click", () => {
      COL.shown += 12;
      drawCollectionGrid();
    });
  }

  // --------------------------------------------------------------------------
  // Product Detail Page (FIXED: Color Variant Image Switching + Revibe Specs)
  // --------------------------------------------------------------------------
  const PDP = { p: null, sel: {}, qty: 1 };

  function pdpVariant() {
    const p = PDP.p;
    if (!p) return null;
    const keys = p.options.map((o) => o.name);
    let v = p.variants.find((x) => keys.every((k, i) => x["o" + (i + 1)] === PDP.sel[k]));
    if (!v) v = p.variants.find((x) => x.available) || p.variants[0];
    return v;
  }

  // Update image smoothly when color changes
  function updateGalleryForVariant(colorVal) {
    const p = PDP.p;
    if (!p) return;
    const v = pdpVariant();

    // Look for image source
    let targetSrc = v?.image?.src;
    if (!targetSrc && colorVal) {
      const match = p.variants.find((x) => Object.values(x).includes(colorVal) && x.image?.src);
      if (match) targetSrc = match.image.src;
    }
    if (!targetSrc) targetSrc = p.images?.[0] || p.image;

    const mainImg = document.getElementById("gallery-main-img");
    if (mainImg && targetSrc) {
      mainImg.style.opacity = "0.3";
      mainImg.style.transition = "opacity 0.25s ease";
      setTimeout(() => {
        mainImg.src = targetSrc;
        mainImg.style.opacity = "1";
      }, 150);
    }
  }

  function pdpInfoHTML() {
    const p = PDP.p;
    const v = pdpVariant();
    const price = Number(v?.price ?? p.price);
    const compare = v?.compare ?? p.compare;
    const disc = discountFor(price, compare);
    const isAr = currentLang === "ar";

    // Options UI
    const optionsHTML = p.options.map((o) => {
      if (!o.values.length) return "";
      const isColor = ["color", "colour", "اللون"].includes(o.name.toLowerCase());
      const buttons = o.values.map((val) => {
        const active = PDP.sel[o.name] === val;
        if (isColor) {
          const c = p.colors?.find((c) => c.name === val);
          return `
            <button class="opt-btn color-opt ${active ? "active" : ""}" type="button" data-opt="${esc(o.name)}" data-value="${esc(val)}">
              <span class="color-dot" style="background:${c ? c.hex : "#888"}"></span>
              ${esc(val)}
            </button>
          `;
        }
        return `
          <button class="opt-btn ${active ? "active" : ""}" type="button" data-opt="${esc(o.name)}" data-value="${esc(val)}">
            ${esc(val)}
          </button>
        `;
      }).join("");

      return `
        <div class="opt-group" style="margin-bottom:14px;">
          <div class="opt-label" style="font-weight:800;margin-bottom:6px;">
            ${esc(o.name)}: <span style="color:#10b981;font-weight:700;">${esc(PDP.sel[o.name] || "")}</span>
          </div>
          <div class="opt-values" style="display:flex;gap:8px;flex-wrap:wrap;">${buttons}</div>
        </div>
      `;
    }).join("");

    // Condition Description Box
    const condSelected = PDP.sel["Condition"] || PDP.sel["الحالة"] || "ممتاز (Excellent)";
    let condExplanation = isAr
      ? "كأنه جديد (Grade A+): تم فحصه واختباره بنسبة 100% عبر 50 نقطة فحص. خالي تماماً من الخدوش، مع بطارية وشاشة ممتازة وضمان 12 شهراً."
      : "Excellent État (Grade A) : 100% fonctionnel, vérifié sur 50 points par nos experts. Batterie en parfait état et garantie 12 mois.";

    if (condSelected.includes("جديد") || condSelected.includes("Like New")) {
      condExplanation = isAr
        ? "مثل الجديد (Grade A+): أنقى حالة ممكنة، لا توجد أي آثار استخدام إطلاقاً، كأنه خارج من علبته للتو."
        : "Comme Neuf (Grade A+) : État irréprochable, zéro rayure visible, batterie à 100%.";
    } else if (condSelected.includes("جيد جداً") || condSelected.includes("Very Good")) {
      condExplanation = isAr
        ? "جيد جداً (Grade B+) : يعمل بكفاءة 100% مع خدوش طفيفة سطحية على الهيكل غير ملحوظة، ويوفر سعراً تنافسياً جداً."
        : "Très Bon État (Grade B+) : Fonctionnement parfait, légères traces esthétiques d'usage, excellent rapport qualité/prix.";
    }

    // What's Included Box
    const includedList = p.whats_included || [
      { name: "شاحن سريع معتمد", name_fr: "Chargeur rapide certifié" },
      { name: "كابل التوصيل والشحن الأصلي", name_fr: "Câble officiel" },
      { name: "الجهاز بحالته المختارة مع فحص 50 نقطة", name_fr: "Appareil reconditionné certifié" },
      { name: "بطاقة الضمان المعتمد 12 شهراً", name_fr: "Garantie 12 mois" }
    ];

    return `
      <div class="product-info" id="product-info">
        <div class="battery-badge">
          🔋 ${t("battery_health")}: <strong>${p.battery_health || "100%"} (أصلية مفحوصة)</strong>
        </div>
        <div class="vendor">${esc(p.vendor || SETTINGS.brand)}</div>
        <h1 style="font-size:24px;font-weight:900;margin:6px 0 10px;">${esc(p.title)}</h1>
        <div class="rating" style="display:flex;align-items:center;gap:6px;margin-bottom:14px;">
          <span style="color:#f59e0b;">${ICON.star.repeat(5)}</span>
          <span style="font-weight:700;">4.9 · 142 ${isAr ? "تقييم معتمد" : "avis vérifiés"}</span>
        </div>

        <div class="price-row" style="margin-bottom:14px;">
          <span class="price-now" style="font-size:26px;font-weight:900;color:#10b981;">${money(price)}</span>
          ${compare && compare > price ? `
            <span class="price-was" style="text-decoration:line-through;color:var(--soft-muted);">${money(compare)}</span>
            <span class="price-badge" style="background:#ea580c;color:#fff;padding:3px 8px;border-radius:6px;font-weight:800;">-${disc}% ${isAr ? "مقارنة بالجديد" : "vs neuf"}</span>
          ` : ""}
        </div>

        <!-- Bankily Promo Banner -->
        <div class="bankily-banner">
          <div class="bankily-banner-content">
            <span class="tag">BANKILY</span>
            <span>${isAr ? "ادفع عبر بنكيلي واحصل على خصم فوري 10%!" : "Payez avec Bankily et profitez de 10% de remise !"}</span>
          </div>
          <span style="font-weight:800;color:#ea580c;">${money(price * 0.9)}</span>
        </div>

        ${optionsHTML}

        <!-- Condition Explanation Box -->
        <div class="condition-desc-box">
          <div style="font-weight:800;margin-bottom:4px;color:#10b981;">
            ✓ ${t("condition")}: ${esc(condSelected)}
          </div>
          <div>${esc(condExplanation)}</div>
        </div>

        <!-- Quantity -->
        <div class="opt-label" style="font-weight:800;margin-bottom:6px;">${t("qty")}</div>
        <div class="qty" style="margin-bottom:18px;">
          <button type="button" data-qty="-1" aria-label="Decrease quantity">−</button>
          <span id="qty-val">${PDP.qty}</span>
          <button type="button" data-qty="1" aria-label="Increase quantity">+</button>
        </div>

        <!-- Action Buttons -->
        <div class="product-actions" style="display:flex;gap:10px;margin-bottom:20px;">
          <button class="btn btn-primary" type="button" data-add-cart style="flex:1;padding:14px 20px;font-size:15px;font-weight:800;">
            ${t("add_to_cart")}
          </button>
          <button class="btn-whatsapp" type="button" data-buy-now style="flex:1.2;font-size:15px;font-weight:800;">
            ${ICON.whatsapp}
            <span>${t("order_via_whatsapp")}</span>
          </button>
        </div>

        <!-- Trust Badges Strip (Revibe Exact) -->
        <div class="trust-mini" style="margin-bottom:24px;">
          <div>${ICON.shield}<span><strong>12 ${isAr ? "شهراً ضمان شامل" : "mois de garantie"}</strong><small>${isAr ? "استبدال وإصلاح رسمي معتمد" : "Remplacement ou réparation"}</small></span></div>
          <div>${ICON.badgeCheck}<span><strong>${t("trust_expert")}</strong><small>${isAr ? "50 نقطة فحص تقنية معتمدة" : "Contrôle 50 points certifié"}</small></span></div>
          <div>${ICON.truck}<span><strong>${t("free_delivery")}</strong><small>${isAr ? "شحن سريع لكافة ولايات موريتانيا" : "Partout en Mauritanie"}</small></span></div>
          <div>${ICON.return}<span><strong>${t("return_window")}</strong><small>${isAr ? "حق المعاينة والاستبدال" : "Satisfait ou remboursé"}</small></span></div>
        </div>

        <!-- What's Included Box -->
        <div class="whats-included">
          <h3>
            <span data-icon="check" class="ico-check">✓</span>
            <span>${t("whats_included")}</span>
          </h3>
          <ul>
            ${includedList.map((it) => `
              <li>
                <span class="ico-check">✓</span>
                <span>${esc(isAr ? it.name : it.name_fr)}</span>
              </li>
            `).join("")}
          </ul>
        </div>

        <!-- Accordion details -->
        <div class="accordion">
          <details open>
            <summary style="font-weight:800;">${isAr ? "الوصف والمواصفات الفنية" : "Description & Caractéristiques"}</summary>
            <div class="acc-body">
              ${p.body || "<p>جهاز إلكتروني مجدد معتمد، مفحوص بنسبة 100% ويعمل بكفاءة فائقة ومرفق مع ملحقاته وضمان 12 شهراً.</p>"}
              <table class="specs-table">
                <tr><td>${isAr ? "نوع الجهاز" : "Type"}</td><td>${esc(p.type)}</td></tr>
                <tr><td>${isAr ? "العلامة التجارية" : "Marque"}</td><td>${esc(p.vendor)}</td></tr>
                <tr><td>${isAr ? "نسبة البطارية" : "Batterie"}</td><td>${esc(p.battery_health || "100%")}</td></tr>
                <tr><td>${isAr ? "الضمان المعتمد" : "Garantie"}</td><td>12 شهراً رسمي</td></tr>
              </table>
            </div>
          </details>
          <details>
            <summary style="font-weight:800;">${isAr ? "الشحن والتوصيل في موريتانيا" : "Livraison en Mauritanie"}</summary>
            <div class="acc-body">
              <p>توصيل مجاني وسريع في نواكشوط خلال ساعات قليلة. كما نشحن يومياً إلى نواذيبو، روصو، كيفة، أطار، زويرات، وبقية المدن الموريتانية مع إمكانية المعاينة قبل الدفع.</p>
            </div>
          </details>
          <details>
            <summary style="font-weight:800;">${isAr ? "الضمان وسياسة الإرجاع" : "Garantie et Retours"}</summary>
            <div class="acc-body">
              <p>نقدم ضماناً شاملاً لمدة 12 شهراً يغطي كافة العيوب الفنية والمصنعية، بالإضافة إلى حق الاستبدال أو الإرجاع خلال 10 أيام في حال وجود أي ملاحظة.</p>
            </div>
          </details>
        </div>
      </div>
    `;
  }

  function renderProduct() {
    const handle = new URLSearchParams(location.search).get("handle");
    const p = handle ? BY_HANDLE.get(handle) : null;
    if (!p) {
      document.title = `${t("no_products_found")} | ${SETTINGS.brand}`;
      const root = document.getElementById("product-root");
      if (root) {
        root.innerHTML = `
          <div class="empty-state" style="grid-column:1/-1;text-align:center;padding:50px 20px;">
            <h2>${t("no_products_found")}</h2>
            <p>${currentLang === "ar" ? "الجهاز المطلوب غير متوفر حالياً." : "Appareil non disponible."}</p>
            <a class="btn btn-primary" href="collection.html?handle=all">${t("all_products")}</a>
          </div>
        `;
      }
      return;
    }

    PDP.p = p;
    PDP.qty = 1;
    PDP.sel = {};
    p.options.forEach((o) => {
      if (o.values.length) PDP.sel[o.name] = o.values[0];
    });

    document.title = `${p.title} | ${SETTINGS.brand}`;
    const crumb = document.getElementById("prod-crumb");
    if (crumb) {
      crumb.innerHTML = `<a href="index.html">${currentLang === "ar" ? "الرئيسية" : "Accueil"}</a><span>/</span><a href="collection.html?handle=all">${t("all_products")}</a><span>/</span><span>${esc(p.title)}</span>`;
    }

    const images = p.images?.length ? p.images : [p.image];
    const root = document.getElementById("product-root");
    if (root) {
      root.innerHTML = `
        <div class="gallery">
          <div class="gallery-main">
            <img id="gallery-main-img" src="${images[0]}" alt="${esc(p.title)}">
          </div>
          <div class="thumbs">
            ${images.map((src, i) => `
              <button type="button" class="${i === 0 ? "active" : ""}" data-thumb="${src}" aria-label="Image ${i + 1}">
                <img src="${src}" alt="">
              </button>
            `).join("")}
          </div>
        </div>
        ${pdpInfoHTML()}
      `;
    }

    // Similar Products Carousel
    const related = document.getElementById("product-related");
    if (related) {
      const pool = PRODUCTS.filter((x) => x.handle !== p.handle && (x.type === p.type || x.vendor === p.vendor)).slice(0, 5);
      related.innerHTML = `
        <div class="container" style="margin:40px auto 60px;">
          <section class="related">
            <h2 style="font-size:24px;font-weight:900;margin-bottom:20px;">${t("related_products")}</h2>
            <div class="grid">${pool.map(cardHTML).join("")}</div>
          </section>
        </div>
      `;
    }

    hydrateIcons();
  }

  // --------------------------------------------------------------------------
  // Checkout & Direct WhatsApp Purchase (Mauritania Edition)
  // --------------------------------------------------------------------------
  function renderCheckout() {
    const root = document.getElementById("checkout-root");
    if (!root) return;
    const items = cartDetails();
    const isAr = currentLang === "ar";

    if (!items.length) {
      root.innerHTML = `
        <div class="container" style="padding:60px 20px;text-align:center;">
          <div class="empty-state">
            <h2 style="font-size:24px;margin-bottom:12px;">${t("cart_empty")}</h2>
            <p style="color:var(--soft-muted);margin-bottom:24px;">${isAr ? "اختر جهازك المفضل واستمتع بالضمان المعتمد والتوصيل السريع." : "Sélectionnez un appareil certifié."}</p>
            <a class="btn btn-primary" href="collection.html?handle=all">${t("all_products")}</a>
          </div>
        </div>
      `;
      return;
    }

    const subtotal = cartSubtotal();
    const cities = SETTINGS.shipping_rates?.length ? SETTINGS.shipping_rates : S.shipping_rates || [];
    const paymentMethods = SETTINGS.payment_methods?.length ? SETTINGS.payment_methods : S.payment_methods || [];

    root.innerHTML = `
      <div class="container animate-fade-in" style="padding:30px 20px 60px;">
        <div class="breadcrumb">
          <a href="index.html">${isAr ? "الرئيسية" : "Accueil"}</a><span>/</span><span>${t("checkout_title")}</span>
        </div>

        <div class="checkout-layout" style="display:grid;grid-template-columns:1fr 420px;gap:30px;">
          <!-- Order Form -->
          <form class="checkout-form" id="checkout-form" autocomplete="on">
            <h2 style="font-size:20px;font-weight:800;margin-bottom:18px;">${t("checkout_customer_info")}</h2>
            
            <div class="field" style="margin-bottom:14px;">
              <label for="co-name" style="font-weight:700;display:block;margin-bottom:6px;">${t("fullname")} *</label>
              <input id="co-name" name="name" required placeholder="${isAr ? 'مثال: محمد ولد أحمد' : 'ex: Mohamed Ould Ahmed'}" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:8px;">
            </div>

            <div class="field-row" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
              <div class="field">
                <label for="co-phone" style="font-weight:700;display:block;margin-bottom:6px;">${t("phone_whatsapp")} *</label>
                <input id="co-phone" name="phone" type="tel" required placeholder="36 12 34 56" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:8px;">
              </div>
              <div class="field">
                <label for="co-city" style="font-weight:700;display:block;margin-bottom:6px;">${t("city")} *</label>
                <select id="co-city" name="city" required style="width:100%;padding:12px;border:1px solid var(--line);border-radius:8px;">
                  ${cities.map((c, i) => `
                    <option value="${esc(c.city)}" data-fee="${c.fee}" ${i === 0 ? "selected" : ""}>
                      ${esc(isAr ? c.city : c.city_fr)} (${c.fee === 0 ? (isAr ? "توصيل مجاني" : "Gratuit") : money(c.fee)})
                    </option>
                  `).join("")}
                </select>
              </div>
            </div>

            <div class="field" style="margin-bottom:20px;">
              <label for="co-address" style="font-weight:700;display:block;margin-bottom:6px;">${t("address")} *</label>
              <input id="co-address" name="address" required placeholder="${isAr ? 'مثال: تفرغ زينة - قرب السفارة الفرنسية' : 'ex: Tevragh-Zeina'}" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:8px;">
            </div>

            <!-- Payment Methods Selection -->
            <h3 style="font-size:17px;font-weight:800;margin:24px 0 12px;">${t("payment_method")}</h3>
            <div class="pay-methods-grid">
              ${paymentMethods.map((pm, idx) => `
                <label class="pay-method-card ${idx === 0 ? "active" : ""}" data-pay-id="${pm.id}">
                  <input type="radio" name="pay_method" value="${pm.id}" ${idx === 0 ? "checked" : ""}>
                  <img src="${pm.icon}" alt="${esc(pm.name)}">
                  <div class="pay-method-info">
                    <span class="pay-method-title">${esc(pm.name)}</span>
                    <span class="pay-method-desc">${esc(pm.desc)}</span>
                  </div>
                </label>
              `).join("")}
            </div>

            <div class="field" style="margin-bottom:24px;">
              <label for="co-notes" style="font-weight:700;display:block;margin-bottom:6px;">${t("order_notes")}</label>
              <textarea id="co-notes" name="notes" rows="2" placeholder="${isAr ? 'أي تعليمات بخصوص موعد التوصيل...' : 'Instructions particulières...'}" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:8px;"></textarea>
            </div>

            <button class="btn-whatsapp" id="btn-submit-order" type="submit" style="width:100%;padding:16px;font-size:16px;">
              ${ICON.whatsapp}
              <span>${t("order_via_whatsapp")}</span>
            </button>
          </form>

          <!-- Order Summary Sidebar -->
          <div class="order-summary" style="padding:24px;border:1.5px solid var(--line);border-radius:12px;background:var(--soft);height:fit-content;">
            <h3 style="font-size:18px;font-weight:800;margin-bottom:16px;">${t("order_summary")}</h3>
            <div class="summary-lines" style="border-bottom:1px solid var(--line);padding-bottom:14px;margin-bottom:14px;">
              ${items.map((it) => `
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;font-size:13px;">
                  <div>
                    <div style="font-weight:700;">${it.qty}x ${esc(it.product.title)}</div>
                    <div style="font-size:11px;color:var(--soft-muted);">${esc(it.variant?.title || "")}</div>
                  </div>
                  <div style="font-weight:800;">${money(it.line)}</div>
                </div>
              `).join("")}
            </div>

            <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px;">
              <span>${t("subtotal")}</span>
              <span id="sum-subtotal" style="font-weight:700;">${money(subtotal)}</span>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px;">
              <span>${t("shipping_fee")}</span>
              <span id="sum-shipping" style="font-weight:700;color:#10b981;">0 أ.ج</span>
            </div>
            <div id="row-bankily-discount" style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:13px;color:#ea580c;font-weight:700;">
              <span>${t("bankily_discount")}</span>
              <span id="sum-discount">-${money(subtotal * 0.1)}</span>
            </div>

            <div style="display:flex;justify-content:space-between;border-top:1.5px solid var(--line);padding-top:14px;margin-top:10px;font-size:17px;font-weight:900;">
              <span>${t("total_amount")}</span>
              <span id="sum-total" style="color:#10b981;">${money(subtotal * 0.9)}</span>
            </div>
          </div>
        </div>
      </div>
    `;

    // Dynamic calculations in checkout
    const citySelect = document.getElementById("co-city");
    const payRadios = document.querySelectorAll('input[name="pay_method"]');
    const sumShipping = document.getElementById("sum-shipping");
    const sumDiscount = document.getElementById("sum-discount");
    const sumTotal = document.getElementById("sum-total");
    const rowDiscount = document.getElementById("row-bankily-discount");

    function recalculateTotal() {
      const selectedOption = citySelect.options[citySelect.selectedIndex];
      const shippingFee = Number(selectedOption.dataset.fee) || 0;
      const isBankily = document.querySelector('input[name="pay_method"]:checked')?.value === "bankily";
      const discount = isBankily ? Math.round(subtotal * 0.1) : 0;
      const finalTotal = subtotal - discount + shippingFee;

      sumShipping.textContent = shippingFee === 0 ? (isAr ? "مجاني" : "Gratuit") : money(shippingFee);
      if (rowDiscount) rowDiscount.style.display = isBankily ? "flex" : "none";
      if (sumDiscount) sumDiscount.textContent = `-${money(discount)}`;
      if (sumTotal) sumTotal.textContent = money(finalTotal);

      // Card highlight
      document.querySelectorAll(".pay-method-card").forEach((c) => {
        const rad = c.querySelector('input[type="radio"]');
        c.classList.toggle("active", rad.checked);
      });
    }

    citySelect?.addEventListener("change", recalculateTotal);
    payRadios.forEach((r) => r.addEventListener("change", recalculateTotal));
    recalculateTotal();

    // Abandoned Cart Tracker: Saves info when customer inputs phone
    const phoneInput = document.getElementById("co-phone");
    const nameInput = document.getElementById("co-name");
    let abandonedTimeout;

    function registerAbandoned() {
      const phone = phoneInput?.value.trim();
      const name = nameInput?.value.trim();
      if (!phone || phone.length < 6) return;

      try {
        const abandonedList = JSON.parse(localStorage.getItem(ABANDONED_KEY) || "[]");
        const exists = abandonedList.find((x) => x.phone === phone);
        if (!exists) {
          abandonedList.unshift({
            id: `AB-${Date.now()}`,
            name: name || "زبون",
            phone: phone,
            city: citySelect?.value || "نواكشوط",
            items: items.map((it) => ({ title: it.product.title, variant: it.variant?.title, qty: it.qty, price: it.line })),
            total: subtotal,
            date: new Date().toISOString()
          });
          localStorage.setItem(ABANDONED_KEY, JSON.stringify(abandonedList.slice(0, 50)));
        }
      } catch (e) {}
    }

    phoneInput?.addEventListener("blur", () => {
      clearTimeout(abandonedTimeout);
      abandonedTimeout = setTimeout(registerAbandoned, 5000);
    });

    // Form Submission: Save order & Redirect to WhatsApp
    const form = document.getElementById("checkout-form");
    form?.addEventListener("submit", (e) => {
      e.preventDefault();
      const orderId = `RIM-${Math.floor(10000 + Math.random() * 90000)}`;
      const name = nameInput.value.trim();
      const phone = phoneInput.value.trim();
      const city = citySelect.value;
      const address = document.getElementById("co-address").value.trim();
      const notes = document.getElementById("co-notes").value.trim();
      const payMethod = document.querySelector('input[name="pay_method"]:checked')?.value || "bankily";
      const selectedOption = citySelect.options[citySelect.selectedIndex];
      const shippingFee = Number(selectedOption.dataset.fee) || 0;
      const isBankily = payMethod === "bankily";
      const discount = isBankily ? Math.round(subtotal * 0.1) : 0;
      const finalTotal = subtotal - discount + shippingFee;

      // Save Order to Local Database (Ready for Supabase sync)
      const orderData = {
        id: orderId,
        customer_name: name,
        customer_phone: phone,
        city: city,
        address: address,
        notes: notes,
        payment_method: payMethod,
        items: items.map((it) => ({
          title: it.product.title,
          handle: it.product.handle,
          variant: it.variant?.title || "",
          qty: it.qty,
          battery_health: it.product.battery_health || "100%",
          line_price: it.line
        })),
        subtotal: subtotal,
        discount: discount,
        shipping_fee: shippingFee,
        total: finalTotal,
        status: "New",
        created_at: new Date().toISOString()
      };

      try {
        const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || "[]");
        orders.unshift(orderData);
        localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));

        // Broadcast to Admin Dashboard
        if (window.BroadcastChannel) {
          const bc = new BroadcastChannel("rimtech_channel");
          bc.postMessage({ type: "NEW_ORDER", order: orderData });
        }
      } catch (err) {}

      // Build Formatted WhatsApp Message
      const payName = paymentMethods.find((p) => p.id === payMethod)?.name || payMethod;
      const linesText = items.map((it) => `• ${it.qty}x ${it.product.title}\n  - المواصفات: ${it.variant?.title || 'قياسي'}\n  - البطارية: ${it.product.battery_health || '100%'}\n  - السعر: ${money(it.line)}`).join("\n\n");

      const waMessage = `🌟 *طلب شراء جديد من متجر ${SETTINGS.brand}* 🌟
----------------------------------
📦 *رقم الطلب:* #${orderId}
👤 *الاسم:* ${name}
📞 *رقم الهاتف:* ${phone}
📍 *المدينة:* ${city}
🏠 *العنوان:* ${address}
💳 *طريقة الدفع:* ${payName}
${notes ? `📝 *ملاحظات:* ${notes}\n` : ''}
----------------------------------
🛍️ *الأجهزة المطلوبة:*
${linesText}

----------------------------------
💵 *المجموع الفرعي:* ${money(subtotal)}
${discount > 0 ? `🎁 *خصم بنكيلي (10%):* -${money(discount)}\n` : ''}🚚 *رسوم الشحن:* ${shippingFee === 0 ? 'مجاني' : money(shippingFee)}
💰 *الإجمالي المطلوب:* ${money(finalTotal)}
----------------------------------
يرجى تأكيد الطلب وتزويدي ببيانات الدفع للتنفيذ. شكراً لكم!`;

      // Clear Cart
      localStorage.setItem(CART_KEY, "[]");
      syncBadges();

      // Show Confirmation Modal & Direct to WhatsApp
      toast(t("order_confirmed"));
      const waUrl = `https://wa.me/${SETTINGS.whatsapp.replace(/\+/g, '')}?text=${encodeURIComponent(waMessage)}`;

      setTimeout(() => {
        window.open(waUrl, "_blank");
      }, 700);

      root.innerHTML = `
        <div class="container" style="padding:60px 20px;text-align:center;">
          <div class="empty-state">
            <span style="font-size:54px;">🎉</span>
            <h2 style="font-size:24px;color:#10b981;margin:12px 0;">${isAr ? "تم إرسال طلبك بنجاح!" : "Commande enregistrée avec succès !"}</h2>
            <p style="font-size:16px;margin-bottom:8px;">${isAr ? `رقم الطلب الخاص بك: <strong>#${orderId}</strong>` : `Numéro de commande : <strong>#${orderId}</strong>`}</p>
            <p style="color:var(--soft-muted);max-width:500px;margin:0 auto 24px;">
              ${isAr ? "إذا لم يتم فتح تطبيق واتساب تلقائياً، اضغط على الزر أدناه لتأكيد طلبك مباشرة مع فريق المبيعات." : "Cliquez sur le bouton ci-dessous pour confirmer votre commande sur WhatsApp."}
            </p>
            <a class="btn-whatsapp" href="${waUrl}" target="_blank" rel="noopener" style="display:inline-flex;padding:14px 28px;font-size:16px;">
              ${ICON.whatsapp}
              <span>${isAr ? "فتح واتساب ومتابعة الطلب" : "Ouvrir WhatsApp"}</span>
            </a>
            <div style="margin-top:20px;">
              <a href="index.html" class="btn btn-dark">${isAr ? "العودة للرئيسية" : "Retour à l'accueil"}</a>
            </div>
          </div>
        </div>
      `;
    });
  }

  // --------------------------------------------------------------------------
  // Cart Drawer, Mobile Menu & Search Overlay
  // --------------------------------------------------------------------------
  function mountCart() {
    let d = document.getElementById("cart-drawer");
    if (!d) {
      d = document.createElement("div");
      d.id = "cart-drawer";
      d.className = "drawer";
      document.body.appendChild(d);
    }
  }

  function openCart() {
    document.getElementById("cart-drawer")?.classList.add("open");
    document.body.classList.add("no-scroll");
  }

  function closeCart() {
    document.getElementById("cart-drawer")?.classList.remove("open");
    document.body.classList.remove("no-scroll");
  }

  function renderCart() {
    const d = document.getElementById("cart-drawer");
    if (!d) return;
    const items = cartDetails();
    const sub = cartSubtotal();

    d.innerHTML = `
      <div class="drawer-head">
        <h2>${t("cart_title")} (${cartCount()})</h2>
        <button type="button" data-close-cart aria-label="Close">${ICON.close}</button>
      </div>
      <div class="drawer-body">
        ${!items.length ? `<div class="empty-state" style="padding:40px 20px;text-align:center;"><p>${t("cart_empty")}</p></div>` : `
          <ul class="cart-items">
            ${items.map((it) => `
              <li class="cart-item" style="display:flex;gap:12px;padding:14px 0;border-bottom:1px solid var(--line);">
                <img src="${it.product.image}" alt="${esc(it.product.title)}" style="width:65px;height:65px;object-fit:contain;background:var(--soft);border-radius:6px;">
                <div style="flex:1;">
                  <div style="font-weight:700;font-size:13px;">${esc(it.product.title)}</div>
                  <div style="font-size:11px;color:var(--soft-muted);">${esc(it.variant?.title || "")}</div>
                  <div style="font-weight:800;color:#10b981;margin-top:4px;">${money(it.line)}</div>
                  <div class="qty" style="margin-top:6px;">
                    <button type="button" data-qty-cart="-1" data-id="${it.variantId}" data-h="${it.handle}">−</button>
                    <span>${it.qty}</span>
                    <button type="button" data-qty-cart="1" data-id="${it.variantId}" data-h="${it.handle}">+</button>
                    <button type="button" data-remove-line data-id="${it.variantId}" data-h="${it.handle}" style="margin-right:8px;color:#ef4444;">${ICON.trash}</button>
                  </div>
                </div>
              </li>
            `).join("")}
          </ul>
        `}
      </div>
      <div class="drawer-foot">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:15px;font-weight:800;">
          <span>${t("cart_subtotal")}</span>
          <span style="color:#10b981;">${money(sub)}</span>
        </div>
        <p style="font-size:11px;color:var(--soft-muted);margin-bottom:12px;">${t("cart_shipping_calc")}</p>
        <a class="btn btn-primary" href="checkout.html" style="width:100%;text-align:center;padding:14px;font-weight:800;display:block;">
          ${t("cart_checkout_btn")}
        </a>
      </div>
    `;

    d.querySelector("[data-close-cart]")?.addEventListener("click", closeCart);
    d.querySelectorAll("[data-qty-cart]").forEach((b) => {
      b.addEventListener("click", () => {
        const delta = Number(b.dataset.qtyCart);
        const it = items.find((x) => x.handle === b.dataset.h && String(x.variantId) === String(b.dataset.id));
        if (it) setQty(b.dataset.id, b.dataset.h, it.qty + delta);
      });
    });
    d.querySelectorAll("[data-remove-line]").forEach((b) => {
      b.addEventListener("click", () => removeLine(b.dataset.h, b.dataset.id));
    });
    hydrateIcons(d);
  }

  function mountMenu() {
    let m = document.getElementById("mobile-menu");
    if (!m) {
      m = document.createElement("div");
      m.id = "mobile-menu";
      m.className = "drawer menu-drawer";
      document.body.appendChild(m);
    }
    const isAr = currentLang === "ar";
    m.innerHTML = `
      <div class="drawer-head">
        <a class="logo" href="index.html"><img src="assets/img/logo-black.svg" alt=""></a>
        <button type="button" data-close-menu aria-label="Close">${ICON.close}</button>
      </div>
      <div class="drawer-body">
        <ul style="padding:16px 0;">
          ${NAV.map((n) => `
            <li style="border-bottom:1px solid var(--line);padding:12px 0;">
              <a href="${n.href}" style="font-weight:700;font-size:15px;">${isAr ? n.label_ar : n.label_fr}</a>
            </li>
          `).join("")}
          <li style="padding:16px 0;">
            <a href="admin.html" class="btn btn-dark" style="width:100%;text-align:center;display:block;">
              لوحة التحكم / Admin Dashboard
            </a>
          </li>
        </ul>
      </div>
    `;
    m.querySelector("[data-close-menu]")?.addEventListener("click", closeMenu);
  }

  function openMenu() {
    document.getElementById("mobile-menu")?.classList.add("open");
    document.body.classList.add("no-scroll");
  }

  function closeMenu() {
    document.getElementById("mobile-menu")?.classList.remove("open");
    document.body.classList.remove("no-scroll");
  }

  // --------------------------------------------------------------------------
  // Wishlist Page
  // --------------------------------------------------------------------------
  function renderWishlist() {
    const root = document.getElementById("wishlist-root");
    if (!root) return;
    const wish = [...readWish()];
    const items = wish.map((h) => BY_HANDLE.get(h)).filter(Boolean);

    if (!items.length) {
      root.innerHTML = `
        <div class="container" style="padding:60px 20px;text-align:center;">
          <div class="empty-state">
            <h2 style="font-size:24px;margin-bottom:12px;">${t("wishlist_empty")}</h2>
            <a class="btn btn-primary" href="collection.html?handle=all">${t("all_products")}</a>
          </div>
        </div>
      `;
    } else {
      root.innerHTML = `
        <div class="container" style="padding:30px 20px 60px;">
          <h1 style="font-size:26px;font-weight:900;margin-bottom:24px;">${t("wishlist_title")} (${items.length})</h1>
          <div class="grid">${items.map(cardHTML).join("")}</div>
        </div>
      `;
    }
  }

  // --------------------------------------------------------------------------
  // Global Event Delegation (Option clicks, color updates, buy now)
  // --------------------------------------------------------------------------
  document.addEventListener("click", (e) => {
    // 1. Color / Option Click
    const opt = e.target.closest("[data-opt]");
    if (opt && PDP.p) {
      const optName = opt.dataset.opt;
      const optVal = opt.dataset.value;
      PDP.sel[optName] = optVal;

      // Update gallery if color option
      if (["color", "colour", "اللون"].includes(optName.toLowerCase())) {
        updateGalleryForVariant(optVal);
      }

      // Re-render product info
      const infoEl = document.getElementById("product-info");
      if (infoEl) infoEl.outerHTML = pdpInfoHTML();
      hydrateIcons();
      return;
    }

    // 2. Thumbnail Click
    const thumb = e.target.closest("[data-thumb]");
    if (thumb) {
      const src = thumb.dataset.thumb;
      const mainImg = document.getElementById("gallery-main-img");
      if (mainImg && src) {
        mainImg.src = src;
        document.querySelectorAll("[data-thumb]").forEach((t) => t.classList.toggle("active", t === thumb));
      }
      return;
    }

    // 3. Quantity adjustments on product page
    const qbtn = e.target.closest("[data-qty]");
    if (qbtn) {
      PDP.qty = Math.max(1, Math.min(MAX_QTY, PDP.qty + Number(qbtn.dataset.qty)));
      const span = document.getElementById("qty-val");
      if (span) span.textContent = PDP.qty;
      return;
    }

    // 4. Add to cart button
    if (e.target.closest("[data-add-cart]")) {
      if (!PDP.p) return;
      const v = pdpVariant();
      if (!v) return;
      addToCart(PDP.p.handle, v.id, PDP.qty);
      openCart();
      return;
    }

    // 5. Buy Now / WhatsApp Direct on product page
    if (e.target.closest("[data-buy-now]")) {
      if (!PDP.p) return;
      const v = pdpVariant();
      if (!v) return;
      addToCart(PDP.p.handle, v.id, PDP.qty);
      location.href = "checkout.html";
      return;
    }

    // 6. Wishlist toggle
    const wishBtn = e.target.closest("[data-wish]");
    if (wishBtn) {
      toggleWish(wishBtn.dataset.wish);
      return;
    }

    // 7. Carousel arrows
    const arrow = e.target.closest("[data-scroll]");
    if (arrow) {
      const track = arrow.closest(".carousel-wrap")?.querySelector(".track");
      if (track) {
        const isNext = arrow.dataset.scroll === "next";
        const isRtl = currentLang === "ar";
        const factor = isRtl ? -1 : 1;
        track.scrollBy({ left: factor * (isNext ? 300 : -300), behavior: "smooth" });
      }
      return;
    }
  });

  // --------------------------------------------------------------------------
  // Real-Time Sync with Admin Dashboard via BroadcastChannel
  // --------------------------------------------------------------------------
  if (window.BroadcastChannel) {
    const bc = new BroadcastChannel("rimtech_channel");
    bc.onmessage = (event) => {
      const data = event.data;
      if (!data) return;
      if (data.type === "SETTINGS_UPDATED" || data.type === "PRODUCTS_UPDATED") {
        refreshProductsMap();
        boot();
        toast("تم تحديث البيانات من لوحة التحكم مباشرة!");
      }
    };
  }

  window.addEventListener("storage", (e) => {
    if (e.key === "rimtech_settings" || e.key === "rimtech_products") {
      refreshProductsMap();
      boot();
    }
  });

  // --------------------------------------------------------------------------
  // Application Boot
  // --------------------------------------------------------------------------
  function boot() {
    // Set Direction and Language
    document.documentElement.lang = currentLang;
    document.documentElement.dir = currentLang === "ar" ? "rtl" : "ltr";
    document.body.classList.toggle("rtl", currentLang === "ar");

    renderHeader();
    renderFooter();
    mountCart();
    mountMenu();
    syncBadges();
    hydrateIcons();

    const page = document.body.dataset.page;
    if (page === "home") renderHome();
    else if (page === "collection") renderCollection();
    else if (page === "product") renderProduct();
    else if (page === "checkout") renderCheckout();
    else if (page === "wishlist") renderWishlist();

    renderCart();
    hydrateIcons();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

})();
