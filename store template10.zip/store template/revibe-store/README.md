# Revibe-style storefront replica

A static, no-build reconstruction of the **sa.revibe.me** storefront: the same page
structure, spacing, typography, product sections, cart interactions and responsive
layout, rebuilt as plain HTML, CSS and JavaScript.

> **Prototype status.** This is a design/engineering reconstruction, not the live
> Shopify store. It has no backend, payment processing, authentication, inventory or
> email. Read [`LEGAL.md`](LEGAL.md) before publishing it or using it commercially.

---

## Quick start

Requires only Python 3 (or any static file server).

```bash
cd revibe-store
python3 -m http.server 8099
```

Open <http://127.0.0.1:8099/>.

There is no build step, package manager, framework or server-side code. Opening
`index.html` directly also works in most browsers, but serving it over HTTP is
recommended so local storage and relative assets behave consistently.

---

## What is included

- **Home page** — hero slideshow (desktop and square mobile banners), trust bar,
  renewed-info strip, category carousel / mobile category grid, four merchandised
  product sections with promo panels, service block, community/video row, review
  carousel, press section, mobile-only sustainability carousel, and full footer.
- **Collection page** — collection and search results, vendor filters, sale filter,
  sorting, product count, and incremental “Load more”.
- **Product page** — image gallery, colour / storage / condition variant selection,
  live price and discount updates, quantity, add to cart, buy now, wishlist,
  description accordion, and related products.
- **Cart drawer** — quantity changes, remove, subtotal, persisted in `localStorage`.
- **Checkout** — demo order form with validation, order summary, and a confirmation
  screen. No payment is taken and no order is sent anywhere.
- **Wishlist** — add/remove from any product card or product page, persisted in
  `localStorage`.
- **Predictive search** — header search overlay, popular products, live results, and
  Enter to open the full collection search.
- **Account page** and **static information pages** — demo forms/content shells.
- **Responsive layout** — desktop, tablet and 390 px mobile layouts, slide-in mobile
  menu, self-hosted font, and local assets (no external font or image requests).

### Catalog snapshot

`assets/js/data.js` contains a normalized snapshot of the public catalog:

| Item | Count |
| --- | ---: |
| Products | 137 |
| Variants | 2,434 |
| Collections | 11 |
| Product images | 187 |
| Theme / marketing images | 49 |

The homepage uses the same product handles and section order as the captured
reference. Collection counts and product availability depend on the snapshot.

Collections included: Revibe Anniversary, Certified Renewed iPhones, Certified
Renewed Samsung, Certified Renewed Laptops, Refurbished MacBooks, Refurbished iPads,
Apple Watches, Audio, Chargers & Cables, Gaming, and Cases & Screen Protectors.

---

## Pages and URL parameters

| Page | URL | Notes |
| --- | --- | --- |
| Home | `index.html` | Hero, categories and all homepage sections |
| Collection | `collection.html?handle=all` | `handle` may be any collection handle |
| Collection search | `collection.html?q=iphone` | Text search over title, vendor and type |
| Product | `product.html?handle=iphone-13-pro-max` | Unknown handles show a not-found state |
| Checkout | `checkout.html` | Empty state when the cart is empty |
| Wishlist | `wishlist.html` | Reads the local wishlist |
| Account | `account.html` | Demo sign-in |
| Info page | `page.html?slug=renewed` | See slugs below |

Available info-page slugs: `about-us`, `help`, `contact`, `terms`, `legal`,
`privacy`, `track-order`, `raise-claim`, `track-claim`, `blog`, `become-a-seller`,
`for-businesses`, `renewed`, `shipping`, `returns`.

### Local storage

| Key | Contents |
| --- | --- |
| `revibe_cart_v1` | Array of `{ handle, variantId, qty }` |
| `revibe_wish_v1` | Array of product handles |

Clearing site data empties the cart and wishlist. No personal data is transmitted.

---

## How it works

- `assets/js/data.js` defines `window.STORE` with products, variants, collections,
  homepage mappings and theme assets.
- `assets/js/app.js` renders the header/footer, hydrates icons, dispatches on
  `document.body.dataset.page`, and mounts the cart drawer, search overlay and mobile
  menu. All interactions are delegated from `document`.
- `assets/css/styles.css` contains the design tokens (`:root`), layout system and
  responsive breakpoints. The main breakpoints are 1280 px, 1140 px, 1100 px,
  900 px and 640 px.
- Prices use the minimum available variant for product cards, matching the target
  cards. Product-page prices update when a variant is selected.
- Images are lazy-loaded where appropriate; the screenshot tooling waits for image
  decoding before capture.

### Project layout

```text
revibe-store/
├── index.html
├── collection.html
├── product.html
├── checkout.html
├── wishlist.html
├── page.html
├── account.html
├── README.md
├── LEGAL.md
└── assets/
    ├── css/styles.css
    ├── js/app.js
    ├── js/data.js
    ├── fonts/                 # self-hosted Montserrat variable font (OFL)
    ├── img/                   # logo, banners, categories, press, payments, etc.
    └── products/              # product photography snapshot
```

---

## Rebranding checklist

The layout is written to be reusable, but the Revibe brand strings and artwork are
still present for visual fidelity. Before a public launch:

1. Replace `assets/img/logo-black.svg` and the footer logo with your own mark, and
   update the `Revibe` strings in `assets/js/app.js`, the HTML `<title>` tags and
   `page.html` content.
2. Change the colour tokens in `:root` in `assets/css/styles.css` (especially
   `--orange`, `--purple` and `--lav`).
3. Replace product photography, banners and press/payment logos, or confirm written
   permission for each asset.
4. Replace the review cards and press quotes with licensed or first-party content.
5. Replace the demo terms, privacy, shipping and returns copy with your real
   policies.
6. Replace the demo checkout with a PCI-compliant payment provider and connect a
   real backend.
7. Remove or replace the Trustpilot name/stars unless you are an authorised
   Trustpilot customer.

---

## Verification performed

- Desktop layout checked at 1440 px against a full-page reference capture, including
  header search width/position, hero height, section gaps, cards, reviews, press and
  footer.
- Mobile layout checked at 390 px: square hero for both slides, 3-column category
  grid, mobile menu, announcement marquee, footer, and no horizontal overflow.
- Collection filters, sale filter, sorting, and Load more verified.
- Product variant selection updates price/discount; gallery, wishlist, add-to-cart,
  cart increment, subtotal and checkout totals verified.
- Demo checkout clears the cart and shows the success state.
- Search overlay, live results, Enter-to-search, unknown-product handling and all
  seven HTML entry pages verified with no console errors and no broken local images.
- Self-hosted Montserrat confirmed loaded; no Google Fonts request is required.

---

## Known differences and limitations

- **Representative catalog.** The live store has more listings than this 137-product
  snapshot. The homepage selection and handles match the reference; collection totals
  reflect the snapshot.
- **Reviews.** The reference embeds a third-party Trustpilot widget. This build uses
  a static, accessible review carousel in its place rather than loading the external
  iframe.
- **Press section.** Logos and short illustrative descriptions are displayed for
  layout fidelity; they are not live article embeds or verified quotations.
- **No backend.** Accounts, orders, stock, emails, payments and claims are demo
  interactions only. Cart and wishlist live in `localStorage`.
- **Shopify routes.** The live store uses `/collections/...` and `/products/...`.
  This static build uses `collection.html?handle=...` and
  `product.html?handle=...`; rewrite rules can map those paths on a host if needed.
- **Content drift.** Prices, products and marketing copy on the live store can
  change; this snapshot will not update automatically.
- **Third-party trademarks.** See `LEGAL.md` before any public deployment.

---

## Legal

This project is a non-production reconstruction. Brand names, logos, product photos,
marketing copy, press marks, payment marks and review content remain the property of
their respective owners. The project owner has stated that permission for this
reconstruction was obtained; that permission should be recorded in writing and should
cover every asset you publish.

See [`LEGAL.md`](LEGAL.md) for the full asset/licensing notes and a launch checklist.
