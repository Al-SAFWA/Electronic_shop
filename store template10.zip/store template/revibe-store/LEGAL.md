# Legal and asset notes

## 1. Status

This repository is a **non-production design and engineering reconstruction** of the
public storefront at `sa.revibe.me`. It is not the live Shopify store, is not operated
by Revibe, and is not affiliated with or endorsed by Revibe, Shopify, Trustpilot, or
any brand whose mark appears in the demo.

The project owner has stated that permission to reproduce the referenced storefront
was obtained for this project. That statement is recorded here as project context. It
is **not** a substitute for written permission from each rights holder, and it does
not automatically grant rights to every image, logo, quotation, or trademark that was
captured from the reference site.

No licence is granted by this repository for any third-party brand, image, text, or
trademark. The code is provided for the project owner's prototype use.

## 2. Third-party material in the demo

| Material | Owner / source | Status in this build |
| --- | --- | --- |
| “Revibe” name, wordmark and logo | Revibe | Used for visual fidelity in the authorised prototype; replace or license for public use |
| Product photography and product copy | Revibe / respective manufacturers and merchants | Captured from the public Shopify catalog/CDN as prototype placeholders |
| Marketing banners, category and service artwork | Revibe | Captured from the public storefront as prototype placeholders |
| Press logos and excerpts | Gulf Business, The National, Al Arabiya / their owners | Illustrative layout placeholders; not verified quotations or live embeds |
| Visa, Mastercard, mada, Apple Pay, tabby, tamara, Baseeta marks | Their respective owners | Displayed for payment-method fidelity; no payment integration exists |
| Trustpilot name and star marks | Trustpilot | Static layout placeholder; not a live Trustpilot widget and not an endorsement |
| Customer review cards | Illustrative content prepared for this demo | Not a verified feed of real Trustpilot reviews; replace before launch |
| Video thumbnails and social links | YouTube / the respective creators | External links and placeholder thumbnails; replace or license before launch |
| Saudi flag icon | Public national flag symbolism | Used as a country selector icon |
| Montserrat font | Google Fonts / SIL Open Font License 1.1 | Self-hosted under the OFL; see `assets/fonts/` |

The product data was obtained from public Shopify product JSON endpoints. It contains
no customer records, credentials, or private data. Product names and descriptions
remain the property of their respective owners.

## 3. What the demo does not do

- It does **not** process payments or collect card data.
- It does **not** create orders, accounts, shipments, claims, or emails.
- It does **not** send cart, wishlist, or form data to a server.
- Cart and wishlist are stored only in the browser's `localStorage`.
- It does **not** include analytics, advertising pixels, or third-party tracking.
- It does **not** load a live Trustpilot iframe or live review feed.

External links to YouTube, Instagram, TikTok, and Facebook are ordinary links; those
sites have their own terms and privacy policies.

## 4. Required before a public or commercial launch

1. **Obtain written permission or replace every third-party asset** listed above,
   including the Revibe name/logo, product photos, marketing copy, press marks,
   payment marks, review content, video thumbnails, and Trustpilot references.
2. **Replace the demo policies** (`page.html` content for terms, privacy, shipping,
   returns, warranty, and legal) with policies reviewed for your jurisdiction.
3. **Do not use the demo as a checkout.** Integrate a PCI-compliant payment provider,
   a real order backend, tax/shipping logic, fraud checks, and customer notifications.
4. **Remove the Trustpilot branding** unless you are an authorised Trustpilot customer
   and the displayed rating/review data is genuine and current.
5. **Verify every product claim, price, discount, warranty, and delivery estimate.**
   Consumer-protection and advertising rules apply to savings claims and reviews.
6. **Add privacy/cookie notices** appropriate to any analytics, chat, payment, or
   marketing tools you add.
7. **Record the permission you rely on in writing**, including the scope (territory,
   duration, channels, sublicensing, and whether modification is allowed).
8. **Use licensed fonts and images** for any replacement assets. Montserrat is
   self-hosted under the SIL Open Font License 1.1; keep its licence notice with the
   font files.

## 5. Disclaimer

This demo is provided “as is”, without warranties of any kind, express or implied,
including fitness for a particular purpose, non-infringement, or accuracy of product
information. The project owner is responsible for clearing rights, complying with
applicable law, and obtaining any required permits or consumer disclosures before
using the storefront publicly.

If you are a rights holder and believe material in this repository is used without
authorisation, contact the project owner so the material can be removed or licensed.
